import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objs as go
import pandas as pd
import urllib
import StringIO
import flask
from datetime import datetime
from pandas.tseries.offsets import MonthBegin

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

unclaimed_procedures = pd.read_csv(
    'missing_procedures_000',
    delimiter='|',
    names=[
        'first_name', 'middle_name', 'last_name', 'dob', 'sex', 'cc_cpt_code',
        'cc_date_of_service', 'prov_last_name', 'prov_first_name',
        'prov_middle_name', 'responsible_prov_last_name',
        'responsible_prov_first_name', 'responsible_prov_middle_name', 'site',
        'id_1', 'id_2', 'id_3', 'claimed'
    ],
    index_col=False).fillna('')

unclaimed_procedures['provider'] = unclaimed_procedures[[
    'responsible_prov_first_name', 'responsible_prov_middle_name',
    'responsible_prov_last_name'
]].apply(
    lambda x: ' '.join(x), axis=1).str.upper()

unclaimed_procedures['dos_month'] = (pd.to_datetime(
    unclaimed_procedures['cc_date_of_service']) - MonthBegin(1)).dt.date

unclaimed_procedures_aggregated = unclaimed_procedures[[
    'site', 'provider', 'dos_month', 'claimed'
]].groupby(['site', 'provider', 'dos_month'])['claimed'].agg(
    ['sum', 'count']).reset_index().rename(columns={
        'sum': 'claimed',
        'count': 'total'
    })
unclaimed_procedures_aggregated_provider_all = unclaimed_procedures[[
    'site', 'dos_month', 'claimed'
]].groupby(['site', 'dos_month'])['claimed'].agg(
    ['sum', 'count']).reset_index().rename(columns={
        'sum': 'claimed',
        'count': 'total'
    })
unclaimed_procedures_aggregated_provider_all['provider'] = 'ALL PROVIDERS'
unclaimed_procedures_aggregated = pd.concat([
    unclaimed_procedures_aggregated,
    unclaimed_procedures_aggregated_provider_all
])

SITE_DICT = [{
    'label': site,
    'value': site
} for site in unclaimed_procedures_aggregated.site.unique()]

app.layout = html.Div([
    html.H4(children='Claimed Procedures'),
    html.Div(
        [
            dcc.Dropdown(
                id='unclaimed_procedures_site',
                options=SITE_DICT,
                style={'width': '400px'}),
            dcc.Dropdown(
                id='unclaimed_procedures_provider', style={'width': '400px'}),
            dcc.Graph(id='unclaimed_procedures', figure={}),
            html.A(
                'Download Unclaimed Procedures',
                id='download_link',
                download='rawdata.csv',
                href='',
                target='_blank')
        ],
        style={
            'width': '800px',
            'height': '500px',
            'margin': '0 auto',
            'padding-top': '80px',
        })
])


@app.callback(
    dash.dependencies.Output('unclaimed_procedures_provider', 'options'),
    [dash.dependencies.Input('unclaimed_procedures_site', 'value')])
def update_provider(site):
    provider_dict = [{
        'label': provider,
        'value': provider
    } for provider in unclaimed_procedures_aggregated[(
        unclaimed_procedures_aggregated['site'] == site)].provider.unique()
                     if provider.split()]
    return provider_dict


@app.callback(
    dash.dependencies.Output('unclaimed_procedures', 'figure'), [
        dash.dependencies.Input('unclaimed_procedures_site', 'value'),
        dash.dependencies.Input('unclaimed_procedures_provider', 'value'),
    ])
def update_output(site, provider):
    filtered_df = unclaimed_procedures_aggregated.loc[
        (unclaimed_procedures_aggregated['site'] == site)
        & (unclaimed_procedures_aggregated['provider'] == provider)]

    return {
        'data': [
            go.Scatter(
                x=filtered_df.dos_month,
                y=filtered_df.claimed,
                name='Claimed',
                opacity=1,
                mode='markers',
                marker=dict(size=16)),
            go.Scatter(
                x=filtered_df.dos_month,
                y=filtered_df.total,
                name='Total',
                opacity=1,
                mode='markers',
                marker=dict(size=16)),
        ],
        'layout':
        go.Layout(
            xaxis={'type': 'date'},
            yaxis={'title': 'Claimed Procedures'},
            hovermode='closest')
    }


@app.callback(
    dash.dependencies.Output('download_link', 'href'), [
        dash.dependencies.Input('unclaimed_procedures_site', 'value'),
        dash.dependencies.Input('unclaimed_procedures_provider', 'value'),
    ])
def update_download_link(site, provider):
    return '/dash/urlToDownload?value={}'.format(site + '|' + provider)


@app.server.route('/dash/urlToDownload')
def download_csv():
    value = flask.request.args.get('value')
    site = value.split('|')[0]
    provider = value.split('|')[1]
    print site, provider
    filtered_df = unclaimed_procedures.loc[
        (unclaimed_procedures['site'] == site)
        & (unclaimed_procedures['claimed'] == 0)]

    if provider != 'ALL PROVIDERS':
        filtered_df = filtered_df.loc[(
            unclaimed_procedures['provider'] == provider)]
    str_io = StringIO.StringIO()
    filtered_df.to_csv(str_io, index=False)
    str_io.seek(0)
    return flask.send_file(
        str_io,
        mimetype='text/csv',
        attachment_filename='unclaimed_procedures_{}_{}_{}.csv'.format(
            site, provider,
            datetime.today().strftime('%Y%m%d')),
        as_attachment=True)


if __name__ == '__main__':
    app.run_server(port=7779, host='10.0.10.24')
