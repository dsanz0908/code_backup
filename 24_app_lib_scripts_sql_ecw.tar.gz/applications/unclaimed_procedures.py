import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objs as go
import pandas as pd

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

unclaimed_procedures = pd.read_csv(
    'missing_procedures_000',
    delimiter='|',
    names=[
        'first_name', 'middle_name', 'last_name', 'dob', 'sex', 'cc_cpt_code',
        'cc_date_of_service', 'prov_last_name', 'prov_first_name',
        'prov_middle_name', 'responsible_prov_last_name',
        'responsible_prov_first_name', 'responsible_prov_middle_name',
        'site', 'id_1', 'id_2', 'id_3', 'claimed2'
    ],
    index_col=False).fillna('')

unclaimed_procedures['provider'] = unclaimed_procedures[[
    'prov_first_name', 'prov_middle_name', 'prov_last_name'
]].apply(
    lambda x: ' '.join(x), axis=1).str.upper()

unclaimed_procedures['dos'] = pd.to_datetime(unclaimed_procedures[
    'cc_date_of_service']).dt.date
unclaimed_procedures_aggregated = unclaimed_procedures.groupby(['site','provider','dos']).agg({'cc_date_of_service':'count', 'claimed2': 'sum'}).reset_index()

print unclaimed_procedures_aggregated

SITE_DICT = [{
    'label': site,
    'value': site
} for site in unclaimed_procedures_aggregated.site.unique()]

app.layout = html.Div([
    html.Div(
        [
            dcc.Dropdown(
                id='unclaimed_procedures_site',
                options=SITE_DICT,
                style={'width': '300px'}),
            dcc.Dropdown(
                id='unclaimed_procedures_provider', style={'width': '300px'}),
            dcc.Graph(id='unclaimed_procedures', figure={})
        ],
        style={
            'width': '800px',
            'height': '500px',
            'margin': '0 auto',
            'padding-top': '80px',
        })
])


@app.callback(
    dash.dependencies.Output('unclaimed_procedures_provider', 'options'),
    [dash.dependencies.Input('unclaimed_procedures_site', 'value')])
def update_provider(site):
    provider_dict = [{
        'label': provider,
        'value': provider
    } for provider in unclaimed_procedures_aggregated[(
        unclaimed_procedures_aggregated['site'] == site)].provider.unique()]
    return provider_dict


@app.callback(
    dash.dependencies.Output('unclaimed_procedures', 'figure'), [
        dash.dependencies.Input('unclaimed_procedures_site', 'value'),
        dash.dependencies.Input('unclaimed_procedures_provider', 'value'),
    ])
def update_output(site, provider):
    filtered_df = unclaimed_procedures_aggregated.loc[
        (unclaimed_procedures_aggregated['site'] == site)
        & (unclaimed_procedures_aggregated['provider'] == provider)]
    return {
        'data': [
            go.Scatter(
                x=filtered_df.dos,
                y=filtered_df.claimed,
                name='Claimed',
                opacity=1,
                mode='markers',
                marker=dict(size=16)),
            go.Scatter(
                x=filtered_df.dos,
                y=filtered_df.total,
                name='Total',
                opacity=1,
                mode='markers',
                marker=dict(size=16)),
        ],
        'layout':
        go.Layout(
            xaxis={'type': 'date'},
            yaxis={'title': 'Claimed Procedures'},
            hovermode='closest')
    }


if __name__ == '__main__':
    app.run_server(port=7779, host='10.0.10.24')
