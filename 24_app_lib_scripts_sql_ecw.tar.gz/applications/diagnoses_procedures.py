import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objs as go
import pandas as pd
import urllib
import StringIO
import flask
import pyodbc
from datetime import datetime
from pandas.tseries.offsets import MonthBegin
from dash.dependencies import Input, Output

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

FULFILLED_2018_DIAGNOSES_QUERY = """
WITH cte_diagnoses_2018 
     AS (SELECT DISTINCT site_id, 
                         patient_id, 
                         icd10_code 
         FROM   t_assessment 
         WHERE  delete_ind = 'N' 
                AND Year(assessment_date) = 2018), 
     cte_diagnoses_2019 
     AS (SELECT DISTINCT site_id, 
                         patient_id, 
                         icd10_code 
         FROM   t_assessment 
         WHERE  delete_ind = 'N' 
                AND Year(assessment_date) = 2019) 
select * from (select *, row_number() over (partition by provider, site order by total desc) as rn from (SELECT Upper(prov_fullname)               AS provider, 
       Upper(site_center_name)            AS site, 
       Upper(icd10_code)                  AS icd10_code, 
       Sum(happened)                      AS happened, 
       Count(*)                           AS total, 
       ( Sum(happened) * 100 ) / Count(*) AS percentage 
FROM   (SELECT DISTINCT cte_diagnoses_2018.*, 
                        pat_responsible_provider_id, 
                        CASE 
                          WHEN cte_diagnoses_2019.patient_id IS NOT NULL THEN 1 
                          ELSE 0 
                        END AS happened 
        FROM   cte_diagnoses_2018 
               LEFT JOIN cte_diagnoses_2019 
                      ON cte_diagnoses_2018.patient_id = cte_diagnoses_2019.patient_id 
               JOIN t_patient 
                 ON cte_diagnoses_2018.patient_id = pat_id) AS tbl 
       JOIN provider_master 
         ON pat_responsible_provider_id = prov_id 
       JOIN site_master 
         ON tbl.site_id = site_master.site_id 
GROUP  BY Upper(prov_fullname), 
          Upper(site_center_name), 
          Upper(icd10_code)) as t2) as t3 where rn <= 20
"""

#FULFILLED_2018_DIAGNOSES_QUERY = "select 'a' as provider, 'b' as site, 'c' as icd, 1 as happened, 2 as total, 0.5, 1 as rn"
CONNECTION_ARCADIA = pyodbc.connect(
    "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
)
FULFILLED_2018_DIAGNOSES = pd.read_sql(FULFILLED_2018_DIAGNOSES_QUERY, CONNECTION_ARCADIA)
print FULFILLED_2018_DIAGNOSES


app.layout = html.Div([
    dcc.Tabs(id="tabs-example", value='fulfilled_2018', children=[
        dcc.Tab(label='2018 to 2019', value='fulfilled_2018'),
        dcc.Tab(label='Tab Two', value='tab-2-example'),
    ]),
    html.Div(id='tabs_content')
])

SITE_DICT = [{
    'label': site,
    'value': site
} for site in FULFILLED_2018_DIAGNOSES.site.unique()]

PROVIDER_DICT = [{
    'label': provider,
    'value': provider
} for provider in FULFILLED_2018_DIAGNOSES.provider.unique()]

fulfulled_2018 = html.Div([
    html.Div(
        [
            dcc.Dropdown(
                id='fulfulled_2018_site',
                options=SITE_DICT,
                style={'width': '400px'}),
            dcc.Dropdown(
                id='fulfulled_2018_provider',
                options=PROVIDER_DICT,
                style={'width': '400px'}),
            dcc.Graph(id='fulfilled_2018_graph', figure={
            'data': [
                {
                    'x': FULFILLED_2018_DIAGNOSES.icd10_code,
                    'y': FULFILLED_2018_DIAGNOSES.happened,
                    'name': 'Happened',
                    'mode': 'markers',
                    'marker': {'size': 12}
                },
                {
                    'x': FULFILLED_2018_DIAGNOSES.icd10_code,
                    'y': FULFILLED_2018_DIAGNOSES.total,
                    'name': 'Total',
                    'mode': 'markers',
                    'marker': {'size': 12}
                }
            ]})
        ],
        style={
            'width': '800px',
            'height': '500px',
            'margin': '0 auto',
            'padding-top': '80px',
        })
])


@app.callback(Output('tabs_content', 'children'),
              [Input('tabs-example', 'value')])
def render_content(tab):
    if tab == 'fulfilled_2018':
        return fulfulled_2018
    elif tab == 'tab-2-example':
        return html.Div([
            html.H3('Tab content 2'),
            dcc.Graph(
                id='graph-2-tabs',
                figure={
                    'data': [{
                        'x': [1, 2, 3],
                        'y': [5, 10, 6],
                        'type': 'bar'
                    }]
                }
            )
        ])

if __name__ == '__main__':
    app.run_server(port=9000, host='10.0.10.24')

