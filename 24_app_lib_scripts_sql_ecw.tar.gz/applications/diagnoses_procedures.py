import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objs as go
import pandas as pd
import urllib
import StringIO
import flask
import pyodbc
from datetime import datetime
from pandas.tseries.offsets import MonthBegin
from dash.dependencies import Input, Output

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

FULFILLED_2018_DIAGNOSES_QUERY = """
WITH cte_2018_diagnoses 
     AS (SELECT DISTINCT patient_id, 
                         person_id, 
                         icd10_code 
         FROM   t_assessment 
                JOIN mpi.person_patient 
                  ON t_assessment.patient_id = person_patient.pat_id 
         WHERE  delete_ind = 'N' 
                AND Year(assessment_date) = 2018 
                AND icd10_code IS NOT NULL), 
     cte_2019_diagnoses 
     AS (SELECT DISTINCT patient_id, 
                         person_id, 
                         icd10_code 
         FROM   t_assessment 
                JOIN mpi.person_patient 
                  ON t_assessment.patient_id = person_patient.pat_id 
         WHERE  delete_ind = 'N' 
                AND Year(assessment_date) = 2019 
                AND icd10_code IS NOT NULL), 
     cte_fulfilled_diagnoses 
     AS (SELECT DISTINCT pat_medical_record_number, 
                         pat_first_name, 
                         pat_last_name, 
                         pat_middle_name, 
                         pat_date_of_birth, 
                         pat_phone_1, 
                         upper(prov_fullname) as prov_fullname, 
                         prov_npi, 
                         site_center_name, 
                         cte_2018_diagnoses.icd10_code, 
                         description, 
                         CASE 
                           WHEN cte_2019_diagnoses.patient_id IS NULL THEN 0 
                           ELSE 1 
                         END AS diagnosis_2019_fulfilled 
         FROM   cte_2018_diagnoses 
                LEFT JOIN cte_2019_diagnoses 
                       ON cte_2018_diagnoses.person_id = cte_2019_diagnoses.person_id 
                          AND cte_2018_diagnoses.icd10_code = cte_2019_diagnoses.icd10_code 
                JOIN t_patient 
                  ON t_patient.pat_id = cte_2018_diagnoses.patient_id 
                JOIN provider_master 
                  ON pat_responsible_provider_id = prov_id 
                LEFT JOIN lookup.code 
                       ON cte_2018_diagnoses.icd10_code = code_value 
                JOIN site_master 
                  ON prov_orig_site_id = site_orig_site_id 
         WHERE  pat_delete_ind = 'N') 
select top 100 * from cte_fulfilled_diagnoses
"""
CONNECTION_ARCADIA = pyodbc.connect(
    "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
)
FULFILLED_2018_DIAGNOSES = pd.read_sql(FULFILLED_2018_DIAGNOSES_QUERY, CONNECTION_ARCADIA)
print FULFILLED_2018_DIAGNOSES


app.layout = html.Div([
    dcc.Tabs(id="tabs-example", value='fulfilled_2018', children=[
        dcc.Tab(label='2018 to 2019', value='fulfilled_2018'),
        dcc.Tab(label='Tab Two', value='tab-2-example'),
    ]),
    html.Div(id='tabs_content')
])


@app.callback(Output('tabs_content', 'children'),
              [Input('tabs-example', 'value')])
def render_content(tab):
    if tab == 'fulfilled_2018':
        return html.Div([
            html.H3('Tab content 1'),
            dcc.Graph(
                id='graph-1-tabs',
                figure={
                    'data': [{
                        'x': [1, 2, 3],
                        'y': [3, 1, 2],
                        'type': 'bar'
                    }]
                }
            )
        ])
    elif tab == 'tab-2-example':
        return html.Div([
            html.H3('Tab content 2'),
            dcc.Graph(
                id='graph-2-tabs',
                figure={
                    'data': [{
                        'x': [1, 2, 3],
                        'y': [5, 10, 6],
                        'type': 'bar'
                    }]
                }
            )
        ])

if __name__ == '__main__':
    app.run_server(port=9001, host='10.0.10.24')

