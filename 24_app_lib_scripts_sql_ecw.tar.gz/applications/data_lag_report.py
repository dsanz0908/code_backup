import dash
import dash_core_components as dcc
import dash_html_components as html
from datetime import datetime
import pandas as pd
import numpy as np
import plotly.graph_objs as go
import pyodbc
import csv
import dash_table as dt
import re
from dateutil.relativedelta import relativedelta
import warnings
import statsmodels.api as sm
from statsmodels.tsa.arima_model import ARIMA
warnings.simplefilter(action='ignore')

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True


def smoothTriangle(data, degree, dropVals=False):
    triangle = np.array(
        list(range(degree)) + [degree] + list(range(degree)[::-1])) + 1
    smoothed = []

    for i in range(degree, len(data) - degree * 2):
        point = data[i:i + len(triangle)] * triangle
        smoothed.append(sum(point) / sum(triangle))
    if dropVals:
        return smoothed
    smoothed = [smoothed[0]] * int(degree + degree / 2) + smoothed
    while len(smoothed) < len(data):
        smoothed.append(smoothed[-1])
    return smoothed


AUTOMATED_DAG_RESULT_QUERY = """
SELECT dag_id, 
       start_date, 
       state 
FROM   (SELECT *, 
               Row_number() 
                 over ( 
                   PARTITION BY dag_id, start_date 
                   ORDER BY s DESC) AS rn 
        FROM   (SELECT DISTINCT dag_id, 
                                start_date :: DATE, 
                                state, 
                                CASE 
                                  WHEN state = 'failed' THEN 1 
                                  ELSE 0 
                                END AS s 
                FROM   dag_run 
                WHERE  dag_id LIKE '%ecw%' 
                       AND start_date >= '2019-01-01') AS a) AS b 
WHERE  rn = 1 
"""

END_DAG_RESULT_QUERY = """
SELECT DISTINCT a.dag_id, 
                a.start_date, 
                state 
FROM   (SELECT dag_id, 
               start_date :: DATE, 
               Max(start_date) AS latest_time 
        FROM   dag_run 
        WHERE  dag_id LIKE '%ecw%' and start_date >= '2019-01-01'
        GROUP  BY 1, 
                  2) AS a 
       join (SELECT dag_id, 
                    start_date, 
                    state 
             FROM   dag_run) AS b 
         ON a.dag_id = b.dag_id 
            AND latest_time = b.start_date 
"""

ARCADIA_LAG_QUERY = """
SELECT Cast(Max(enc_entry_timestamp) AS DATE)             AS latest_date, 
       site_emr_name                                      AS EMR, 
       Datediff(day, Max(enc_entry_timestamp), Getdate())-4 AS lag, 
       site_center_name                                   AS "Practice (in Arcadia)"
FROM   t_encounter t1 
       INNER JOIN site_master t2 
               ON t1.enc_site_id = t2.site_id 
GROUP  BY site_emr_name, 
          site_center_name 
HAVING Datediff(day, Max(enc_entry_timestamp), Getdate()) > 4 
ORDER  BY 2,4 
"""


def get_max_encounter_dates(conn_type):
    connection_string = "arcadia_sql_02{};uid=dev-etl;pwd=2aUK*BSy&z295sD"
    connection = pyodbc.connect(dsn=connection_string.format(conn_type))
    databases = get_database_names(connection)
    encounter_dates_df = pd.DataFrame()
    for database in databases:
        try:
            db_df = pd.DataFrame(
                np.array(get_dates(connection, database)),
                columns=['latest_date'])
            db_df["database"] = database
            encounter_dates_df = encounter_dates_df.append(db_df)
        except:
            pass
    return encounter_dates_df


def get_database_names(conn):
    database_query = "select name from master..sysdatabases where status = 2163712"
    cursor = conn.execute(database_query)
    database_names = [db[0] for db in cursor.fetchall()]
    cursor.close()
    return database_names


def get_dates(conn, db):
    max_encounter_date_query = """
    SELECT Max(d) 
    FROM   (SELECT CONVERT(DATE, date) AS d, 
		   Count(*)            AS c 
	    FROM   {}.dbo.enc 
	    WHERE  date < Getdate() 
	    GROUP  BY date 
	    HAVING Count(*) > 5) AS a 
    """.format(db)
    cursor = conn.execute(max_encounter_date_query)
    max_encounter = cursor.fetchall()
    cursor.close()
    return [me for me in max_encounter]


with open(
        '/home/etl/etl_home/applications/20190307_practice_database_mapping.csv',
        mode='r') as mapping_file:
    reader = csv.reader(mapping_file)
    mapping = dict(("db_{}".format(rows[0].lstrip().rstrip().lower()),
                    rows[1].lstrip().rstrip().decode('ascii', 'ignore'))
                   for rows in reader)

ecw_feeds_2012 = get_max_encounter_dates("")
ecw_feeds_2012["version"] = 2012
ecw_feeds_2016 = get_max_encounter_dates("_2016")
ecw_feeds_2016["version"] = 2016
ecw_feeds_2017 = get_max_encounter_dates("_2017")
ecw_feeds_2017["version"] = 2017
ecw_feeds = pd.concat([ecw_feeds_2012, ecw_feeds_2016, ecw_feeds_2017])
ecw_feeds["lag"] = (datetime.today().date() - pd.to_datetime(
    ecw_feeds["latest_date"]).dt.date).dt.days - 1
ecw_feeds["Practice (in ECW)"] = ecw_feeds["database"].map(mapping)
ecw_feeds = ecw_feeds.sort_values(by=["Practice (in ECW)"])
ecw_lag = ecw_feeds.groupby(['lag']).size().reset_index(name='count')
ecw_lag.loc[ecw_lag.lag > 7, 'lag'] = "Over 7"
ecw_lag = ecw_lag.groupby(['lag']).sum().reset_index()
ecw_lag = ecw_lag.loc[(ecw_lag['lag'] > 0)].applymap(str)
ecw_lag["lag"] = ecw_lag["lag"] + ' day(s)'

conn_24 = pyodbc.connect(dsn="postgres_24")
conn_67 = pyodbc.connect(dsn="postgres_67")
df = pd.concat([
    pd.read_sql(END_DAG_RESULT_QUERY, conn_24),
    pd.read_sql(END_DAG_RESULT_QUERY, conn_67)
]).groupby(['start_date', 'state']).size().reset_index()

success = df[df["state"] == "success"].sort_values(
    by="start_date").reset_index(drop=True).fillna(0)
failed = df[df["state"] == 'failed'].sort_values(by="start_date").reset_index(
    drop=True).fillna(0)

df2 = pd.concat([
    pd.read_sql(AUTOMATED_DAG_RESULT_QUERY, conn_24),
    pd.read_sql(AUTOMATED_DAG_RESULT_QUERY, conn_67)
]).groupby(['start_date', 'state']).size().reset_index()
automated_success = df2[df2["state"] == "success"].sort_values(
    by="start_date").reset_index(drop=True).fillna(0)

connection_arcadia = pyodbc.connect(
    "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
)
arcadia_lag_df = pd.read_sql(ARCADIA_LAG_QUERY, connection_arcadia)

CONNECTION_CDW = pyodbc.connect(dsn="claims_dw")
CDW_QUERY = """
    SELECT source,
	   the_date,
	   sum(membership_month_count) as member_months,
	   'real' as state
    FROM   fact_eligibility
	   JOIN dim_date
	     ON fact_eligibility.date_id = dim_date.date_id
    WHERE  eligibility_ind = 1
    GROUP  BY 1,
	      2
    ORDER  BY 1,
	      2
"""

CDW_QUERY = """
    SELECT split_part(source, ' ', 1) as mco,
	   split_part(source, ' ', 2) as ipa,
	   the_date,
	   cast(sum(membership_month_count) as int) as member_months,
	   'real' as state
    FROM   fact_eligibility
	   JOIN dim_date
	     ON fact_eligibility.date_id = dim_date.date_id
    WHERE  eligibility_ind = 1
    GROUP  BY 1,
	      2,3
	      
    union
    SELECT split_part(source, ' ', 1) as mco,
	   'All',
	   the_date,
	   cast(sum(membership_month_count) as int) as member_months,
	   'real' as state
    FROM   fact_eligibility
	   JOIN dim_date
	     ON fact_eligibility.date_id = dim_date.date_id
    WHERE  eligibility_ind = 1
    GROUP  BY 1,
	      2,3
    ORDER BY 1,2,3

"""
ALL_DF = pd.DataFrame()
RESULTS = pd.read_sql(CDW_QUERY, CONNECTION_CDW)
SOURCES = RESULTS.groupby(['mco', 'ipa'], as_index=False).first()[['mco', 'ipa']].values.tolist()
MCO_DICT = [{'label': mco, 'value': mco} for mco in RESULTS.mco.unique()]
IPA_DICT = [{'label': ipa, 'value': ipa} for ipa in RESULTS.ipa.unique()]
for mco, ipa in SOURCES:
    rows = RESULTS[(RESULTS['mco'] == mco) & (RESULTS['ipa'] == ipa)]
    start_date = rows['the_date'].max() #- relativedelta(months=6)
    end_date = start_date + relativedelta(months=5)
    forecast_temp = pd.DataFrame(
        pd.date_range(start_date, end_date, freq='MS'), columns=['the_date'])
    forecast_temp['the_date'] = forecast_temp['the_date'].dt.date
    forecast_temp.insert(0, 'mco', mco)
    forecast_temp.insert(0, 'ipa', ipa)
    X = rows[['the_date', 'member_months']]
    X.set_index('the_date', inplace=True)
    model = ARIMA(X, order=(2, 1, 0))
    model_fit = model.fit(disp=0)
    output = model_fit.forecast(steps=6)
    last_row = rows.iloc[-1:]
    last_row['state'] = 'forecast'
    forecast_dates = pd.concat([
        forecast_temp,
        pd.DataFrame(data=output[0], columns=['member_months'])
    ],
                               axis=1)
    forecast_dates = last_row.append(forecast_dates)
    forecast_dates['state'] = 'forecast'
    rows['state'] = 'real'
    df = rows.append(forecast_dates)
    ALL_DF = ALL_DF.append(df)

ALL_DF.reset_index().set_index(['mco', 'the_date', 'state'], inplace=True)
ALL_DF = pd.DataFrame(ALL_DF.to_records())
ALL_DF[ALL_DF['member_months'] < 0] = 0

app.layout = html.Div([
    html.Div([
        dcc.Graph(
            id='eCW_dag_success',
            figure={
                'data': [
                    go.Scatter(
                        x=success.start_date,
                        y=success[0],
                        mode='lines',
                        name='Success',
                        opacity=1),
                    go.Scatter(
                        x=automated_success.start_date,
                        y=automated_success[0],
                        mode='lines',
                        name='Automated Success',
                        opacity=0.5),
                    go.Scatter(
                        x=failed.start_date,
                        y=failed[0],
                        line=dict(color='red'),
                        mode='lines',
                        name='Failed',
                        opacity=1)
                ],
                'layout':
                go.Layout(
                    xaxis={
                        'rangeselector': {
                            'buttons':
                            list([{
                                'count': 3,
                                'label': '3M',
                                'step': 'month',
                                'stepmode': 'backward'
                            },
                                  {
                                      'count': 6,
                                      'label': '6M',
                                      'step': 'month',
                                      'stepmode': 'backward'
                                  }, {
                                      'step': 'all'
                                  }])
                        },
                        'type': 'date'
                    },
                    yaxis={'title': 'eCW Dags'},
                    hovermode='closest')
            })
    ],
             style={
                 'width': '1000px',
                 'height': '500px',
                 'margin': '0 auto'
             }),
    html.Div(
        [
            dcc.Graph(
                id='lagging_ecw_practices',
                figure={
                    'data': [
                        go.Scatter(
                            x=ecw_lag['lag'],
                            y=ecw_lag['count'],
                            mode='markers')
                    ],
                    'layout':
                    go.Layout(
                        xaxis=dict(autorange=True), yaxis={'title': 'eCW Lag'})
                }),
            dt.DataTable(
                id='lagging_ecw_datatable',
                columns=[{
                    "name": i,
                    "id": i
                } for i in ecw_feeds.columns],
                data=ecw_feeds[ecw_feeds["lag"] > 7].to_dict('records'),
                style_cell={
                    'font_size': '10px',
                    'text_align': 'center'
                })
        ],
        style={
            'width': '1000px',
            'height': '300px',
            'margin': '0 auto',
            'padding-top': '100px',
            'display': 'flex',
            'flex': '1'
        }),
    html.Div(
        [
            dt.DataTable(
                id='lagging_arcadia_datatable',
                columns=[{
                    "name": i,
                    "id": i
                } for i in arcadia_lag_df.columns],
                data=arcadia_lag_df.to_dict('records'),
                style_cell={
                    'font_size': '10px',
                    'text_align': 'center'
                })
        ],
        style={
            'width': '1000px',
            #'height': '600px',
            'margin': '0 auto',
            'padding-top': '100px',
        }),
    html.Div(
        [
            dcc.Dropdown(
                id='forecast_dropdown_mco',
                options=MCO_DICT,
                value='Healthfirst',
                style={'width': '300px'}),
            dcc.Dropdown(
                id='forecast_dropdown_ipa',
                options=IPA_DICT,
                value='All',
                style={'width': '300px'}),
            dcc.Graph(id='mco_forecast', figure={})
        ],
        style={
            'width': '1000px',
            'height': '600px',
            'margin': '0 auto',
            'padding-top': '100px',
            'display': 'flex',
            'flex': '1'
        })
])


@app.callback(
    dash.dependencies.Output('mco_forecast', 'figure'),
    [dash.dependencies.Input('forecast_dropdown_mco', 'value'),dash.dependencies.Input('forecast_dropdown_ipa', 'value')])
def update_output(mco, ipa):
    mco_df = ALL_DF.loc[ALL_DF['mco'] == mco]
    return {
        'data': [
            go.Scatter(
                x=mco_df[(mco_df['ipa'] == ipa)
                         & (mco_df['state'] == 'real')].the_date,
                y=mco_df[(mco_df['ipa'] == ipa)
                         & (mco_df['state'] == 'real')].member_months,
                mode='lines',
                name='Data'),
            go.Scatter(
                x=mco_df[(mco_df['ipa'] == ipa)
                         & (mco_df['state'] == 'forecast')].the_date,
                y=mco_df[(mco_df['ipa'] == ipa)
                         & (mco_df['state'] == 'forecast')].member_months,
                line=dict(color='red'),
                mode='lines',
                name='Forecast',
                yaxis='y'),
        ],
        'layout':
        go.Layout(
            yaxis={'title': 'mco Forecast'},
            yaxis2={'overlaying': 'y'},
            hovermode='closest')
    }


if __name__ == '__main__':
    app.run_server(port=7778, host='10.0.10.24')
