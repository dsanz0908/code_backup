import dash
import dash_core_components as dcc
import dash_html_components as html
from datetime import datetime
import pandas as pd
import numpy as np
import plotly.graph_objs as go
import pyodbc
import csv
import dash_table as dt
import re
from dateutil.relativedelta import relativedelta
import warnings
import statsmodels.api as sm
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error
from math import sqrt
warnings.simplefilter(action='ignore')

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True


CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
DISTINCT_QUERY = """
select distinct mco, ipa, lob, product, practice, pcp, taxonomy, age, sex from member_months_forecast
"""

RESULTS = pd.read_sql(DISTINCT_QUERY, CONNECTION)
MCO_DICT = [{'label': mco, 'value': mco} for mco in pd.read_sql("select distinct mco from member_months_forecast union select 'All'", CONNECTION).mco.tolist()]
IPA_DICT = [{'label': ipa, 'value': ipa} for ipa in pd.read_sql("select distinct ipa from member_months_forecast union select 'All'", CONNECTION).ipa.tolist()]
LOB_DICT = [{'label': lob, 'value': lob} for lob in pd.read_sql("select distinct lob from member_months_forecast union select 'All'", CONNECTION).lob.tolist()]
#PRODUCT_DICT = [{'label': product, 'value': product} for product in pd.read_sql("select distinct product from member_months_forecast union select 'All'", CONNECTION).product.tolist()]
PRACTICE_DICT = [{'label': practice, 'value': practice} for practice in pd.read_sql("select distinct practice from member_months_forecast union select 'All'", CONNECTION).practice.tolist()]
PCP_DICT = [{'label': pcp, 'value': pcp} for pcp in pd.read_sql("select distinct pcp from member_months_forecast union select 'All'", CONNECTION).pcp.tolist()]
TAXONOMY_DICT = [{'label': taxonomy, 'value': taxonomy} for taxonomy in pd.read_sql("select distinct taxonomy from member_months_forecast union select 'All'", CONNECTION).taxonomy.tolist()]
AGE_DICT = [{'label': age, 'value': age} for age in pd.read_sql("select distinct age from member_months_forecast union select 'All'", CONNECTION).age.tolist()]
SEX_DICT = [{'label': sex, 'value': sex} for sex in pd.read_sql("select distinct sex from member_months_forecast union select 'All'", CONNECTION).sex.tolist()]
ALL_DF = pd.DataFrame(RESULTS.to_records())

app.layout = html.Div([
    html.Div(
        [
            dcc.Dropdown(
                id='forecast_dropdown_mco',
                options=MCO_DICT,
                value='All',
                style={'width': '400px'}),
            dcc.Dropdown(
                id='forecast_dropdown_ipa',
                options=IPA_DICT,
                value='All',
                style={'width': '400px'}),
            dcc.Dropdown(
                id='forecast_dropdown_lob',
                options=LOB_DICT,
                value='All',
                style={'width': '400px'}),
            dcc.Dropdown(
                id='forecast_dropdown_practice',
                options=PRACTICE_DICT,
                value='All',
                style={'width': '400px'}),
            dcc.Dropdown(
                id='forecast_dropdown_pcp',
                options=PCP_DICT,
                value='All',
                style={'width': '400px'}),
            dcc.Dropdown(
                id='forecast_dropdown_taxonomy',
                options=TAXONOMY_DICT,
                value='All',
                style={'width': '400px'}),
            dcc.Dropdown(
                id='forecast_dropdown_age',
                options=AGE_DICT,
                value='All',
                style={'width': '400px'}),
            dcc.Dropdown(
                id='forecast_dropdown_sex',
                options=SEX_DICT,
                value='All',
                style={'width': '400px'}),
            html.Div(
                id='score',
                style={
                    'margin': '0 auto',
                    'display': 'block',
                    'color': 'red',
                    'font_size': '24px',
                    'text_align': 'center',
                    'font-weight': 'bold'
                }),
            dcc.Graph(id='mco_forecast', figure={})
        ],
        style={
            'width': '1000px',
            'height': '600px',
            'margin': '0 auto',
            'padding-top': '100px',
            #'display': 'flex',
           # 'flex': '1'
        })
])


@app.callback(
    dash.dependencies.Output('mco_forecast', 'figure'), [
    dash.dependencies.Input('forecast_dropdown_mco', 'value'),
    dash.dependencies.Input('forecast_dropdown_ipa', 'value'),
    dash.dependencies.Input('forecast_dropdown_lob', 'value'),
    dash.dependencies.Input('forecast_dropdown_practice', 'value'),
    dash.dependencies.Input('forecast_dropdown_pcp', 'value'),
    dash.dependencies.Input('forecast_dropdown_taxonomy', 'value'),
    dash.dependencies.Input('forecast_dropdown_age', 'value'),
    dash.dependencies.Input('forecast_dropdown_sex', 'value'),
])
def update_output(mco, ipa, lob, practice, pcp, taxonomy, age, sex):
    #print [field for field in [{'mco':mco}, ipa, lob, practice, pcp, taxonomy, age, sex] if field != 'All']
    fields = [['mco',mco], ['ipa',ipa], ['lob',lob], ['practice',practice], ['pcp',pcp], ['taxonomy',taxonomy], ['age',age], ['sex',sex]]
    non_all_fields = [[field,value] for field, value in fields if value != 'All']
    if non_all_fields:
        where = 'where'
    else:
        where = ''
    query_template = """
    select {} state, the_date, sum(member_months) as member_months from member_months_forecast
    {} {}
    group by 1,2,3,4,5,6,7,8,9,10
    order by 1,2,3,4,5,6,7,8,9 desc,10"""
    columns = ''
    where_string = []
    for field, value in fields:
        if value == 'All':
            columns += '\'{}\','.format(value)
        else:
            columns += '{},'.format(field)
            where_string.append('{} = \'{}\''.format(field, value))
    query = query_template.format(columns, where, ' and '.join(where_string))
    query_df = pd.read_sql(query, CONNECTION)
    
    max_real_date = query_df.loc[(query_df['state'] == 'real')].the_date.max() - relativedelta(months=6)
    query_df = query_df.drop(query_df[(query_df.state == 'forecast') & (query_df.the_date < max_real_date)].index)
    return {
        'data': [
            go.Scatter(
                x=query_df[(query_df['state'] == 'real')].the_date,
                y=query_df[(query_df['state'] == 'real')].member_months,
                mode='lines',
                name='Data'),
            go.Scatter(
                x=query_df[(query_df['state'] == 'forecast')].the_date,
                y=query_df[(query_df['state'] == 'forecast')].member_months,
                line=dict(color='red'),
                mode='lines',
                name='Forecast',
                yaxis='y'),
        ],
        'layout':
        go.Layout(
            yaxis={
                'title': 'Member Months Forecast',
                'range': [0, query_df.member_months.max()]
            },
            yaxis2={'overlaying': 'y'},
            hovermode='closest')
    }


if __name__ == '__main__':
    app.run_server(port=7781, host='10.0.10.24')
