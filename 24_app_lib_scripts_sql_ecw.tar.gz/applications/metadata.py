import dash
import dash_html_components as html
import dash_core_components as dcc
import dash_table
import plotly.graph_objs as go
import pandas as pd
import urllib
import StringIO
import flask
import pyodbc
from datetime import datetime
from pandas.tseries.offsets import MonthBegin

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

QUERY = """
SELECT Upper(source_name)          AS source_name, 
       case when parameters = 'NA' then '' else parameters end as parameters, 
       date_of_exec, 
       source_count, 
       target_count, 
       Upper(direction)            AS direction, 
       Upper(external_vendor_name) AS partner
FROM   etl_status 
WHERE  status = 'success' 
"""

CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
ROWS = pd.read_sql(QUERY, CONNECTION)

DIRECTION_DICT = [{
    'label': direction,
    'value': direction
} for direction in ROWS.direction.unique()]

PARTNER_DICT = [{
    'label': partner,
    'value': partner
} for partner in ROWS.partner.unique()]

app.layout = html.Div([
    html.Div(
        [
            dcc.Dropdown(
                id='direction',
                options=DIRECTION_DICT,
                style={'width': '400px'}),
            dcc.Dropdown(id='partner', style={'width': '400px'}),
            dcc.Graph(id='metadata_graph', figure={})
        ],
        style={
            'width': '1500px',
            'margin': '0 auto',
            'padding-top': '100px',
        })
])


@app.callback(
    dash.dependencies.Output('partner', 'options'),
    [dash.dependencies.Input('direction', 'value')])
def update_partner(direction):
    partner_dict = [{
        'label': partner,
        'value': partner
    } for partner in ROWS[(ROWS['direction'] == direction)].partner.unique()
                    if partner.split()]
    return partner_dict


@app.callback(
    dash.dependencies.Output('metadata_graph', 'figure'), [
        dash.dependencies.Input('direction', 'value'),
        dash.dependencies.Input('partner', 'value'),
    ])
def update_output(direction, partner):
    filtered_rows = ROWS.loc[(ROWS['direction'] == direction)
                             & (ROWS['partner'] == partner)]
    data = []
    for trace_num, fr in enumerate(filtered_rows.source_name):
        if trace_num == 0:
            visible = True
        else:
            visible = 'legendonly'
        filtered_source_rows = filtered_rows.loc[(
            filtered_rows['source_name'] == fr)]
        data.append(
            go.Scatter(
                x=filtered_source_rows.date_of_exec,
                y=filtered_source_rows.target_count,
                opacity=1,
                name=fr,
                visible=visible,
                mode='lines+markers',
                hovertext=filtered_source_rows.parameters,
                marker=dict(size=8)))

    return {'data': data}


if __name__ == '__main__':
    app.run_server(port=8051, host='10.0.10.24')
