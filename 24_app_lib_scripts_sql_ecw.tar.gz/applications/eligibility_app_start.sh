#!/bin/bash
ps -ef | grep "bokeh serve elig" | grep -v grep | awk '{print $2}' | xargs kill -9
bokeh serve eligibility_app --port 8888 --allow-websocket-origin=10.0.10.24:8888 --allow-websocket-origin=10.0.10.24:8009 --log-level=debug --keep-alive 10000
