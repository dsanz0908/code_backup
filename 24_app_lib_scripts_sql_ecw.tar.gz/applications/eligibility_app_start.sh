#!/bin/bash
ps -ef | grep "bokeh serve elig" | grep -v grep | awk '{print $2}' | xargs kill -9
source /home/ssundararaman/anaconda3/bin/activate
bokeh serve eligibility_app --port 8888 --allow-websocket-origin=10.0.10.24:8888 --allow-websocket-origin=10.0.10.24:8009 --log-level=debug --keep-alive 10000
