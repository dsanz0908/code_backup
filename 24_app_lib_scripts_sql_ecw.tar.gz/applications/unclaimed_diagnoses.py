import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objs as go
import pandas as pd
import urllib
import StringIO
import flask
import pyodbc
from datetime import datetime
from pandas.tseries.offsets import MonthBegin

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

QUERY_COST = """
SELECT code as icd10_code, 
       Sum(to_pay_amount) / Count(*) AS cost 
FROM   fact_claims 
       JOIN fact_claims_code_details 
         ON fact_claims.claim_id = fact_claims_code_details.claim_id 
            AND fact_claims.claim_line_no = fact_claims_code_details.claim_line_no 
       JOIN dim_codes 
         ON dim_codes.local_code_id = fact_claims_code_details.local_code_id 
WHERE  type = 'DIAG' 
       AND service_start_date >= '2019-01-01' 
GROUP  BY 1
"""

QUERY_1 = """
CREATE TEMPORARY TABLE get_arcadia_icd10
  (
    patient_id varchar(255),
    icd10_code varchar(255),
    prov_fullname varchar(255),
    prov_npi varchar(255),
    site_center_name varchar(255),
    pat_first_name varchar(255),
    pat_last_name varchar(255),
    pat_middle_name varchar(255),
    pat_phone_1 varchar(255),
    pat_date_of_birth varchar(255)
  );

copy get_arcadia_icd10
from 's3://sftp_test/get_arcadia_icd10.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|'
acceptinvchars
null as '\\0';

CREATE TEMPORARY TABLE fuzz_test
  (
     arcadia_name   VARCHAR(255),
     arcadia_dob    DATE,
     arcadia_pat_id VARCHAR(100),
     mco_name       VARCHAR(255),
     mco_dob        DATE,
     mco_cin        VARCHAR(50),
     mco_source     VARCHAR(50),
     mco_npi        VARCHAR(20),
     mco_address    VARCHAR(255),
     mco_phone      VARCHAR(20),
     mco_month      VARCHAR(20)
  );

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
last_encounter timestamp);

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';
"""


QUERY_2 = """
WITH cte_claims_icd_2019
     AS (SELECT DISTINCT member_cin,
                         code
         FROM   (SELECT member_cin,
                        code
                 FROM   fact_claims
                        JOIN fact_claims_code_details
                          ON fact_claims.claim_id = fact_claims_code_details.claim_id
                             AND fact_claims.claim_line_no = fact_claims_code_details.claim_line_no
                        JOIN dim_codes
                          ON dim_codes.local_code_id = fact_claims_code_details.local_code_id
                        JOIN dim_membership
                          ON dim_membership.local_member_id = fact_claims.local_member_id
                 WHERE  type = 'DIAG'
                        AND service_start_date >= '2019-01-01'
                 UNION
                 SELECT healthfirst_src_member_id,
                        code
                 FROM   fact_claims
                        JOIN fact_claims_code_details
                          ON fact_claims.claim_id = fact_claims_code_details.claim_id
                             AND fact_claims.claim_line_no = fact_claims_code_details.claim_line_no
                        JOIN dim_codes
                          ON dim_codes.local_code_id = fact_claims_code_details.local_code_id
                        JOIN dim_membership
                          ON dim_membership.local_member_id = fact_claims.local_member_id
                 WHERE  type = 'DIAG'
                        AND service_start_date >= '2019-01-01'
                 UNION
                 SELECT wellcare_src_member_id,
                        code
                 FROM   fact_claims
                        JOIN fact_claims_code_details
                          ON fact_claims.claim_id = fact_claims_code_details.claim_id
                             AND fact_claims.claim_line_no = fact_claims_code_details.claim_line_no
                        JOIN dim_codes
                          ON dim_codes.local_code_id = fact_claims_code_details.local_code_id
                        JOIN dim_membership
                          ON dim_membership.local_member_id = fact_claims.local_member_id
                 WHERE  type = 'DIAG'
                        AND service_start_date >= '2019-01-01'))
SELECT distinct mco_cin                     AS cin,
                pat_first_name
                || ' '
                || pat_last_name            AS patient,
                pat_phone_1                 AS phone,
                LEFT(pat_date_of_birth, 10) AS dob,
                prov_fullname as provider,
                prov_npi,
                site_center_name            AS site,
                icd10_code,
                claimed
FROM   (SELECT get_arcadia_icd10.*,
               policy_nbr as mco_cin,
               CASE
                 WHEN code IS NULL THEN 0
                 ELSE 1
               END                          AS claimed
        FROM   get_arcadia_icd10
               JOIN (SELECT pat_id,
                          policy_nbr
                   FROM   direct_match
                   UNION
                   SELECT arcadia_pat_id,
                          mco_cin
                   FROM   fuzz_test)
                 ON patient_id = pat_id
               LEFT JOIN cte_claims_icd_2019
                      ON policy_nbr = member_cin
                         AND icd10_code = code)


"""

CONNECTION = pyodbc.connect(dsn="claims_dw")
costs = pd.read_sql(QUERY_COST, CONNECTION)

CONNECTION.execute(QUERY_1)
unclaimed_diagnoses = pd.read_sql(QUERY_2, CONNECTION)

unclaimed_diagnoses_aggregated = unclaimed_diagnoses[[
    'site', 'provider', 'icd10_code', 'claimed'
]].groupby(['site', 'provider', 'icd10_code'])['claimed'].agg(
    ['sum', 'count']).reset_index().rename(columns={
        'sum': 'claimed',
        'count': 'total'
    })

unclaimed_diagnoses_aggregated_provider_all = unclaimed_diagnoses[[
    'site', 'icd10_code', 'claimed'
]].groupby(['site', 'icd10_code'])['claimed'].agg(
    ['sum', 'count']).reset_index().rename(columns={
        'sum': 'claimed',
        'count': 'total'
    })
unclaimed_diagnoses_aggregated_provider_all['provider'] = 'ALL PROVIDERS'
unclaimed_diagnoses_aggregated = pd.concat([
    unclaimed_diagnoses_aggregated, unclaimed_diagnoses_aggregated_provider_all
])

unclaimed_diagnoses_aggregated = pd.merge(unclaimed_diagnoses_aggregated, costs, on=['icd10_code'])
unclaimed_diagnoses_aggregated['total_costs'] = unclaimed_diagnoses_aggregated['total'] * unclaimed_diagnoses_aggregated['cost']
unclaimed_diagnoses_aggregated['claimed_costs'] = unclaimed_diagnoses_aggregated['claimed'] * unclaimed_diagnoses_aggregated['cost']
unclaimed_diagnoses_aggregated = unclaimed_diagnoses_aggregated.sort_values(
    by=['site', 'provider', 'total_costs'], ascending=[True, True, False])

unclaimed_diagnoses_aggregated['rank'] = unclaimed_diagnoses_aggregated.groupby(
        ['site', 'provider'])['total_costs'].rank(ascending=False)
unclaimed_diagnoses_aggregated = unclaimed_diagnoses_aggregated.query('rank < 21')

print unclaimed_diagnoses_aggregated

SITE_DICT = [{
    'label': site,
    'value': site
} for site in unclaimed_diagnoses_aggregated.site.unique()]

app.layout = html.Div([
    html.H4(children='Unclaimed Diagnoses (ordered by potential total costs)'),
    html.Div(
        [
            dcc.Dropdown(
                id='unclaimed_diagnoses_site',
                options=SITE_DICT,
                style={'width': '400px'}),
            dcc.Dropdown(
                id='unclaimed_diagnoses_provider', style={'width': '400px'}),
            dcc.Graph(id='unclaimed_diagnoses', figure={}),
            html.A(
                'Download Raw Data',
                id='download_link',
                download='rawdata.csv',
                href='',
                target='_blank')
        ],
        style={
            'width': '1600px',
            'height': '500px',
            'margin': '0 auto',
            'padding-top': '80px',
        })
])


@app.callback(
    dash.dependencies.Output('unclaimed_diagnoses_provider', 'options'),
    [dash.dependencies.Input('unclaimed_diagnoses_site', 'value')])
def update_provider(site):
    provider_dict = [{
        'label': provider,
        'value': provider
    } for provider in unclaimed_diagnoses_aggregated[(
        unclaimed_diagnoses_aggregated['site'] == site)].provider.unique()
                     if provider.split()]
    return provider_dict


@app.callback(
    dash.dependencies.Output('unclaimed_diagnoses', 'figure'), [
        dash.dependencies.Input('unclaimed_diagnoses_site', 'value'),
        dash.dependencies.Input('unclaimed_diagnoses_provider', 'value'),
    ])
def update_output(site, provider):
    filtered_df = unclaimed_diagnoses_aggregated.loc[
        (unclaimed_diagnoses_aggregated['site'] == site)
        & (unclaimed_diagnoses_aggregated['provider'] == provider)]

    return {
        'data': [
            go.Scatter(
                x=filtered_df.icd10_code,
                y=filtered_df.claimed,
                name='Claimed',
                opacity=1,
                mode='markers',
                marker=dict(size=16)),
            go.Scatter(
                x=filtered_df.icd10_code,
                y=filtered_df.total,
                name='Total',
                opacity=1,
                mode='markers',
                marker=dict(size=16)),
        ],
        'layout':
        go.Layout(
            #xaxis={'type': 'date'},
            yaxis={'title': 'Unique Members'},
            hovermode='closest')
    }


@app.callback(
    dash.dependencies.Output('download_link', 'href'), [
        dash.dependencies.Input('unclaimed_diagnoses_site', 'value'),
        dash.dependencies.Input('unclaimed_diagnoses_provider', 'value'),
    ])
def update_download_link(site, provider):
    return '/dash/urlToDownload?value={}'.format(site + '|' + provider)


@app.server.route('/dash/urlToDownload')
def download_csv():
    value = flask.request.args.get('value')
    site = value.split('|')[0]
    provider = value.split('|')[1]
    print site, provider
    filtered_df = unclaimed_diagnoses.loc[
        (unclaimed_diagnoses['site'] == site)]
        #& (unclaimed_diagnoses['claimed'] == 0)]

    if provider != 'ALL PROVIDERS':
        filtered_df = filtered_df.loc[(
            unclaimed_diagnoses['provider'] == provider)]
    str_io = StringIO.StringIO()
    filtered_df.to_csv(str_io, index=False)
    str_io.seek(0)
    return flask.send_file(
        str_io,
        mimetype='text/csv',
        attachment_filename='unclaimed_diagnoses_{}_{}_{}.csv'.format(
            site, provider,
            datetime.today().strftime('%Y%m%d')),
        as_attachment=True)


if __name__ == '__main__':
    app.run_server(port=7779, host='10.0.10.24')
