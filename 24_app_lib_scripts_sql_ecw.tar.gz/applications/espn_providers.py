import dash
import dash_html_components as html
import dash_core_components as dcc
import dash_table
import plotly.graph_objs as go
import pandas as pd
import urllib
import StringIO
import flask
import pyodbc
from datetime import datetime
from pandas.tseries.offsets import MonthBegin

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

QUERY = """
WITH cte_espn_eligibility 
     AS (SELECT provider_last_name 
                || ', ' 
                || provider_first_name           AS provider, 
                dim_provider.provider_npi, 
                provider_taxonomies, 
                practice_name, 
                provider_tin, 
                Sum(CASE 
                      WHEN eligibility_ind = 1 THEN 1 
                      ELSE 0 
                    END)                         AS membership, 
                Sum(membership_month_count) * 12 AS mm 
         FROM   fact_eligibility 
                JOIN dim_provider 
                  ON fact_eligibility.local_provider_id = dim_provider.local_provider_id 
                JOIN dim_provider_org_detail 
                  ON fact_eligibility.local_provider_org_id = dim_provider_org_detail.local_provider_org_id
         WHERE  fact_eligibility.effective_date = '2019-08-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5), 
     cte_espn_paid 
     AS (SELECT provider, 
                provider_npi, 
                provider_taxonomies, 
                practice_name, 
                provider_tin, 
                Sum(to_pay_amount)                                                             AS cost,
                Round(( Count(DISTINCT claim_id) * 1.0 ) / Count(DISTINCT local_member_id), 2) AS pcp_claims_member
         FROM   (SELECT provider_last_name 
                        || ', ' 
                        || provider_first_name AS provider, 
                        dim_provider.provider_npi, 
                        provider_taxonomies, 
                        practice_name, 
                        provider_tin, 
                        to_pay_amount, 
                        claim_id, 
                        local_member_id 
                 FROM   fact_claims 
                        JOIN dim_provider 
                          ON fact_claims.local_pcp_provider_id = dim_provider.local_provider_id
                        JOIN dim_provider_org_detail 
                          ON fact_claims.local_pcp_org_id = dim_provider_org_detail.local_provider_org_id
                 WHERE  effective_date = '2019-08-01' 
                 UNION ALL 
                 SELECT provider_last_name 
                        || ', ' 
                        || provider_first_name, 
                        dim_provider.provider_npi, 
                        provider_taxonomies, 
                        practice_name, 
                        provider_tin, 
                        to_pay_amount, 
                        claim_id, 
                        local_member_id 
                 FROM   fact_pharmacy_claims 
                        JOIN dim_provider 
                          ON fact_pharmacy_claims.local_pcp_prov_id = dim_provider.local_provider_id
                        JOIN dim_provider_org_detail 
                          ON fact_pharmacy_claims.local_provider_org_id = dim_provider_org_detail.local_provider_org_id
                 WHERE  effective_date = '2019-08-01') 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5), 
     cte_nonuser 
     AS (SELECT provider_last_name 
                || ', ' 
                || provider_first_name                                                                   AS provider,
                dim_provider.provider_npi, 
                provider_taxonomies, 
                practice_name, 
                provider_tin, 
                1 - ( ( Count(DISTINCT CASE 
                                         WHEN service_start_date BETWEEN '2018-09-01' AND '2019-08-31' 
                                               OR service_date BETWEEN '2018-09-01' AND '2019-08-31' THEN fact_claims.local_member_id 
                                         ELSE NULL 
                                       END) * 1.0 ) / Count(DISTINCT fact_eligibility.local_member_id) ) AS non_user_rate
         FROM   fact_eligibility 
                JOIN dim_provider 
                  ON fact_eligibility.local_provider_id = dim_provider.local_provider_id 
                JOIN dim_provider_org_detail 
                  ON fact_eligibility.local_provider_org_id = dim_provider_org_detail.local_provider_org_id
                LEFT JOIN fact_claims 
                       ON fact_eligibility.local_member_id = fact_claims.local_member_id 
                LEFT JOIN fact_pharmacy_claims 
                       ON fact_eligibility.local_member_id = fact_pharmacy_claims.local_member_id
         WHERE  fact_eligibility.effective_date = '2019-08-01' 
                AND eligibility_ind = 1 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5) 
SELECT cte_espn_eligibility.provider            AS Name, 
       cte_espn_eligibility.provider_npi        AS NPI, 
       cte_espn_eligibility.provider_taxonomies AS Speciality, 
       cte_espn_eligibility.practice_name       AS Practice, 
       cte_espn_eligibility.provider_tin        AS TIN, 
       membership                               AS "Current Membership", 
       mm                                       AS "Member Months", 
       Round(cost / ( mm / 12 ), 2)             AS "Cost PMPM", 
       pcp_claims_member                        AS "PCP Claims/Member", 
       Round(non_user_rate, 2)                  AS "Non-User Rate" 
FROM   cte_espn_eligibility 
       JOIN cte_espn_paid 
         ON cte_espn_eligibility.provider = cte_espn_paid.provider 
            AND cte_espn_eligibility.provider_npi = cte_espn_paid.provider_npi 
            AND cte_espn_eligibility.provider_taxonomies = cte_espn_paid.provider_taxonomies 
            AND cte_espn_eligibility.practice_name = cte_espn_paid.practice_name 
            AND cte_espn_eligibility.provider_tin = cte_espn_paid.provider_tin 
       JOIN cte_nonuser 
         ON cte_espn_eligibility.provider = cte_nonuser.provider 
            AND cte_espn_eligibility.provider_npi = cte_nonuser.provider_npi 
            AND cte_espn_eligibility.provider_taxonomies = cte_nonuser.provider_taxonomies 
            AND cte_espn_eligibility.practice_name = cte_nonuser.practice_name 
            AND cte_espn_eligibility.provider_tin = cte_nonuser.provider_tin 
ORDER  BY mm DESC 
LIMIT 100
"""

CONNECTION = pyodbc.connect(dsn="claims_dw")
ROWS = pd.read_sql(QUERY, CONNECTION)
ROWS.columns = [
    'Name', 'NPI', 'Speciality', 'Practice', 'TIN', 'Current Membership',
    'Member Months', 'Cost PMPM', 'PCP Claims/Member', 'Non-User Rate'
]
app.layout = html.Div(
    [
        dash_table.DataTable(
            columns=[{
                "name": i,
                "id": i
            } for i in ROWS.columns],
            data=ROWS.to_dict('records'),
            sorting=True,
            style_cell={
                'font_size': '10px',
                'text_align': 'center',
                'min-width': '150px'
            },
            style_data_conditional=[{
                'if': {
                    'row_index': 'odd'
                },
                'backgroundColor': 'rgb(248, 248, 248)'
            }],
            style_header={
                'fontWeight': 'bold',
            },
            style_table={
                'maxWidth': '1500px',
                'maxHeight': '800px'
            },
            n_fixed_rows=1,
            n_fixed_columns=5,
            style_data={'text-align': 'center'},
            css=[{
                'selector':
                '.dash-cell div.dash-cell-value',
                'rule':
                'display: inline; white-space: inherit; overflow: inherit; text-overflow: inherit;'
            }])
    ],
    style={
        'width': '1500px',
        'height': '800px',
        'textAlign': 'center',
        'margin': '0 auto',
        'padding-top': '100px',
    })

if __name__ == '__main__':
    app.run_server(port=8050, host='10.0.10.24')
