import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objs as go
import pandas as pd
import numpy as np
import pyodbc

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

CONNECTION_CDW = pyodbc.connect(dsn="claims_dw")
CDW_QUERY = """
WITH eligibility_aggregation 
     AS (SELECT Split_part(source, ' ', 1)      AS mco, 
                Split_part(source, ' ', 2)      AS ipa, 
                product_cd, 
                effective_date, 
                'distinct members'              AS field, 
                Count(DISTINCT local_member_id) AS value 
         FROM   fact_eligibility 
                JOIN dim_product 
                  ON fact_eligibility.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1)        AS mco, 
                Split_part(source, ' ', 2)        AS ipa, 
                product_cd, 
                effective_date, 
                'distinct providers', 
                Count(DISTINCT local_provider_id) AS value 
         FROM   fact_eligibility 
                JOIN dim_product 
                  ON fact_eligibility.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1)            AS mco, 
                Split_part(source, ' ', 2)            AS ipa, 
                product_cd, 
                effective_date, 
                'distinct practices', 
                Count(DISTINCT local_provider_org_id) AS value 
         FROM   fact_eligibility 
                JOIN dim_product 
                  ON fact_eligibility.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1)  AS mco, 
                Split_part(source, ' ', 2)  AS ipa, 
                product_cd, 
                effective_date, 
                'member months', 
                Sum(membership_month_count) AS value 
         FROM   fact_eligibility 
                JOIN dim_product 
                  ON fact_eligibility.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'new count', 
                Sum(new_count)             AS value 
         FROM   fact_eligibility 
                JOIN dim_product 
                  ON fact_eligibility.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'continue count', 
                Sum(continue_count)        AS value 
         FROM   fact_eligibility 
                JOIN dim_product 
                  ON fact_eligibility.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'drop count', 
                Sum(drop_count)            AS value 
         FROM   fact_eligibility 
                JOIN dim_product 
                  ON fact_eligibility.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5), 
     claims_aggregation 
     AS (SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'total medical claims'     AS field, 
                Count(DISTINCT claim_id)   AS value 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'total service providers', 
                Count(DISTINCT local_service_provider_id) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'account payable amount', 
                Sum(acct_payable_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'net allowed amount', 
                Sum(net_allowed_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'allowed amount', 
                Sum(allowed_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'to pay amount', 
                Sum(to_pay_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'billed amount', 
                Sum(billed_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'copay amount', 
                Sum(copay_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'coinsurance amount', 
                Sum(coinsurance_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'deductible amount', 
                Sum(deductible_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'non covered amount', 
                Sum(non_covered_amount) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'distinct services', 
                Count(DISTINCT local_service_id) 
         FROM   fact_claims 
                JOIN dim_product 
                  ON fact_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5), 
     pharmacy_aggregation 
     AS (SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'total phamacy claims'     AS field, 
                Count(DISTINCT claim_id)   AS value 
         FROM   fact_pharmacy_claims 
                JOIN dim_product 
                  ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'distinct pharmacies', 
                Count(DISTINCT local_pharmacy_id) 
         FROM   fact_pharmacy_claims 
                JOIN dim_product 
                  ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'distinct prescribers', 
                Count(DISTINCT local_prescriber_id) 
         FROM   fact_pharmacy_claims 
                JOIN dim_product 
                  ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'distinct drugs', 
                Count(DISTINCT local_drug_id) 
         FROM   fact_pharmacy_claims 
                JOIN dim_product 
                  ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'total prescription cost', 
                Sum(prescription_cost) 
         FROM   fact_pharmacy_claims 
                JOIN dim_product 
                  ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'pharmacy to pay amount', 
                Sum(to_pay_amount) 
         FROM   fact_pharmacy_claims 
                JOIN dim_product 
                  ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5 
         UNION 
         SELECT Split_part(source, ' ', 1) AS mco, 
                Split_part(source, ' ', 2) AS ipa, 
                product_cd, 
                effective_date, 
                'prescribed amount', 
                Sum(prescribed_days_supply) 
         FROM   fact_pharmacy_claims 
                JOIN dim_product 
                  ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
         WHERE  effective_date >= '2017-01-01' 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4, 
                   5), 
     /*pmpm 
     AS (SELECT eligibility_aggregation.mco, 
                eligibility_aggregation.ipa, 
                eligibility_aggregation.product_cd, 
                eligibility_aggregation.effective_date, 
                'pmpm', 
                CASE 
                  WHEN eligibility_aggregation.value > 0 THEN ( claims_aggregation.value 
                                                                + pharmacy_aggregation.value ) /
                                                              eligibility_aggregation.value 
                  ELSE 0 
                END AS pmpm 
         FROM   eligibility_aggregation 
                JOIN claims_aggregation 
                  ON eligibility_aggregation.mco = claims_aggregation.mco 
                     AND eligibility_aggregation.ipa = claims_aggregation.ipa 
                     AND eligibility_aggregation.product_cd = claims_aggregation.product_cd 
                     AND eligibility_aggregation.effective_date = claims_aggregation.effective_date
                JOIN pharmacy_aggregation 
                  ON eligibility_aggregation.mco = pharmacy_aggregation.mco 
                     AND eligibility_aggregation.ipa = pharmacy_aggregation.ipa 
                     AND eligibility_aggregation.product_cd = pharmacy_aggregation.product_cd 
                     AND eligibility_aggregation.effective_date = pharmacy_aggregation.effective_date
         WHERE  eligibility_aggregation.field = 'member months' 
                AND claims_aggregation.field = 'to pay amount' 
                AND pharmacy_aggregation.field = 'pharmacy to pay amount'), */
     eligibility_claims_pharmacy 
     AS (SELECT * 
         FROM   eligibility_aggregation 
         UNION 
         SELECT * 
         FROM   claims_aggregation 
         UNION 
         SELECT * 
         FROM   pharmacy_aggregation 
         /*UNION 
         SELECT * 
         FROM   pmpm*/), 
     floor_ceiling 
     AS (SELECT mco, 
                ipa, 
                product_cd, 
                field, 
                Avg(value) - ( Stddev(value) * 2 ) AS field_floor, 
                Avg(value) + ( Stddev(value) * 2 ) AS field_ceiling 
         FROM   eligibility_claims_pharmacy 
         WHERE  effective_date < (SELECT Dateadd(month, -2, Max(effective_date)) 
                                  FROM   eligibility_claims_pharmacy) 
         GROUP  BY 1, 
                   2, 
                   3, 
                   4) 
SELECT Upper(eligibility_claims_pharmacy.mco)        AS mco, 
       Upper(eligibility_claims_pharmacy.ipa)        AS ipa, 
       Upper(eligibility_claims_pharmacy.product_cd) AS product, 
       effective_date, 
       Upper(eligibility_claims_pharmacy.field)      AS field, 
       value, 
       CASE 
         WHEN value < field_floor 
               OR value > field_ceiling THEN 1 
         ELSE 0 
       END                                           AS anomaly 
FROM   eligibility_claims_pharmacy 
       JOIN floor_ceiling 
         ON eligibility_claims_pharmacy.mco = floor_ceiling.mco 
            AND eligibility_claims_pharmacy.ipa = floor_ceiling.ipa 
            AND eligibility_claims_pharmacy.product_cd = floor_ceiling.product_cd 
            AND eligibility_claims_pharmacy.field = floor_ceiling.field 
ORDER  BY 1, 
          2, 
          3, 
          5, 
          4 
"""

COST_service_codes_ANOMALIES_QUERY = """
WITH top_providers 
     AS (SELECT local_pcp_provider_id 
         FROM   (SELECT local_pcp_provider_id, 
                        Sum(to_pay_amount)      AS paid, 
                        Row_number() 
                          OVER ( 
                            ORDER BY paid DESC) AS rn 
                 FROM   fact_claims 
                 WHERE  service_start_date >= '2019-07-01' 
                 GROUP  BY 1) 
         WHERE  rn <= 20) 
SELECT DISTINCT provider_full_name, 
                provider_npi, 
                member_first_name 
                || ' ' 
                || member_last_name AS member_name, 
                case when member_cin is null then '' else member_cin end as member_cin, 
                service_start_date, 
                to_pay_amount, 
                CASE 
                  WHEN service_cd_description_short IS NULL THEN service_cd_description 
                  ELSE service_cd_description_short 
                END                 AS service_cd_description 
FROM   fact_claims 
       JOIN top_providers 
         ON fact_claims.local_pcp_provider_id = top_providers.local_pcp_provider_id 
       JOIN dim_membership 
         ON fact_claims.local_member_id = dim_membership.local_member_id 
       JOIN dim_provider 
         ON fact_claims.local_pcp_provider_id = dim_provider.local_provider_id 
       JOIN dim_service_type 
         ON fact_claims.local_service_id = dim_service_type.local_service_id 
WHERE  service_start_date > '2019-07-01' 
       AND to_pay_amount > 0 
"""

COST_ANOMALIES_QUERY = """
WITH all_claims 
     AS (SELECT local_pcp_provider_id, 
                source, 
                to_pay_amount 
         FROM   fact_claims 
         WHERE  service_start_date >= '2019-01-01' 
         UNION ALL 
         SELECT local_pcp_prov_id, 
                source, 
                to_pay_amount 
         FROM   fact_pharmacy_claims 
         WHERE  service_date >= '2019-01-01'), 
     top_providers 
     AS (SELECT DISTINCT local_pcp_provider_id 
         FROM   (SELECT local_pcp_provider_id, 
                        source, 
                        Sum(to_pay_amount)      AS paid, 
                        Row_number() 
                          OVER ( 
                            partition BY source 
                            ORDER BY paid DESC) AS rn 
                 FROM   all_claims 
                 GROUP  BY 1, 
                           2) 
         WHERE  rn <= 5) 
SELECT Upper(mco)         AS mco, 
       Upper(ipa)         AS ipa, 
       Upper(product)     AS product, 
       provider_full_name, 
       provider_npi, 
       member_name, 
       member_cin, 
       Sum(to_pay_amount) AS paid_amount 
FROM   (SELECT Split_part(source, ' ', 1) AS mco, 
               Split_part(source, ' ', 2) AS ipa, 
               product_cd                 AS product, 
               provider_full_name, 
               provider_npi, 
               member_first_name 
               || ' ' 
               || member_last_name        AS member_name, 
               CASE 
                 WHEN member_cin IS NULL THEN '' 
                 ELSE member_cin 
               END                        AS member_cin, 
               to_pay_amount 
        FROM   fact_claims 
               JOIN dim_product 
                 ON fact_claims.local_product_id = dim_product.local_product_id 
               JOIN top_providers 
                 ON fact_claims.local_pcp_provider_id = top_providers.local_pcp_provider_id 
               JOIN dim_membership 
                 ON fact_claims.local_member_id = dim_membership.local_member_id 
               JOIN dim_provider 
                 ON fact_claims.local_pcp_provider_id = dim_provider.local_provider_id 
        WHERE  service_start_date > '2019-01-01' 
        UNION ALL 
        SELECT Split_part(source, ' ', 1) AS mco, 
               Split_part(source, ' ', 2) AS ipa, 
               product_cd, 
               provider_full_name, 
               provider_npi, 
               member_first_name 
               || ' ' 
               || member_last_name        AS member_name, 
               CASE 
                 WHEN member_cin IS NULL THEN '' 
                 ELSE member_cin 
               END                        AS member_cin, 
               to_pay_amount 
        FROM   fact_pharmacy_claims 
               JOIN dim_product 
                 ON fact_pharmacy_claims.local_product_id = dim_product.local_product_id 
               JOIN top_providers 
                 ON fact_pharmacy_claims.local_pcp_prov_id = top_providers.local_pcp_provider_id
               JOIN dim_membership 
                 ON fact_pharmacy_claims.local_member_id = dim_membership.local_member_id 
               JOIN dim_provider 
                 ON fact_pharmacy_claims.local_pcp_prov_id = dim_provider.local_provider_id 
        WHERE  service_date > '2019-01-01') 
GROUP  BY 1,2,3,4,5,6,7 """

RESULTS = pd.read_sql(CDW_QUERY, CONNECTION_CDW)
RESULTS_ALL = RESULTS[[
    'mco', 'product', 'field', 'effective_date', 'value'
]].groupby(['mco', 'product', 'field', 'effective_date'])['value'].agg(
    ['sum']).reset_index().rename(columns={'sum': 'value'})
RESULTS_ALL['ipa'] = 'ALL IPAs'
RESULTS_ALL['anomaly'] = 0
RESULTS = pd.concat([RESULTS, RESULTS_ALL])
MCO_DICT = [{'label': mco, 'value': mco} for mco in RESULTS.mco.unique()]
IPA_DICT = [{'label': ipa, 'value': ipa} for ipa in RESULTS.ipa.unique()]
PRODUCT_DICT = [{
    'label': product,
    'value': product
} for product in RESULTS['product'].unique()]
FIELD_DICT = [{
    'label': field,
    'value': field
} for field in RESULTS.field.unique()]

COST_RESULTS = pd.read_sql(COST_ANOMALIES_QUERY, CONNECTION_CDW)
COST_ALL = COST_RESULTS.copy()
COST_ALL['ipa'] = 'ALL IPAs'
COST_RESULTS = pd.concat([COST_RESULTS, COST_ALL])
app.layout = html.Div([
    html.H4(children='CDW Data Anomalies'),
    html.Div(
        [
            dcc.Dropdown(
                id='anomalies_mco',
                options=MCO_DICT,
                placeholder='MCO',
                style={'width': '300px'}),
            dcc.Dropdown(
                id='anomalies_ipa',
                options=IPA_DICT,
                placeholder='IPA',
                style={'width': '300px'}),
            dcc.Dropdown(
                id='anomalies_product',
                options=PRODUCT_DICT,
                placeholder='Product',
                style={'width': '300px'}),
            dcc.Dropdown(
                id='anomalies_field',
                options=FIELD_DICT,
                placeholder='Value Point',
                style={'width': '300px'}),
            dcc.Graph(
                id='anomalies',
                figure={
                    'layout': go.Layout(yaxis={'title': 'Data Anomalies'})
                }),
            dcc.Graph(id='cost_anomalies', figure={})
        ],
        style={
            'width': '1500px',
            'height': '200px',
            'margin': '0 auto',
            'padding-top': '20px',
            #'display': 'flex',
            #'flex': '1'
        })
])


@app.callback([
    dash.dependencies.Output('anomalies', 'figure'),
    dash.dependencies.Output('cost_anomalies', 'figure')
], [
    dash.dependencies.Input('anomalies_mco', 'value'),
    dash.dependencies.Input('anomalies_ipa', 'value'),
    dash.dependencies.Input('anomalies_product', 'value'),
    dash.dependencies.Input('anomalies_field', 'value'),
])
def update_output(mco, ipa, product, field):
    macro_df = RESULTS.loc[(RESULTS['field'] == field)
                           & (RESULTS['mco'] == mco)
                           & (RESULTS['ipa'] == ipa)
                           & (RESULTS['product'] == product)]
    anomaly_1 = macro_df.loc[(macro_df['anomaly'] == 1)]
    anomaly_0 = macro_df.loc[(macro_df['anomaly'] == 0)]

    cost_df = COST_RESULTS.loc[(COST_RESULTS['mco'] == mco)
                               & (COST_RESULTS['ipa'] == ipa)
                               & (COST_RESULTS['product'] == product)]
    cost_traces = []
    for pcp in cost_df.provider_full_name.unique():
        cost_df_filtered = cost_df.loc[(cost_df['provider_full_name'] == pcp)]
        trace = go.Box(
            y=cost_df_filtered.paid_amount,
            boxpoints='outliers',
            name=pcp,
            hoveron='points',
            hovertext='Member: ' + cost_df_filtered.member_name + '<br />CIN: '
            + cost_df_filtered.member_cin + "<br />Provider NPI: " +
            cost_df_filtered.provider_npi)
        cost_traces.append(trace)

    return {
        'data': [
            go.Scatter(
                x=anomaly_1.effective_date,
                y=anomaly_1.value,
                mode='markers',
                marker=dict(size=12, color='red'),
                name='Suspicious'),
            go.Scatter(
                x=anomaly_0.effective_date,
                y=anomaly_0.value,
                marker=dict(size=12, color='blue'),
                mode='markers',
                name='Normal'),
        ]
    }, {
        'data': cost_traces
    }


if __name__ == '__main__':
    app.run_server(port=7780, host='10.0.10.24')
