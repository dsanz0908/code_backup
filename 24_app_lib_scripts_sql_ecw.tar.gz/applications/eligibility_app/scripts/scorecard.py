import pyodbc
import pandas as pd
from bokeh.io import curdoc, show
from bokeh.layouts import row,widgetbox,column,gridplot
from bokeh.models.widgets import DataTable,TableColumn,HTMLTemplateFormatter,Panel,Tabs,Select,RadioGroup, Paragraph
from bokeh.plotting import figure,ColumnDataSource
from bokeh.models import Range1d,HoverTool,BoxSelectTool,TapTool,FactorRange
from bokeh.models import DatetimeTickFormatter,BasicTickFormatter  
conn=pyodbc.connect(dsn="somos_redshift_1")

def scorecard_tab():
	query = """ select for_date,t1.sitename,measure,universe,denominator,numerator,county_burrough,bus_group 
            from scorecard_report t1
            left outer join arcadia_site_county_map t2 
            on t1.sitename = t2.sitename
        """
	q_sites= """
	    select 'All' as sitename 
	    union all
	    select distinct sitename from scorecard_report order by 1
	    """
	q_measures = """
	    select 'All' as measure
	    union
	    select distinct measure from scorecard_report order by 1
	    """
	q_county = " select distinct county_burrough as  county from arcadia_site_county_map union select 'All' "
	q_group = " select distinct bus_group as group from arcadia_site_county_map union select 'All' "
	mdf=pd.read_sql(query,conn)
	df_sites=pd.read_sql(q_sites,conn)
	df_measures=pd.read_sql(q_measures,conn)
	df_county=pd.read_sql(q_county,conn)
	df_group=pd.read_sql(q_group,conn)
	#site_list=list(df_sites["sitename"])
	#measures_list=list(df_measures.loc[:,("measure")])
	#county_list=list(df_county.loc[:,("county")])
	#group_list=list(df_group.loc[:,("group")])
	site_list=[sitename for sitename in df_sites["sitename"]]
	measures_list = [ measure for measure in df_measures["measure"]]
	county_list=[county for county in df_county["county"]]
	group_list=[group for group in df_group["group"]]
	radio_hierarchy=RadioGroup(name="Level",labels=["SiteName","County","Group"],active=0)
	select_site=Select(name="name_site",title="Sites",options=site_list,value=site_list[1])
	select_county=Select(name="name_county",title="Count",value=county_list[0],options=county_list,disabled=True)
	select_group=Select(name="name_group",title="Groups",value=group_list[0],options=group_list,disabled=True)
	select_measure=Select(name="name_measure",title="Measure",value=measures_list[0],options=measures_list,disabled=False)
	
	p=figure(plot_width=600,plot_height=800)
	p1=figure(plot_width=600,plot_height=800)

	def print_selected(attr,old,new):
		if new == 0:
			select_site.disabled=False
			select_county.disabled=True
			select_group.disabled=True
		elif new == 1:
			select_site.disabled=True
			select_county.disabled=False
			select_group.disabled=True
		else:
			select_site.disabled=True
			select_county.disabled=True
			select_group.disabled=False
	def plot_figure(attr,old,new):
		measures=measures_list if select_measure.value == 'All' else [select_measure.value]
		if radio_hierarchy.active == 0:
			sites=site_list if select_site.value == 'All' else [select_site.value]
			filt_df = mdf.loc[(mdf["sitename"].isin(sites) ) & ( mdf["measure"].isin(measures)) ].groupby(["for_date"],as_index=False).sum()
		elif radio_hierarchy.active == 1:
			counties=county_list if select_county.value == 'All' else [select_county.value]
			filt_df = mdf.loc[(mdf["county_burrough"].isin(counties) ) & ( mdf["measure"].isin(measures)) ].groupby(["for_date"],as_index=False).sum()
		else:
			groups=group_list if select_group.value == 'All' else [select_group.value]
			filt_df = mdf.loc[(mdf["bus_group"].isin(groups) ) & ( mdf["measure"].isin(measures)) ].groupby(["for_date"],as_index=False).sum()

		filt_df["pct"] = ( filt_df["numerator"].astype(float) / filt_df["denominator"].astype(float)  ) * 100
		filt_df["cob_date"]=filt_df["for_date"].astype(str)
		filt_source=ColumnDataSource(filt_df)
		hover=HoverTool(tooltips=[("Date ","@cob_date"),("Denominator ", "@denominator"),("Numerator ", "@numerator"),("PCT % ", "@pct")])
		p=figure(plot_width=800,plot_height=800,title="Score Card Trend for [Sites] : " + ' [Measures] : ' + measures[0] )
		p.line(x="for_date",y="denominator",line_color="blue",line_width=5,legend=["denominator"],source=filt_source)
		p.circle(x="for_date",y="denominator",color="black",size=0.3,line_width=7,alpha=0.8,source=filt_source)
		p.line(x="for_date",y="numerator",line_color="green",line_width=5,source=filt_source,legend=["numerator"])
		p.circle(x="for_date",y="numerator",color="black",size=0.3,line_width=7,alpha=0.8,source=filt_source)
		p.xaxis.formatter=DatetimeTickFormatter(days=["%D"], months=["%m"],years=["%Y"],)
		p.yaxis.formatter=BasicTickFormatter(use_scientific=False)
		p.legend.location="top_left"
		p.xaxis.major_label_orientation=1.5
		p.add_tools(hover)
		p1=figure(plot_width=800,plot_height=800,title="Score Card Trend for [Sites] : " +  ' [Measures] : ' + measures[0] )	
		p1.line(x="for_date",y="pct",line_color="blue",line_width=5,legend=["Percent"],source=filt_source)
		p1.circle(x="for_date",y="pct",color="black",size=0.3,line_width=7,alpha=0.8,source=filt_source)
		p1.xaxis.formatter=DatetimeTickFormatter(days=["%D"], months=["%m"],years=["%Y"],)
		p1.yaxis.formatter=BasicTickFormatter(use_scientific=False)
		p1.legend.location="top_left"
		p1.add_tools(hover)
		layout.children[5]=row(p,p1)
	radio_hierarchy.on_change("active",print_selected)
	select_site.on_change("value",plot_figure)
	select_county.on_change("value",plot_figure)
	select_group.on_change("value",plot_figure)
	select_measure.on_change("value",plot_figure)
	layout = column(radio_hierarchy,select_site,select_county,select_group,select_measure,row(p,p1))
	#curdoc().add_root(layout)
	return layout
