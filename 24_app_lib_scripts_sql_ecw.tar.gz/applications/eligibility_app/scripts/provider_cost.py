# myapp.py
import pyodbc
conn = pyodbc.connect(dsn="claims_dw")
import pandas as pd

from bokeh.plotting import figure, ColumnDataSource
from bokeh.layouts import column
from bokeh.core.properties import value
from bokeh.models import HoverTool
from bokeh.models.widgets import Select


def cost_by_year():
    top_provider_query = """
    SELECT provider_npi, 
	   provider_full_name, 
	   year 
	   || Lpad(month, 2, '0')                   AS period, 
	   Sum(claim_amount) + Sum(rx_claim_amount) AS total, 
	   Sum(claim_amount)                        AS claim, 
	   Sum(rx_claim_amount)                     AS rx 
    FROM   fact_eligibility AS t1 
	   INNER JOIN dim_provider t2 
		   ON t1.local_provider_id = t2.local_provider_id 
	   INNER JOIN dim_date t3 
		   ON t1.date_id = t3.date_id 
    WHERE  EXISTS (SELECT 1 
		   FROM   (SELECT provider_npi, 
				  Rank() 
				    OVER ( 
				      ORDER BY Sum(claim_amount+rx_claim_amount) 
				    DESC) AS 
				  rnk 
			   FROM   fact_eligibility AS t1 
				  INNER JOIN dim_provider t2 
					  ON t1.local_provider_id = 
					     t2.local_provider_id 
				  INNER JOIN dim_date t3 
					  ON t1.date_id = t3.date_id 
			   WHERE  year = 2018 
			   GROUP  BY provider_npi) AS t4 
		   WHERE  rnk <= 20 
			  AND t2.provider_npi = t4.provider_npi) 
    GROUP  BY provider_npi, 
	      provider_full_name, 
	      period 
    """

    provider_dataframe_all = pd.read_sql(top_provider_query, conn)
    provider_full_name_list = [
        provider_full_name for provider_full_name in sorted(
            set(provider_dataframe_all["provider_full_name"]))
    ]
    select_provider_full_name = Select(
        name="Provider",
        title="Provider",
        options=provider_full_name_list,
        value='Juan Chabla',
    )
    provider_dataframe = provider_dataframe_all[(
        provider_dataframe_all["provider_full_name"] ==
        select_provider_full_name.value)]
    source = ColumnDataSource(provider_dataframe)
    provider_plot = figure(
        x_range=sorted(set(provider_dataframe["period"])),
        y_range=(0, provider_dataframe["total"].max().astype(int)),
        title='Twenty Most Costly Providers of 2018',
        width=800,
        height=800,
        tools=["box_select", "wheel_zoom", "tap"])
    provider_plot.vbar_stack(
        ['claim', 'rx'],
        x='period',
        width=0.9,
        source=source,
        color=['blue', 'green'],
        legend=[value(cost_type) for cost_type in ['claim', 'rx']])
    provider_plot.add_tools(
        HoverTool(
            show_arrow=False,
            line_policy='next',
            tooltips=[("Claim cost", "@claim"), ("Rx cost", "@rx"),
                      ("Total cost", "@total"), ("Period", '@period')]))
    provider_plot.x_range.range_padding = 0.1
    provider_plot.xgrid.grid_line_color = None
    provider_plot.xaxis.major_label_orientation = 1
    provider_plot.axis.minor_tick_line_color = None
    provider_plot.outline_line_color = None
    provider_plot.legend.location = "top_left"
    provider_plot.legend.orientation = "horizontal"
    provider_plot.left[0].formatter.use_scientific = False
    return column(select_provider_full_name, provider_plot)
