# myapp.py
import pyodbc
conn = pyodbc.connect(dsn="claims_dw")
from random import random
import pandas as pd

from bokeh.layouts import column
from bokeh.models import Button
from bokeh.palettes import RdYlBu3
from bokeh.plotting import figure, curdoc


def cost_by_year():
    top_provider_query = """
    SELECT top 1000 provider_npi, 
	   provider_full_name, 
           year || lpad(month,2,'0') as period,
	   Sum(claim_amount) + Sum(rx_claim_amount) AS total, 
	   Sum(claim_amount)                        AS claim, 
	   Sum(rx_claim_amount)                     AS rx 
    FROM   fact_eligibility AS t1 
	   INNER JOIN dim_provider t2 
		   ON t1.local_provider_id = t2.local_provider_id 
	   INNER JOIN dim_date t3 
		   ON t1.date_id = t3.date_id 
    GROUP  BY provider_npi, 
	      provider_full_name, 
	      period
    """

    provider_dataframe = pd.read_sql(top_provider_query, conn)
    provider_plot = figure(
        x_range=list(provider_dataframe["period"]),
        y_range=(0, provider_dataframe["total"].max().astype(int)),
        title='Top 20 Providers by Cost',
        width=600,
        height=600,
        tools=["box_select", "wheel_zoom", "tap"])
    provider_plot.vbar_stack(['claim', 'rx'],
                             x=provider_dataframe['period'],
                             width=0.9,
                             color=['blue', 'green'])

    return column(provider_plot)
