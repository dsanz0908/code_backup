import pyodbc
import pandas as pd
from bokeh.io import curdoc, show, output_notebook
from bokeh.layouts import row, widgetbox, column, gridplot
from bokeh.models.widgets import DataTable, TableColumn, HTMLTemplateFormatter, Panel, Tabs, Select, RadioGroup, Paragraph
from bokeh.plotting import figure, ColumnDataSource
from bokeh.models import Range1d, HoverTool, BoxSelectTool, TapTool, FactorRange
from bokeh.models import DatetimeTickFormatter, BasicTickFormatter
from bokeh.core.properties import value
from bokeh.transform import factor_cmap
from bokeh.palettes import Spectral5
conn = pyodbc.connect(dsn="claims_dw")


def member_cost_tab():
    member_cost_ipa_query = """
    SELECT Split_part(source, ' ', 2)                                                 AS ipa, 
	   year :: VARCHAR, 
	   ( SUM(claim_amount) + SUM(rx_claim_amount) ) / SUM(membership_month_count) AS pmpm 
    FROM   fact_eligibility t1 
	   inner join dim_membership t2 
		   ON t1.local_member_id = t2.local_member_id 
	   inner join dim_date t3 
		   ON t1.date_id = t3.date_id 
    WHERE  Split_part(source, ' ', 1) = 'Healthfirst' 
    GROUP  BY Split_part(source, ' ', 2), 
	      year 
    """

    member_cost_ipa_dataframe = pd.read_sql(member_cost_ipa_query,
                                                conn)
    member_cost_ipa_dataframe = member_cost_ipa_dataframe[
        member_cost_ipa_dataframe.pmpm > 0]
    source = ColumnDataSource(member_cost_ipa_dataframe)
    ipa_year = member_cost_ipa_dataframe.groupby(by=['ipa', 'year'])
    """ipa_year_cmap = factor_cmap(
        'year',
        palette=Spectral5,
        factors=sorted(member_cost_ipa_dataframe.year.unique()), end=1)"""
    year_cmap = factor_cmap(
        'ipa_year',
        palette=Spectral5,
        factors=sorted(member_cost_ipa_dataframe["year"].unique()))

    member_cost_ipa_plot = figure(
        x_range=ipa_year,
        y_range=(member_cost_ipa_dataframe["pmpm"].min(),
                 member_cost_ipa_dataframe["pmpm"].max()),
        title="Average Per Member Per Month (PMPM) at Healthfirst",
        height=400,
        width=400,
        tools=["save"])
    member_cost_ipa_plot.vbar(
        x='ipa',
        top='pmpm',
        width=1,
        source=source,
        line_color='white',
        fill_color=year_cmap)

    member_cost_ipa_plot.x_range.range_padding = 0.05
    member_cost_ipa_plot.xgrid.grid_line_color = None
    member_cost_ipa_plot.xaxis.axis_label = "Independent Practice Association (IPA) by Year"
    member_cost_ipa_plot.outline_line_color = None
    return column(member_cost_ipa_plot)
