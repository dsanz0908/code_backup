# myapp.py
import pyodbc
conn = pyodbc.connect(dsn="claims_dw")
import pandas as pd

from bokeh.plotting import figure, ColumnDataSource
from bokeh.layouts import column
from bokeh.core.properties import value
from bokeh.models import HoverTool
from bokeh.models.widgets import Select


def plot_member_cost():
    top_member_cost_query = """
    SELECT top 1000 source, 
	   t2.provider_npi, 
	   provider_full_name, 
	   hospital_name, 
	   practice_name, 
	   year 
	   || Lpad(month, 2, '0')      AS period, 
	   member_cin, 
	   member_first_name 
	   || ' ' 
	   || member_last_name         AS member_name, 
	   Sum(claim_amount) + Sum(rx_claim_amount)        AS cost,
	   Sum(membership_month_count) AS mm 
    FROM   fact_eligibility AS t1 
	   INNER JOIN dim_provider t2 
		   ON t1.local_provider_id = t2.local_provider_id 
	   INNER JOIN dim_date t3 
		   ON t1.date_id = t3.date_id 
	   INNER JOIN dim_provider_org_detail t4 
		   ON t1.local_provider_org_id = t4.local_provider_org_id 
	   INNER JOIN dim_membership t5 
		   ON t1.local_member_id = t5.local_member_id 
    GROUP  BY source, 
	      t2.provider_npi, 
	      provider_full_name, 
	      hospital_name, 
	      practice_name, 
	      period, 
	      member_cin, 
	      member_name
    """

    member_cost_dataframe_all = pd.read_sql(top_member_cost_query, conn)
    """
    member_cost_full_name_list = [
        member_cost_full_name for member_cost_full_name in sorted(
            set(member_cost_dataframe_all["member_cost_full_name"]))
    ]
    select_member_cost_full_name = Select(
        name="Provider",
        title="Provider",
        options=member_cost_full_name_list,
        value='Juan Chabla',
    )
    member_cost_dataframe = member_cost_dataframe_all[(
        member_cost_dataframe_all["member_cost_full_name"] ==
        select_member_cost_full_name.value)]
    """

    #member_cost_dataframe = member_cost_dataframe_all.groupby(["source", "provider_npi", "provider_full_name", "hospital_name", "practice_name", "period","member_cin", "member_name"],as_index=False).agg({'claim':'sum','rx':'sum'})
    member_cost_dataframe = member_cost_dataframe_all.groupby(["source", "provider_npi", "provider_full_name"],as_index=False).agg({'cost':'sum','mm':'sum'})
    member_cost_dataframe['pmpm'] = member_cost_dataframe['cost'] / member_cost_dataframe['mm']
    print member_cost_dataframe.nlargest(10, 'pmpm')
    """
    source = ColumnDataSource(member_cost_dataframe)
    member_cost_plot = figure(
        x_range=sorted(set(member_cost_dataframe["period"])),
        y_range=(0, member_cost_dataframe["total"].max().astype(int)),
        title='Twenty Most Costly Providers of 2018',
        width=800,
        height=800,
        tools=["box_select", "wheel_zoom", "tap"])
    member_cost_plot.vbar_stack(
        ['claim', 'rx'],
        x='period',
        width=0.9,
        source=source,
        color=['blue', 'green'],
        legend=[value(cost_type) for cost_type in ['claim', 'rx']])
    member_cost_plot.add_tools(
        HoverTool(
            show_arrow=False,
            line_policy='next',
            tooltips=[("Claim cost", "@claim"), ("Rx cost", "@rx"),
                      ("Total cost", "@total"), ("Period", '@period')]))
    member_cost_plot.x_range.range_padding = 0.1
    member_cost_plot.xgrid.grid_line_color = None
    member_cost_plot.xaxis.major_label_orientation = 1
    member_cost_plot.axis.minor_tick_line_color = None
    member_cost_plot.outline_line_color = None
    member_cost_plot.legend.location = "top_left"
    member_cost_plot.legend.orientation = "horizontal"
    member_cost_plot.left[0].formatter.use_scientific = False
    return column(select_member_cost_full_name, member_cost_plot)
    """

plot_member_cost()
