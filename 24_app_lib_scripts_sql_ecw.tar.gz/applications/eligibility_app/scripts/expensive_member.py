import pyodbc
import pandas as pd
from bokeh.io import curdoc, show, output_notebook
from bokeh.layouts import column, widgetbox, gridplot, row
from bokeh.models.widgets import DataTable, TableColumn, HTMLTemplateFormatter, Panel, Tabs, Select, RadioGroup, Paragraph
from bokeh.plotting import figure, ColumnDataSource
from bokeh.models import Range1d, HoverTool, BoxSelectTool, TapTool, FactorRange, Span
from bokeh.models import DatetimeTickFormatter, BasicTickFormatter
from bokeh.core.properties import value
from bokeh.transform import factor_cmap
from bokeh.palettes import Set2, Accent
conn = pyodbc.connect(dsn="claims_dw")


def member_cost_tab():
    plots = [
        create_mci_plot(),
        create_mcm_plot(),
        combine_expensive_provider_plots()
    ]
    return column(plots)


def create_mci_plot():
    member_cost_ipa_query = """
    SELECT Split_part(source, ' ', 2)                                                 AS ipa, 
	   year :: VARCHAR, 
	   ( SUM(claim_amount) + SUM(rx_claim_amount) ) / SUM(membership_month_count) AS pmpm 
    FROM   fact_eligibility t1 
	   inner join dim_membership t2 
		   ON t1.local_member_id = t2.local_member_id 
	   inner join dim_date t3 
		   ON t1.date_id = t3.date_id where  eligibility_ind = 1 and year >= 2017
    GROUP  BY Split_part(source, ' ', 2), 
	      year 
    """

    member_cost_ipa_dataframe = pd.read_sql(member_cost_ipa_query, conn)
    ipa_year = member_cost_ipa_dataframe.groupby(by=['ipa', 'year'])
    source = ColumnDataSource(ipa_year)
    ipa_cmap = factor_cmap(
        'ipa_year',
        palette=Set2[3],
        factors=sorted(member_cost_ipa_dataframe.ipa.unique()),
        end=1)

    member_cost_ipa_plot = figure(
        x_range=ipa_year,
        y_range=(0,
                 member_cost_ipa_dataframe["pmpm"].max() * 1.1),
        title=
        "Average Per Member Per Month (PMPM) by Independent Practice Association (IPA)",
        height=300,
        width=member_cost_ipa_dataframe.shape[0] * 100,
        tools=["save"])
    member_cost_ipa_plot.vbar(
        x='ipa_year',
        top='pmpm_mean',
        width=1,
        source=source,
        line_color="white",
        fill_color=ipa_cmap)
    member_cost_ipa_plot.x_range.range_padding = 0.05
    member_cost_ipa_plot.xgrid.grid_line_color = None
    member_cost_ipa_plot.xaxis.axis_label = "IPA by Year"
    member_cost_ipa_plot.yaxis.axis_label = "PMPM"
    member_cost_ipa_plot.outline_line_color = None
    member_cost_ipa_plot.add_tools(
        HoverTool(
            show_arrow=False,
            line_policy='next',
            tooltips=[("PMPM", "$@pmpm_mean")]))
    member_cost_ipa_plot.axis.minor_tick_line_color = None
    member_cost_ipa_plot.outline_line_color = None
    member_cost_ipa_plot.toolbar.logo = None
    member_cost_ipa_plot.title.align = 'center'
    return member_cost_ipa_plot


def create_mcm_plot():
    member_cost_mco_query = """
    SELECT Split_part(source, ' ', 1)                                                 AS mco, 
	   year :: VARCHAR, 
	   ( SUM(claim_amount) + SUM(rx_claim_amount) ) / SUM(membership_month_count) AS pmpm 
    FROM   fact_eligibility t1 
	   inner join dim_membership t2 
		   ON t1.local_member_id = t2.local_member_id 
	   inner join dim_date t3 
		   ON t1.date_id = t3.date_id where eligibility_ind = 1 and year >= 2017

    GROUP  BY Split_part(source, ' ', 1), 
	      year 
    """

    member_cost_mco_dataframe = pd.read_sql(member_cost_mco_query, conn)
    mco_year = member_cost_mco_dataframe.groupby(by=['mco', 'year'])
    source = ColumnDataSource(mco_year)
    mco_cmap = factor_cmap(
        'mco_year',
        palette=Accent[3],
        factors=sorted(member_cost_mco_dataframe.mco.unique()),
        end=1)

    member_cost_mco_plot = figure(
        x_range=mco_year,
        y_range=(0,
                 member_cost_mco_dataframe["pmpm"].max() * 1.1),
        title="Average PMPM by Managed Care Organization (MCO)",
        height=300,
        width=member_cost_mco_dataframe.shape[0] * 100,
        tools=["save"])
    member_cost_mco_plot.vbar(
        x='mco_year',
        top='pmpm_mean',
        width=1,
        source=source,
        line_color="white",
        fill_color=mco_cmap)
    member_cost_mco_plot.x_range.range_padding = 0.05
    member_cost_mco_plot.xgrid.grid_line_color = None
    member_cost_mco_plot.xaxis.axis_label = "MCO by Year"
    member_cost_mco_plot.yaxis.axis_label = "PMPM"
    member_cost_mco_plot.outline_line_color = None
    member_cost_mco_plot.add_tools(
        HoverTool(
            show_arrow=False,
            line_policy='next',
            tooltips=[("PMPM", "$@pmpm_mean")]))
    member_cost_mco_plot.axis.minor_tick_line_color = None
    member_cost_mco_plot.outline_line_color = None
    member_cost_mco_plot.toolbar.logo = None
    member_cost_mco_plot.title.align = 'center'
    return member_cost_mco_plot


def combine_expensive_provider_plots():
    ep_plots = []
    for year_ in range(2017, 2020):
        ep_plots.append(create_expensive_provider_plot(str(year_)))
    return row(ep_plots)


def create_expensive_provider_plot(year):
    expensive_provider_query = """
    SELECT * 
    FROM   (SELECT *, 
		   Rank() 
		     OVER ( 
		       partition BY year 
		       ORDER BY pmpm desc) 
	    FROM   (SELECT provider_npi, 
			   provider_full_name, 
			   year, 
			   ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS pmpm,
                           sum(membership_month_count) as mm
		    FROM   fact_eligibility t1 
			   INNER JOIN dim_date t3 
				   ON t1.date_id = t3.date_id 
			   INNER JOIN dim_provider t4 
				   ON t1.local_provider_id = t4.local_provider_id 
		    WHERE  year = {} and eligibility_ind = 1
		    GROUP  BY provider_npi, 
			      provider_full_name, 
			      year) 
	    WHERE  pmpm > 0) 
    WHERE  rank <= 10 order by rank desc
    """

    expensive_provider_median_query = """
    SELECT ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS pmpm 
    FROM   fact_eligibility t1 
	   INNER JOIN dim_date t3 
		   ON t1.date_id = t3.date_id 
    WHERE  eligibility_ind = 1 
	   AND year = {} 
    """

    expensive_provider_dataframe = pd.read_sql(
        expensive_provider_query.format(year), conn)
    expensive_provider_median = pd.read_sql(
        expensive_provider_median_query.format(year), conn).at[0,"pmpm"]
    source = ColumnDataSource(expensive_provider_dataframe)
    expensive_provider_plot = figure(
        x_range=(0, expensive_provider_dataframe["pmpm"].max() * 1.1),
        y_range=list(expensive_provider_dataframe["provider_full_name"]),
        title="Top 10 PMPM per Provider in {}".format(year),
        height=300,
        width=500,
        tools=["save"])
    expensive_provider_plot.hbar(
        y='provider_full_name', right='pmpm', height=.5, source=source)

    median = Span(location=expensive_provider_median, dimension='height', line_color='red', line_dash='dashed')
    expensive_provider_plot.add_layout(median)
    expensive_provider_plot.y_range.range_padding = 0.05
    expensive_provider_plot.ygrid.grid_line_color = None
    expensive_provider_plot.xaxis.axis_label = "MCO by Year"
    expensive_provider_plot.xaxis.axis_label = "PMPM"
    expensive_provider_plot.outline_line_color = None
    expensive_provider_plot.add_tools(
        HoverTool(
            show_arrow=False,
            line_policy='next',
            tooltips=[("NPI", "@provider_npi"),("PMPM", "$@pmpm{1.11}"), ("Membership Months", "@mm{1.11}")]))
    expensive_provider_plot.axis.minor_tick_line_color = None
    expensive_provider_plot.outline_line_color = None
    expensive_provider_plot.toolbar.logo = None
    expensive_provider_plot.title.align = 'center'
    expensive_provider_plot.ygrid.grid_line_color = None
    return expensive_provider_plot
