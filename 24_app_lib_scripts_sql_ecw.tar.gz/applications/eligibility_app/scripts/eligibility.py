import pyodbc
import pandas as pd
from bokeh.io import curdoc, show,output_notebook
from bokeh.layouts import row,widgetbox,column,gridplot
from bokeh.models.widgets import DataTable,TableColumn,HTMLTemplateFormatter,Panel,Tabs,Select,RadioGroup, Paragraph
from bokeh.plotting import figure,ColumnDataSource
from bokeh.models import Range1d,HoverTool,BoxSelectTool,TapTool,FactorRange
from bokeh.models import DatetimeTickFormatter,BasicTickFormatter  
from bokeh.core.properties import value
conn=pyodbc.connect(dsn="somos_redshift_1")

def eligibility_tab():
	query="""  select provider_npi,coalesce(provider_tin,provider_npi) as provider_tin,provider_org as provider_org, cast(year as varchar) as year ,month, product,source,
            sum(total_count) as Total, sum(new_count) as New, sum(dropped_count) as Drop, sum(continuity_count) as Continue,
            pcp_name, year || lpad(month,2,'0') as eligibility_period
            from eligibility_fact t1
            INNER join dim_provider t2
            on t1.local_provider_id = t2.local_provider_id
            INNER join dim_date t3
            on t1.date_id = t3.date_id
            INNER join dim_product t4
            on t1.product_id = t4.product_id
            group by provider_npi,provider_tin,provider_org,year,month,pcp_name,product,source
	"""

	q_distinct_provider = """ select distinct pcp_name || '|' || provider_npi as provider_npi from dim_provider t1 
		where exists ( select 1 from eligibility_fact t2 where t1.local_provider_id = t2.local_provider_id) 
		and  provider_npi is not null 
		and provider_npi != ''
		and pcp_name is not null
		order by 1"""

	q_distinct_tin = """ select distinct practice_name || '|' || provider_tin as provider_tin from dim_provider t1 
		where exists ( select 1 from eligibility_fact t2 where t1.local_provider_id = t2.local_provider_id) 
		and provider_tin is not null 
		and provider_tin != ''
		and practice_name is not null
		and practice_name != '' order by 1"""
	q_distinct_source = """ select distinct source  from eligibility_fact t1  order by 1"""
	q_distinct_eligibility_period = """select 'All' AS year
       						union all
       					select DISTINCT cast(YEAR as varchar)
       					FROM DIM_DATE WHERE DATE_ID IN ( SELECT DISTINCT DATE_ID FROM ELIGIBILITY_FACT ) order by 1 """
	q_product="select 'All' AS product union all select distinct product from dim_product order by 1"

	mdf = pd.read_sql(query,conn)  
	df_npi=pd.read_sql(q_distinct_provider,conn)
	df_tin=pd.read_sql(q_distinct_tin,conn)
	df_source=pd.read_sql(q_distinct_source,conn)
	df_period=pd.read_sql(q_distinct_eligibility_period,conn)
	df_product=pd.read_sql(q_product,conn)
	npi_list = [ npi for npi in df_npi["provider_npi"] ]
	tin_list = [ tin for tin in df_tin["provider_tin"] ]
	source_list = [ source for source in df_source["source"] ]
	source_list.append("All")
	period_list=[period for period in df_period["year"]]
	product_list=[product for product in df_product["product"]]
	radio_hierarchy=RadioGroup(name="Level",labels=["NPI","TIN","Source"],active=0)
	select_npi=Select(name="Npi",title="Npi",options=npi_list,value=npi_list[0],disabled=False)
	select_tin=Select(name="Tin",title="Tin",options=tin_list,value=tin_list[0],disabled=True)
	select_period=Select(name="Period",title="Eligibility Period",options=period_list,value=period_list[period_list.index("All")])
	select_product=Select(name="Product",title="Product",options=product_list,value=product_list[product_list.index("All")])
	select_source=Select(name="Source",title="Source",options=source_list,value=source_list[source_list.index("All")],disabled=True)
	p=figure(plot_width=800,plot_height=800)

	def print_selected(attr,old,new):
		if new == 0:
			select_npi.disabled=False
			select_tin.disabled=True
			select_source.disabled=True
		elif new == 1:
			select_npi.disabled=True
			select_tin.disabled=False
			select_source.disabled=True
		else:
			select_npi.disabled=True
			select_tin.disabled=True
			select_source.disabled=False

	def plot_figure(attr,old,new):
		eperiod=period_list if select_period.value == 'All' else [select_period.value]
		product=product_list if select_product.value == 'All' else [select_product.value]
		source=source_list if select_source.value == 'All' else [select_source.value]
		if radio_hierarchy.active == 0:
			level="NPI"
			npi=select_npi.value.split("|")[1]
			level_value=npi
			gdf=mdf[(mdf["provider_npi"] ==npi) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product))].groupby(["provider_npi","eligibility_period"],as_index=False).sum()
			vdf=mdf.loc[(mdf["provider_npi"] ==npi) & (mdf["new"] > 0 ) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product)),["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source","new"]].groupby(["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source"],as_index=False).sum()
			rdf=mdf.loc[(mdf["provider_npi"] ==npi) & (mdf["drop"] < 0 ) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product)),["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source","drop"]].groupby(["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source"],as_index=False).sum()
		elif radio_hierarchy.active == 1:
			level = "TIN"
			tin=select_tin.value.split("|")[1]
			level_value=tin
			gdf=mdf[( mdf["provider_tin"] ==tin ) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product))].groupby(["provider_tin","eligibility_period"],as_index=False).sum()
			vdf=mdf.loc[(mdf["provider_tin"] ==tin) & (mdf["new"] > 0) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product)) ,["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source","new"]].groupby(["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source"],as_index=False).sum()
			rdf=mdf.loc[(mdf["provider_tin"] ==tin) & (mdf["drop"] < 0 ) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product)) ,["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source","drop"]].groupby(["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source"],as_index=False).sum()

		else:
			level = "SOURCE"
			level_value='All' if len(source) > 1 else source[0]
			print(source)
			gdf=mdf[(mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product))].groupby(["eligibility_period"],as_index=False).sum()
			vdf=mdf.loc[(mdf["new"] > 0) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product)) ,["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source","new"]].groupby(["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source"],as_index=False).sum()
			rdf=mdf.loc[(mdf["drop"] < 0 ) & (mdf["source"].isin(source)) & ( mdf["year"].isin(eperiod)) & ( mdf["product"].isin(product)) ,["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source","drop"]].groupby(["eligibility_period","pcp_name","provider_npi","provider_tin","provider_org","source"],as_index=False).sum()
		if len(gdf) == 0:
			print ( "No records satisfying this filter")
		else:
    			rgdf=gdf[gdf["drop"] < 0]
    			source=ColumnDataSource(gdf)
    			rsource=ColumnDataSource(rgdf)
    			min_range=gdf["drop"].min().astype(int)
    			max_range=gdf["continue"].max().astype(int) + gdf["continue"].max().astype(int) *.3
    			stacked=["continue","new"]
    			colors=["blue","green"]
    			e_period=list(gdf["eligibility_period"])
    			p=figure(x_range=e_period,y_range=(min_range,max_range),title="Eligibility period for " + level + " : " + level_value,height=800,width=800,tools=["box_select","wheel_zoom","tap"] )
    			p.vbar_stack(stacked,x='eligibility_period',width=0.9,color=colors,source=source,legend=[value(x) for x in stacked])
    			p.vbar_stack(["drop"],x="eligibility_period",width=0.9,color="red",source=rsource,legend=[value(x) for x in ["drop"]])
    			p.add_tools(HoverTool(show_arrow=False, line_policy='next',tooltips= [ ("New count","@new"),("Dropped count","@drop"),("Continue count","@continue"),("Eligibility Period", '@eligibility_period')]))
	    		#p.y_range.start = -10
    			p.x_range.range_padding = 0.1
    			p.xgrid.grid_line_color = None
 	   		p.xaxis.major_label_orientation = 1
    			p.axis.minor_tick_line_color = None
    			p.outline_line_color = None
	    		p.legend.location = "top_left"
    			p.legend.orientation = "horizontal"
    			vn_source=ColumnDataSource(vdf)
	    		vr_source=ColumnDataSource(rdf)
    			cols=[TableColumn(field="eligibility_period",title="Period"),
                	      TableColumn(field="pcp_name",title="pcp_name") ,
                              TableColumn(field="provider_npi",title="NPI"),
	                      TableColumn(field="provider_tin",title="TIN"),
                    	      TableColumn(field="provider_org",title="Org"),
                    	      TableColumn(field="source",title="Source"),
                    	      TableColumn(field="new",title="New Count"),
                              TableColumn(field="drop",title="Drop Count"),
                    	]
    			dtn=Panel(child=DataTable(source=vn_source,columns=cols,width=800,height=800,sortable=True,fit_columns=False),title="New")
    			dtr=Panel(child=DataTable(source=vr_source,columns=cols,width=800,height=800,sortable=True,fit_columns=False),title="Drop")
    			tabs=Tabs(tabs=[dtn,dtr])
    			layout.children[6]=row(p,tabs)
	radio_hierarchy.on_change("active",print_selected)
	select_npi.on_change("value",plot_figure)
	select_tin.on_change("value",plot_figure)
	select_source.on_change("value",plot_figure)
	select_period.on_change("value",plot_figure)
	select_product.on_change("value",plot_figure)
	layout = child=column(radio_hierarchy,select_npi,select_tin,select_period,select_source,select_product,row(p))
	return layout
	#curdoc().add_root(layout)


