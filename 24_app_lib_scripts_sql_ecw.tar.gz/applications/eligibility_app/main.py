# os methods for manipulating paths
from os.path import dirname, join

# Bokeh basics 
from bokeh.io import curdoc
from bokeh.models.widgets import Tabs,Panel


# Each tab is drawn by one script
from scripts.eligibility import eligibility_tab
from scripts.scorecard import scorecard_tab
from scripts.provider_cost import cost_by_year


# Create each of the tabs
#e_tab = Panel(child=eligibility_tab(),title = 'Eligibility')
m_tab = Panel(child=cost_by_year(),title = 'Provider Breakdown')
#s_tab = Panel(child=scorecard_tab(),title='Scorecard')

# Put all the tabs into one application
#mtabs = Tabs(tabs = [e_tab,s_tab])
mtabs = Tabs(tabs = [m_tab])

# Put the tabs in the current document for display
print(dir(curdoc().session_context.request))
curdoc().add_root(mtabs)
