import dash
import dash_core_components as dcc
import dash_html_components as html
import datetime as dt
import pandas as pd
import numpy as np
import plotly.graph_objs as go
import pyodbc
import csv

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


def smoothTriangle(data, degree, dropVals=False):
    triangle = np.array(
        list(range(degree)) + [degree] + list(range(degree)[::-1])) + 1
    smoothed = []

    for i in range(degree, len(data) - degree * 2):
        point = data[i:i + len(triangle)] * triangle
        smoothed.append(sum(point) / sum(triangle))
    if dropVals:
        return smoothed
    smoothed = [smoothed[0]] * int(degree + degree / 2) + smoothed
    while len(smoothed) < len(data):
        smoothed.append(smoothed[-1])
    return smoothed


AUTOMATED_DAG_RESULT_QUERY = """
SELECT dag_id, 
       start_date, 
       state 
FROM   (SELECT *, 
               Row_number() 
                 over ( 
                   PARTITION BY dag_id, start_date 
                   ORDER BY s DESC) AS rn 
        FROM   (SELECT DISTINCT dag_id, 
                                start_date :: DATE, 
                                state, 
                                CASE 
                                  WHEN state = 'failed' THEN 1 
                                  ELSE 0 
                                END AS s 
                FROM   dag_run 
                WHERE  dag_id LIKE '%ecw%' 
                       AND start_date >= '2018-01-01') AS a) AS b 
WHERE  rn = 1 
"""

END_DAG_RESULT_QUERY = """
SELECT DISTINCT a.dag_id, 
                a.start_date, 
                state 
FROM   (SELECT dag_id, 
               start_date :: DATE, 
               Max(start_date) AS latest_time 
        FROM   dag_run 
        WHERE  dag_id LIKE '%ecw%' and start_date >= '2018-01-01'
        GROUP  BY 1, 
                  2) AS a 
       join (SELECT dag_id, 
                    start_date, 
                    state 
             FROM   dag_run) AS b 
         ON a.dag_id = b.dag_id 
            AND latest_time = b.start_date 
"""


def get_max_encounter_dates(conn_type):
    connection_string = "arcadia_sql_02{};uid=dev-etl;pwd=2aUK*BSy&z295sD"
    connection = pyodbc.connect(dsn=connection_string.format(conn_type))
    databases = get_database_names(connection)
    encounter_dates_df = pd.DataFrame()
    for database in databases:
        try:
            db_df = pd.DataFrame(
                np.array(get_dates(connection, database)), columns=['dates'])
            db_df["database"] = database
            encounter_dates_df = encounter_dates_df.append(db_df)
        except:
            pass
    return encounter_dates_df


def get_database_names(conn):
    database_query = "select name from master..sysdatabases where status = 2163712"
    cursor = conn.execute(database_query)
    database_names = [db[0] for db in cursor.fetchall()]
    cursor.close()
    return database_names


def get_dates(conn, db):
    max_encounter_date_query = """
    SELECT Max(d) 
    FROM   (SELECT CONVERT(DATE, date) AS d, 
		   Count(*)            AS c 
	    FROM   {}.dbo.enc 
	    WHERE  date < Getdate() 
	    GROUP  BY date 
	    HAVING Count(*) > 5) AS a 
    """.format(db)
    cursor = conn.execute(max_encounter_date_query)
    max_encounter = cursor.fetchall()
    cursor.close()
    return [me for me in max_encounter]


ecw_feeds_2012 = get_max_encounter_dates("")
ecw_feeds_2012["version"] = 2012
ecw_feeds_2016 = get_max_encounter_dates("_2016")
ecw_feeds_2016["version"] = 2016
ecw_feeds_2017 = get_max_encounter_dates("_2017")
ecw_feeds_2017["version"] = 2017
ecw_feeds = pd.concat([ecw_feeds_2012, ecw_feeds_2016, ecw_feeds_2017])
ecw_feeds["lag"] = (dt.datetime.today().date() - ecw_feeds["dates"]).dt.days
ecw_lag = ecw_feeds.groupby(['lag']).size().reset_index(name='count')
ecw_lag = ecw_lag.loc[(ecw_lag['lag'] > 0)]
print ecw_feeds

conn_24 = pyodbc.connect(dsn="postgres_24")
conn_67 = pyodbc.connect(dsn="postgres_67")
df = pd.concat([
    pd.read_sql(END_DAG_RESULT_QUERY, conn_24),
    pd.read_sql(END_DAG_RESULT_QUERY, conn_67)
]).groupby(['start_date', 'state']).size().reset_index()

success = df[df["state"] == "success"].sort_values(
    by="start_date").reset_index(drop=True).fillna(0)
failed = df[df["state"] == 'failed'].sort_values(by="start_date").reset_index(
    drop=True).fillna(0)

df2 = pd.concat([
    pd.read_sql(AUTOMATED_DAG_RESULT_QUERY, conn_24),
    pd.read_sql(AUTOMATED_DAG_RESULT_QUERY, conn_67)
]).groupby(['start_date', 'state']).size().reset_index()
automated_success = df2[df2["state"] == "success"].sort_values(
    by="start_date").reset_index(drop=True).fillna(0)

print csv.DictReader(open('20190307_practice_database_mapping.csv')).items()

app.layout = html.Div([
    dcc.Tabs(
        id="tabs",
        children=[
            dcc.Tab(
                label='eCW Dags',
                children=[
                    html.Div([
                        dcc.Graph(
                            id='eCW_dags_success',
                            figure={
                                'data': [
                                    go.Scatter(
                                        x=success.start_date,
                                        y=success[0],
                                        mode='lines',
                                        name='Success',
                                        opacity=1),
                                    go.Scatter(
                                        x=automated_success.start_date,
                                        y=automated_success[0],
                                        mode='lines',
                                        name='Automated Success',
                                        opacity=0.5),
                                    go.Scatter(
                                        x=failed.start_date,
                                        y=failed[0],
                                        line=dict(color='red'),
                                        mode='lines',
                                        name='Failed',
                                        opacity=1)
                                ],
                                'layout':
                                go.Layout(
                                    xaxis={
                                        'rangeselector': {
                                            'buttons':
                                            list([{
                                                'count': 3,
                                                'label': '3M',
                                                'step': 'month',
                                                'stepmode': 'backward'
                                            },
                                                  {
                                                      'count': 6,
                                                      'label': '6M',
                                                      'step': 'month',
                                                      'stepmode': 'backward'
                                                  }, {
                                                      'step': 'all'
                                                  }])
                                        },
                                        'type': 'date'
                                    },
                                    yaxis={
                                        'title': 'eClinicalWorks Dags Success'
                                    },
                                    hovermode='closest')
                            })
                    ])
                ]),
            dcc.Tab(
                label='Lagging eClinicalWorks Practices',
                children=[
                    html.Div([
                        dcc.Graph(
                            id='lagging_ecw_practices',
                            figure={
                                'data': [
                                    go.Scatter(
                                        x=ecw_lag['lag'],
                                        y=ecw_lag['count'],
                                        mode='markers')
                                ],
                                'layout':
                                go.Layout(
                                    xaxis=dict(type='log', autorange=True),
                                    yaxis=dict(autorange=True))
                            })
                    ]),
                ])
        ])
])

if __name__ == '__main__':
    app.run_server(port=7778, host='10.0.10.24')
