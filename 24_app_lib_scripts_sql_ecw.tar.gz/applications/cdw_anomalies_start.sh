#!/bin/bash

fuser -k 7780/tcp;
nohup python $ETL_HOME/applications/cdw_anomalies.py &
exit
