#!/bin/bash

fuser -k 7778/tcp;
nohup python $ETL_HOME/applications/data_lag_report.py &
exit
