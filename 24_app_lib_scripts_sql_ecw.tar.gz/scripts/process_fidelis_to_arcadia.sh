#!/bin/bash
 
cd $ETL_HOME/temp/Fidelis_Somos_to_Arcadia/
export SSHPASS=$ARCADIATOFID_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/arcadia.sftp $ARCADIATOFID_FTP@sftp.arcadiaanalytics.com
