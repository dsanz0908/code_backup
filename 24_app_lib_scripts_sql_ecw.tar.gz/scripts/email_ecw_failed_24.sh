#!/bin/bash
today=`date '+%Y-%m-%d'`
grep -irl 'backup set begins' /data/airflow/logs/ecw_* | grep $today 

#while read line
#do
#feed=`echo $line | awk -F'_' '{print $2}' | tr '[:lower:]' '[:upper:]' | sed 's/^MY/NY/g'`
#error=`echo $line | grep -oh "The log .*restored"`
#echo "$feed: $error."
#done | sed 's/*//g' | sort -u
