#!/bin/bash
today=`date '+%Y-%m-%d'`

grep -ir 'backup set begins' /data/airflow/logs/ecw_* | grep $today  |
while read line
do
feed=`echo $line | awk -F'_' '{print $2}' | tr '[:lower:]' '[:upper:]' | sed 's/^MY/NY/g'`
error=`echo $line | grep -oh "The log .*restored"`
echo "$feed: $error."
done | sed 's/*//g' | sort -u > ${today}_24.txt

aws s3 cp ${today}_24.txt s3://sftp_test/ecw_lag/
aws s3 cp s3://sftp_test/ecw_lag/${today}_67.txt .

text=`cat ${today}_24.txt ${today}_67.txt`
if [ ! -z "$text" ]
then
    echo $text | mail -s "Somos/Optimus Lag - ${today}" dsanz@somoscommunitycare.org
fi

rm ${today}_24.txt 
rm ${today}_67.txt
