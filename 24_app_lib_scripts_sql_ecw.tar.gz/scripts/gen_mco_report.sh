#!/bin/bash
source /home/ssundararaman/anaconda3/bin/activate
python --version
cd $ETL_HOME/lib
python mco_rawdata_comp.py
cp $ETL_HOME/Reports/mco_raw_data_status.html /var/www/html/.
