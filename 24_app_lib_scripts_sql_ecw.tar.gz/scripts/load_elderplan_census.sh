#!/bin/bash
set -x
OIFS="$IFS"
IFS=$'\n'

export SSHPASS=$ELDERPLAN_PW
today=$(date '+%m.%d.%Y')

rm "$ETL_HOME"/downloads/elderplan_census/*
printf "cd /Out/Reports\nlcd /home/etl/etl_home/downloads/elderplan_census/\nget *${today}*" > downloaded_elderplan_census_files.sftp
sshpass -e sftp -o BatchMode=no -b downloaded_elderplan_census_files.sftp $ELDERPLAN_USER@$ELDERPLAN_FTP
cd "$ETL_HOME"/downloads/elderplan_census/
ps -ef | grep libreoffice | grep -v color | awk '{print $2}' | xargs kill -9
libreoffice --headless --convert-to csv  $ETL_HOME/downloads/elderplan_census/BalCns_$today.xlsx
aws s3 cp BalCns_$today.csv s3://acp-data/census/elderplan/
echo "create temp table staging_elderplan (" > $ETL_HOME/sql/elderplan_census_load.sql
head -1 BalCns_$today.csv | sed 's/ /_/g' | sed 's/\//_/g' | sed 's/,/ varchar(255),\n/g' >> $ETL_HOME/sql/elderplan_census_load.sql
echo " varchar(255)); copy staging_elderplan from 's3://acp-data/census/elderplan/BalCns_$today.csv' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter ',' removequotes; delete from payor.elderplan_census where filename = 'BalCns_$today.csv'; insert into payor.elderplan_census select *, 'BalCns_$today.csv' from staging_elderplan; " >> $ETL_HOME/sql/elderplan_census_load.sql
bash $ETL_HOME/scripts/ipsql.sh elderplan_census_load.sql

echo "unload (\$\$ SELECT * FROM   (SELECT *, Row_number() OVER ( partition BY memberid, facility_provider_name, To_date(actual_admit_date, 'MM/DD/YYYY') ORDER BY added_tz) AS rn FROM   payor.elderplan_census) WHERE  rn = 1 AND filename = 'BalCns_$today.csv' \$\$) to 's3://sftp_test/${today}_elderplan_census_new_patients' delimiter ',' addquotes parallel off ALLOWOVERWRITE iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'" > $ETL_HOME/sql/elderplan_census_unload.sql
bash $ETL_HOME/scripts/ipsql.sh elderplan_census_unload.sql
aws s3 cp s3://sftp_test/${today}_elderplan_census_new_patients000 $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.csv
if [ ! -s $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.csv ]; then
  echo "No new patients from Elderplan Census for ${today} from Somos/Optimus"| mail -s "Elderplan Census" nlopez@somoscommunitycare.org,ireyes@rapidcaresolution.com,ibarra@rapidcaresolution.com
else
  sed -i '1s/^/last_name,first_name,dob,lob,auth_number,facility_provider_name,diagnosis_code_desc,actual_admit_date,actual_discharge_date,memberid,ipaname,pcp_npi,pcp_name,member_address1,member_city,member_state,member_zip,member_phone,filename,added_tz,modified_tz,rn\n/' $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.csv
  zip -j --password Balance321 $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.zip $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.csv
  aws s3 cp $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.zip s3://sftp_test/${today}_elderplan_census_new_patients.zip
  aws s3 rm s3://sftp_test/${today}_elderplan_census_new_patients000
  rm $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.csv
  echo "New Patients from Elderplan Census for ${today} from Somos/Optimus"| mail -s "Elderplan Census" -a $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.zip nlopez@somoscommunitycare.org,ireyes@rapidcaresolution.com,ibarra@rapidcaresolution.com

  rm $ETL_HOME/downloads/elderplan_census/${today}_elderplan_census_new_patients.zip
fi

