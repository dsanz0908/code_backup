#!/bin/bash

filename="PCPRoster_(CORINTHIPA)_06_01_2019.csv"
columns=`head -1 "${ETL_HOME}/temp/${filename}" | tr '[:upper:]' '[:lower:]'`
table_name="payor.affinity_corinthian_all_rosters"
echo "drop table if exists staging_affinity;" > $ETL_HOME/sql/affinity_temp.sql
echo "create temp table if not exists staging_affinity ( " >> $ETL_HOME/sql/affinity_temp.sql

echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" >> $ETL_HOME/sql/affinity_temp.sql

echo 'VARCHAR(255));' >> $ETL_HOME/sql/affinity_temp.sql
echo "grant all on staging_affinity to etluser;" >> $ETL_HOME/sql/affinity_temp.sql
echo "copy staging_affinity from 's3://acp-data/Affinity/Corinthian/${filename}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;" >> $ETL_HOME/sql/affinity_temp.sql
echo "delete from ${table_name} where filename = '${filename}';" >> $ETL_HOME/sql/affinity_temp.sql
echo "insert into ${table_name} (${sql_columns}, filename, received_month) select ${sql_columns}, '${filename}', ${yearmonth} from staging_affinity;" >> $ETL_HOME/sql/affinity_temp.sql

