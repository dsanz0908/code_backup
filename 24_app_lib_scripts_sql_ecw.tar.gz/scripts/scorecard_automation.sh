#!/bin/bash
set -x
#export PYTHONPATH=/usr/lib64/python2.7/site-packages
source /home/ssundararaman/anaconda3/bin/activate
python $ETL_HOME/lib/scorecard_automation.py
python $ETL_HOME/lib/scorecard_LBPImagingForLowBackPain.py
