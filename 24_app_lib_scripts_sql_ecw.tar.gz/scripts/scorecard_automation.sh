#!/bin/bash
export PYTHONPATH=/usr/lib64/python2.7/site-packages
python $ETL_HOME/lib/scorecard_automation.py
