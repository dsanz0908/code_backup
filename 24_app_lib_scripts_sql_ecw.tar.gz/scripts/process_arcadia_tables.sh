#!/bin/bash
set -x
table_name=$1
month=$2
ls $ETL_HOME/input/$month*.csv | grep -i ${table_name} > $ETL_HOME/temp/${table_name}_files.txt
grep -v "^#" $ETL_HOME/temp/${table_name}_files.txt |
while read filename
do
filename_without_dir=`echo $filename | awk -F"/" ' { print $6} '`
echo "Processing file $filename_without_dir"
columns=`head -1 $filename`
echo "create table if not exists arcadia.${table_name} (" > $ETL_HOME/temp/columns.sql
echo $columns | sed -e "s/,/ VARCHAR(255),\\n/g" | sed -e "s/\r/ VARCHAR(255),/" >> $ETL_HOME/temp/columns.sql
echo "ARCADIA_TO_SOMOS_FILENAME VARCHAR(255) ); grant all on arcadia.${table_name} to etluser;" >> $ETL_HOME/temp/columns.sql
sed -e "s/\r/,\"${filename_without_dir}\"/" ${filename} > $ETL_HOME/temp/${filename_without_dir}
aws s3 cp $ETL_HOME/temp/${filename_without_dir} s3://acp-data/Arcadia/Incoming/$filename_without_dir --sse AES256
sed -e "s/FILENAME/${filename_without_dir}/" $ETL_HOME/sql/arcadia_load_template.sql | sed -e "s/TABLENAME/${table_name}/" > $ETL_HOME/sql/arcadia_${table_name}.sql
mv $ETL_HOME/temp/columns.sql $ETL_HOME/sql/.
$ETL_HOME/scripts/ipsql.sh columns.sql
$ETL_HOME/scripts/ipsql.sh arcadia_${table_name}.sql
rm -f $ETL_HOME/temp/${filename_without_dir}
done
rm -f $ETL_HOME/temp/${table_name}_files.txt
