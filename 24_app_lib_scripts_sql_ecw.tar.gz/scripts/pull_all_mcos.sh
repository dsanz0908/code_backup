#!/bin/bash

bash $ETL_HOME/scripts/grab_latest_affinity_somos_roster.sh
bash $ETL_HOME/scripts/grab_latest_affinity_corinthian_roster.sh
bash $ETL_HOME/scripts/run_missing_mco_month.sh received_month empire_somos_claim_det $ETL_HOME/scripts/load_empire_somos_zipfiles.sh
bash $ETL_HOME/scripts/run_missing_mco_month.sh received_month empire_bcbs_healthplus_legacy_all_claims_oldformat $ETL_HOME/scripts/anthem_corinthian_load.sh
bash $ETL_HOME/scripts/run_missing_mco_month_hf.sh SOMOS
bash $ETL_HOME/scripts/run_missing_mco_month_hf.sh CORINTHIAN
bash $ETL_HOME/scripts/run_missing_mco_month_hf.sh EXCELSIOR
#bash $ETL_HOME/scripts/run_missing_mco_month.sh received_month uhc_somos_all_membership $ETL_HOME/scripts/uhc_somos_load.sh
bash $ETL_HOME/scripts/run_wellcare_legacy.sh
bash $ETL_HOME/scripts/run_wellcare_somos.sh
