#!/bin/bash
OIFS="$IFS"
IFS=$'\n'

export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month}
sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/uhc_somos_to_arcadia_template.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/uhc_somos_to_arcadia.sql
$ETL_HOME/scripts/ipsql.sh uhc_somos_to_arcadia.sql
rm $ETL_HOME/temp/UHC_Somos/*

aws s3 cp s3://acp-data/Arcadia/Outgoing/uhc/uhc_somos_eligibility_${delim_value}_000.gz $ETL_HOME/temp/UHC_Somos/. --sse AES256
aws s3 cp s3://acp-data/Arcadia/Outgoing/uhc/uhc_somos_claims_${delim_value}_000.gz $ETL_HOME/temp/UHC_Somos/. --sse AES256
#aws s3 cp s3://acp-data/Arcadia/Outgoing/uhc/uhc_somos_eligibility_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/ --sse AES256
#aws s3 cp s3://acp-data/Arcadia/Outgoing/uhc/uhc_somos_claims_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/ --sse AES256

cd $ETL_HOME/temp/UHC_Somos/
cp uhc_somos_eligibility_${delim_value}_000.gz ELIG_UHC_SOM_${for_month}.gz
cp uhc_somos_claims_${delim_value}_000.gz CLAIM_UHC_SOM_${for_month}.gz
export SSHPASS=$GARAGE_SFTP_PW
printf "cd /Files/United/\nmput *UHC*\nls *" > to_garage.sftp

sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/UHC_Somos/uhc_somos_eligibility_${delim_value}_000.gz
rm $ETL_HOME/temp/UHC_Somos/uhc_somos_eligibility_${delim_value}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/UHC_Somos/uhc_somos_claims_${delim_value}_000.gz
rm $ETL_HOME/temp/UHC_Somos/uhc_somos_claims_${delim_value}_000.gz

export SSHPASS=$ARCADIAUNITED_SH
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/arcadia.sftp $ARCADIAUNITED_FTP@sftp.arcadiaanalytics.com


#printf "UHC Somos files for the month of ${for_month} were dropped on $(date +%m)/$(date +%d)/$(date +%y) at s3://garage-s3/United Healthcare/\n\nThe following files were dropped:\nuhc_somos_eligibility_${delim_value}_000.gz\nuhc_somos_claims_${delim_value}_000.gz\n" | mail -s "UHC to Garage file drop" dsanz@somoscommunitycare.org,mwade@somoscommunitycare.org,ssundararaman@somoscommunitycare.org alexc@thegaragein.com,pmarrett@thegaragein.com,nrobeson@thegaragein.com,mkordit@thegaragein.com,bmccreary@thegaragein.com

