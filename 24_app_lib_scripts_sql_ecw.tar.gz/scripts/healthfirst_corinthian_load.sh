#!/bin/bash
export sftp_yearmonth=$1
export sql_yearmonth=$2
# EXAMPLE: `./healthfirst_corinthian_load.sh DEC2018 201812`

export SSHPASS=$HF_CORINTHIAN_PW
cd $ETL_HOME/downloads/Healthfirst_Corinthian/
rm $ETL_HOME/downloads/Healthfirst_Corinthian/*
printf "cd /corinthianmed/From\ HF\nlcd /data/downloads/Healthfirst_Corinthian\nmget *${sftp_yearmonth}*\n" > healthfirst_corinthian.sftp
sshpass -e sftp -o BatchMode=no -b healthfirst_corinthian.sftp $HF_CORINTHIAN_USER@$HF_CORINTHIAN_FTP
rm healthfirst_corinthian.sftp

ls *${sftp_yearmonth}*txt > $ETL_HOME/scripts/Healthfirst_Corinthian_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/Healthfirst_Corinthian_to_s3.txt |
while read filename
do
aws s3 cp ${filename} s3://acp-data/Healthfirst/Corinthian/${filename} --sse AES256
done

#sed -e "s/\\$//g" -e "s/*//g" -e "s/†//g" -e "s/,//g" /data/downloads/Healthfirst_Corinthian/ANA07701_CORINTHIAN_${sftp_yearmonth}_DTL_PHARMACY.txt > $ETL_HOME/downloads/Healthfirst_Corinthian/ANA07701_CORINTHIAN_${sftp_yearmonth}_DTL_PHARMACY_1.txt
#aws s3 cp $ETL_HOME/downloads/Healthfirst_Corinthian/ANA07701_CORINTHIAN_${sftp_yearmonth}_DTL_PHARMACY_1.txt s3://acp-data/Healthfirst/Corinthian/ANA07701_CORINTHIAN_${sftp_yearmonth}_DTL_PHARMACY_1.txt --sse AES256
sed -e "s/YRMNTH/${sql_yearmonth}/g" -e "s/SFTPYEARMONTH/${sftp_yearmonth}/g" $ETL_HOME/sql/healthfirst_corinthian_load_template.sql > $ETL_HOME/sql/healthfirst_corinthian_load.sql
$ETL_HOME/scripts/ipsql.sh healthfirst_corinthian_load.sql
