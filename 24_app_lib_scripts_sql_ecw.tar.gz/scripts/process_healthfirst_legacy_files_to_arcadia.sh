#!/bin/bash
OIFS="$IFS"
IFS=$'\n'

export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month} 
sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/healthfirst_legacy_to_arcadia_eligibility_template.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/healthfirst_legacy_to_arcadia.sql
$ETL_HOME/scripts/ipsql.sh healthfirst_legacy_to_arcadia.sql
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_eligibility_${delim_value}_000.gz $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_eligibility_${delim_value}_000.gz
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_claims_${delim_value}_000.gz $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_claims_${delim_value}_000.gz
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_pharmacy_${delim_value}_000.gz $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_pharmacy_${delim_value}_000.gz
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_eligibility_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/healthfirst_corinthian_eligibility_${delim_value}_000.gz --sse AES256
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_claims_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/healthfirst_corinthian_claims_${delim_value}_000.gz --sse AES256
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_pharmacy_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/healthfirst_corinthian_pharmacy_${delim_value}_000.gz --sse AES256
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_eligibility_${delim_value}_000.gz s3://garage-s3/Healthfirst/healthfirst_corinthian_eligibility_${delim_value}_000.gz --sse AES256
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_claims_${delim_value}_000.gz s3://garage-s3/Healthfirst/healthfirst_corinthian_claims_${delim_value}_000.gz --sse AES256
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_pharmacy_${delim_value}_000.gz s3://garage-s3/Healthfirst/healthfirst_corinthian_pharmacy_${delim_value}_000.gz --sse AES256
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_eligibility_${delim_value}_000.gz
rm $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_eligibility_${delim_value}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_claims_${delim_value}_000.gz
rm $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_claims_${delim_value}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_pharmacy_${delim_value}_000.gz
rm $ETL_HOME/temp/Healthfirst_Corinthian/healthfirst_corinthian_pharmacy_${delim_value}_000.gz

cd $ETL_HOME/temp/Healthfirst_Corinthian/
export SSHPASS=$ARCADIAHEALTHFIRST_SH
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/arcadia.sftp $ARCADIAHEALTHFIRST_FTP@sftp.arcadiaanalytics.com

export SSHPASS=$GARAGE_SFTP_PW
printf "cd /Files/\nmput *\nls *" > to_garage.sftp
sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP

rm $ETL_HOME/temp/Healthfirst_Corinthian/*

#echo "Healthfirst Corinthian files for the month of ${for_month} were dropped on $(date +%m)/$(date +%d)/$(date +%y) at s3://garage-s3/Healthfirst/" | mail -s "Healthfirst to Garage file drop" -c dsanz@somoscommunitycare.org,mwade@somoscommunitycare.org,ssundararaman@somoscommunitycare.org alexc@thegaragein.com,pmarrett@thegaragein.com,nrobeson@thegaragein.com,mkordit@thegaragein.com,bmccreary@thegaragein.com

