#!/bin/bash
set -x
RECEIVED_MONTH_FIELD=$1

last_month_template="date --date='-MONTHS_TO_SUBTRACT month' +'%Y%m'"

echo "SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(period), 'YYYYMM')) AS INT) FROM payor.affinity_somos_roster_all" > $ETL_HOME/sql/get_mco_missing_months.sql
mco_missing_months=`$ETL_HOME/scripts/ipsql.sh get_mco_missing_months.sql | head -3 | tail -1 | awk '{$1=$1};1'`

for i in `seq 1 ${mco_missing_months}`
do
  month_command=`echo ""${last_month_template} | sed "s/MONTHS_TO_SUBTRACT/${i}/g"""`
  month_to_process=`eval ${month_command}`
  filename="PCPRoster_(SOMOS)_${month_to_process: -2}_01_${month_to_process:0:4}"
  eval "python $ETL_HOME/lib/grab_affinity_somos_roster.py ${month_to_process}"
  ps -ef | grep libreoffice | grep -v color | awk '{print $2}' | xargs kill -9
  libreoffice --headless --convert-to csv --outdir $ETL_HOME/temp/ $ETL_HOME/temp/${filename}.xlsx
  aws s3 cp $ETL_HOME/temp/${filename}.csv s3://acp-data/Affinity/SOMOS/ --sse AES256
  columns="'$(head -1 "${ETL_HOME}/temp/${filename}" | tr '[:upper:]' '[:lower:]' | sed 's/ /_/g' | sed 's/*//g' | sed "s/,/\',\'/g")'"
  echo "select 'drop table if exists staging_affinity; create temp table if not exists staging_affinity (' || listagg(raw_column || ' ' || column_data_type, ', ') within group (order by id) || ');' from (select * from payor.mco_table_column_reference where mco = 'Affinity' and ipa = 'Somos' and file_type = 'Roster' and raw_column in (${columns}) order by id)" > "$ETL_HOME"/sql/affinity_load_temp.sql
  "$ETL_HOME"/scripts/ipsql.sh affinity_load_temp.sql | sed -n '3p' > "$ETL_HOME"/sql/affinity_load.sql
  echo "grant all on staging_affinity to etluser; copy staging_affinity from 's3://acp-data/Affinity/SOMOS/${filename}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv; delete from payor.affinity_somos_roster_all where filename = '${filename}';" >> "$ETL_HOME"/sql/affinity_load.sql
  echo "select listagg(query, ' ') from (SELECT 'insert into payor.affinity_somos_roster_all (' || listagg(table_column, ',') within group (order by id) || ',filename,period)' as query FROM payor.mco_table_column_reference WHERE mco = 'Affinity' AND ipa = 'Somos' AND file_type = 'Roster' AND raw_column IN (${columns} ) union select 'select ' || listagg(raw_column, ',') within group (order by id) || ',''${filename}'', ''${month_to_process}'' from staging_affinity' FROM payor.mco_table_column_reference WHERE mco = 'Affinity' AND ipa = 'Somos' AND file_type = 'Roster' AND raw_column IN (${columns} ))" > "$ETL_HOME"/sql/affinity_load_temp.sql
  "$ETL_HOME"/scripts/ipsql.sh affinity_load_temp.sql | sed -n '3p' >> "$ETL_HOME"/sql/affinity_load.sql
  rm ETL_HOME/sql/affinity_load_temp.sql
  rm ETL_HOME/sql/affinity_load.sql
done

