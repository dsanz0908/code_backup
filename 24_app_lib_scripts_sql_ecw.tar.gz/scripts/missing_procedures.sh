#!/bin/bash

sudo sqlcmd -S 10.254.232.106,1433 -U ACPPS_ClientAccess -P 490qXXAAt6zsSvFL -d acpps_warehouse_prd01 -i $ETL_HOME/sql/missing_healthfirst_procedures_arcadia.sql -o $ETL_HOME/temp/missing_healthfirst_procedures_arcadia.txt -h-1 -W -w 999 -s"|"
sudo sqlcmd -S 10.254.232.106,1433 -U ACPPS_ClientAccess -P 490qXXAAt6zsSvFL -d acpps_warehouse_prd01 -i $ETL_HOME/sql/missing_wellcare_procedures_arcadia.sql -o $ETL_HOME/temp/missing_wellcare_procedures_arcadia.txt -h-1 -W -w 999 -s"|"
aws s3 cp $ETL_HOME/temp/missing_healthfirst_procedures_arcadia.txt s3://sftp_test/
aws s3 cp $ETL_HOME/temp/missing_wellcare_procedures_arcadia.txt s3://sftp_test/

