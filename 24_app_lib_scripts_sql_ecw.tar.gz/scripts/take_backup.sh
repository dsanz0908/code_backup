#!/bin/bash

cd $ETL_HOME
tar -czf $ETL_HOME/24_app_lib_scripts_sql_ecw.tar.gz applications lib sql scripts ~/sftp_pipeline/*py
tar -czf $ETL_HOME/24_dags.tar.gz ~/airflow/dags/*py
tar -czf $ETL_HOME/24_config_files.tar.gz ~/.bashrc ~/.odbc.ini /etc/httpd/
git add $ETL_HOME/24*
git commit -m "`date`"
git push origin master
