#!/bin/bash
cd /home/etl/etl_home/temp/DY3_Unprocessed/
rm /home/etl/etl_home/temp/dy3_unprocessed_files_1.txt
ls /home/etl/etl_home/temp/DY3_Unprocessed/ > /home/etl/etl_home/temp/dy3_unprocessed_files_1.txt 
grep -iv "^#" /home/etl/etl_home/temp/dy3_unprocessed_files_1.txt |
while read filename
do
aws s3 cp "$filename" "s3://engagement-reporting/DY3/$filename" --sse AES256 
done
