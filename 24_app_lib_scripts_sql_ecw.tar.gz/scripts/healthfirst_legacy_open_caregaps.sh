#!/bin/bash
month_to_check=$1
today=`date '+%Y%m%d'`;
sed -e "s/MONTH_TO_CHECK/${month_to_check}/g" -e "s/TODAY/${today}/g" $ETL_HOME/sql/healthfirst_legacy_open_caregaps_template.sql > $ETL_HOME/sql/healthfirst_legacy_open_caregaps.sql
./ipsql.sh healthfirst_legacy_open_caregaps.sql
