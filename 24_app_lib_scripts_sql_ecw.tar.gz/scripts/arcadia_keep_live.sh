#!/bin/bash

python $ETL_HOME/lib/arcadia_keep_live.py
