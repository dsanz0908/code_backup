#!/bin/bash
set -x
export SSHPASS=$EMPIRE_SOMOS_PW
export receivedmonth=$1
rm -f $ETL_HOME/scripts/Empire_to_s3.txt
rm -f $ETL_HOME/downloads/Empire_Somos/*
printf "cd /Somos/Amerigroup_Sftp/Outbound\nlcd /data/downloads/Empire_Somos/\nget *${receivedmonth}.TXT" > Empire_to_s3.sftp
sshpass -e sftp -o BatchMode=no -b Empire_to_s3.sftp Somos@ftp2.amerigroup.com
ls $ETL_HOME/downloads/Empire_Somos/ > Empire_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/Empire_to_s3.txt |
while read filename
do
sed -e "s/\\$//g" -e "s/*//g" -e "s/†//g" -e '1s/^\xEF\xBB\xBF//' $ETL_HOME/downloads/Empire_Somos/$filename > $ETL_HOME/downloads/Empire_Somos/${filename}_1
aws s3 cp $ETL_HOME/downloads/Empire_Somos/${filename}_1 s3://acp-data/Anthem/Somos/$filename --sse AES256
cd $ETL_HOME/downloads/Empire_Somos/
filetype=`echo $filename  | awk -F '_' '{print $4}'`
if [ "$filetype" == "Enrollment" ] ||  [ "$filetype" == "MEDICAL" ] ||  [ "$filetype" == "RX" ]
then
columns=`head -1 $filename`
echo "create temp table if not exists staging_empire_somos_${filetype} ( " > $ETL_HOME/sql/Empire_Somos_${filetype}.sql

# FOR THE LINE BELOW, THE SED COMMAND: THIRD REPLACEMENT (turning comma to varchar) may need to be replaced by space (or something else) when dealing with space delimited files
echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/ / VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" -e "s/Service_Code_Description VARCHAR(255)/Service_Code_Description VARCHAR(300)/g" >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql

echo "grant all on staging_empire_somos_${filetype} to etluser;" >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql
echo "copy staging_empire_somos_${filetype} from 's3://acp-data/Anthem/Somos/${filename}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter ' ' removequotes;" >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql
cd $ETL_HOME/scripts/

$ETL_HOME/scripts/ipsql.sh Empire_${filetype}_automation.sql > $ETL_HOME/sql/Empire_${filetype}_query1.sql

master_table=`$ETL_HOME/scripts/ipsql.sh Empire_Somos_${filetype}_master_table.sql | sed -n '3p'`
echo "delete from ${master_table} where filename = '${filename}';" >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql
echo "insert into ${master_table} ( " >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql
grep -iv "^-" $ETL_HOME/sql/Empire_${filetype}_query1.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" | sed -e "$ s/.$//" >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql
echo ")" >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql
$ETL_HOME/scripts/ipsql.sh Empire_${filetype}_automation_1.sql > $ETL_HOME/sql/Empire_${filetype}_query2.sql
echo "select " > $ETL_HOME/sql/Empire_${filetype}_query2_1.sql
grep -iv "^-" $ETL_HOME/sql/Empire_${filetype}_query2.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" | sed -e "s/FILENAME/${filename}/g" -e "s/RECEIVEDMONTH/\'${receivedmonth}\'/g" | sed -e "$ s/.$//" >> $ETL_HOME/sql/Empire_${filetype}_query2_1.sql
echo "from staging_empire_somos_${filetype};" >> $ETL_HOME/sql/Empire_${filetype}_query2_1.sql
cat $ETL_HOME/sql/Empire_${filetype}_query2_1.sql >> $ETL_HOME/sql/Empire_Somos_${filetype}.sql
$ETL_HOME/scripts/ipsql.sh Empire_Somos_${filetype}.sql

rm $ETL_HOME/sql/Empire_Somos_${filetype}.sql
rm $ETL_HOME/sql/Empire_${filetype}_query1.sql
rm $ETL_HOME/sql/Empire_${filetype}_query2.sql
rm $ETL_HOME/sql/Empire_${filetype}_query2_1.sql
fi
done

echo "select count(*) from payor.empire_bcbs_healthplus_somos_all_roster where received_month = '${receivedmonth}'" > $ETL_HOME/sql/empire_somos_receivedmonth_count.sql
receivedmonth_count=`$ETL_HOME/scripts/ipsql.sh empire_somos_receivedmonth_count.sql | sed -n '3p'`
if (( ${receivedmonth_count} > 0 )); then
  bash process_empire_somos_to_arcadia.sh ${receivedmonth}
fi
