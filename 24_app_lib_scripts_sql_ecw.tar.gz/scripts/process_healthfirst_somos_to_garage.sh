#!/bin/bash

export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month}
#sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/healthfirst_somos_to_garage_template.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/healthfirst_somos_to_garage.sql
$ETL_HOME/scripts/ipsql.sh healthfirst_somos_to_garage.sql
