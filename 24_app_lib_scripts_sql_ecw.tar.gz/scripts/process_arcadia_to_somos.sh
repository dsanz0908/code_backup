#!/bin/bash
set -x
export SSHPASS=$ARCADIATOSOMOS_SH
rm -f $ETL_HOME/arcadiatosomos_files.txt
rm -f $ETL_HOME/downloads/arcadia_comprehensive/*.csv
sshpass -e sftp -o BatchMode=no -b arcadia_to_somos.sftp $ARCADIATOSOMOS_FTP@sftp.arcadiaanalytics.com
ls $ETL_HOME/downloads/arcadia_comprehensive/*.csv > $ETL_HOME/scripts/arcadiatosomos_files.txt
grep -iv "^#" $ETL_HOME/scripts/arcadiatosomos_files.txt |
while read filename
do
echo "Decrpting $filename"
o_file=`echo $filename | awk -F"/" '{ print $7 }'`
if [ ! -f $ETL_HOME/input/$o_file ]
then
echo $ARCADIATOSOMOS_GP | gpg --batch --yes  --passphrase-fd 0 -o $ETL_HOME/input/$o_file $filename
fi
done
shpass -e sftp -o BatchMode=no -b archive.sftp $ARCADIATOSOMOS_FTP@sftp.arcadiaanalytics.com

