#!/bin/bash
sqlcmd -S 10.254.232.106,1433 -U ACPPS_ClientAccess -P 490qXXAAt6zsSvFL -d acpps_warehouse_prd01 -i $ETL_HOME/sql/get_direct_cin_match.sql -o /home/etl/etl_home/temp/get_direct_cin_match.txt -h-1 -W -w 999 -s"|"
