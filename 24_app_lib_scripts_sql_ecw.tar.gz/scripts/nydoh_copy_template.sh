#!/bin/bash
rm -r /data/nydoh/TOPERIOD
aws s3 cp s3://acp-nydoh/TOPERIOD /data/nydoh/TOPERIOD --recursive
ls /data/nydoh/TOPERIOD/*.pgp > list.txt
rm -r $ETL_HOME/output/TOPERIOD/
mkdir $ETL_HOME/output/TOPERIOD/
grep -iv "^#" list.txt |
while read filename
do
claims=`echo $filename | grep "MAPPAS0014"`
pharmacy_claims=`echo $filename | grep "MAPPAS0021"`
#echo $pharmacy_claims
shred=`echo $filename | grep "MAPPAS0018"`
#echo $shred
roster=`echo $filename | grep "MAPPAS0012"`
#echo $roster
patient_alert=`echo $filename | grep "MAPPAS0022"`
#echo $patient_alert
cpa=`echo $filename | grep "CPA"`
#echo $cpa
if [  "$claims"  ]
then
        echo "" | gpg --output $ETL_HOME/output/TOPERIOD/claims.gz --batch --yes  --passphrase-fd 0 $claims
        gunzip $ETL_HOME/output/TOPERIOD/claims.gz
        mv $ETL_HOME/output/TOPERIOD/claims $ETL_HOME/output/TOPERIOD/claims.txt
elif [  "$pharmacy_claims" ]
then
        echo "" | gpg --output $ETL_HOME/output/TOPERIOD/rx_claims.gz --batch --yes  --passphrase-fd 0 $pharmacy_claims
        gunzip $ETL_HOME/output/TOPERIOD/rx_claims.gz
        mv $ETL_HOME/output/TOPERIOD/rx_claims $ETL_HOME/output/TOPERIOD/rx_claims.txt
elif [  "$shred"  ]
then
        echo "" | gpg --output $ETL_HOME/output/TOPERIOD/shred.txt --batch --yes  --passphrase-fd 0 $shred
elif [  "$roster"  ]
then
        echo "" | gpg --output $ETL_HOME/output/TOPERIOD/roster.txt --batch --yes  --passphrase-fd 0 $roster
elif [  "$patient_alert"  ]
then
        echo "" | gpg --output $ETL_HOME/output/TOPERIOD/patient_alerts.txt --batch --yes  --passphrase-fd 0 $patient_alert
elif [  "$cpa"  ]
then
        echo "" | gpg --output $ETL_HOME/output/TOPERIOD/cpa.txt --batch --yes  --passphrase-fd 0 "$cpa"
fi
done

aws s3 cp $ETL_HOME/output/TOPERIOD/ s3://acp-data/NYDOH/TOPERIOD/ --recursive --sse AES256
rm -r $ETL_HOME/output/TOPERIOD/
