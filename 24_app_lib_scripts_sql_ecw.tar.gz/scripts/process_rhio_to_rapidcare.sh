#!/bin/bash
set -x
export SSHPASS=$BRONXRHIO_SH
rm -f $ETL_HOME/scripts/RHIO_to_Rapid.txt
rm -f $ETL_HOME/downloads/RHIO_to_Rapid/*
rm -f $ETL_HOME/input/RHIO_to_Rapid/*
rm -f $ETL_HOME/input/RHIO_to_Rapid_Excel/*.xlsx
#rm -f /home/etl/etl_home/Arcadia_rename_RHIO.sftp
export t1=`date -d '-1 day' '+%m.%d.%Y'`
sed -e "s/MM.DD.YYYY/${t1}/g" $ETL_HOME/scripts/RHIO_to_Rapid_template.sftp > $ETL_HOME/scripts/RHIO_to_Rapid.sftp
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/RHIO_to_Rapid.sftp SFTP_ACP@64.90.194.134
if [ ! "$(ls -A $ETL_HOME/downloads/RHIO_to_Rapid/)" ]
then
	echo 1 #echo "There are no alert files dropped for the date $(date +%m)/$(date +%d)/$(date +%y)"| mail -s "NO BRONX RHIO FILE ALERT for $(date +%m)/$(date +%d)/$(date +%y)" -c dsanz@somoscommunitycare.org,vtanis@somoscommunitycare.org,nmitek@somoscommunitycare.org,jdionisio@somoscommunitycare.org ssundararaman@somoscommunitycare.org
else
	ls $ETL_HOME/downloads/RHIO_to_Rapid/ > $ETL_HOME/scripts/RHIO_to_Rapid.txt
	grep -iv "^#" $ETL_HOME/scripts/RHIO_to_Rapid.txt |
	while read filename
	do 
	echo $ARCADIATOSOMOS_GP | gpg --batch --yes --passphrase-fd 0 -o $ETL_HOME/input/RHIO_to_Rapid/$filename $ETL_HOME/downloads/RHIO_to_Rapid/$filename
	$ETL_HOME/scripts/process_rhio_enhancement.sh $filename
	excel_file=`echo $filename  | awk -F ".csv" ' { print $1".xlsx" } '`
	echo "Alert file has been dropped on the date $(date +%m)/$(date +%d)/$(date +%y) for the date ${t1} "| mail -s "BRONX RHIO FILE ALERT for $(date +%m)/$(date +%d)/$(date +%y)" -a $ETL_HOME/input/RHIO_to_Rapid_Excel/$excel_file -c dsanz@somoscommunitycare.org,vtanis@somoscommunitycare.org ssundararaman@somoscommunitycare.org
	done
fi

export SSHPASS=$FTP_01_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/RHIO_to_Rapid_1.sftp $FTP_01_US@10.0.12.217
