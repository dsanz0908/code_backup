#!/bin/bash
set -x
filename=$1
columns=`head -1 $ETL_HOME/temp/$filename`
echo "create temporary table if not exists $filename (" > $ETL_HOME/sql/affinity_somos_pcproster.sql
echo $columns | sed -e "s/,/ VARCHAR(255),\\n/g" | sed -e "s/\r/ VARCHAR(255),/" >> $ETL_HOME/sql/affinity_somos_pcproster.sql
echo ")" >> $ETL_HOME/sql/affinity_somos_pcproster.sql
aws s3 cp $ETL_HOME/temp/${filename} s3://acp-data/Affinity/$filename --sse AES256
sed -e "s/FILENAME/$filename/g" $ETL_HOME/sql/affinity_somos_pcproster_template.sql >> $ETL_HOME/sql/affinity_somos_pcproster.sql
cat $ETL_HOME/sql/affinity_somos_pcproster.sql
