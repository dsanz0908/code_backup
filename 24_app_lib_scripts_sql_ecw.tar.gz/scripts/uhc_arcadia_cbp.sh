#!/bin/bash
sqlcmd -D arcadia_replica -d acpps_warehouse_prd01 -i $ETL_HOME/sql/arcadia_cbp.sql -o $ETL_HOME/temp/abc.csv  -W -w 999 -s","
