#!/bin/bash

export mco=$1 
sed -e "s/MCO/$mco/g" mco_corinthian_automation_template.sh > mco_corinthian_automation.sh
$ETL_HOME/scripts/mco_corinthian_automation.sh
