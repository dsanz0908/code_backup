#1/bin/bash
latest_file=`aws s3 ls s3://acp-data/DataAnalytics/ | grep snet_assignments | sort -r | awk '{print $4}' | head -1`
echo "delete from etl_new.sneakernet_assignments; copy etl_new.sneakernet_assignments from 's3://acp-data/DataAnalytics/${latest_file}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 region 'us-east-1' dateformat 'auto' delimiter ',' removequotes fillrecord; update etl_new.sneakernet_assignments set filename = '${latest_file}', added_tz = getdate();" > $ETL_HOME/sql/sneakernet_assignments_load.sql
$ETL_HOME/scripts/ipsql.sh sneakernet_assignments_load.sql
python $ETL_HOME/lib/macro_engagement_chw_report.py
cp $ETL_HOME/Reports/macro_engagement.html /var/www/html/.

