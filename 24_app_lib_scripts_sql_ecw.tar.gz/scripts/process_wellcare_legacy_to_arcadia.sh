#!/bin/bash
#set -x
OIFS="$IFS"
IFS=$'\n'

export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month}
rm $ETL_HOME/temp/Wellcare_to_Arcadia/*

sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/wellcare_legacy_to_arcadia_template.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/wellcare_legacy_to_arcadia.sql
$ETL_HOME/scripts/ipsql.sh wellcare_legacy_to_arcadia.sql

aws s3 cp s3://acp-data/Arcadia/Outgoing/wellcare/wellcare_all_claims_${delim_value}_000.gz $ETL_HOME/temp/Wellcare_to_Arcadia/.
aws s3 cp s3://acp-data/Arcadia/Outgoing/wellcare/wellcare_all_demographics_${delim_value}_000.gz $ETL_HOME/temp/Wellcare_to_Arcadia/.
aws s3 cp s3://acp-data/Arcadia/Outgoing/wellcare/wellcare_all_rx_${delim_value}_000.gz $ETL_HOME/temp/Wellcare_to_Arcadia/.
#aws s3 cp s3://acp-data/Arcadia/Outgoing/wellcare/wellcare_all_claims_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/ --sse AES256
#aws s3 cp s3://acp-data/Arcadia/Outgoing/wellcare/wellcare_all_demographics_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/ --sse AES256
#aws s3 cp s3://acp-data/Arcadia/Outgoing/wellcare/wellcare_all_rx_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/ --sse AES256
extras=`aws s3 ls s3://acp-data/Wellcare/ --recursive | grep -P "(ADJ|SPECCAP|MLSF)-${for_month}" | awk '{print $4}'`
for f in ${extras};  do aws s3 cp "s3://acp-data/"${f} s3://garage-s3/WellCare/ --sse AES256; done

gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Wellcare_to_Arcadia/wellcare_all_claims_${delim_value}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Wellcare_to_Arcadia/wellcare_all_demographics_${delim_value}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Wellcare_to_Arcadia/wellcare_all_rx_${delim_value}_000.gz

cd $ETL_HOME/temp/Wellcare_to_Arcadia/
export SSHPASS=$ARCADIAWELLCARE_SH
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/arcadia.sftp $ARCADIAWELLCARE_FTP@sftp.arcadiaanalytics.com

mv wellcare_all_claims_${delim_value}_000.gz CLAIM_WC_COR_${for_month}
mv wellcare_all_demographics_${delim_value}_000.gz ELIG_WC_COR_${for_month}
mv wellcare_all_rx_${delim_value}_000.gz RX_WC_COR_${for_month}
export SSHPASS=$GARAGE_SFTP_PW
printf "cd /Files/WellCare/\nmput *\nls *" > to_garage.sftp
sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP
rm $ETL_HOME/temp/Wellcare_to_Arcadia/*

#printf "Wellcare Legacy files for the month of ${for_month} were dropped on $(date +%m)/$(date +%d)/$(date +%y) into the SFTP folder.\n\nThe following files were dropped:\nwellcare_all_rx_${delim_value}_000.gz\nwellcare_all_claims_${delim_value}_000.gz\nwellcare_all_demographics_${delim_value}_000.gz\n\nMLSF, ADJ, and SPEC CAP files were also dropped for ${for_month}" | mail -s "Wellcare to Garage file drop" dsanz@somoscommunitycare.org,mwade@somoscommunitycare.org,ssundararaman@somoscommunitycare.org alexc@thegaragein.com,pmarrett@thegaragein.com,nrobeson@thegaragein.com,mkordit@thegaragein.com,bmccreary@thegaragein.com

