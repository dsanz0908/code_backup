#!/bin/bash
export sftp_yearmonth=$1
export sql_yearmonth=$2
# EXAMPLE: `./healthfirst_somos_load.sh DEC2018 201812`
cd "$ETL_HOME"/downloads/Healthfirst_Somos/
rm "$ETL_HOME"/downloads/Healthfirst_Somos/*
export SSHPASS=$HF_SOMOS_PW
printf "lcd /data/downloads/Healthfirst_Somos/\ncd /SOMOS_Fa/From\ HF\nget *${sftp_yearmonth}*\n" > healthfirst_somos.sftp
sshpass -e sftp -o BatchMode=no -b healthfirst_somos.sftp SOMOS_Fa@hfftp.healthfirst.org

ls *"${sftp_yearmonth}"*txt > "$ETL_HOME"/scripts/Healthfirst_Somos_to_s3.txt
grep -iv "^#" "$ETL_HOME"/scripts/Healthfirst_Somos_to_s3.txt |
while read filename
do
aws s3 cp "${filename}" s3://acp-data/Healthfirst/Somos/"${filename}" --sse AES256
done

sed -e "s/\\$//g" -e "s/*//g" -e "s/†//g" -e "s/,//g" /data/downloads/Healthfirst_Somos/ANA07701_SOMOS_${sftp_yearmonth}_DTL_PHARMACY.txt > $ETL_HOME/temp/ANA07701_SOMOS_${sftp_yearmonth}_DTL_PHARMACY_1.txt
aws s3 cp $ETL_HOME/temp/ANA07701_SOMOS_${sftp_yearmonth}_DTL_PHARMACY_1.txt s3://acp-data/Healthfirst/Somos/ANA07701_SOMOS_${sftp_yearmonth}_DTL_PHARMACY_1.txt --sse AES256
sed -e "s/YRMNTH/${sql_yearmonth}/g" -e "s/SFTPYEARMONTH/${sftp_yearmonth}/g" $ETL_HOME/sql/healthfirst_somos_load_template.sql > $ETL_HOME/sql/healthfirst_somos_load.sql
$ETL_HOME/scripts/ipsql.sh healthfirst_somos_load.sql

echo "select count(*) from payor.healthfirst_somos_all_eligibility where received_month = '${receivedmonth}'" > $ETL_HOME/sql/healthfirst_somos_receivedmonth_count.sql
receivedmonth_count=`./ipsql.sh healthfirst_somos_receivedmonth_count.sql | sed -n '3p'`
if (( ${receivedmonth_count} > 0 )); then
  bash process_healthfirst_somos_to_arcadia.sh ${receivedmonth}
fi

