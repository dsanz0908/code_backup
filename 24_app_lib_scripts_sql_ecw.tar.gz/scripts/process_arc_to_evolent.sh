#!/bin/bash
set -x
export SSHPASS=$ARCADIATOEVOLENT
rm -f $ETL_HOME/downloads/evolent/*.csv
rm -f $ETL_HOME/scripts/archive.sftp
sshpass -e sftp -o BatchMode=no -b pull.sftp 1411-OF-EVHDWF_PRD@sftp.arcadiaanalytics.com
ls $ETL_HOME/downloads/evolent/*.csv > $ETL_HOME/scripts/arcadia_files.txt
grep -iv "^#" $ETL_HOME/scripts/arcadia_files.txt |
while read filename
do
sfile=`echo $filename | awk -F"/" '{ print $7 }'`
aws s3 cp $filename s3://acp-evolent/ToEvolent/FromArcadia/$sfile --sse AES256
echo "rename $sfile backup/$sfile" >> archive.sftp
done
sshpass -e sftp -o BatchMode=no -b archive.sftp 1411-OF-EVHDWF_PRD@sftp.arcadiaanalytics.com
