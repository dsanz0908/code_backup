#!/bin/bash

today=`date -d '-1 day' '+%Y-%m-%d'`
today=`date '+%Y-%m-%d'`
rm /data/downloads/dental_referrals_upload/*
aws s3 ls s3://acp-data/dental_referrals/need_to_be_processed/ | grep -i pdf | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//' |
while read filename
do
aws s3 cp "s3://acp-data/dental_referrals/need_to_be_processed/${filename}" /data/downloads/dental_referrals_upload/
return_code=`python $ETL_HOME/lib/dental_referral_sf_upload.py "/data/downloads/dental_referrals_upload/${filename}"`
if [ "$return_code" -eq 0 ]; then
  aws s3 mv "s3://acp-data/dental_referrals/need_to_be_processed/${filename}" "s3://acp-data/dental_referrals/processed/${filename}" --sse AES256
else
  aws s3 mv "s3://acp-data/dental_referrals/need_to_be_processed/${filename}" "s3://acp-data/dental_referrals/need_to_be_fixed/${filename}" --sse AES256
fi
done

#aws s3 ls s3://acp-data/dental_referrals/processed/ | grep -i pdf | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//' | awk -F'_' '{print $2}' | sort | uniq > $ETL_HOME/temp/${today}_dental_referral_cins.txt
#echo "List of CINs with dental referrals in Salesforce as of ${today} is attached. Total: `cat $ETL_HOME/temp/${today}_dental_referral_cins.txt | wc -l`"| mail -s "Dental Referral CINs" -a $ETL_HOME/temp/${today}_dental_referral_cins.txt mkordit@somoscommunitycare.org,nfallah@somoscommunitycare.org

