#!/bin/bash
$ETL_HOME/scripts/wellcare_legacy_missing_months.sh CORINTHIAN
$ETL_HOME/scripts/wellcare_legacy_missing_months.sh EXCELSIOR
$ETL_HOME/scripts/wellcare_legacy_missing_months.sh BALANCE
$ETL_HOME/scripts/wellcare_legacy_missing_months.sh ECAP
