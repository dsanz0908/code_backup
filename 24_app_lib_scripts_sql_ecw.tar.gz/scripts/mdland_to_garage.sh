#!/bin/bash

export SSHPASS=$GARAGE_MDLAND_PW
printf "cd /Files/\nlcd /data/downloads/garage_mdland/\nmput *\nls *" > mdland_to_garage.sftp
sshpass -e sftp -o BatchMode=no -b mdland_to_garage.sftp $GARAGE_MDLAND_USER@$GARAGE_MDLAND_FTP


