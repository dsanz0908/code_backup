#!/bin/bash

DATE_TO_DIFF=`date -d '-4 day' '+%Y-%m-%d'`
#DATE_TO_DIFF='2019-07-23'
rm /data/downloads/garage_mdland/*DIFF*
python $ETL_HOME/lib/mdland_to_garage.py D $DATE_TO_DIFF
export SSHPASS=$GARAGE_MDLAND_PW
printf "cd /Files/\nlcd /data/downloads/garage_mdland/\nmput *${DATE_TO_DIFF}*\nls *" > mdland_to_garage.sftp
sshpass -e sftp -o BatchMode=no -b mdland_to_garage.sftp $GARAGE_MDLAND_USER@$GARAGE_MDLAND_FTP


