#!/bin/bash
grep -iv "^#" $ETL_HOME/scripts/healthfirst_legacy.txt |
while read month
do
$ETL_HOME/scripts/process_healthfirst_eligibility_files_to_arcadia.sh $month
done

cd $ETL_HOME/temp/Healthfirst_Eligibility/
export SSHPASS=$ARCADIAHEALTHFIRST_SH
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/arcadia.sftp $ARCADIAHEALTHFIRST_FTP@sftp.arcadiaanalytics.com
rm $ETL_HOME/temp/Healthfirst_Eligibility/*
