#!/bin/bash
set -x
export SSHPASS=$UHC_SOMOS_PW
export receivedmonth=$1
uhc_somos_files="/home/etl/etl_home/downloads/UHC_Somos/"
rm ${uhc_somos_files}*
printf "cd /out/somos_ipa_ny/mi1\nlcd /home/etl/etl_home/downloads/UHC_Somos/\nget *${receivedmonth}*.gz" > UHC_to_s3.sftp
sshpass -e sudo sftp -o BatchMode=no -b UHC_to_s3.sftp es00byk@ecgpe.healthtechnologygroup.com

for filepath in ${uhc_somos_files}*; do
  sudo gunzip ${filepath}
  filename=`echo ${filepath} | sed 's/.gz//g'`
  if [[ ${filename} == *"CLM"* ]]; then
    basename=`echo ${filename} | awk -F'/' '{print $7}'`
    year_month=`echo ${basename} | awk -F'_' {'print $2}'`
    sudo chmod 774 ${filename}
    aws s3 cp ${filename} s3://acp-data/UHC/Somos/${basename} --sse AES256
    sed -e "s/BASENAME/${basename}/g" -e "s/YEARMONTH/${year_month}/g" /home/etl/etl_home/sql/uhc_somos_claims_load_template.sql > /home/etl/etl_home/sql/uhc_somos_claims_load.sql
    $ETL_HOME/scripts/ipsql.sh uhc_somos_claims_load.sql
  elif [[ ${filename} == *"MEM"* ]]; then
    basename=`echo ${filename} | awk -F'/' '{print $7}'`
    year_month=`echo ${basename} | awk -F'_' {'print $2}'`
    sudo chmod 774 ${filename}
    aws s3 cp ${filename} s3://acp-data/UHC/Somos/${basename} --sse AES256
    sed -e "s/BASENAME/${basename}/g" -e "s/YEARMONTH/${year_month}/g" /home/etl/etl_home/sql/uhc_somos_membership_load_template.sql > /home/etl/etl_home/sql/uhc_somos_membership_load.sql
    $ETL_HOME/scripts/ipsql.sh uhc_somos_membership_load.sql
  fi
done

echo "select count(*) from payor.uhc_somos_all_membership where received_month = '${receivedmonth}'" > $ETL_HOME/sql/uhc_somos_receivedmonth_count.sql
receivedmonth_count=`$ETL_HOME/scripts/ipsql.sh uhc_somos_receivedmonth_count.sql | sed -n '3p'`
if (( ${receivedmonth_count} > 0 )); then
  bash process_uhc_somos_to_arcadia.sh ${receivedmonth}
fi

