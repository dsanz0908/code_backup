#!/bin/bash
set -x
export SSHPASS=$UHC_SOMOS_PW
export receivedmonth=$1
#rm -f /home/etl/etl_home/scripts/UHC_to_s3.txt
#rm -f /home/etl/etl_home/downloads/UHC_Corinthian/*
printf "cd /out/somos_ipa_ny/mi1\nlcd /home/etl/etl_home/downloads/UHC_Somos/\nget *${receivedmonth}*.gz" > UHC_to_s3.sftp
sshpass -e sftp -o BatchMode=no -b UHC_to_s3.sftp es00byk@ecgpe.healthtechnologygroup.com

uhc_somos_files="/home/etl/etl_home/downloads/UHC_Somos/"
#rm ${uhc_somos_files}*
for filepath in ${uhc_somos_files}*; do
  gunzip ${filepath}
  if [[ ${filepath} == *"CLM"* ]]; then
    basename=`echo ${filepath} | awk -F'/' '{print $7}'`
    year_month=`echo ${basename} | awk -F'_' {'print $2}'`
    aws s3 cp ${filepath} s3://acp-data/UHC/Somos/${basename} --sse AES256
    sed -e "s/BASENAME/${basename}/g" -e "s/YEARMONTH/${year_month}/g" /home/etl/etl_home/sql/uhc_somos_claims_load_template.sql > /home/etl/etl_home/sql/uhc_somos_claims_load.sql
    ./ipsql.sh uhc_somos_claims_load.sql
  elif [[ ${filepath} == *"MEM"* ]]; then
    basename=`echo ${filepath} | awk -F'/' '{print $7}'`
    year_month=`echo ${basename} | awk -F'_' {'print $2}'`
    aws s3 cp ${filepath} s3://acp-data/UHC/Somos/${basename} --sse AES256
    sed -e "s/BASENAME/${basename}/g" -e "s/YEARMONTH/${year_month}/g" /home/etl/etl_home/sql/uhc_somos_membership_load_template.sql > /home/etl/etl_home/sql/uhc_somos_membership_load.sql
    ./ipsql.sh uhc_somos_membership_load.sql
  fi
done
