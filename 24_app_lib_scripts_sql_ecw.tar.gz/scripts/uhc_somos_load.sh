#!/bin/bash
#set -x
#export SSHPASS=$FTP_01_PW
#export receivedmonth=$1
#rm -f $ETL_HOME/scripts/Healthfirst_to_s3.txt
#rm -f $ETL_HOME/downloads/Healthfirst_Corinthian/*
#rm -f $ETL_HOME/scripts/Healthfirst_rm_file.sftp
#printf "cd /data/ftp_users/jdionisio-corinthian/incoming/Healthfirst/\nlcd /home/etl/etl_home/downloads/Healthfirst_Corinthian/\nget *${receivedmonth}.txt" > Healthfirst_to_s3.sftp
#sshpass -e sftp -o BatchMode=no -b Healthfirst_to_s3.sftp $FTP_01_US@10.0.12.217


uhc_somos_files="$ETL_HOME/temp/UHC_Somos/"
rm ${uhc_somos_files}*
for filepath in ${uhc_somos_files}*; do
  if [[ ${filepath} == *"CLM"* ]]; then
    basename=`echo ${filepath} | awk -F'/' '{print $7}'`
    year_month=`echo ${basename} | awk -F'_' {'print $2}'`
    aws s3 cp ${filepath} s3://acp-data/UHC/Somos/${basename} --sse AES256
    sed -e "s/BASENAME/${basename}/g" -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/uhc_somos_claims_load_template.sql > $ETL_HOME/sql/uhc_somos_claims_load.sql
    ./ipsql.sh uhc_somos_claims_load.sql
  elif [[ ${filepath} == *"MEM"* ]]; then
    basename=`echo ${filepath} | awk -F'/' '{print $7}'`
    year_month=`echo ${basename} | awk -F'_' {'print $2}'`
    aws s3 cp ${filepath} s3://acp-data/UHC/Somos/${basename} --sse AES256
    sed -e "s/BASENAME/${basename}/g" -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/uhc_somos_membership_load_template.sql > $ETL_HOME/sql/uhc_somos_membership_load.sql
    ./ipsql.sh uhc_somos_membership_load.sql
  fi
done
