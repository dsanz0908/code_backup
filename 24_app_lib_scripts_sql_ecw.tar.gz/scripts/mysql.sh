#!/bin/bash
set -x
JAVA_HOME=/data/jdk-10.0.1
export PATH=$JAVA_HOME/bin:$PATH
#export CLASSPATH=$CLASSPATH:$ETL_HOME/scripts/sqljdbc42.jar
export driver="com.microsoft.sqlserver.jdbc.SQLServerDriver"
export url="jdbc:sqlserver://arcadia-sql-02.data.acppps.org:1433;databaseName=db_pediatric_plaza;"
export user=ssundararaman
export pwd=Optimus@2018
java -Xms512m -Xmx10048m -cp $ETL_HOME/lib/sqlline-1.5.0-SNAPSHOT-jar-with-dependencies.jar:$ETL_HOME/lib/sqljdbc42.jar --add-modules java.xml.bind sqlline.SqlLine -u $url -n $user -p $pwd -f /data/input/m1.sql

