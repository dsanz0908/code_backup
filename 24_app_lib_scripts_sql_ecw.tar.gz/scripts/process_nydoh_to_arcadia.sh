#!/bin/bash
#set -x
export for_month=$1
sed -e "s/YYYYMM/$for_month/g" $ETL_HOME/sql/arcadia_nydoh_template.sql > $ETL_HOME/sql/arcadia_nydoh.sql
$ETL_HOME/scripts/ipsql.sh arcadia_nydoh.sql

aws s3 cp s3://acp-data/Arcadia/Outgoing/nydoh/${for_month}/nydoh_claims_${for_month}_000.gz $ETL_HOME/downloads/nydoh_to_arcadia/
aws s3 cp s3://acp-data/Arcadia/Outgoing/nydoh/${for_month}/nydoh_cpa_${for_month}_000.gz $ETL_HOME/downloads/nydoh_to_arcadia/
aws s3 cp s3://acp-data/Arcadia/Outgoing/nydoh/${for_month}/nydoh_all_rosters_all_columns_${for_month}_000.gz $ETL_HOME/downloads/nydoh_to_arcadia/
aws s3 cp s3://acp-data/Arcadia/Outgoing/nydoh/${for_month}/nydoh_shred_${for_month}_000.gz $ETL_HOME/downloads/nydoh_to_arcadia/
aws s3 cp s3://acp-data/Arcadia/Outgoing/nydoh/${for_month}/nydoh_patient_alerts_${for_month}_000.gz $ETL_HOME/downloads/nydoh_to_arcadia/
aws s3 cp s3://acp-data/Arcadia/Outgoing/nydoh/${for_month}/nydoh_rx_claims_${for_month}_000.gz $ETL_HOME/downloads/nydoh_to_arcadia/

gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/downloads/nydoh_to_arcadia/nydoh_claims_${for_month}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/downloads/nydoh_to_arcadia/nydoh_cpa_${for_month}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/downloads/nydoh_to_arcadia/nydoh_all_rosters_all_columns_${for_month}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/downloads/nydoh_to_arcadia/nydoh_shred_${for_month}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/downloads/nydoh_to_arcadia/nydoh_patient_alerts_${for_month}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/downloads/nydoh_to_arcadia/nydoh_rx_claims_${for_month}_000.gz

cd $ETL_HOME/downloads/nydoh_to_arcadia/
rm *gz

export SSHPASS=$NYDOHTOARCADIA_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/arcadia.sftp $NYDOHTOARCADIA_USER@sftp.arcadiaanalytics.com
