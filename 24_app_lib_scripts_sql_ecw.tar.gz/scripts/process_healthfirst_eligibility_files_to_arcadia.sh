#!/bin/bash

export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month}
sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/healthfirst_legacy_to_arcadia_eligibility_template_1.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/healthfirst_legacy_to_arcadia_eligibility.sql
$ETL_HOME/scripts/ipsql.sh healthfirst_legacy_to_arcadia_eligibility.sql
#aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_claims_${delim_value}_000.gz $ETL_HOME/temp/Healthfirst_Eligibility/.
aws s3 cp s3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_eligibility_${delim_value}_000.gz $ETL_HOME/temp/Healthfirst_Eligibility/.
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Healthfirst_Eligibility/healthfirst_corinthian_eligibility_${delim_value}_000.gz
#gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Healthfirst_Eligibility/healthfirst_corinthian_rx_claims_${delim_value}_000.gz
rm $ETL_HOME/temp/Healthfirst_Eligibility/healthfirst_corinthian_eligibility_${delim_value}_000.gz
#rm healthfirst_corinthian_rx_claims_${delim_value}_000.gz
