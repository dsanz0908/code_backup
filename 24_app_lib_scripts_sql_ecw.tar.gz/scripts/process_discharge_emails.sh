#!/bin/bash
rm $ETL_HOME/scripts/discharge_csvs.txt
#rm $ETL_HOME/downloads/discharge_email_excel/*
rm $ETL_HOME/downloads/discharge_email_csv/*
python $ETL_HOME/lib/discharge_email_automation.py
ls $ETL_HOME/downloads/discharge_email_csv/ > $ETL_HOME/scripts/discharge_csvs.txt
grep -iv "^#" $ETL_HOME/scripts/discharge_csvs.txt |
while read filename
do
cd $ETL_HOME/downloads/discharge_email_csv/
receiveddate=`echo "$filename"  | awk -F "_" ' { print $1 } '`
columns=`head -1 "$filename"`
echo "create table if not exists staging_discharge ( " > $ETL_HOME/sql/discharge_columns.sql
echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" >> $ETL_HOME/sql/discharge_columns.sql
echo "VARCHAR(255));" >> $ETL_HOME/sql/discharge_columns.sql
echo "grant all on staging_discharge to etluser;" >> $ETL_HOME/sql/discharge_columns.sql
aws s3 cp "$ETL_HOME/downloads/discharge_email_csv/${filename}" "s3://acp-data/monte/discharge_csvs/${filename}" --sse AES256
sed -e "s/FILENAME/${filename}/g" $ETL_HOME/sql/discharge_load_template.sql > $ETL_HOME/sql/discharge_load.sql

echo "delete from discharge where filename = '${filename}';" > $ETL_HOME/sql/discharge_insert.sql
echo "insert into discharge select *, '${receiveddate}', '${filename}' from staging_discharge;" >> $ETL_HOME/sql/discharge_insert.sql
echo "drop table staging_discharge;" >> $ETL_HOME/sql/discharge_insert.sql
cd $ETL_HOME/scripts/
./ipsql.sh discharge_columns.sql
./ipsql.sh discharge_load.sql
./ipsql.sh discharge_insert.sql

done
