#!/bin/bash
bash ipsql.sh get_mdanalytics_roster.sql
aws s3 cp s3://acp-data/mdanalytics/hc_wc_latest_roster_000 $ETL_HOME/temp/
