#!/bin/bash

rm /data/downloads/garage/*

export SSHPASS=$GARAGE_SFTP_PW
printf "lcd /data/downloads/garage/\ncd /Files/OutBound/\nget *zip*\nls *" > to_garage.sftp
sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP

cd /data/downloads/garage/
ls *001 |
while read filename
do
7za e $filename
done

ls *txt |
while read filename
do
aws s3 cp $filename s3://acp-data/garage/
table_name=`echo $filename | sed 's/\.txt//g'`
echo "copy $table_name from 's3://acp-data/garage/$filename' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter '|';" > $ETL_HOME/sql/garage.sql
psql -U $REDSHIFT_USER -h $REDSHIFT_HOST  -p$REDSHIFT_PORT -d garage_dw -q -f $ETL_HOME/sql/garage.sql
done
