#!/bin/bash
set -x
export SSHPASS=$WELLCARE_CENSUS_PW
today=$(date '+%m%d%Y')
#today='04022019'
rm "$ETL_HOME"/downloads/wellcare_census/*
printf "cd /home/IPA_Balance/From_WellCare\nlcd /home/etl/etl_home/downloads/wellcare_census/\nget ${today}-CENSUS*csv" > downloaded_wellcare_census_files.sftp
sshpass -e sftp -o BatchMode=no -b downloaded_wellcare_census_files.sftp IPA_Balance@edi.wellcare.com

ls "$ETL_HOME"/downloads/wellcare_census/* |
while read filename
do
aws s3 cp "${filename}" s3://acp-data/census/wellcare/ --sse AES256
columns=$(head -3 "${filename}" | tail -1 | tr '[:upper:]' '[:lower:]' | sed 's/\r//g')
echo "create temp table if not exists staging_wellcare_census ( " > "$ETL_HOME"/sql/wellcare_census_load.sql

echo "$columns" | sed -e "s/(//g" -e "s/)//g" -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" >> "$ETL_HOME"/sql/wellcare_census_load.sql

echo 'VARCHAR(255));' >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "grant all on staging_wellcare_census to etluser;" >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "copy staging_wellcare_census from 's3://acp-data/census/wellcare/${filename##*/}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 4 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;" >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "delete from payor.wellcare_census where filename = '${filename##*/}';" >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "insert into payor.wellcare_census (${columns}, filename) select ${columns}, '${filename##*/}' from staging_wellcare_census;" >> "$ETL_HOME"/sql/wellcare_census_load.sql
$ETL_HOME/scripts/ipsql.sh wellcare_census_load.sql
done

