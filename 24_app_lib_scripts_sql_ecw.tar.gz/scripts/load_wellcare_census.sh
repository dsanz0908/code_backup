#!/bin/bash
set -x
OIFS="$IFS"
IFS=$'\n'

export SSHPASS=$WELLCARE_CENSUS_PW
today=$(date '+%m%d%Y')
sql_today=`date '+%Y-%m-%d'`
rm "$ETL_HOME"/downloads/wellcare_census/*
printf "cd /home/IPA_Balance/From_WellCare\nlcd /home/etl/etl_home/downloads/wellcare_census/\nget ${today}-CENSUS*csv" > downloaded_wellcare_census_files.sftp
sshpass -e sftp -o BatchMode=no -b downloaded_wellcare_census_files.sftp IPA_Balance@edi.wellcare.com

export SSHPASS=$GARAGE_SFTP_PW
garage_date=`date '+%Y%m%d'`
ls "$ETL_HOME"/downloads/wellcare_census/* |
while read filename
do
f=`echo ${filename} | awk -F'.' '{print $1}' | awk -F'/' '{print $7}' | awk -F'-' '{print "ALERT_WC_"_$4$3"_"$1".csv"}' | sed "s/$today/$garage_date/g"`
cp $filename $f
aws s3 cp "${filename}" s3://acp-data/census/wellcare/ --sse AES256

printf "cd /Files/Intake\ Files\nput "\"${f}\""\nls *" > to_garage.sftp
sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP
rm to_garage.sftp
rm $f

aws s3 cp "${filename}" s3://garage-s3/alert_files/wellcare/ --sse AES256
columns=$(head -3 "${filename}" | tail -1 | tr '[:upper:]' '[:lower:]' | sed 's/\r//g')
echo "create temp table if not exists staging_wellcare_census ( " > "$ETL_HOME"/sql/wellcare_census_load.sql

echo "$columns" | sed -e "s/(//g" -e "s/)//g" -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" >> "$ETL_HOME"/sql/wellcare_census_load.sql

echo 'VARCHAR(255));' >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "grant all on staging_wellcare_census to etluser;" >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "copy staging_wellcare_census from 's3://acp-data/census/wellcare/${filename##*/}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 4 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;" >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "delete from payor.wellcare_census where filename = '${filename##*/}';" >> "$ETL_HOME"/sql/wellcare_census_load.sql
echo "insert into payor.wellcare_census (${columns}, filename) select ${columns}, '${filename##*/}' from staging_wellcare_census;" >> "$ETL_HOME"/sql/wellcare_census_load.sql
$ETL_HOME/scripts/ipsql.sh wellcare_census_load.sql
done

echo "unload (\$\$ select distinct * from (select *, row_number() over (partition by subscriber_id, facility, ad_date order by added_tz) as rn from payor.wellcare_census where ath in ('INP', 'BHD', 'BHI', 'NSG', 'SNF') ) where rn = 1 and To_date(LEFT(filename, 8), 'MMDDYYYY') = '${sql_today}'\$\$) to 's3://sftp_test/${sql_today}_wellcare_census_new_patients' delimiter ',' addquotes parallel off ALLOWOVERWRITE iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';" > $ETL_HOME/sql/load_wellcare_census.sql
#echo "unload (\$\$ SELECT * FROM payor.wellcare_census WHERE ath in ('INP', 'BHD', 'BHI', 'NSG', 'SNF') AND To_date(LEFT(filename, 8), 'MMDDYYYY') = '${sql_today}' \$\$) to 's3://sftp_test/${sql_today}_wellcare_census_new_patients' delimiter ',' parallel off ALLOWOVERWRITE iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';" > $ETL_HOME/sql/load_wellcare_census.sql
$ETL_HOME/scripts/ipsql.sh load_wellcare_census.sql
aws s3 cp s3://sftp_test/${sql_today}_wellcare_census_new_patients000 $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.csv
if [ ! -s $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.csv ]; then
  echo "No new patients from Wellcare Census for ${sql_today} from Somos/Optimus"| mail -s "Wellcare Census" nlopez@somoscommunitycare.org,ireyes@rapidcaresolution.com,ibarra@rapidcaresolution.com
else
  sed -i '1s/^/ath,last_name,first_name,dob,subscriber_id,cmcd,lob,facility,attending,ad_date,dis_date,diagnosis,auth_days,auth_no,pcp,denial_days,ov,ipa,service_details_notes,diag_code,diag_text,filename,added_tz,modified_tz\n/' $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.csv
  zip -j --password Balance321 $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.zip $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.csv
  aws s3 cp $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.zip s3://sftp_test/${sql_today}_wellcare_census_new_patients.zip
  aws s3 rm s3://sftp_test/${sql_today}_wellcare_census_new_patients000
  rm $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.csv
  echo "New Patients from Wellcare Census for ${sql_today} from Somos/Optimus"| mail -s "Wellcare Census" -a $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.zip nlopez@somoscommunitycare.org,ireyes@rapidcaresolution.com,ibarra@rapidcaresolution.com

  rm $ETL_HOME/temp/${sql_today}_wellcare_census_new_patients.zip
fi

