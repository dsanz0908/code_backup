#!/bin/bash

dental_referral_folder="$ETL_HOME/downloads/dental_referrals/"
rm ${dental_referral_folder}*
aws s3 ls s3://acp-data/dental_referrals/original/ | grep `date -d '-1 day' +%F` | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//' | 
#aws s3 ls s3://acp-data/dental_referrals/original/ | grep 2019-11-01 | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//' | 
while read filename
do 
  aws s3 cp "s3://acp-data/dental_referrals/original/${filename}" ${dental_referral_folder}
  split_name=`echo ${filename} | sed 's/.pdf/-%d.pdf/g'`
  pdfseparate "${dental_referral_folder}${filename}" "${dental_referral_folder}${split_name}"
  rm "${dental_referral_folder}${filename}"
done

ls ${dental_referral_folder} |
while read split_file
do
  ps -ef | grep -i tess | grep -v color | awk '{print $2}' | xargs kill -9
  tiff_file=`echo ${split_file} | sed 's/.pdf/.tiff/g'`
  txt_file=`echo ${split_file} | sed 's/.pdf/.txt/g'`
  pdftocairo "${dental_referral_folder}${split_file}" "${dental_referral_folder}${split_file}" -tiff -rx 300 -ry 300
  tesseract "${dental_referral_folder}${split_file}-1.tif" "${dental_referral_folder}${split_file}"
  cin=`sed -n 's/Insurance .*://p' "${dental_referral_folder}${split_file}.txt" | sed -e 's/ //g'`
  echo ${cin}
  dentist_office=`sed -n 's/Dentist Organization Name://p' "${dental_referral_folder}${split_file}.txt" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'`
  referral_date_raw=`sed -n 's/DATE OF REFERRAL://p' "${dental_referral_folder}${split_file}.txt" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'`
  referral_date=`date -d"${referral_date_raw}" +%Y%m%d`
  if [ `echo ${cin} | grep -P "[A-Za-z][A-Za-z]\d\d\d\d\d[A-Za-z]"` ]; then
    aws s3 cp "${dental_referral_folder}${split_file}" "s3://acp-data/dental_referrals/need_to_be_processed/${dentist_office}_${cin}_${referral_date}.pdf" --sse AES256
  else
    aws s3 cp "${dental_referral_folder}${split_file}" "s3://acp-data/dental_referrals/need_to_be_fixed/${dentist_office}_${cin}_${referral_date}.pdf" --sse AES256
  fi
done
