#!/bin/bash

export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month}
sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/empire_somos_to_garage_template.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/empire_somos_to_garage.sql
$ETL_HOME/scripts/ipsql.sh empire_somos_to_garage.sql

printf "Empire Somos files for the month of ${for_month} were dropped on $(date +%m)/$(date +%d)/$(date +%y) at s3://garage-s3/Empire/\n" | mail -s "Empire to Garage file drop" dsanz@somoscommunitycare.org,mwade@somoscommunitycare.org,ssundararaman@somoscommunitycare.org alexc@thegaragein.com,pmarrett@thegaragein.com,nrobeson@thegaragein.com,mkordit@thegaragein.com

