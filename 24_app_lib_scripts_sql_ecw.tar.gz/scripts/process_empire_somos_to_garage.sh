#!/bin/bash

export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month}
sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/empire_somos_to_garage_template.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/empire_somos_to_garage.sql
$ETL_HOME/scripts/ipsql.sh empire_somos_to_garage.sql
cd /home/etl/etl_home/downloads/Empire_Somos/
rm /home/etl/etl_home/downloads/Empire_Somos/*
aws s3 ls s3://garage-s3/Empire/ | grep $delim_value | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//' |
while read empire_file
do
filetype=`echo $empire_file | sed 's/empire_somos_//g' | tr '[:lower:]' '[:upper:]' | sed 's/_20.*//g' | sed 's/_//g' | sed 's/MEMBERELIGIBILITY/ELIG/g'`
new_file="${filetype}_EMP_SOM_${for_month}.gz"
aws s3 cp s3://garage-s3/Empire/$empire_file $new_file
done

export SSHPASS=$GARAGE_SFTP_PW
printf "cd /Files/Empire_Anthem/\nmput *\nls *" > to_garage.sftp
sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP

printf "Empire Somos files for the month of ${for_month} were dropped on $(date +%m)/$(date +%d)/$(date +%y) in the SFTP at /Files/Empire_Anthem/\n" | mail -s "Empire to Garage file drop" dsanz@somoscommunitycare.org,mwade@somoscommunitycare.org,ssundararaman@somoscommunitycare.org alexc@thegaragein.com,pmarrett@thegaragein.com,nrobeson@thegaragein.com,mkordit@thegaragein.com,bmccreary@thegaragein.com

