#!/bin/bash
set -x
export legacy=$1
export year_month="$2"

rm $ETL_HOME/temp/*${legacy}*_allfiles.zip
rm -f $ETL_HOME/scripts/Wellcare_to_s3.txt
rm -f $ETL_HOME/downloads/Wellcare_${legacy}/*

MONTHS=(ZERO Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec)
month=`echo ${year_month: -2} | sed 's/^0*//'`
month_string=`echo ${MONTHS[$month]}`
ps -ef | grep chrome | grep -v color | awk '{print $2}' | xargs kill -9
python $ETL_HOME/lib/grab_wellcare_all.py ${legacy} ${month_string}
mv $ETL_HOME/temp/*${legacy}*_allfiles.zip $ETL_HOME/downloads/Wellcare_${legacy}/
zipfile=`ls $ETL_HOME/downloads/Wellcare_${legacy}/`
unzip -oP "WellC@re17!" $ETL_HOME/downloads/Wellcare_${legacy}/${zipfile} -d $ETL_HOME/downloads/Wellcare_${legacy}/
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*adj* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-ADJ-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*claims* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-CLAIMS-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*demographics* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-DEMOGRAPHICS-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*mlsf* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-MLSF-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*rx* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-PHARMACY-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*spec* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-SPECCAP-${year_month}.txt --sse AES256
#columns="'$(head -1 $ETL_HOME/downloads/Wellcare_${legacy}/*demographics* | tr '[:upper:]' '[:lower:]' | sed 's/ /_/g' | sed 's/*//g' | sed "s/|/\',\'/g")'"
#echo "select 'drop table if exists staging_wellcare; create temp table if not exists staging_wellcare (' || listagg(raw_column || ' ' || column_data_type, ', ') within group (order by id) || ');' from (select * from payor.mco_table_column_reference where mco = 'Wellcare' and ipa = 'Legacy' and file_type = 'Demographics' and raw_column in (${columns}) order by id)" > "$ETL_HOME"/sql/wellcare_load_temp.sql
#"$ETL_HOME"/scripts/ipsql.sh wellcare_load_temp.sql | sed -n '3p' > "$ETL_HOME"/sql/wellcare_load.sql
#echo "grant all on staging_wellcare to etluser; copy staging_wellcare from 's3://acp-data/Wellcare/${legacy}/${filename}.csv' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv; delete from payor.wellcare_somos_roster_all where filename = '${filename}.csv';" >> "$ETL_HOME"/sql/wellcare_load.sql
#echo "select listagg(query, ' ') from (SELECT 'insert into payor.wellcare_somos_roster_all (' || listagg(table_column, ',') within group (order by id) || ',filename,period)' as query FROM payor.mco_table_column_reference WHERE mco = 'Wellcare' AND ipa = 'Somos' AND file_type = 'Roster' AND raw_column IN (${columns} ) union select 'select ' || listagg(raw_column, ',') within group (order by id) || ',''${filename}.csv'', ''${month_to_process}'' from staging_wellcare' FROM payor.mco_table_column_reference WHERE mco = 'Wellcare' AND ipa = 'Somos' AND file_type = 'Roster' AND raw_column IN (${columns} ))" > "$ETL_HOME"/sql/wellcare_load_temp.sql
#"$ETL_HOME"/scripts/ipsql.sh wellcare_load_temp.sql | sed -n '3p' >> "$ETL_HOME"/sql/wellcare_load.sql

cd $ETL_HOME/downloads/Wellcare_${legacy}/
if [ ${legacy} == 'SOMOS' ]; then
  sed -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/wellcare_somos_load_template.sql | sed -e "s/LEGACY/${legacy}/g" > $ETL_HOME/sql/wellcare_somos_load.sql
  $ETL_HOME/scripts/ipsql.sh wellcare_somos_load.sql
else
  sed -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/wellcare_legacy_load_template.sql | sed -e "s/LEGACY/${legacy}/g" > $ETL_HOME/sql/wellcare_legacy_load.sql
  $ETL_HOME/scripts/ipsql.sh wellcare_legacy_load.sql
fi
rm $ETL_HOME/temp/WELLCARE-${legacy}*${year_month}*

bash $ETL_HOME/scripts/load_wellcare_mlsf.sh $legacy $year_month
