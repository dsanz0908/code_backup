#!/bin/bash
set -x
export legacy=$1
export year_month=$2

rm $ETL_HOME/temp/*${legacy}*_allfiles.zip
rm -f $ETL_HOME/scripts/Wellcare_to_s3.txt
rm -f $ETL_HOME/downloads/Wellcare_${legacy}/*

MONTHS=(ZERO Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec)
month_string=`echo ${MONTHS[${year_month: -2}]}`
echo ${month_string}
python $ETL_HOME/lib/grab_wellcare_all.py ${legacy} ${month_string}
mv $ETL_HOME/temp/*${legacy}*_allfiles.zip $ETL_HOME/downloads/Wellcare_${legacy}/
zipfile=`ls $ETL_HOME/downloads/Wellcare_${legacy}/`
unzip -oP "WellC@re17!" $ETL_HOME/downloads/Wellcare_${legacy}/${zipfile} -d $ETL_HOME/downloads/Wellcare_${legacy}/
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*adj* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-ADJ-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*claims* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-CLAIMS-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*demographics* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-DEMOGRAPHICS-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*mlsf* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-MLSF-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*rx* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-PHARMACY-${year_month}.txt --sse AES256
aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/*spec* s3://acp-data/Wellcare/${legacy}/WELLCARE-${legacy}-SPECCAP-${year_month}.txt --sse AES256

cd $ETL_HOME/downloads/Wellcare_${legacy}/
if [ ${legacy} == 'SOMOS' ]; then
  sed -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/wellcare_somos_load_template.sql | sed -e "s/LEGACY/${legacy}/g" > $ETL_HOME/sql/wellcare_somos_load.sql
  $ETL_HOME/scripts/ipsql.sh wellcare_somos_load.sql
else
  sed -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/wellcare_legacy_load_template.sql | sed -e "s/LEGACY/${legacy}/g" > $ETL_HOME/sql/wellcare_legacy_load.sql
  $ETL_HOME/scripts/ipsql.sh wellcare_legacy_load.sql
fi
rm $ETL_HOME/temp/WELLCARE-${legacy}*${year_month}*

