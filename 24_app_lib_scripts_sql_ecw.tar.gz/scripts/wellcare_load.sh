#!/bin/bash
set -x
export legacy=$1
export year_month=$2
export SSHPASS=$FTP_01_PW

#rm -f $ETL_HOME/scripts/Wellcare_to_s3.txt
#rm -f $ETL_HOME/downloads/Wellcare_${legacy}/*
#rm -f $ETL_HOME/scripts/Wellcare_rm_file.sftp

#printf "cd /data/ftp_users/jdionisio-corinthian/incoming/WellCare/\nlcd /home/etl/etl_home/downloads/Wellcare_${legacy}/\nget *${legacy}*${year_month}.txt" > Wellcare_to_s3.sftp
#sshpass -e sftp -o BatchMode=no -b Wellcare_to_s3.sftp $FTP_01_US@10.0.12.217
#ls $ETL_HOME/downloads/Wellcare_${legacy}/ > Wellcare_to_s3.txt
#grep -iv "^#" $ETL_HOME/scripts/Wellcare_to_s3.txt |
#while read filename
#do
#aws s3 cp $ETL_HOME/downloads/Wellcare_${legacy}/${filename} s3://acp-data/Wellcare/${legacy}/$filename --sse AES256
#done


cd $ETL_HOME/downloads/Wellcare_${legacy}/
if [ ${legacy} == 'SOMOS' ]; then
  sed -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/wellcare_somos_load_template.sql | sed -e "s/LEGACY/${legacy}/g" > $ETL_HOME/sql/wellcare_somos_load.sql
  $ETL_HOME/scripts/ipsql.sh wellcare_somos_load.sql
else
  sed -e "s/YEARMONTH/${year_month}/g" $ETL_HOME/sql/wellcare_legacy_load_template.sql | sed -e "s/LEGACY/${legacy}/g" > $ETL_HOME/sql/wellcare_legacy_load.sql
  $ETL_HOME/scripts/ipsql.sh wellcare_legacy_load.sql
fi
rm $ETL_HOME/temp/WELLCARE-${legacy}*${year_month}*

