#!/bin/bash

grep -iv "^#" bucket_list.txt |
while read bucket
do
size=`aws s3api list-objects --bucket $bucket --output json --query "[sum(Contents[].Size), length(Contents[])]"`
bsize=`echo $size | awk -F"," ' { print $1 } ' | cut -c 2-`
blen=`echo $size | awk -F"," ' { print $2 } '  |  awk -F"]" ' { print $1 } '`
echo $bucket $(($bsize/1024/1024/1024)) $blen
done
