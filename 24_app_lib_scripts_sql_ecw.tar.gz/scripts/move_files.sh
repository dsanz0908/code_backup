#!/bin/bash
grep -iv "^#" files.txt |
while read filename
do
aws s3 cp $filename s3://acp-data/Fidelis/Somos/$filename --sse AES256
done
