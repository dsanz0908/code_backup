#!/bin/bash
#set -x
ls -ltr $ETL_HOME/downloads/arcadia_comprehensive | awk -F"_" ' { print $7 } ' | sort | uniq | grep -v "^$" > $ETL_HOME/temp/arcadia_uniq.lst
grep -iv "^#" $ETL_HOME/temp/arcadia_uniq.lst |
while read filetype
do
ls $ETL_HOME/downloads/arcadia_comprehensive/*${filetype}*.csv > $ETL_HOME/scripts/arcadiatosomos_files.txt
grep -iv "^#" $ETL_HOME/scripts/arcadiatosomos_files.txt |
while read filename
do
echo "Decrpting $filename ||| $o_file"
o_file=`echo $filename | awk -F"/" '{ print $7 }'`
if [ ! -f $ETL_HOME/input/$o_file ]
then
echo $ARCADIATOSOMOS_GP | gpg --batch --yes  --passphrase-fd 0 -o $ETL_HOME/input/$o_file $filename
$ETL_HOME/scripts/process_arcadia_tables.sh $filetype
rm -f $ETL_HOME/input/$o_file
fi
done
done
