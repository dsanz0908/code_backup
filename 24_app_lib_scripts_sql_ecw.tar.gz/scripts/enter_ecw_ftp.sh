#!/bin/bash

practice=$1
port=`credstash get ECW_${practice}.sftp.port`
host=`credstash get ECW_${practice}.sftp.host`
username=`credstash get ECW_${practice}.sftp.username`

rm temp_ecw_access.key
credstash get ECW_${practice}.sftp.private_key > temp_ecw_access.key
chmod 700 temp_ecw_access.key
sftp -i temp_ecw_access.key -P ${port} ${username}@${host}
