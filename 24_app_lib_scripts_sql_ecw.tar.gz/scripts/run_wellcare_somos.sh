#!/bin/bash
last_month_template="date --date='-MONTHS_TO_SUBTRACT month' +'%Y%m'"
echo "SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(receivedmonth), 'YYYYMM')) AS INT) FROM payor.wellcare_somos_all_demographics" > $ETL_HOME/sql/get_wellcare_months.sql
wellcare_months=`$ETL_HOME/scripts/ipsql.sh get_wellcare_months.sql | head -3 | tail -1 | awk '{$1=$1};1'`

for i in `seq ${wellcare_months} -1 0`
do
  month_command=`echo ""${last_month_template} | sed "s/MONTHS_TO_SUBTRACT/${i}/g"""`
  month_to_process=`eval ${month_command}`
  $ETL_HOME/scripts/wellcare_load.sh SOMOS ${month_to_process}

  echo "select count(*) from payor.wellcare_somos_all_demographics where  receivedmonth = '${month_to_process}'" > $ETL_HOME/sql/wellcare_somos_receivedmonth_count.sql
  receivedmonth_count=`$ETL_HOME/scripts/ipsql.sh wellcare_somos_receivedmonth_count.sql | sed -n '3p'`
  if (( ${receivedmonth_count} > 0 )); then
    bash process_wellcare_somos_to_arcadia.sh ${month_to_process}
  fi
done


