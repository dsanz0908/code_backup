#!/bin/bash

sql_today=`date -d '-3 day' '+%Y-%m-%d'`
cd $ETL_HOME/temp/
rm *Member*Alerts*2019*
python $ETL_HOME/lib/grab_affinity_census.py
affinity_alerts_excel=`ls *Member*Alerts*xlsx`
libreoffice --headless --convert-to csv "${affinity_alerts_excel}"
affinity_alerts_csv=`ls *Member*Alerts*csv`
aws s3 cp "${affinity_alerts_csv}" "s3://acp-data/census/affinity/${affinity_alerts_csv}"  --sse AES256

export SSHPASS=$GARAGE_SFTP_PW
printf "cd /Files/\nput "${affinity_alerts_csv}"\nls *" > to_garage.sftp
sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP
rm to_garage.sftp

aws s3 cp "${affinity_alerts_csv}" "s3://garage-s3/alert_files/affinity/${affinity_alerts_csv}"  --sse AES256
echo "delete from payor.affinity_census; copy payor.affinity_census from 's3://acp-data/census/affinity/${affinity_alerts_csv}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' fillrecord csv; update payor.affinity_census set added_tz = getdate();" > "$ETL_HOME"/sql/affinity_census_load.sql
$ETL_HOME/scripts/ipsql.sh affinity_census_load.sql
echo "unload (\$\$ SELECT * FROM (SELECT * FROM payor.affinity_census WHERE admit_date :: DATE = '${sql_today}') AS table1 WHERE NOT EXISTS (SELECT 1 FROM payor.affinity_census WHERE admit_date :: DATE < '${sql_today}' AND member_id = table1.member_id AND table1.facility_name = facility_name) \$\$) to 's3://sftp_test/${sql_today}_affinity_census_new_patients' delimiter ',' addquotes parallel off ALLOWOVERWRITE iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';" > $ETL_HOME/sql/load_affinity_census.sql
echo ${sql_today}
$ETL_HOME/scripts/ipsql.sh load_affinity_census.sql

aws s3 cp s3://sftp_test/${sql_today}_affinity_census_new_patients000 $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.csv
if [ ! -s $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.csv ]; then
  echo "No new patients from Affinity Census for ${sql_today} from Somos/Optimus"| mail -s "Affinity Census" mgonzalez@rapidcaresolution.com,nlopez@somoscommunitycare.org
else
  sed -i '1s/^/lob,authorization_number,notification_date,admit_date,discharge_date,member_id,last_name,first_name,date_of_birth,provider_name,provider_id#,facility_name,approved_units,alternative_authorization_number,diagnosis,decision_status,event,added_tz,modified_tz\n/' $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.csv
  zip -j --password Balance321 $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.zip $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.csv
  aws s3 cp $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.zip s3://sftp_test/${sql_today}_affinity_census_new_patients.zip
  aws s3 rm s3://sftp_test/${sql_today}_affinity_census_new_patients000
  rm $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.csv
  echo "New Patients from Affinity Census for ${sql_today} from Somos/Optimus"| mail -s "Affinity Census" -a $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.zip mgonzalez@rapidcaresolution.com,nlopez@somoscommunitycare.org
  rm $ETL_HOME/temp/${sql_today}_affinity_census_new_patients.zip
fi

