#!/bin/bash

export legacy=$1

MONTHS=(ZERO Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec)
last_month=`date -d '-1 month' +'%m' | sed 's/^0*//'`
wellcare_month=`echo ${MONTHS[$a]}`
wellcare_month="Sep"
yearmonth=`date '+%Y%m'`
yearmonth="201909"

rm -f $ETL_HOME/downloads/Wellcare_${legacy}/*
python $ETL_HOME/lib/grab_wellcare_caregaps.py ${legacy} $wellcare_month
mv $ETL_HOME/temp/*${legacy}*_gapfile.zip $ETL_HOME/downloads/Wellcare_${legacy}/
zipfile=`ls $ETL_HOME/downloads/Wellcare_${legacy}/`
unzip -oP "WellC@re17!" $ETL_HOME/downloads/Wellcare_${legacy}/${zipfile}
#unzip -oP "WellC@re17!" $ETL_HOME/temp/CMI_CORINTHIAN_gapfile.zip
#aws s3 cp $ETL_HOME/temp/CMI_CORINTHIAN_gapfile.txt s3://Wellcare/CORINTHIAN/WELLCARE_CORINTHIAN_CAREGAPS_{$yearmonth}.txt
