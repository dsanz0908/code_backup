#!/bin/bash
RECEIVED_MONTH_FIELD=$1
TABLE_NAME=$2
MCO_SCRIPT=$3

last_month_template="date --date='-MONTHS_TO_SUBTRACT month' +'%Y%m'"
query_template="SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(RECIEVED_MONTH_FIELD), 'YYYYMM')) AS INT) FROM payor.TABLE_NAME"

echo ${query_template} | sed "s/RECIEVED_MONTH_FIELD/${RECEIVED_MONTH_FIELD}/g" | sed "s/TABLE_NAME/${TABLE_NAME}/g" > $ETL_HOME/sql/get_mco_missing_months.sql
mco_missing_months=`$ETL_HOME/scripts/ipsql.sh get_mco_missing_months.sql | head -3 | tail -1 | awk '{$1=$1};1'`

for i in `seq ${mco_missing_months} -1 0`
do
  month_command=`echo ""${last_month_template} | sed "s/MONTHS_TO_SUBTRACT/${i}/g"""`
  month_to_process=`eval ${month_command}`
  eval "bash ${MCO_SCRIPT} ${month_to_process}"
done

