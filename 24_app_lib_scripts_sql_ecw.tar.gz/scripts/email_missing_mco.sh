#!/bin/bash

last_month=`date --date='-1 month'  +'%Y%m'`
email_string=""
echo "SELECT Max(period) FROM payor.affinity_somos_roster_all" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Affinity Somos: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(period) FROM payor.affinity_corinthian_all_rosters" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Affinity Corinthian: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(received_month) FROM payor.empire_bcbs_healthplus_legacy_all_claims_oldformat" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Anthem Corinthian: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(received_month) FROM payor.empire_somos_claim_det" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Empire Somos: last received month was ${missing_months}.\n"
fi
echo "select Max(received_month) AS months FROM payor.healthfirst_all_claims where lower(filename) like '%corinthian%'" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Healthfirst Corinthian: last received month was ${missing_months}.\n"
fi
echo "select Max(received_month) AS months FROM payor.healthfirst_all_claims where lower(filename) like '%excelsior%'" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Healthfirst Excelsior: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(received_month) FROM payor.healthfirst_somos_all_claims" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Healthfirst Somos: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(received_month) FROM payor.uhc_somos_all_membership" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="UHC Somos: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(receivedmonth) FROM payor.wellcare_all_claims where master_ipa = 'CMI'" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Wellcare Corinthian: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(receivedmonth) FROM payor.wellcare_all_claims where master_ipa = 'EC1'" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Wellcare ECAP: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(receivedmonth) FROM payor.wellcare_all_claims where master_ipa = 'EX1'" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Wellcare Excelsior: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(receivedmonth) FROM payor.wellcare_all_claims where master_ipa = 'VR1'" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Wellcare Balance: last received month was ${missing_months}.\n"
fi
echo "SELECT Max(receivedmonth) FROM payor.wellcare_somos_all_claims" > $ETL_HOME/sql/email_missing_mco.sql
missing_months=`$ETL_HOME/scripts/ipsql.sh email_missing_mco.sql | head -3 | tail -1 | awk '{$1=$1};1'`
if [[ ! ${missing_months} == ${last_month} ]]; then
  email_string+="Wellcare Somos: last received month was ${missing_months}.\n"
fi


printf "${email_string}" | mail -s "MCO Data Gap" dsanz@somoscommunitycare.org,kjackto@somoscommunitycare.org,ssundararaman@somoscommunitycare.org,darslan@somoscommunitycare.org,mcabral@somoscommunitycare.org,svarughese@somoscommunitycare.org,jdionisio@somoscommunitycare.org

#printf "${email_string}" | mail -s "MCO Data Gap" dsanz@somoscommunitycare.org



