#!/bin/bash
export receivedmonth=$1
sed -e "s/RECEIVEDMONTH/${receivedmonth}/g" $ETL_HOME/sql/optimus_healthfirst_medicare_template.sql > $ETL_HOME/sql/optimus_healthfirst_medicare.sql
$ETL_HOME/scripts/ipsql.sh optimus_healthfirst_medicare.sql

