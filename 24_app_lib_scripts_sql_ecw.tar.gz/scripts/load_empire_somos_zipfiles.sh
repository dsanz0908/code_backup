#!/bin/bash
set -x
export zip_date=$1
export SSHPASS=$FTP_01_PW
echo ${received_month}
anthem_somos="/data/downloads/Anthem_Somos/"
#sshpass -e scp $FTP_01_US@10.0.12.217:/data/anthem-ftp/SOMOS_zipfiles_${zip_date}.zip ${anthem_somos}
#unzip -d ${anthem_somos}SOMOS_zipfiles_${zip_date} ${anthem_somos}SOMOS_zipfiles_${zip_date}.zip
cd ${anthem_somos}SOMOS_zipfiles_${zip_date}/;
ls *out | grep -v ctl |
while read filename
do
aws s3 cp ${filename} s3://acp-data/Anthem/Somos/${filename} --sse AES256
filedate=`echo ${filename} | awk -F'.' '{print $1}' | awk -F'_' '{print $NF}'`
table_name=`echo ${filename} | awk -F "_${filedate}" '{print $1}'`
received_month="${filedate:4:7}${filedate:0:2}"
cat $ETL_HOME/sql/load_empire_zipfiles_template.sql | sed -e "s/RECEIVED_MONTH/${received_month}/g" | sed -e "s/TABLE_NAME/${table_name}/g" | sed -e "s/FILENAME/${filename}/" > $ETL_HOME/sql/load_empire_zipfiles.sql
$ETL_HOME/scripts/ipsql.sh load_empire_zipfiles.sql
done
