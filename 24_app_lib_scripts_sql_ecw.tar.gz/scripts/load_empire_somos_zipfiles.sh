#!/bin/bash
export receivedmonth=$1
export zip_date="${receivedmonth: -2}${receivedmonth:0:4}"
export SSHPASS=$FTP_01_PW
anthem_somos="/data/downloads/Anthem_Somos/"
#rm -r ${anthem_somos}/*
#rm ${anthem_somos}/*
#sshpass -e scp $FTP_01_US@10.0.12.217:/data/anthem-ftp/SOMOS_zipfiles_${zip_date}.zip ${anthem_somos}
#unzip -d ${anthem_somos}SOMOS_zipfiles_${zip_date} ${anthem_somos}SOMOS_zipfiles_${zip_date}.zip
cd ${anthem_somos}SOMOS_zipfiles_${zip_date}/;
ls ${anthem_somos}SOMOS_zipfiles_${zip_date}/* | grep -v ctl |
while read filename
do
echo '================='
filename_base=`basename $filename`
aws s3 cp ${filename_base} s3://acp-data/Anthem/Somos/${filename_base} --sse AES256
table_name=`echo ${filename_base} | awk -F'.' '{print $1}' | awk -F"_${receivedmonth: -2}" '{print $1}'`
cat $ETL_HOME/sql/load_empire_zipfiles_template.sql | sed "s/RECEIVED_MONTH/${receivedmonth}/g" | sed "s/TABLE_NAME/${table_name}/g" | sed "s/FILENAME/${filename_base}/g" > $ETL_HOME/sql/load_empire_zipfiles.sql
$ETL_HOME/scripts/ipsql.sh load_empire_zipfiles.sql
done

#bash process_empire_somos_to_garage.sh $receivedmonth
