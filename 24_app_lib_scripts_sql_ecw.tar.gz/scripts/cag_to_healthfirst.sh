#!/bin/bash
today=`date '+%Y%m%d'`;
cag="$ETL_HOME/temp/cag_"
rm ${cag}*
sqlcmd -D -S arcadia_replica -U ACPPS_ClientAccess -P 490qXXAAt6zsSvFL -d ACPPS_WAREHOUSE_PRD01 -i $ETL_HOME/sql/cag2.sql -o ${cag}${today}_temp.txt -h-1 -W -w 999 -s"|"
echo "measure|personid|memberid|memberno|member_name|dob|age|sex|membership_startdate|membership_enddate|planpayer|planproduct|denominator|eventstartdate|eventenddate|eventcodevalue|eventsourcesystem|eventprovidername|eventprovidernpi|eventlocationname|numerator|diagnosis_code" > ${cag}headers.txt
cat ${cag}headers.txt ${cag}${today}_temp.txt > ${cag}${today}.txt
bash $ETL_HOME/scripts/piped_file_to_excel.sh ${cag}${today}.txt ${cag}${today}.xlsx
aws s3 cp ${cag}${today}.xlsx s3://acp-data/CAG/cag_${today}.xlsx --sse AES256
export SSHPASS=$HF_SUPPLEMENTARY_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/cag_healthfirst.sftp somosipa@hfftp.healthfirst.org

