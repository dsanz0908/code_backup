#!/bin/bash
latest_file=`aws s3 ls s3://acp-ecap/2019/ | sort -r | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//' | head -1`
received_month="2019`echo "${latest_file}" | awk -F'allfiles' '{print $2}' | tr -d -c 0-9 | cut -c1-2`"
echo "select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EC1'"> $ETL_HOME/sql/wellcare_ecap_maxmonth.sql
maxmonth="`$ETL_HOME/scripts/ipsql.sh wellcare_ecap_maxmonth.sql | head -3 | tail -1 | awk '{$1=$1};1'`"
echo ${maxmonth}
echo ${received_month}
if [[ ${maxmonth} == ${received_month} ]]; then
  exit
else
  rm $ETL_HOME/downloads/Wellcare_ECAP/*
  aws s3 cp "s3://acp-ecap/2019/${latest_file}" $ETL_HOME/downloads/Wellcare_ECAP/
  unzip -oP "WellC@re17!" "$ETL_HOME/downloads/Wellcare_ECAP/${latest_file}" -d $ETL_HOME/downloads/Wellcare_ECAP/
  aws s3 cp $ETL_HOME/downloads/Wellcare_ECAP/EC1_EASTERNCHI_claims.txt s3://acp-data/Wellcare/ECAP/WELLCARE-ECAP-CLAIMS-${received_month}.txt --sse AES256
  aws s3 cp $ETL_HOME/downloads/Wellcare_ECAP/EC1_EASTERNCHI_rx.txt s3://acp-data/Wellcare/ECAP/WELLCARE-ECAP-PHARMACY-${received_month}.txt --sse AES256
  aws s3 cp $ETL_HOME/downloads/Wellcare_ECAP/EC1_EASTERNCHI_demographics.txt s3://acp-data/Wellcare/ECAP/WELLCARE-ECAP-DEMOGRAPHICS-${received_month}.txt --sse AES256
  sed -e "s/YEARMONTH/${received_month}/g" $ETL_HOME/sql/wellcare_ecap_load_format_2_template.sql > $ETL_HOME/sql/wellcare_ecap_load_format_2.sql
  ./ipsql.sh wellcare_ecap_load_format_2.sql
fi
