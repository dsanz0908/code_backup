#!/bin/bash
set -x
export SSHPASS=$MDLAND_PW
yesterday=`date -d "yesterday 13:00" '+%m_%d_%Y.zip'`
#yesterday="04_10_2019.zip"
rm $ETL_HOME/downloads/mdland/*
printf "cd /outgoing/ACP_ReportData\nlcd /home/etl/etl_home/downloads/mdland/\nget *${yesterday}" > downloaded_mdland_files.sftp
sshpass -e sftp -o BatchMode=no -b downloaded_mdland_files.sftp acp@sftp-prod.mdland.com
ls $ETL_HOME/downloads/mdland/*zip |
while read zips
do
unzip -P mdland "${zips}" -d $ETL_HOME/downloads/mdland/
done

ls $ETL_HOME/downloads/mdland/*xlsx |
while read excels
do
ps -ef | grep libreoffice | grep -v color | awk '{print $2}' | xargs kill -9
libreoffice --headless --convert-to csv --outdir $ETL_HOME/downloads/mdland/ "${excels}"
done

ls $ETL_HOME/downloads/mdland/*csv |
while read filename
do
aws s3 cp "${filename}" s3://acp-data/mdland/ --sse AES256
columns=`head -1 "${filename}" | tr '[:upper:]' '[:lower:]'`
echo "create temp table if not exists staging_mdland ( " > $ETL_HOME/sql/mdland_load.sql

echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" >> $ETL_HOME/sql/mdland_load.sql

echo 'VARCHAR(255));' >> $ETL_HOME/sql/mdland_load.sql
echo "grant all on staging_mdland to etluser;" >> $ETL_HOME/sql/mdland_load.sql
echo "copy staging_mdland from 's3://acp-data/mdland/${filename##*/}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;" >> $ETL_HOME/sql/mdland_load.sql
echo "delete from feeds.mdland_all where filename = '${filename##*/}';" >> $ETL_HOME/sql/mdland_load.sql
echo "insert into feeds.mdland_all (${columns}, filename) select ${columns}, '${filename##*/}' from staging_mdland;" >> $ETL_HOME/sql/mdland_load.sql
./ipsql.sh mdland_load.sql
done;
