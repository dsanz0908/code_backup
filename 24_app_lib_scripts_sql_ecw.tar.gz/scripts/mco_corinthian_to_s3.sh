#!/bin/bash
#set -x
#export SSHPASS=$MCO_SFTP_PW
#rm -f $ETL_HOME/scripts/healthfirst_to_s3.txt
#rm -f $ETL_HOME/downloads/Healthfirst_Corinthian/*
#rm -f $ETL_HOME/scripts/healthfirst_rm_file.sftp
#sshpass -e sftp -o BatchMode=no -b healthfirst_to_s3.sftp $MCO_SFTP_US@10.0.12.217
ls $ETL_HOME/downloads/Healthfirst_Corinthian/ > healthfirst_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/Healthfirst_to_s3.txt |
while read filename
do
#aws s3 cp $ETL_HOME/downloads/Healthfirst_Corinthian/$filename s3://acp-data/Healthfirst/Corinthian/$filename --sse AES256
#echo "rm /data/ftp_users/jdionisio-corinthian/incoming/Healthfirst/${filename}" >> $ETL_HOME/scripts/healthfirst_rm_file.sftp
cd $ETL_HOME/downloads/Healthfirst_Corinthian/
#sshpass -e sftp -o BatchMode=no -b healthfirst_rm_file.sftp $MCO_SFTP_US@10.0.12.217
filetype=`echo $filename  | awk -F "." ' { print $1 } ' | awk -F "-" ' { print $3 } '`
receivedmonth=`echo $filename  | awk -F "." ' { print $1 } ' | awk -F "-" ' { print $4 } '`
if [ "$filetype" == "ELIGIBILITY" ] || [ "$filetype" == "CLAIM" ] || [ "$filetype" == "PHARMACY" ] 
#aws s3 cp $ETL_HOME/downloads/Healthfirst_Corinthian/$filename s3://acp-data/Healthfirst/Corinthian/$filename --sse AES256
then 
columns=`head -1 $filename`
echo "drop table payor.staging_healthfirst_corinthian_${filetype};" > $ETL_HOME/sql/Healthfirst_${filetype}_columns.sql 
echo "create table if not exists payor.staging_healthfirst_corinthian_${filetype} ( " >> $ETL_HOME/sql/Healthfirst_${filetype}_columns.sql
echo $columns | sed -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/-//g" -e "s/*//g" >> $ETL_HOME/sql/Healthfirst_${filetype}_columns.sql
echo "grant all on payor.staging_healthfirst_corinthian_${filetype} to etluser;" >> $ETL_HOME/sql/Healthfirst_${filetype}_columns.sql
sed -e "s/FILETYPE/${filetype}/g" -e "s/FILENAME/${filename}/g" $ETL_HOME/sql/Healthfirst_load_template.sql > $ETL_HOME/sql/Healthfirst_load_${filetype}.sql 
cd $ETL_HOME/scripts/
./ipsql.sh Healthfirst_${filetype}_automation.sql > $ETL_HOME/sql/Healthfirst_${filetype}_query1.sql
master_table=`./ipsql.sh Healthfirst_${filetype}_master_table.sql | sed -n '3p'`
echo "delete from ${master_table} where filename = '${filename}';" > $ETL_HOME/sql/Healthfirst_${filetype}_query.sql
echo "insert into ${master_table} ( " >> $ETL_HOME/sql/Healthfirst_${filetype}_query.sql
grep -iv "^-" $ETL_HOME/sql/Healthfirst_${filetype}_query1.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" >> $ETL_HOME/sql/Healthfirst_${filetype}_query.sql
echo "added_tz )" >> $ETL_HOME/sql/Healthfirst_${filetype}_query.sql
./ipsql.sh Healthfirst_${filetype}_automation_1.sql > $ETL_HOME/sql/Healthfirst_${filetype}_query2.sql
echo "select " > $ETL_HOME/sql/Healthfirst_${filetype}_query2_1.sql
grep -iv "^-" $ETL_HOME/sql/Healthfirst_${filetype}_query2.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" | sed -e "s/FILENAME/${filename}/g" -e "s/RECEIVEDMONTH/\'${receivedmonth}\'/g" >> $ETL_HOME/sql/Healthfirst_${filetype}_query2_1.sql
echo " GETDATE() from payor.staging_healthfirst_corinthian_${filetype}" >> $ETL_HOME/sql/Healthfirst_${filetype}_query2_1.sql
cat $ETL_HOME/sql/Healthfirst_${filetype}_query2_1.sql >> $ETL_HOME/sql/Healthfirst_${filetype}_query.sql
#./ipsql.sh healthfirst_${filetype}_columns.sql
#./ipsql.sh healthfirst_load_${filetype}.sql
#./ipsql.sh healthfirst_${filetype}_query.sql
fi 
done
