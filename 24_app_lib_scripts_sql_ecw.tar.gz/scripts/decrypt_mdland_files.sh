#!/bin/bash

rm $ETL_HOME/downloads/mdland/*
cd $ETL_HOME/downloads/mdland/

yesterday=`date -d '-1 day' '+%Y%m%d'`
yesterday_folder=`aws s3 ls s3://acp-arcadia-mdland/ec21/ | grep $yesterday | awk '{print $2}'`
aws s3 ls s3://acp-arcadia-mdland/ec21/$yesterday_folder | awk '{print $4}' |
while read filename
do
  aws s3 cp s3://acp-arcadia-mdland/ec21/$yesterday_folder$filename .
  echo $FTP_01_PW | gpg --batch --yes  --passphrase-fd 0 $filename
done

ls *csv |
while read csv
do
  aws s3 cp $csv s3://acp-arcadia-mdland/decrypted/ --sse AES256
done
