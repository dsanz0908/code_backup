#!/bin/bash
rm -r /data/nydoh/201910_2
aws s3 cp s3://acp-nydoh/201910_2 /data/nydoh/201910_2 --recursive
ls /data/nydoh/201910_2/*.pgp > list.txt
rm -r $ETL_HOME/output/201910_2/
mkdir $ETL_HOME/output/201910_2/
grep -iv "^#" list.txt |
while read filename
do
claims=`echo $filename | grep "MAPPAS0014"`
pharmacy_claims=`echo $filename | grep "MAPPAS0021"`
shred=`echo $filename | grep "MAPPAS0018"`
roster=`echo $filename | grep "MAPPAS0012"`
patient_alert=`echo $filename | grep "MAPPAS0022"`
cpa=`echo $filename | grep "CPA"`
if [  "$claims"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201910_2/claims.gz --batch --yes  --passphrase-fd 0 $claims
        gunzip $ETL_HOME/output/201910_2/claims.gz
        mv $ETL_HOME/output/201910_2/claims $ETL_HOME/output/201910_2/claims.txt
elif [  "$pharmacy_claims" ]
then
        echo "" | gpg --output $ETL_HOME/output/201910_2/rx_claims.gz --batch --yes  --passphrase-fd 0 $pharmacy_claims
        gunzip $ETL_HOME/output/201910_2/rx_claims.gz
        mv $ETL_HOME/output/201910_2/rx_claims $ETL_HOME/output/201910_2/rx_claims.txt
elif [  "$shred"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201910_2/shred.txt --batch --yes  --passphrase-fd 0 $shred
elif [  "$roster"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201910_2/roster.txt --batch --yes  --passphrase-fd 0 $roster
elif [  "$patient_alert"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201910_2/patient_alerts.txt --batch --yes  --passphrase-fd 0 $patient_alert
elif [  "$cpa"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201910_2/cpa.txt --batch --yes  --passphrase-fd 0 "$cpa"
fi
done

aws s3 cp $ETL_HOME/output/201910_2/ s3://acp-data/NYDOH/201910_2/ --recursive --sse AES256
rm -r $ETL_HOME/output/201910_2/
