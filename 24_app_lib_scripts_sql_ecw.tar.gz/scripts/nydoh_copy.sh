#!/bin/bash
rm -r /data/nydoh/201901
aws s3 cp s3://acp-nydoh/201901 /data/nydoh/201901 --recursive
ls /data/nydoh/201901/*.pgp > list.txt
rm -r $ETL_HOME/output/201901/
mkdir $ETL_HOME/output/201901/
grep -iv "^#" list.txt |
while read filename
do
claims=`echo $filename | grep "MAPPAS0014"`
pharmacy_claims=`echo $filename | grep "MAPPAS0021"`
#echo $pharmacy_claims
shred=`echo $filename | grep "MAPPAS0018"`
#echo $shred
roster=`echo $filename | grep "MAPPAS0012"`
#echo $roster
patient_alert=`echo $filename | grep "MAPPAS0022"`
#echo $patient_alert
cpa=`echo $filename | grep "CPA"`
#echo $cpa
if [  "$claims"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201901/claims.gz --batch --yes  --passphrase-fd 0 $claims
        gunzip $ETL_HOME/output/201901/claims.gz
        mv $ETL_HOME/output/201901/claims $ETL_HOME/output/201901/claims.txt
elif [  "$pharmacy_claims" ]
then
        echo "" | gpg --output $ETL_HOME/output/201901/rx_claims.gz --batch --yes  --passphrase-fd 0 $pharmacy_claims
        gunzip $ETL_HOME/output/201901/rx_claims.gz
        mv $ETL_HOME/output/201901/rx_claims $ETL_HOME/output/201901/rx_claims.txt
elif [  "$shred"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201901/shred.txt --batch --yes  --passphrase-fd 0 $shred
elif [  "$roster"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201901/roster.txt --batch --yes  --passphrase-fd 0 $roster
elif [  "$patient_alert"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201901/patient_alerts.txt --batch --yes  --passphrase-fd 0 $patient_alert
elif [  "$cpa"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201901/cpa.txt --batch --yes  --passphrase-fd 0 "$cpa"
fi
done

aws s3 cp $ETL_HOME/output/201901/ s3://acp-data/NYDOH/201901/ --recursive --sse AES256
rm -r $ETL_HOME/output/201901/
