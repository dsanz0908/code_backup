#!/bin/bash
rm -r /data/nydoh/201906
aws s3 cp s3://acp-nydoh/201906 /data/nydoh/201906 --recursive
ls /data/nydoh/201906/*.pgp > list.txt
rm -r $ETL_HOME/output/201906/
mkdir $ETL_HOME/output/201906/
grep -iv "^#" list.txt |
while read filename
do
claims=`echo $filename | grep "MAPPAS0014"`
pharmacy_claims=`echo $filename | grep "MAPPAS0021"`
#echo $pharmacy_claims
shred=`echo $filename | grep "MAPPAS0018"`
#echo $shred
roster=`echo $filename | grep "MAPPAS0012"`
#echo $roster
patient_alert=`echo $filename | grep "MAPPAS0022"`
#echo $patient_alert
cpa=`echo $filename | grep "CPA"`
#echo $cpa
if [  "$claims"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201906/claims.gz --batch --yes  --passphrase-fd 0 $claims
        gunzip $ETL_HOME/output/201906/claims.gz
        mv $ETL_HOME/output/201906/claims $ETL_HOME/output/201906/claims.txt
elif [  "$pharmacy_claims" ]
then
        echo "" | gpg --output $ETL_HOME/output/201906/rx_claims.gz --batch --yes  --passphrase-fd 0 $pharmacy_claims
        gunzip $ETL_HOME/output/201906/rx_claims.gz
        mv $ETL_HOME/output/201906/rx_claims $ETL_HOME/output/201906/rx_claims.txt
elif [  "$shred"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201906/shred.txt --batch --yes  --passphrase-fd 0 $shred
elif [  "$roster"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201906/roster.txt --batch --yes  --passphrase-fd 0 $roster
elif [  "$patient_alert"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201906/patient_alerts.txt --batch --yes  --passphrase-fd 0 $patient_alert
elif [  "$cpa"  ]
then
        echo "" | gpg --output $ETL_HOME/output/201906/cpa.txt --batch --yes  --passphrase-fd 0 "$cpa"
fi
done

aws s3 cp $ETL_HOME/output/201906/ s3://acp-data/NYDOH/201906/ --recursive --sse AES256
rm -r $ETL_HOME/output/201906/
