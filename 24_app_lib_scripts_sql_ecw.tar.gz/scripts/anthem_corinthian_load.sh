#!/bin/bash
set -x
export SSHPASS=$ANTHEM_CORINTHIAN_SFTP_PW
export receivedmonth=$1
rm -f $ETL_HOME/scripts/Anthem_to_s3.txt
rm -f $ETL_HOME/downloads/Anthem_Corinthian/*
printf "cd /Corinthian_Medical/Amerigroup_Sftp/Outbound\nlcd /data/downloads/Anthem_Corinthian/\nget *${receivedmonth}.TXT" > $ETL_HOME/scripts/Anthem_to_s3.sftp
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/Anthem_to_s3.sftp Corinthian_Medical@ftp2.amerigroup.com
ls $ETL_HOME/downloads/Anthem_Corinthian/ > Anthem_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/Anthem_to_s3.txt |
while read filename
do
sed -e "s/\\$//g" -e "s/*//g" -e "s/†//g" -e '1s/^\xEF\xBB\xBF//' $ETL_HOME/downloads/Anthem_Corinthian/$filename > $ETL_HOME/downloads/Anthem_Corinthian/${filename}_1
aws s3 cp $ETL_HOME/downloads/Anthem_Corinthian/${filename}_1 s3://acp-data/Anthem/Corinthian/$filename --sse AES256
cd $ETL_HOME/downloads/Anthem_Corinthian/
filetype=`echo $filename  | awk -F '_' '{print $4}'`
if [ "$filetype" == "Enrollment" ] ||  [ "$filetype" == "MEDICAL" ] ||  [ "$filetype" == "RX" ]
then
columns=`head -1 $filename`
echo "create temp table if not exists staging_anthem_corinthian_${filetype} ( " > $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql

# FOR THE LINE BELOW, THE SED COMMAND: THIRD REPLACEMENT (turning comma to varchar) may need to be replaced by space (or something else) when dealing with space delimited files
echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/ / VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" -e "s/Service_Code_Description VARCHAR(255)/Service_Code_Description VARCHAR(300)/g" >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql

echo "grant all on staging_anthem_corinthian_${filetype} to etluser;" >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
echo "copy staging_anthem_corinthian_${filetype} from 's3://acp-data/Anthem/Corinthian/${filename}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter ' ' removequotes;" >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
cd $ETL_HOME/scripts/

$ETL_HOME/scripts/ipsql.sh Anthem_${filetype}_automation.sql > $ETL_HOME/sql/Anthem_${filetype}_query1.sql

master_table=`$ETL_HOME/scripts/ipsql.sh Anthem_Corinthian_${filetype}_master_table.sql | sed -n '3p'`
echo "delete from ${master_table} where filename = '${filename}';" >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
echo "insert into ${master_table} ( " >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
grep -iv "^-" $ETL_HOME/sql/Anthem_${filetype}_query1.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" | sed -e "$ s/.$//" >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
echo ")" >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
$ETL_HOME/scripts/ipsql.sh Anthem_${filetype}_automation_1.sql > $ETL_HOME/sql/Anthem_${filetype}_query2.sql
echo "select " > $ETL_HOME/sql/Anthem_${filetype}_query2_1.sql
grep -iv "^-" $ETL_HOME/sql/Anthem_${filetype}_query2.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" | sed -e "s/FILENAME/${filename}/g" -e "s/RECEIVEDMONTH/\'${receivedmonth}\'/g" | sed -e "$ s/.$//" >> $ETL_HOME/sql/Anthem_${filetype}_query2_1.sql
echo "from staging_anthem_corinthian_${filetype};" >> $ETL_HOME/sql/Anthem_${filetype}_query2_1.sql
cat $ETL_HOME/sql/Anthem_${filetype}_query2_1.sql >> $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
$ETL_HOME/scripts/ipsql.sh Anthem_Corinthian_${filetype}.sql

rm $ETL_HOME/sql/Anthem_Corinthian_${filetype}.sql
rm $ETL_HOME/sql/Anthem_${filetype}_query1.sql
rm $ETL_HOME/sql/Anthem_${filetype}_query2.sql
rm $ETL_HOME/sql/Anthem_${filetype}_query2_1.sql
fi
done

echo "select count(*) from payor.anthem_corinthian_all_rosters where received_month = '${receivedmonth}'" > $ETL_HOME/sql/anthem_corinthian_receivedmonth_count.sql
receivedmonth_count=`$ETL_HOME/scripts/ipsql.sh anthem_corinthian_receivedmonth_count.sql | sed -n '3p'`
if (( ${receivedmonth_count} > 0 )); then
  bash process_anthem_legacy_to_arcadia.sh ${receivedmonth}
fi
