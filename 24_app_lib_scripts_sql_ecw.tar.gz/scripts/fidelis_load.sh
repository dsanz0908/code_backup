#!/bin/bash
export yearmonth=$1
export SSHPASS=$FIDELIS_SFTP_PWD

cd $ETL_HOME/downloads/Fidelis_Somos/
rm $ETL_HOME/downloads/Fidelis_Somos/*
printf "cd /FromFidelis/\nlcd /data/downloads/Fidelis_Somos\nmget *${yearmonth}*.txt\n" > fidelis_somos.sftp
sshpass -e sftp -o BatchMode=no -b fidelis_somos.sftp $FIDELIS_SFTP_USER@$FIDELIS_SFTP_FTP
rm fidelis_somos.sftp

ls *${yearmonth}*txt > $ETL_HOME/scripts/Fidelis_Somos_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/Fidelis_Somos_to_s3.txt |
while read filename
do
  aws s3 cp ${filename} s3://acp-data/Fidelis/Somos/${filename} --sse AES256
  columns=`head -1 "${filename}" | tr '[:upper:]' '[:lower:]' | sed 's///g' `
  sql_columns=`echo ${columns} | sed -e 's/|/,/g'`
  table_name=`echo ${filename} | awk -F'_2016' '{print $1}' | sed -e 's/INNOVATOR/_all/g'`| sed -e 's/Innovator/_all/g'`
  echo "drop table if exists staging_fidelis;" > $ETL_HOME/sql/fidelis_load.sql
  echo "create temp table if not exists staging_fidelis ( " >> $ETL_HOME/sql/fidelis_load.sql

  echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" >> $ETL_HOME/sql/fidelis_load.sql

  echo 'VARCHAR(255));' >> $ETL_HOME/sql/fidelis_load.sql
  echo "grant all on staging_fidelis to etluser;" >> $ETL_HOME/sql/fidelis_load.sql
  echo "copy staging_fidelis from 's3://acp-data/Fidelis/Somos/${filename}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter '|';" >> $ETL_HOME/sql/fidelis_load.sql
  echo "delete from payor.${table_name} where filename = '${filename}';" >> $ETL_HOME/sql/fidelis_load.sql
  echo "insert into payor.${table_name} (${sql_columns}, filename, received_month) select ${sql_columns}, '${filename}', '${yearmonth}' from staging_fidelis;" >> $ETL_HOME/sql/fidelis_load.sql
  bash $ETL_HOME/scripts/ipsql.sh fidelis_load.sql
done

