#!/bin/bash

ls $ETL_HOME/input/RHIO_to_Rapid |
while read filename
do
python $ETL_HOME/lib/bronx_rhio_data_enrichement.py ${filename}
done
