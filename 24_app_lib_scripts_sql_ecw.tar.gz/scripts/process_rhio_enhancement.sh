#!/bin/bash
export filename=$1
python /home/etl/etl_home/lib/bronx_rhio_data_enrichement.py ${filename}
