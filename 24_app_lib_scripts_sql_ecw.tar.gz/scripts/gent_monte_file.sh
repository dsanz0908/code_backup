#!/bin/bash

#$ETL_HOME/scripts/ipsql.sh monte.sql
aws s3 cp s3://sftp_test/SomosEligibility_Batch3_06292018_750.txt000 $ETL_HOME/temp/.
echo "member_id ( healthplan)|member cin (required)|member ssn|member_dob|member_gender|dual eligible (y/n)|member_last_name|member_first_name|member_middle_name|member_address1|member_address2|member_city|member_state|member_zip|member_email|healthplan|member home/main phone number|member cell phone number|member work number|pcp npi|somos enrollment date|somos term date?" > $ETL_HOME/temp/SomosEligibility_Batch3_06292018_750.txt
cat $ETL_HOME/temp/SomosEligibility_Batch3_06292018_750.txt000 >> $ETL_HOME/temp/SomosEligibility_Batch3_06292018_750.txt



