#!/bin/bash
set -x
#env | grep -i bronx
export SSHPASS=$ARCADIATOBRONX_SH
rm -f /home/etl/etl_home/scripts/Arcadia_to_RHIO.txt
rm -f /home/etl/etl_home/downloads/Arcadia_to_RHIO/*
rm -f /home/etl/etl_home/scripts/Arcadia_rename_RHIO.sftp
sshpass -e sftp -o BatchMode=no -b /home/etl/etl_home/scripts/Arcadia_to_RHIO_1.sftp $ARCADIATOBRONX_FTP@sftp.arcadiaanalytics.com
ls /home/etl/etl_home/downloads/Arcadia_to_RHIO/ > /home/etl/etl_home/scripts/Arcadia_to_RHIO.txt
grep -iv "^#" /home/etl/etl_home/scripts/Arcadia_to_RHIO.txt |
while read filename
do
echo "rename ${filename} Archive/${filename}" >> /home/etl/etl_home/scripts/Arcadia_rename_RHIO.sftp
done

sshpass -e sftp -o BatchMode=no -b /home/etl/etl_home/scripts/Arcadia_rename_RHIO.sftp $ARCADIATOBRONX_FTP@sftp.arcadiaanalytics.com

export SSHPASS=$BRONXRHIO_SH
echo $BRONXRHIO_SH
sshpass -e sftp -o BatchMode=no -b /home/etl/etl_home/scripts/Arcadia_to_RHIO_2.sftp SFTP_ACP@64.90.194.134
