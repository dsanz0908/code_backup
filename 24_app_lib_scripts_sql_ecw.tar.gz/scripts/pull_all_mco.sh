#!/bin/bash

bash run_missing_mco_month.sh period affinity_corinthian_all_rosters affinity_corinthian_load.sh

echo "SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(period), 'YYYYMM')) AS INT) FROM payor.affinity_somos_roster_all" > $ETL_HOME/sql/get_mco_missing_months.sql
mco_missing_months=`$ETL_HOME/scripts/ipsql.sh get_mco_missing_months.sql | head -3 | tail -1 | awk '{$1=$1};1'`

bash run_missing_mco_month.sh received_month anthem_corinthian_all_rosters anthem_corinthian_load.sh
bash run_missing_mco_month.sh received_month empire_bcbs_healthplus_somos_all_roster empire_bcbs_somos_automation.sh
bash run_missing_mco_month.sh received_month healthfirst_all_eligibility healthfirst_corinthian_load.sh

