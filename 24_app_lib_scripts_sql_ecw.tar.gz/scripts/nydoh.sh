#!/bin/bash
export from_period=$1
export to_period=$2
sed -e "s/FROMPERIOD/${from_period}/g" $ETL_HOME/sql/nydoh_template.sql | sed -e "s/TOPERIOD/${to_period}/g" > $ETL_HOME/sql/nydoh.sql
sed -e "s/TOPERIOD/${to_period}/g" $ETL_HOME/scripts/nydoh_copy_template.sh > $ETL_HOME/scripts/nydoh_copy.sh
cd $ETL_HOME/scripts/
chmod +x nydoh_copy.sh
./nydoh_copy.sh
$ETL_HOME/scripts/ipsql.sh nydoh.sql
./arcadia_copy.sh ${to_period}
