#!/bin/bash

rm /data/downloads/uhc_census/*
export SSHPASS=$UHC_SOMOS_PW
sshpass -e sudo sftp -o BatchMode=no -b uhc_census.sftp es00byk@ecgpe.healthtechnologygroup.com
sudo chmod 666 /data/downloads/uhc_census/*
ls /data/downloads/uhc_census/*Daily*txt |
while read filename
do
aws s3 cp ${filename} s3://acp-data/census/uhc/ --sse AES256

export SSHPASS=$GARAGE_SFTP_PW
printf "cd /Files/\nput "${filename}"\nls *" > to_garage.sftp
sshpass -e sftp -o BatchMode=no -b to_garage.sftp $GARAGE_SFTP_USER@$GARAGE_SFTP_FTP
rm to_garage.sftp

aws s3 cp ${filename} s3://garage-s3/alert_files/uhc/ --sse AES256
filedate=`echo ${filename: -12} | awk -F '.' '{print $1}'`
csvfile=`echo ${filename} | sed 's/.txt/.csv/g'`
excelfile=`echo ${filename} | sed 's/.txt/.xlsx/g'`
cp ${filename} ${csvfile}
libreoffice --headless --convert-to xlsx  --outdir $ETL_HOME/downloads/uhc_census/ ${csvfile}
if [[ ${filename} == *"Emergency"* ]]; then
mv ${excelfile} /data/downloads/uhc_census/UHC_ER_DAILYALERTS_${filedate}.xlsx
else
mv ${excelfile} /data/downloads/uhc_census/UHC_IP_DAILYALERTS_${filedate}.xlsx
fi

done

export SSHPASS=$FTP_01_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/uhc_census_to_rapidcare.sftp $FTP_01_US@10.0.12.217

