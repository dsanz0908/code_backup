#!/bin/bash

rm /data/downloads/uhc_census/*
export SSHPASS=$UHC_SOMOS_PW
sshpass -e sudo sftp -o BatchMode=no -b uhc_census.sftp es00byk@ecgpe.healthtechnologygroup.com
sudo chmod 666 /data/downloads/uhc_census/*
ls /data/downloads/uhc_census/*Daily* |
while read filename
do
aws s3 cp ${filename} s3://acp-data/uhc_census/ --sse AES256
done

export SSHPASS=$FTP_01_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/uhc_census_to_rapidcare.sftp $FTP_01_US@10.0.12.217

