#!/bin/bash
set -x
RECEIVED_MONTH_FIELD=$1

last_month_template="date --date='-MONTHS_TO_SUBTRACT month' +'%Y%m'"

echo "SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(period), 'YYYYMM')) AS INT) FROM payor.affinity_corinthian_all_rosters" > $ETL_HOME/sql/get_mco_missing_months.sql
mco_missing_months=`$ETL_HOME/scripts/ipsql.sh get_mco_missing_months.sql | head -3 | tail -1 | awk '{$1=$1};1'`

for i in `seq 1 ${mco_missing_months}`
do
  month_command=`echo ""${last_month_template} | sed "s/MONTHS_TO_SUBTRACT/${i}/g"""`
  month_to_process=`eval ${month_command}`
  filename="PCPRoster_(CORINTHIPA)_${month_to_process: -2}_01_${month_to_process:0:4}"
  eval "python $ETL_HOME/lib/grab_affinity_corinthian_roster.py ${month_to_process}"
  libreoffice --headless --convert-to csv --outdir $ETL_HOME/temp/ $ETL_HOME/temp/${filename}.xlsx
  aws s3 cp $ETL_HOME/temp/${filename}.csv s3://acp-data/Affinity/Corinthian/ --sse AES256
  cat $ETL_HOME/sql/affinity_corinthian_pcproster_template.sql | sed "s/PERIOD/${month_to_process}/g" | sed "s/FILENAME/${filename}/g" > $ETL_HOME/sql/affinity_corinthian_pcproster.sql
  $ETL_HOME/scripts/ipsql.sh affinity_corinthian_pcproster.sql
done

