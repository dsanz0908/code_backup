#!/bin/bash

received_month=$1
file_first=`echo $received_month | cut -c1-4`
file_second=`echo $received_month | cut -c5-8`
file_received_month=`echo "${file_first}_${file_second}"`

cat $ETL_HOME/sql/healthfirst_corinthian_to_evolent_template.sql | sed "s/RECEIVEDMONTH/${received_month}/g" | sed "s/FILEMONTH/${file_received_month}/g" > $ETL_HOME/sql/healthfirst_corinthian_to_evolent.sql
bash ipsql.sh healthfirst_corinthian_to_evolent.sql

cat $ETL_HOME/sql/healthfirst_somos_to_evolent_template.sql | sed "s/RECEIVEDMONTH/${received_month}/g" | sed "s/FILEMONTH/${file_received_month}/g" > $ETL_HOME/sql/healthfirst_somos_to_evolent.sql
bash ipsql.sh healthfirst_somos_to_evolent.sql

