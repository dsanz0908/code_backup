#!/bin/bash
set -x
export SSHPASS=$FTP_01_PW
export receivedmonth=$1
rm -f $ETL_HOME/scripts/MCO_to_s3.txt
rm -f $ETL_HOME/downloads/MCO_Corinthian/*
rm -f $ETL_HOME/scripts/MCO_rm_file.sftp
printf "cd /data/ftp_users/jdionisio-corinthian/incoming/MCO/\nlcd /home/etl/etl_home/downloads/MCO_Corinthian/\nget *${receivedmonth}.txt" > MCO_to_s3.sftp
sshpass -e sftp -o BatchMode=no -b MCO_to_s3.sftp $FTP_01_US@10.0.12.217
ls $ETL_HOME/downloads/MCO_Corinthian/ > MCO_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/MCO_to_s3.txt |
while read filename
do
sed -e "s/\\$//g" -e "s/*//g" -e "s/†//g" -e '1s/^\xEF\xBB\xBF//' $ETL_HOME/downloads/MCO_Corinthian/$filename > $ETL_HOME/downloads/MCO_Corinthian/${filename}_1
aws s3 cp $ETL_HOME/downloads/MCO_Corinthian/${filename}_1 s3://acp-data/MCO/Corinthian/$filename --sse AES256
cd $ETL_HOME/downloads/MCO_Corinthian/
sshpass -e sftp -o BatchMode=no -b MCO_rm_file.sftp $FTP_01_US@10.0.12.217
filetype=`echo $filename  | awk -F "." ' { print $1 } ' | awk -F "-" ' { print $3 } '`
if [ "$filetype" == "ELIGIBILITY" ] ||  [ "$filetype" == "CLAIM" ] ||  [ "$filetype" == "PHARMACY" ] ||  [ "$filetype" == "QUALITY_CARE" ]
then
echo "rename /data/ftp_users/jdionisio-corinthian/incoming/MCO/${filename} /data/ftp_users/jdionisio-corinthian/incoming/MCO/processed/${filename}" >> $ETL_HOME/scripts/MCO_rm_file.sftp
columns=`head -1 $filename`
echo "create table if not exists payor.staging_MCO_corinthian_${filetype} ( " > $ETL_HOME/sql/MCO_${filetype}_columns.sql

# FOR THE LINE BELOW, THE SED COMMAND: THIRD REPLACEMENT (turning comma to varchar) may need to be replaced by space (or something else) when dealing with space delimited files
echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/,/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" -e "s/Service_Code_Description VARCHAR(255)/Service_Code_Description VARCHAR(300)/g" >> $ETL_HOME/sql/MCO_${filetype}_columns.sql

echo "grant all on payor.staging_MCO_corinthian_${filetype} to etluser;" >> $ETL_HOME/sql/MCO_${filetype}_columns.sql
sed -e "s/FILETYPE/${filetype}/g" -e "s/FILENAME/${filename}/g" $ETL_HOME/sql/MCO_load_template.sql > $ETL_HOME/sql/MCO_load_${filetype}.sql
cd $ETL_HOME/scripts/
./ipsql.sh MCO_${filetype}_automation.sql > $ETL_HOME/sql/MCO_${filetype}_query1.sql
master_table=`./ipsql.sh MCO_${filetype}_master_table.sql | sed -n '3p'`
echo "delete from ${master_table} where filename = '${filename}';" > $ETL_HOME/sql/MCO_${filetype}_query.sql
echo "insert into ${master_table} ( " >> $ETL_HOME/sql/MCO_${filetype}_query.sql
grep -iv "^-" $ETL_HOME/sql/MCO_${filetype}_query1.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" | sed -e "$ s/.$//" >> $ETL_HOME/sql/MCO_${filetype}_query.sql
echo ")" >> $ETL_HOME/sql/MCO_${filetype}_query.sql
./ipsql.sh MCO_${filetype}_automation_1.sql > $ETL_HOME/sql/MCO_${filetype}_query2.sql
echo "select " > $ETL_HOME/sql/MCO_${filetype}_query2_1.sql
grep -iv "^-" $ETL_HOME/sql/MCO_${filetype}_query2.sql | grep -iv "?column?" | grep -iv "rows)" | grep -iv "^$" | sed -e "s/FILENAME/${filename}/g" -e "s/RECEIVEDMONTH/\'${receivedmonth}\'/g" | sed -e "$ s/.$//" >> $ETL_HOME/sql/MCO_${filetype}_query2_1.sql
echo "from payor.staging_MCO_corinthian_${filetype};" >> $ETL_HOME/sql/MCO_${filetype}_query2_1.sql
cat $ETL_HOME/sql/MCO_${filetype}_query2_1.sql >> $ETL_HOME/sql/MCO_${filetype}_query.sql
echo "drop table payor.staging_MCO_corinthian_${filetype};">> $ETL_HOME/sql/MCO_${filetype}_query.sql
./ipsql.sh MCO_${filetype}_columns.sql
./ipsql.sh MCO_load_${filetype}.sql
./ipsql.sh MCO_${filetype}_query.sql
rm $ETL_HOME/sql/MCO_${filetype}_columns.sql
rm $ETL_HOME/sql/MCO_load_${filetype}.sql
rm $ETL_HOME/sql/MCO_${filetype}_query.sql
rm $ETL_HOME/sql/MCO_${filetype}_query1.sql
rm $ETL_HOME/sql/MCO_${filetype}_query2.sql
rm $ETL_HOME/sql/MCO_${filetype}_query2_1.sql
fi
done

#sshpass -e sftp -o BatchMode=no -b MCO_rm_file.sftp $FTP_01_US@10.0.12.217
