#!/bin/bash
IPA=$1

last_month_template="date --date='-MONTHS_TO_SUBTRACT month' +'%Y%m'"
echo "SELECT months FROM (SELECT CASE WHEN Lower(filename) LIKE '%corinthian%' THEN 'CORINTHIAN' WHEN Lower(filename) LIKE '%excelsior%' THEN 'EXCELSIOR' END AS ipa , Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(received_month), 'YYYYMM') ) AS INT) AS months FROM payor.healthfirst_all_eligibility GROUP BY 1) WHERE ipa = '${IPA}'"> $ETL_HOME/sql/get_mco_missing_months.sql
mco_missing_months=`$ETL_HOME/scripts/ipsql.sh get_mco_missing_months.sql | head -3 | tail -1 | awk '{$1=$1};1'`

for i in `seq ${mco_missing_months} -1 1`
do
  month_command=`echo ""${last_month_template} | sed "s/MONTHS_TO_SUBTRACT/${i}/g"""`
  month_to_process=`eval ${month_command}`
  sftp_yearmonth=`date -d"${month_to_process}01" +'%b%Y' | awk '{ print toupper($0) }'`

  if [[ ${IPA} == "CORINTHIAN" ]]; then
    eval "bash $ETL_HOME/scripts/healthfirst_corinthian_load.sh ${sftp_yearmonth} ${month_to_process}"
  elif [[ ${IPA} == "EXCELSIOR" ]]; then
    eval "bash $ETL_HOME/scripts/healthfirst_excelsior_load.sh ${sftp_yearmonth} ${month_to_process}"
  fi

  echo "SELECT Count(*) FROM (SELECT CASE WHEN Lower(filename) LIKE '%corinthian%' THEN 'CORINTHIAN' WHEN Lower(filename) LIKE '%excelsior%' THEN 'EXCELSIOR' END AS ipa, Max(received_month) AS received_month FROM payor.healthfirst_all_eligibility GROUP BY 1) WHERE received_month = '${month_to_process}'" > $ETL_HOME/sql/healthfirst_legacy_receivedmonth_count.sql
  receivedmonth_count=`./ipsql.sh healthfirst_legacy_receivedmonth_count.sql | sed -n '3p'`
  if (( ${receivedmonth_count} > 1 )); then
    bash process_healthfirst_legacy_files_to_arcadia.sh ${month_to_process}
  fi
done


