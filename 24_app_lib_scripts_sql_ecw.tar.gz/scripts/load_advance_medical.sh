#!/bin/bash

file_date=$1
export SSHPASS=$FTP_01_PW
file_path="/data/downloads/advancemedical/"
echo ${file_path}${file_date}/
rm -r ${file_path}${file_date}/
cd ${file_path}
mkdir ${file_date}
cd ${file_date}
sshpass -e scp $FTP_01_US@10.0.12.217:"/data/curemd-ftp/incoming/laurelton_heart_spec_pc/Jan\ 15\ 2019/advance_medical_pc\ 011519/${file_date}.rar" .
unrar e ${file_date}.rar
rm ${file_date}.rar

cd $ETL_HOME/scripts/
ls ${file_path}${file_date}/ > advance_medical_data_files.txt
ls advance_medical_data_files.txt |

