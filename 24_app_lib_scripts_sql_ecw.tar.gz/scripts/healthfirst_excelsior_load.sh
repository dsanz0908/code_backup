#!/bin/bash
export sftp_yearmonth=$1
export sql_yearmonth=$2
# EXAMPLE: `./healthfirst_excelsior_load.sh DEC2018 201812`

export SSHPASS=$HF_EXCELSIOR_PW
cd $ETL_HOME/downloads/Healthfirst_Excelsior/
rm $ETL_HOME/downloads/Healthfirst_Excelsior/*
printf "cd /Excelsior/From\ HF/\nlcd /data/downloads/Healthfirst_Excelsior\nmget *${sftp_yearmonth}*\n" > healthfirst_excelsior.sftp
sshpass -e sftp -o BatchMode=no -b healthfirst_excelsior.sftp $HF_EXCELSIOR_USER@$HF_EXCELSIOR_FTP
rm healthfirst_excelsior.sftp

ls *${sftp_yearmonth}* > $ETL_HOME/scripts/Healthfirst_Excelsior_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/Healthfirst_Excelsior_to_s3.txt |
while read zipped_file
do
unzip ${zipped_file}
done

ls *${sftp_yearmonth}*txt > $ETL_HOME/scripts/Healthfirst_Excelsior_to_s3.txt
grep -iv "^#" $ETL_HOME/scripts/Healthfirst_Excelsior_to_s3.txt |
while read filename
do
aws s3 cp ${filename} s3://acp-data/Healthfirst/Excelsior/${filename} --sse AES256
done

#sed -e "s/\\$//g" -e "s/*//g" -e "s/†//g" -e "s/,//g" /data/downloads/Healthfirst_Excelsior/ANA07701_Excelsior_${sftp_yearmonth}_DTL_PHARMACY.txt > $ETL_HOME/downloads/Healthfirst_Excelsior/ANA07701_Excelsior_${sftp_yearmonth}_DTL_PHARMACY_1.txt
#aws s3 cp $ETL_HOME/downloads/Healthfirst_Excelsior/ANA07701_Excelsior_${sftp_yearmonth}_DTL_PHARMACY_1.txt s3://acp-data/Healthfirst/Excelsior/ANA07701_Excelsior_${sftp_yearmonth}_DTL_PHARMACY_1.txt --sse AES256
sed -e "s/YRMNTH/${sql_yearmonth}/g" -e "s/SFTPYEARMONTH/${sftp_yearmonth}/g" $ETL_HOME/sql/healthfirst_excelsior_load_template.sql > $ETL_HOME/sql/healthfirst_excelsior_load.sql
$ETL_HOME/scripts/ipsql.sh healthfirst_excelsior_load.sql

