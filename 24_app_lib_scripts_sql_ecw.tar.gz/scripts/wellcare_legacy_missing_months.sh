#!/bin/bash
IPA=$1

last_month_template="date --date='-MONTHS_TO_SUBTRACT month' +'%Y%m'"
query_template="SELECT months FROM (SELECT CASE WHEN master_ipa = 'EX1' THEN 'EXCELSIOR' WHEN master_ipa = 'VR1' THEN 'BALANCE' WHEN master_ipa = 'CMI' THEN 'CORINTHIAN' WHEN master_ipa = 'EC1' THEN 'ECAP' END AS ipa, Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(receivedmonth), 'YYYYMM')) AS INT) AS months FROM payor.wellcare_all_claims GROUP BY master_ipa) WHERE ipa = '${IPA}'"

echo ${query_template} | sed "s/IPA/${ipa}/g" > $ETL_HOME/sql/get_wellcare_months.sql
wellcare_months=`$ETL_HOME/scripts/ipsql.sh get_wellcare_months.sql | head -3 | tail -1 | awk '{$1=$1};1'`

echo ${IPA}
echo ${wellcare_months}

for i in `seq ${wellcare_months} -1 1`
do
  month_command=`echo ""${last_month_template} | sed "s/MONTHS_TO_SUBTRACT/${i}/g"""`
  month_to_process=`eval ${month_command}`

  if [[ ${IPA} == "ECAP" ]]; then
    $ETL_HOME/scripts/wellcare_ecap_load.sh
  else
    $ETL_HOME/scripts/wellcare_load.sh ${IPA} ${month_to_process}
  fi

  echo "SELECT Count(*) FROM (SELECT CASE WHEN master_ipa = 'EX1' THEN 'EXCELSIOR' WHEN master_ipa = 'VR1' THEN 'BALANCE' WHEN master_ipa = 'CMI' THEN 'CORINTHIAN' END AS ipa, Max(receivedmonth) AS received_month FROM payor.wellcare_all_claims GROUP BY master_ipa) WHERE ipa <> '' AND received_month = '${month_to_process}'" > $ETL_HOME/sql/wellcare_legacy_receivedmonth_count.sql
  receivedmonth_count=`$ETL_HOME/scripts/ipsql.sh wellcare_legacy_receivedmonth_count.sql | sed -n '3p'`
  if (( ${receivedmonth_count} > 3 )); then
    bash process_wellcare_legacy_to_arcadia.sh ${month_to_process}
  fi

done

