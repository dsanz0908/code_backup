#!bin/bash

#rm $ETL_HOME/downloads/nonuser_rosters/*
cd $ETL_HOME/downloads/nonuser_rosters/
#aws s3 cp s3://acp-data/2019_NONUSER/to_be_processed/ . --recursive
OIFS="$IFS"
IFS=$'\n'
#for filename in `find . -type f -name "*.xls*"` 
#do
#ps -ef | grep libreoffice | grep -v color | awk '{print $2}' | xargs kill -9
#libreoffice --headless --convert-to csv "$filename"
#done
#

#for filename in `find . -type f -name "*.ods"` 
#do
#ps -ef | grep libreoffice | grep -v color | awk '{print $2}' | xargs kill -9
#libreoffice --headless --convert-to csv:"Text - txt - csv (StarCalc)":"59,ANSI,1" "$filename"
#done


for filename in `find . -type f -name "*.csv"`  
do
  just_filename=`echo "$filename" | awk -F'/' '{print $2}'`
  basename=`echo "$just_filename" | awk -F'.' '{print $1}'`
  aws_file=`aws s3 ls s3://acp-data/2019_NONUSER/to_be_processed/ | grep "$basename" | awk '{$1=$2=$3=""; print $0}' | awk '{$1=$1;print}'`
  error_message=""
  header_line=`cat "$filename" | egrep -ni 'member[ _]name|patient name|member_nm|,cin,|,medicaid_id,|member[ _]id|membernum' | awk -F':' '{print $1}'`
  if [ ! -z "$header_line" ]
  then
    second=`echo $header_line | awk -F' ' '{print $2}'`
    if [ -z $second ]
    then
      mco=`echo "$just_filename" | awk -F'_' '{print $1}'`
      practice_name=`echo "$just_filename" | awk -F'_' '{print $2}'`
      report_date=`echo "$just_filename" | awk -F'_' '{print $3}'`
      raw_columns=`sed -e "${header_line}q;d" "$filename" | sed 's/ /_/g' | tr '[:upper:]' '[:lower:]' | sed 's/"//g' | sed 's/\.//g' | sed "s/'//g" | sed 's/*//g' | sed 's/(//g' | sed 's/\///g' | dos2unix`
      echo "select 'insert into non_user.fieldrosters (mco, practice_name, report_date, filename, ' || listagg(target,',') within group (order by target) || ')' from non_user.diamonds_mapping where source in ('`echo $raw_columns | sed "s/,/','/g"`')" > $ETL_HOME/sql/nonuser_temp.sql
      insert_statement=`$ETL_HOME/scripts/ipsql.sh nonuser_temp.sql | sed -n '3p'`
      echo "select 'select ''"$mco"'', ''"$practice_name"'', ''"$report_date"'', ''"$aws_file"'', ' || listagg(source,',') within group (order by target) || ' from staging_nonuser;' from non_user.diamonds_mapping where source in ('`echo $raw_columns | sed "s/,/','/g"`');" > $ETL_HOME/sql/nonuser_temp.sql
      select_statement=`$ETL_HOME/scripts/ipsql.sh nonuser_temp.sql | sed -n '3p'`
      echo "delete from non_user.fieldrosters where filename = '"$aws_file"'; create temp table if not exists staging_nonuser (`echo $raw_columns | sed 's/,/ varchar(255),/g'` varchar(255)); grant all on staging_nonuser to etluser; copy staging_nonuser from 's3://acp-data/2019_NONUSER/temp/"$just_filename"' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 5 ignoreheader "$header_line" ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter ',' removequotes; "$insert_statement" "$select_statement"" > $ETL_HOME/sql/nonuser_temp.sql
      aws s3 cp "$just_filename" s3://acp-data/2019_NONUSER/temp/
      errorlog=$(mktemp)
      trap 'rm -f "$errorlog"' EXIT
      pwcheck="$(psql -U $REDSHIFT_USER -h $REDSHIFT_HOST  -p$REDSHIFT_PORT -d dev -q -f $ETL_HOME/sql/nonuser_temp.sql 2> "$errorlog")"
      if [[ `cat "$errorlog"` == *"ERROR"* ]]
      then
        error_message=`cat "$errorlog" | awk -F'ERROR' '{print $2}' | xargs`
      fi
    else
      error_message='Multiple headers in the file'
    fi
  else
    error_message="Unfamiliar header" 
  fi
  if [ "$error_message" ]
  then
    echo "insert into non_user.fieldrosters_failed (filename, error) values ('$aws_file', '$error_message');" > $ETL_HOME/sql/nonuser_temp.sql
    $ETL_HOME/scripts/ipsql.sh nonuser_temp.sql
    #aws s3 mv s3://acp-data/2019_NONUSER/to_be_processed/"$aws_file" s3://acp-data/2019_NONUSER/failed/
  else
    echo "$aws_file"
    aws s3 mv "s3://acp-data/2019_NONUSER/to_be_processed/$aws_file" s3://acp-data/2019_NONUSER/processed/
  fi
done

#aws s3 rm s3://acp-data/2019_NONUSER/temp/
