#!bin/bash

rm $ETL_HOME/downloads/nonuser_rosters/*
cd $ETL_HOME/downloads/nonuser_rosters/
aws s3 cp s3://acp-data/2019_NONUSER/to_be_processed/ . --recursive
ls -1ad *xlsx |
while read filename
do
printf $filename
printf '\n'
done


#grep -ni 'member.*name' "EM_KUMAR PHYSICIAN OFFICE, PC_201908_01.csv"
