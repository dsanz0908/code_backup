#!/bin/bash
python $ETL_HOME/lib/piped_file_to_excel.py $1 $2
