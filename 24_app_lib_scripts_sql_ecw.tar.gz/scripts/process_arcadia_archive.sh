#!/bin/bash
export SSHPASS=$ARCADIATOSOMOS_SH
sshpass -e sftp -o BatchMode=no -b archive.sftp 1260-OF-ACPWHF_PRD@sftp.arcadiaanalytics.com
