#!/bin/bash

rm /data/downloads/elderplan_excelsior_census/*
export SSHPASS=$ELDERPLAN_EXCELSIOR_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/elderplan_excelsior_census.sftp $ELDERPLAN_EXCELSIOR_USER@$ELDERPLAN_FTP
chmod 666 /data/downloads/elderplan_excelsior_census/*
#ls /data/downloads/elderplan_excelsior_census/ExcCns* |
#aws s3 cp ${filename} s3://acp-data/census/elderplan_excelsior/ --sse AES256

export SSHPASS=$FTP_01_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/elderplan_excelsior_census_to_rapidcare.sftp $FTP_01_US@10.0.12.217

