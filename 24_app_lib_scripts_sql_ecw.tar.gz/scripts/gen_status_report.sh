#!/bin/bash
cd $ETL_HOME/lib
python check_ecw_status.py
for_date=`date "+%Y%m%d"`
#python check_engagement.py $for_date 

cp $ETL_HOME/Reports/ecw_status.html /var/www/html/.
#if [ -f $ETL_HOME/Reports/engagement.html ]
#then
#cp $ETL_HOME/Reports/engagement.html /var/www/html/.
#fi

python redshift_inventory.py
cp $ETL_HOME/Reports/inventory.html /var/www/html/.

#python ecw_latest_encounters.py
#cp $ETL_HOME/Reports/encounter_report.html /var/www/html/.
