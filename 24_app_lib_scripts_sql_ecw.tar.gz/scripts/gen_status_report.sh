#!/bin/bash
cd $ETL_HOME/lib
python check_ecw_status.py
for_date=`date "+%Y%m%d"`

cp $ETL_HOME/Reports/ecw_status_24.html /var/www/html/.
cp $ETL_HOME/Reports/ecw_status_67.html /var/www/html/.
python redshift_inventory.py
cp $ETL_HOME/Reports/inventory.html /var/www/html/.

$ETL_HOME/scripts/gen_mco_report.sh

python macro_mco_main.py
cp $ETL_HOME/Reports/mco_macro.html /var/www/html/.

#python check_engagement.py $for_date 
#if [ -f $ETL_HOME/Reports/engagement.html ]
#then
#cp $ETL_HOME/Reports/engagement.html /var/www/html/.
#fi

