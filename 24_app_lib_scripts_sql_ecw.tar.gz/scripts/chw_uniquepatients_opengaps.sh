#!/bin/bash
today=`date '+%Y-%m-%d'`

cat $ETL_HOME/sql/salesforce_gaps_combined_types_template.sql | sed "s/TODAY/${today}/g" > $ETL_HOME/sql/salesforce_gaps_combined_types.sql
$ETL_HOME/scripts/ipsql.sh salesforce_gaps_combined_types.sql
aws s3 mv s3://sftp_test/${today}_gaps_combined_types000 $ETL_HOME/temp/${today}_combined.csv
sed -i '1s/^/type,name,unique_members,unique_members_with_open_gaps,unique_members_with_closed_gaps,unique_members_with_completed_gaps,unique_members_with_excluded_gaps,unique_members_with_issue_gaps,unique_members_with_open_no_show_gaps,unique_members_with_outreach_unable_to_reach_gaps,unique_members_with_pending_gaps\n/' $ETL_HOME/temp/${today}_combined.csv

cat $ETL_HOME/sql/salesforce_gaps_all_types_template.sql | sed "s/TODAY/${today}/g" > $ETL_HOME/sql/salesforce_gaps_all_types.sql
$ETL_HOME/scripts/ipsql.sh salesforce_gaps_all_types.sql
aws s3 mv s3://sftp_test/${today}_gaps_all_types000 $ETL_HOME/temp/${today}_all.csv
sed -i '1s/^/type,name,unique_members,unique_members_with_open_gaps,unique_members_with_closed_gaps,unique_members_with_completed_gaps,unique_members_with_completed_awaiting_claim_submission_gaps,unique_members_with_completed_awaiting_coding_correction_gaps,unique_members_with_excluded_gaps,unique_members_with_exclusion_does_not_meet_criteria_verified_by_management_gaps,unique_members_with_exclusion_moved_out_of_coverage_areaswitched_to_commercial_insurance_gaps,unique_members_with_exclusion_patient_deceased_gaps,unique_members_with_exclusion_patient_switched_to_oon_pcp_gaps,unique_members_with_issue_eligibility_needs_review_gaps,unique_members_with_issue_ineligible_for_measure_needs_review_gaps,unique_members_with_issue_pcp_refused_to_collaborate_gaps,unique_members_with_issue_patient_refused_gaps,unique_members_with_issue_phone_wrongdisconnectedout_of_service_gaps,unique_members_with_issue_referred_to_cbo_for_intervention_gaps,unique_members_with_issue_unable_to_reach_(3)_attempts_needs_management_review_gaps,unique_members_with_open_no_show_gaps,unique_members_with_outreach_unable_to_reach_gaps,unique_members_with_pending_appointment_scheduled_gaps,unique_members_with_pending_patient_will_call_gaps,unique_members_with_pending_practice_will_schedule_gaps,unique_members_with_pending_appointment_scheduled_gaps,unique_members_with_rx_pending_gaps\n/' $ETL_HOME/temp/${today}_all.csv

python $ETL_HOME/lib/two_csv_to_one_excel.py $ETL_HOME/temp/${today}_combined.csv $ETL_HOME/temp/${today}_all.csv $ETL_HOME/temp/${today}_unique_gaps.xlsx
aws s3 cp $ETL_HOME/temp/${today}_unique_gaps.xlsx s3://sftp_test/
rm $ETL_HOME/temp/${today}_combined.csv 
rm $ETL_HOME/temp/${today}_all.csv 
rm $ETL_HOME/temp/${today}_unique_gaps.xlsx

