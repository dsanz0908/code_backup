#!/bin/bash
today=`date '+%Y-%m-%d'`
echo "unload (\$\$ SELECT NAME, Count(DISTINCT whoid) AS unique_members, Count(DISTINCT whoid2) AS unique_members_with_open_gaps FROM (SELECT NAME, whoid, CASE WHEN status = 'Open' THEN whoid ELSE NULL END AS whoid2 FROM salesforce_users AS a LEFT OUTER JOIN (SELECT * FROM salesforce_tasks WHERE Trunc(added_tz) = '${today}') AS b ON b.ownerid = a.id) AS c GROUP BY NAME HAVING Count(DISTINCT whoid) > 0 ORDER BY 1 \$\$) to 's3://sftp_test/${today}_chw_patientsgaps' delimiter ',' parallel off ALLOWOVERWRITE iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';" > $ETL_HOME/sql/salesforce_chw_patientsgaps.sql
$ETL_HOME/scripts/ipsql.sh salesforce_chw_patientsgaps.sql
aws s3 cp s3://sftp_test/${today}_chw_patientsgaps000 $ETL_HOME/temp/${today}_chw_patientsgaps
sed -i '1s/^/chw,unique_members,members_open_gaps\n/' $ETL_HOME/temp/${today}_chw_patientsgaps
aws s3 cp $ETL_HOME/temp/${today}_chw_patientsgaps s3://sftp_test/${today}_chw_patientsgaps.csv
