#!/bin/bash
today=`date '+%Y-%m-%d'`

cat $ETL_HOME/sql/salesforce_gaps_all_types_template.sql | sed "s/TODAY/${today}/g" > $ETL_HOME/sql/salesforce_gaps_all_types.sql
$ETL_HOME/scripts/ipsql.sh salesforce_gaps_all_types.sql
aws s3 cp s3://sftp_test/${today}_gaps_all_types000 $ETL_HOME/temp/${today}_gaps_all_types
sed -i '1s/^/type,name,unique_members,unique_members_with_open_gaps,unique_members_with_closed_gaps,unique_members_with_completed_gaps,unique_members_with_completed_awaiting_claim_submission_gaps,unique_members_with_completed_awaiting_coding_correction_gaps,unique_members_with_completed_pending_claim_submission_gaps,unique_members_with_completed_pending_coding_correction_gaps,unique_members_with_excluded_gaps,unique_members_with_exclusion_does_not_meet_criteria_verified_by_management_gaps,unique_members_with_exclusion_moved_out_of_coverage_areaswitched_to_commercial_insurance_gaps,unique_members_with_exclusion_patient_deceased_gaps,unique_members_with_exclusion_patient_switched_to_oon_pcp_gaps,unique_members_with_issue_eligibility_needs_review_gaps,unique_members_with_issue_ineligible_for_measure_needs_review_gaps,unique_members_with_issue_pcp_refused_to_collaborate_gaps,unique_members_with_issue_patient_refused_gaps,unique_members_with_issue_phone_wrongdisconnectedout_of_service_gaps,unique_members_with_issue_referred_to_cbo_for_intervention_gaps,unique_members_with_issue_unable_to_reach_(3)_attempts_needs_management_review_gaps,unique_members_with_open_no_show_gaps,unique_members_with_outreach_unable_to_reach_gaps,unique_members_with_pending_gaps,unique_members_with_pending_appointment_schedule_gaps,unique_members_with_pending_appointment_scheduled_gaps,unique_members_with_pending_patient_will_call_gaps,unique_members_with_pending_practice_will_schedule_gaps,unique_members_with_pending_with_issues_gaps,unique_members_with_pending_appointment_scheduled_gaps,unique_members_with_rx_pending_gaps\n/' $ETL_HOME/temp/${today}_gaps_all_types
aws s3 cp $ETL_HOME/temp/${today}_gaps_all_types s3://sftp_test/${today}_gaps_all_types.csv
aws s3 rm s3://sftp_test/${today}_gaps_all_types000
rm $ETL_HOME/temp/${today}_gaps_all_types


echo "unload (\$\$ SELECT NAME, Count(DISTINCT whoid) AS unique_members, Count(DISTINCT whoid2) AS unique_members_with_open_gaps FROM (SELECT NAME, whoid, CASE WHEN status = 'Open' THEN whoid ELSE NULL END AS whoid2 FROM salesforce_users AS a LEFT OUTER JOIN (SELECT * FROM (SELECT *, Row_number() OVER ( partition BY id ORDER BY added_tz DESC) AS rn FROM salesforce_tasks) WHERE rn = 1) AS b ON b.ownerid = a.id) AS c GROUP BY NAME HAVING Count(DISTINCT whoid) > 0 ORDER BY 1 \$\$) to 's3://sftp_test/${today}_chw_patientsgaps' delimiter ',' parallel off ALLOWOVERWRITE addquotes iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';" > $ETL_HOME/sql/salesforce_chw_patientsgaps.sql
$ETL_HOME/scripts/ipsql.sh salesforce_chw_patientsgaps.sql
aws s3 cp s3://sftp_test/${today}_chw_patientsgaps000 $ETL_HOME/temp/${today}_chw_patientsgaps
sed -i '1s/^/name,unique_members,unique_members_with_open_gaps\n/' $ETL_HOME/temp/${today}_chw_patientsgaps
aws s3 cp $ETL_HOME/temp/${today}_chw_patientsgaps s3://sftp_test/${today}_chw_patientsgaps.csv
aws s3 rm s3://sftp_test/${today}_chw_patientsgaps000
rm $ETL_HOME/temp/${today}_chw_patientsgaps

