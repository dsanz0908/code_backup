query_file=$1
psql -U $REDSHIFT_USER -h $REDSHIFT_HOST  -p$REDSHIFT_PORT -d claims_dw -q -f $ETL_HOME/sql/$query_file
