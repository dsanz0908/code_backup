#!/usr/bin/expect
spawn sftp 1411-OF-EVHDWF_PRD@sftp.arcadiaanalytics.com
expect "password"
send "CR4FdASuh^h7Ol983\r"
expect "sftp>"
send "lcd downloads\r"
expect "sftp>"
send "get *.csv\r"
expect "sftp>"
send "quit\r"

