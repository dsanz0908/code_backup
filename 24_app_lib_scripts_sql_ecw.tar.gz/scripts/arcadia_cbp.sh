#!/bin/bash
sudo sqlcmd -S 10.254.232.106,1433 -U ACPPS_ClientAccess -P 490qXXAAt6zsSvFL -d acpps_warehouse_prd01 -i $ETL_HOME/sql/arcadia_cbp.sql -o $ETL_HOME/temp/arcadia_cbp.sql  -W -w 999 -s","
