#!/bin/bash
sudo sqlcmd -S 10.254.232.106,1433 -U ACPPS_ClientAccess -P 490qXXAAt6zsSvFL -d acpps_warehouse_prd01 -i $ETL_HOME/sql/arcadia_cbp.sql -o $ETL_HOME/temp/arcadia_cbp.csv  -W -w 999 -s","
aws s3 cp $ETL_HOME/temp/arcadia_cbp.csv s3://acp-data/CBP/arcadia_cbp_20190724.csv --sse AES256
