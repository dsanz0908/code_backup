!/bin/bash
#aws s3 ls s3://acp-data/Arcadia/Outgoing/fidelis/ --recursive > $ETL_HOME/temp/fidelis_somos.txt
grep -iv "^#" $ETL_HOME/temp/fidelis_somos.txt |
while read filename 
do 
#aws s3 cp s3://acp-data/Arcadia/Outgoing/fidelis/$filename $ETL_HOME/temp/Fidelis_Somos_to_Arcadia/.
#gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Fidelis_Somos_to_Arcadia/$filename
rm $ETL_HOME/temp/Fidelis_Somos_to_Arcadia/$filename
done

 
