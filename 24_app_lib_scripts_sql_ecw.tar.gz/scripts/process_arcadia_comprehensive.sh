#!/bin/bash

ls $ETL_HOME/input/*.csv | awk -F "/" ' { print $6 } ' | awk -F"_" ' { print $7 } ' | sort | uniq | grep -iv "^$" > $ETL_HOME/temp/arcadia_table_list.txt
grep -v "^#" $ETL_HOME/temp/arcadia_table_list.txt |
while read table
do
$ETL_HOME/scripts/process_arcadia_tables.sh $table 2018_12
done
