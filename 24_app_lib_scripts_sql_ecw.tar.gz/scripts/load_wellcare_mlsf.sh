#!/bin/bash

#IPA=$1
#received_month=$2

IPA='BALANCE'
received_month='201905'

S3_FILE="s3://acp-data/Wellcare/${IPA}/WELLCARE-${IPA}-MLSF-${received_month}.txt"
MLSF_FOLDER=${ETL_HOME}/downloads/wellcare_mlsf/
MLSF_FILE="${MLSF_FOLDER}WELLCARE-${IPA}-MLSF-${received_month}.txt"

#aws s3 cp $S3_FILE $MLSF_FOLDER
columns=`head -1 $MLSF_FILE`
string="drop temp table wellcare_mlsf_temp if exists; create temp table wellcare_mlsf_temp ("
string+=`echo $columns | dos2unix | sed 's/|/ varchar(255)\n/g'`
string+=" varchar(255));"
echo $string
