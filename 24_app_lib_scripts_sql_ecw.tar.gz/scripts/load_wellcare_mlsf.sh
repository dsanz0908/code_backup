#!/bin/bash

IPA=$1
received_month=$2

S3_FILE="s3://acp-data/Wellcare/${IPA}/WELLCARE-${IPA}-MLSF-${received_month}.txt"
MLSF_FOLDER=${ETL_HOME}/downloads/wellcare_mlsf/
MLSF_FILE="${MLSF_FOLDER}WELLCARE-${IPA}-MLSF-${received_month}.txt"
MLSF_BASENAME="WELLCARE-${IPA}-MLSF-${received_month}.txt"

aws s3 cp $S3_FILE $MLSF_FOLDER
columns=`head -1 $MLSF_FILE`
string="drop table if exists wellcare_mlsf_temp; create temp table wellcare_mlsf_temp ("
string+=`echo $columns | dos2unix | sed 's/|/ varchar(255),\n/g'`
string+=" varchar(255)); "
string+="copy wellcare_mlsf_temp from '${S3_FILE}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter '|'; "
string+="delete from payor.wellcare_all_mlsf where filename = '${MLSF_BASENAME}'; "
string+="insert into payor.wellcare_all_mlsf (`echo $columns | dos2unix | sed 's/|/,/g'`, filename, added_tz) select `echo $columns | dos2unix | sed 's/|/,/g'`, '${MLSF_BASENAME}', getdate() from wellcare_mlsf_temp;"
echo $string > $ETL_HOME/sql/load_wellcare_mlsf.sql
bash $ETL_HOME/scripts/ipsql.sh load_wellcare_mlsf.sql
