#!/bin/bash
#set -x
export SSHPASS=$ARCADIATOBRONX_SH
rm -f $ETL_HOME/downloads/bronx/*.csv
rm -f archive_bronx.sftp
sshpass -e sftp -o BatchMode=no -b arctobronx.sftp $ARCADIATOBRONX_FTP@sftp.arcadiaanalytics.com
ls $ETL_HOME/downloads/bronx/*.csv > $ETL_HOME/temp/arcadia_to_bronx_files.txt
grep -iv "^#" $ETL_HOME/temp/arcadia_to_bronx_files.txt |
while read filename
do
sfile=`echo $filename | awk -F"/" '{ print $7 }'`
aws s3 cp $filename s3://acp-bronxrhio/Outgoing/$sfile --sse AES256
echo "rename $sfile Archive/$sfile" >> archive_bronx.sftp
done
sshpass -e sftp -o BatchMode=no -b archive_bronx.sftp $ARCADIATOBRONX_FTP@sftp.arcadiaanalytics.com
