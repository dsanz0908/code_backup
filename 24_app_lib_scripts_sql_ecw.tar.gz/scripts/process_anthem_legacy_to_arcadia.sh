#!/bin/bash

rm $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/*
export for_month=$1
export sep_year=`echo $for_month | cut -b 1-4`
export sep_month=`echo $for_month | cut -b 5,6`
export delim_value=${sep_year}_${sep_month}
sed -e "s/SEPMNTH/$delim_value/g" $ETL_HOME/sql/anthem_corinthian_to_arcadia_template.sql | sed -e "s/MNTH/$for_month/g" > $ETL_HOME/sql/anthem_corinthian_to_arcadia.sql
$ETL_HOME/scripts/ipsql.sh anthem_corinthian_to_arcadia.sql
cd $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/
aws s3 cp s3://acp-data/Arcadia/Outgoing/anthem/anthem_corinthian_eligibility_${delim_value}_000.gz $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_eligibility_${delim_value}_000.gz
aws s3 cp s3://acp-data/Arcadia/Outgoing/anthem/anthem_corinthian_claims_${delim_value}_000.gz $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_claims_${delim_value}_000.gz
aws s3 cp s3://acp-data/Arcadia/Outgoing/anthem/anthem_corinthian_rx_${delim_value}_000.gz $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_rx_claims_${delim_value}_000.gz
#aws s3 cp s3://acp-data/Arcadia/Outgoing/anthem/anthem_corinthian_eligibility_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/anthem_corinthian_eligibility_${delim_value}_000.gz --sse AES256
#aws s3 cp s3://acp-data/Arcadia/Outgoing/anthem/anthem_corinthian_claims_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/anthem_corinthian_claims_${delim_value}_000.gz --sse AES256
#aws s3 cp s3://acp-data/Arcadia/Outgoing/anthem/anthem_corinthian_rx_${delim_value}_000.gz s3://acp-evolent/ToEvolent/MCO/anthem_corinthian_rx_claims_${delim_value}_000.gz --sse AES256
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_eligibility_${delim_value}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_claims_${delim_value}_000.gz
gpg --batch -r ArcadiaConnect --trust-model always -e $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_rx_claims_${delim_value}_000.gz
rm $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_eligibility_${delim_value}_000.gz
rm $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_claims_${delim_value}_000.gz
rm $ETL_HOME/temp/Anthem_Corinthian_to_Arcadia/anthem_corinthian_rx_claims_${delim_value}_000.gz

export SSHPASS=$ARCADIAEMPIRE_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/arcadia.sftp $ARCADIAEMPIRE_FTP@sftp.arcadiaanalytics.com

