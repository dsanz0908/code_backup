#!/bin/bash 
cd $ETL_HOME/temp/optimus_healthfirst/
rm $ETL_HOME/temp/optimus_healthfirst/*
#
export SSHPASS=${HF_OPTIMUS_PW}
#yearmonth_zip=`date '+%Y-%m'`
#yearmonth=`date '+%Y%m'`
#
yearmonth_zip='2019-09'
yearmonth='201909'

printf "cd /Optimus/From\ HF\nlcd /home/etl/etl_home/temp/optimus_healthfirst/\nget *${yearmonth_zip}*" > $ETL_HOME/scripts/downloaded_optimus_hf_files.sftp
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/downloaded_optimus_hf_files.sftp ${HF_OPTIMUS_USER}@${HF_OPTIMUS_FTP}

ls $ETL_HOME/temp/optimus_healthfirst/ |
while read filename
do
unzip ${filename}
done

ls *txt |
while read filename
do
new_name=`echo ${filename} | sed "s/Proivder/Provider/g" | sed "s/_.*\.txt/_${yearmonth}.txt/g" | tr '[:upper:]' '[:lower:]'`
echo $new_name
#columns=`head -1 "${filename}" | sed 's///g' | tr '[:upper:]' '[:lower:]'`
#sql_columns=`echo ${columns} | sed "s/ /_/g"`  
#table_name="optimus_healthfirst_all_`echo ${filename} | sed 's/_.*//g'`"
aws s3 cp ${filename} s3://acp-data/OPTIMUS_HF_Tables/${new_name} --sse AES256
done

cat $ETL_HOME/sql/optimus_healthfirst_medicare_template.sql | sed "s/RECEIVEDMONTH/${yearmonth}/g" > $ETL_HOME/sql/optimus_healthfirst_medicare.sql
$ETL_HOME/scripts/ipsql.sh optimus_healthfirst_medicare.sql

#echo "drop table if exists staging_optimus_hf;" > $ETL_HOME/sql/optimus_hf_load.sql
#echo "create temp table if not exists staging_optimus_hf ( " >> $ETL_HOME/sql/optimus_hf_load.sql
#
#echo $columns | sed "s/\" \"/,\n/g" | sed "s/\"//g" | sed "s/ /_/g" | sed "s/,/ VARCHAR(255),/g" | sed "s/-//g" | sed "s/\//_/g" | sed -e "s/(//g" -e "s/)//g" >> $ETL_HOME/sql/optimus_hf_load.sql
#echo $columns | sed -e "s/(//g" -e "s/)//g" -e "s/\t/ VARCHAR(255),\\n/g" -e "s/|/ VARCHAR(255),\\n/g" -e "s/\r/ VARCHAR(255));/" -e "s/ /_/g" -e "s/\"//g" -e "s/'//g" -e "s/_VARCHAR(255),/ VARCHAR(255),/g" -e "s/_VARCHAR(255));/ VARCHAR(255));/g" -e "s/\//_/g" -e "s/#/No/g" -e "s/-//g" -e "s/*//g" -e "s/\\$//g" >> $ETL_HOME/sql/optimus_hf_load.sql
#
#echo 'VARCHAR(255));' >> $ETL_HOME/sql/optimus_hf_load.sql
#echo "grant all on staging_optimus_hf to etluser;" >> $ETL_HOME/sql/optimus_hf_load.sql
#echo "copy staging_optimus_hf from 's3://acp-data/OPTIMUS_HF_Tables/${new_name}' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter '\t';" >> $ETL_HOME/sql/optimus_hf_load.sql
#echo "delete from ${table_name} where filename = '${new_name}';" >> $ETL_HOME/sql/optimus_hf_load.sql
#echo "insert into ${table_name} (${sql_columns}, filename) select ${sql_columns}, '${new_name}' from staging_optimus_hf;" >> $ETL_HOME/sql/optimus_hf_load.sql
#$ETL_HOME/scripts/ipsql.sh optimus_hf_load.sql

