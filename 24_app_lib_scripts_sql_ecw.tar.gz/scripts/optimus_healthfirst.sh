#!/bin/bash 
cd $ETL_HOME/temp/optimus_healthfirst/
rm optimus_healthfirst.txt
ls $ETL_HOME/temp/optimus_healthfirst/ > optimus_healthfirst.txt
grep -iv "^#" optimus_healthfirst.txt |
while read filename
do
cd $ETL_HOME/temp/optimus_healthfirst/
filename_without_dir=`echo $filename | awk -F".txt" ' { print $1} '`
echo "drop table public.optimus_healthfirst_${filename_without_dir};" > $ETL_HOME/sql/optimus_healthfirst_${filename_without_dir}_columns.sql
echo "create table if not exists public.optimus_healthfirst_${filename_without_dir} ( " >> $ETL_HOME/sql/optimus_healthfirst_${filename_without_dir}_columns.sql
head -1 $filename | sed -e "s/(//g" -e "s/)//g" -e "s/ /_/g" -e "s/'//g" -e "s/\t/\n/g" -e "s/\"//g" -e "s/\n/ VARCHAR(255), /g" -e "s/\r/ VARCHAR(255));/" -e "s/\//_/g" -e "s/-//g" -e "s/\.//g" >> $ETL_HOME/sql/optimus_healthfirst_${filename_without_dir}_columns.sql
echo "grant all on public.optimus_healthfirst_${filename_without_dir} to etluser;" >> $ETL_HOME/sql/optimus_healthfirst_${filename_without_dir}_columns.sql
sed -e "s/TABLENAME/optimus_healthfirst_${filename_without_dir}/g" -e "s/FILENAME/${filename}/g" $ETL_HOME/sql/copy_optimus_healthfirst.sql > $ETL_HOME/sql/copy_optimus_${filename_without_dir}.sql 
$ETL_HOME/scripts/./ipsql.sh optimus_healthfirst_${filename_without_dir}_columns.sql
$ETL_HOME/scripts/./ipsql.sh copy_optimus_${filename_without_dir}.sql
done
