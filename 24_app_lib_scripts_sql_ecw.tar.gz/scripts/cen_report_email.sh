#/bin/bash
today=`date '+%Y%m%d'`
cat $ETL_HOME/sql/bronx_rhio_cen_report_template.sql | sed "s/TODAY/${today}/g" > $ETL_HOME/sql/bronx_rhio_cen_report.sql
$ETL_HOME/scripts/ipsql.sh bronx_rhio_cen_report.sql
aws s3 cp s3://sftp_test/${today}_bronx_rhio_cin_cen_report.csv000 $ETL_HOME/temp/${today}_bronx_rhio_cin_cen_report.csv
aws s3 cp s3://sftp_test/${today}_bronx_rhio_hospital_cin_report.csv000 $ETL_HOME/temp/${today}_bronx_rhio_hospital_cin_report.csv

sed -i '1s/^/patient_first_name,patient_last_name,patient_dob,medicaid_id,last_7,last_30,last_90\n/' $ETL_HOME/temp/${today}_bronx_rhio_cin_cen_report.csv
sed -i '1s/^/admit_facility,last_7,last_30,last_90\n/' $ETL_HOME/temp/${today}_bronx_rhio_hospital_cin_report.csv
echo "as of ${today}"| mail -s "Bronx RHIO CEN Reports" -a $ETL_HOME/temp/${today}_bronx_rhio_cin_cen_report.csv -a $ETL_HOME/temp/${today}_bronx_rhio_hospital_cin_report.csv vtanis@somoscommunitycare.org,dsanz@somoscommunitycare.org

