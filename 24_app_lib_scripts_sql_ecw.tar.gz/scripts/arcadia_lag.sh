#!/bin/bash

today=`date '+%Y%m%d'`
python $ETL_HOME/lib/arcadia_lag.py
echo "as of ${today}"| mail -s "Arcadia Lag" -a $ETL_HOME/output/${today}_arcadia_lag.csv mwade@somoscommunitycare.org,ssundararaman@somoscommunitycare.org,dsanz@somoscommunitycare.org
