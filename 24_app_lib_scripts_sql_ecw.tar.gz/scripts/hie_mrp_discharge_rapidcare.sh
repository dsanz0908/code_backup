#!/bin/bash

rm /home/etl/etl_home/downloads/hie_mrp_discharge_excel/*
python $ETL_HOME/lib/hie_mrp_discharge.py
export SSHPASS=$FTP_01_PW
sshpass -e sftp -o BatchMode=no -b $ETL_HOME/scripts/hie_mrp_discharge_rapidcare.sftp $FTP_01_US@10.0.12.217

