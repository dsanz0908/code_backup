import pandas as pd
import numpy as np
import pyodbc
from datetime import datetime


def main():
    practice_info = pd.read_csv('/home/etl/etl_home/output/practice_info.csv')
    conn_24 = pyodbc.connect(dsn="postgres_24")
    conn_67 = pyodbc.connect(dsn="postgres_67")
    res_24 = getDBDetails(conn_24)
    res_67 = getDBDetails(conn_67)
    webcreator(res_24, '10.0.10.24', practice_info)
    webcreator(res_67, '10.0.10.67', practice_info)


def getDBDetails(conn):
    query = '''
	WITH cte_failed_dag_run
	     AS (SELECT dag_id,
			execution_date,
			start_date,
			state
		 FROM   dag_run
                 --WHERE  start_date >= '2019-09-01'
                 ),
	     cte_max_start_date_state
	     AS (SELECT dag_id,
			Max(start_date) AS mx_date
		 FROM   dag_run
		 GROUP  BY dag_id),
	     cte_max_success_state
	     AS (SELECT dag_id,
			Max(start_date) AS last_success_date
		 FROM   dag_run
		 WHERE  state = 'success'
		 GROUP  BY dag_id)
	SELECT DISTINCT t1.dag_id,
			t1.state   AS last_state,
			mx.mx_date last_run_date,
			last_success_date
	FROM   dag_run t1
	       INNER JOIN cte_failed_dag_run cte
		       ON t1.dag_id = cte.dag_id
	       INNER JOIN cte_max_start_date_state mx
		       ON t1.dag_id = mx.dag_id
			  AND t1.start_date = mx.mx_date
	       LEFT OUTER JOIN cte_max_success_state scs
			    ON t1.dag_id = scs.dag_id where last_success_date > '2019-11-01'
	order by 2
        '''
    res = pd.read_sql(query, conn)
    return res


def webcreator(server, instance, practice_info):
    finaltable = server
    finaltable["rstr"] = finaltable["last_run_date"].dt.strftime(
        "%m/%d/%Y - %I:%M %p")
    finaltable["sstr"] = finaltable["last_success_date"].dt.strftime(
        "%m/%d/%Y - %I:%M %p")
    finaltable.replace('NaT', '', inplace=True)
    length = len(finaltable.index)
    global x
    x = 0
    fails = 0
    temptable = ""
    for num in range(0, length):
        if finaltable.last_state.iloc[x] == "success":
            laststatus = "class=\"tablesuccess\""
        elif finaltable.last_state.iloc[x] == "failed":
            laststatus = "class=\"tablefailure\""
            fails += 1
        else:
            laststatus = "class=\"tablerunning\""
        if instance == '10.0.10.24':
            hreflink = "http://10.0.10.24:8090/admin/taskinstance/?flt1_dag_id_equals=" + finaltable.dag_id.iloc[
                x]
            click_link = "http://10.0.10.24:8090/admin/airflow/trigger?dag_id=" + finaltable.dag_id.iloc[
                x]
        elif instance == '10.0.10.67':
            hreflink = "http://10.0.10.67:8080/admin/taskinstance/?flt1_dag_id_equals=" + finaltable.dag_id.iloc[
                x]
            click_link = "http://10.0.10.67:8080/admin/airflow/trigger?dag_id=" + finaltable.dag_id.iloc[
                x]

        if 'ecw' in finaltable.dag_id.iloc[x]:
            dag6 = (finaltable.dag_id.iloc[x][4:10])
            sql_df = practice_info[practice_info["Database Name"].str.contains(
                str(dag6))]
            if sql_df.empty:
                sql_version = 'Unknown'
                ecw_name = 'Unknown'
            else:
                sql_version = sql_df["Location"].iloc[0][11:15]
                ecw_name = sql_df["ECW Name"].iloc[0][9:]
        else:
            ecw_name = ' '
            sql_version = ' '

        templine = (
            '<tr><td><a href="%s">%s</td><td style="font-size:14px;">%s</td><td style="font-size:14px;">%s</td><td %s>%s</td><td>%s</td><td>%s</td><td><a href="%s" onclick="return confirm(\'Are you sure that you want to run %s\')" target="_blank">Run Dag</a></td></tr>'
            % (hreflink, finaltable.dag_id.iloc[x], ecw_name, sql_version,
               laststatus, finaltable.last_state.iloc[x],
               finaltable.rstr.iloc[x], finaltable.sstr.iloc[x], click_link,
               finaltable.dag_id.iloc[x]))

        temptable = temptable + templine
        x += 1


    pretemptable = '''<head id="head" class="dark-mode"><link href="/static/css/check.css" rel="stylesheet">
    <script type="text/javascript">
    function toggleDarkLight() {
    var body = document.getElementById("body");
    var currentClass = body.className;
    body.className = currentClass == "dark-mode" ? "light-mode" : "dark-mode";
    var nav = document.getElementById("nav");
    nav.className = currentClass == "dark-mode" ? "light-mode" : "dark-mode";
    var table = document.getElementById("table");
    table.className = currentClass == "dark-mode" ? "light-mode" : "dark-mode";
    }
    </script>
    <div class="header">
    <div  class="oval" name="dark_light" onclick="toggleDarkLight()" title="Toggle dark/light mode"><h3> '''  \
    + instance \
    + '''</h3></div>
    <nav id="nav" class="dark-mode sidebar">
    <ul>
    <li><h2>''' + "As of "+ datetime.strftime(datetime.now(),'%m/%d - %I:%M%p')   \
    + ' Server ' + instance[8:] + ' Total Fails: <span style="color: #ff0000">' + str(fails) \
    + ''' </span></h2></li> </ul> </nav> </head> <body id="body" class="dark-mode"> <table id="table" class = "table dark-mode">
    	<tr class="info"><td style="position:sticky;top:80px;">Dag Identifier</td>
        <td style="position:sticky;top:80px;">ECW Name</td>
        <td style="position:sticky;top:80px;">SQL Version</td>
	<td style="position:sticky;top:80px;">Last State</td>
        <td style="position:sticky;top:80px;">Last Run Time</td>
	<td style="position:sticky;top:80px;">Last success Time</td>
    <td style="position:sticky;top:80px;">Run Dag</td></tr>
        <tr class="spacer"></tr>
    '''
    endtable = pretemptable + temptable + '</table> <br> </body>'
    if instance == '10.0.10.24':
        f = open("/home/etl/etl_home/Reports/ecw_status_24.html", "w")
        f.write(endtable)
        f.close()
    elif instance == '10.0.10.67':
        f = open("/home/etl/etl_home/Reports/ecw_status_67.html", "w")
        f.write(endtable)
        f.close()


if __name__ == '__main__':
    main()
