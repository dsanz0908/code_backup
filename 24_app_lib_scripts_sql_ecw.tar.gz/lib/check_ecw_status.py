import datetime
import pytz
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
def main():
        conn_24=pyodbc.connect(dsn="postgres_24")
        conn_67=pyodbc.connect(dsn="postgres_67")
        res_24=getDBDetails(conn_24)
        res_67=getDBDetails(conn_67)
        processResults(res_24,'10-0-10-24','w')
        processResults(res_67,'10-0-10-67','a')
        #email_report(success,fail,new_cnt,for_dt,table)

def getDBDetails(conn):
        query= """
	WITH cte_failed_dag_run 
	     AS (SELECT dag_id, 
			execution_date, 
			start_date, 
			state 
		 FROM   dag_run 
                 WHERE  start_date >= '2019-03-20'
                 ), 
	     cte_max_start_date_state 
	     AS (SELECT dag_id, 
			Max(start_date) AS mx_date 
		 FROM   dag_run 
		 GROUP  BY dag_id), 
	     cte_max_success_state 
	     AS (SELECT dag_id, 
			Max(start_date) AS last_success_date 
		 FROM   dag_run 
		 WHERE  state = 'success' 
		 GROUP  BY dag_id) 
	SELECT DISTINCT t1.dag_id, 
			t1.state   AS last_state, 
			mx.mx_date last_run_date, 
			last_success_date 
	FROM   dag_run t1 
	       INNER JOIN cte_failed_dag_run cte 
		       ON t1.dag_id = cte.dag_id 
	       INNER JOIN cte_max_start_date_state mx 
		       ON t1.dag_id = mx.dag_id 
			  AND t1.start_date = mx.mx_date 
	       LEFT OUTER JOIN cte_max_success_state scs 
			    ON t1.dag_id = scs.dag_id where t1.dag_id <> 'chw_uniquepatients_opengaps.sh'
        """

        cur=conn.execute(query)
        res=cur.fetchall()
        cur.close()
        return res

def  processResults(dbdetails,instancename,writemode):
        total = 0;
        fail = 0;
        if len(dbdetails) == 0:
                return None
        f=open("/home/etl/etl_home/Reports/ecw_status.html",writemode)
        h=HTML()
        tbl=h.table(style='font-family:"Calibri";font-size:125%;width:100%')
        r=tbl.tr(style="background-color:#e3e0cc;font-size:150%")
        r.td("Instance")
        r.td("Dag Identifier")
        r.td("Last State")
        r.td("Last Run Time")
        r.td("Last Success Time")
        for row in dbdetails:
                if row[1] == "success":
                        bgcolor= "background-color:#c5d5c5"
                else:
                        bgcolor="background-color:#ffeead"
                        fail+=1
                r=tbl.tr(style=bgcolor)
                r.td(instancename)
                r.td(row[0])
                r.td(row[1])
                r.td(datetime.datetime.strftime(row[2],'%Y-%m-%d %H:%M'))
                " " if row[3] == None else r.td(datetime.datetime.strftime(row[3],'%Y-%m-%d %H:%M'))
                total+=1
        #header = '''<center><b><p style="font-family:'Calibri';font-size:200%">ECW Status of ''' + instancename + '''</p></b></center><br><br>'''
	header = '''<head><link href="check.css" rel="stylesheet"></head><body>	<h3>DAG Status of ''' + instancename + '''</h3>
        <div class="content">
	<div class="sidebar">
	  <ul>
	    <li><a href="ecw_status.html">DAG Status</a></li>
	    <li><a href="engagement.html">Engagement Files Status</a></li>
	    <li><a href="inventory.html">Redshift Inventory Status</a></li>
	  </ul>
	  
	  <div class="logo">
	    <img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
	  </div>
	</div>'''         
        footer = '''<br><center><p style="font-family:'Calibri';font-size:100%">Total: ''' + str(total) +  '''</p><p style="font-family:'Calibri';font-size:125%">Total failed: ''' + str(fail) + '''</p><p style="font-family:'Calibri';font-size:125%">Last time checked: ''' + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + '''</p></center><br><br>'''
        
        f.write(header + str(tbl) + footer)
        f.close()
        return tbl
        
if __name__ == '__main__':
 main()
