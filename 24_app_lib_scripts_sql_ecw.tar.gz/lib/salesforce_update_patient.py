# -*- coding: utf-8 -*-
import sys
import os
reload(sys)
sys.setdefaultencoding("utf-8")
from datetime import datetime
import requests
from simple_salesforce import Salesforce
from fuzzywuzzy import fuzz
from collections import defaultdict
import pyodbc


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


PATIENT_QUERY = """
SELECT DISTINCT patient_contact_id, 
                To_char(To_date(dob, 'MM/DD/YYYY'), 'YYYY-MM-DD') AS birthdate, 
                mco 
FROM   salesforce.mco_gaps_groundzeroxwalkstandardized 
WHERE  activity_id IN ( '00T0H00004sidtcUAA', '00T0H00004sidkcUAA', '00T0H00004siibmUAA', '00T0H00004siibCUAQ',
                        '00T0H00004t0SlxUAE', '00T0H00004t0KqdUAE', '00T0H00004t0KqdUAE', '00T0H00004t0KxKUAU',
                        '00T0H000056dff2UAA', '00T0H00004vO8sAUAS', '00T0H00004wlEaKUAU', '00T0H00004wl8vjUAA',
                        '00T0H00004wlH7OUAU', '00T0H00004t0SudUAE', '00T0H00004wlKJOUA2', '00T0H00004vNVASUA4', '00T0H00004weFtMUAU' ); 
"""

TASK_QUERY = """
SELECT DISTINCT activity_id, 
                standardized_measure_name 
FROM   salesforce.mco_gaps_groundzeroxwalkstandardized 
WHERE  activity_id IN ( '00T0H00004sidtcUAA', '00T0H00004sidkcUAA', '00T0H00004siibmUAA', '00T0H00004siibCUAQ',
                        '00T0H00004t0SlxUAE', '00T0H00004t0KqdUAE', '00T0H00004t0KqdUAE', '00T0H00004t0KxKUAU',
                        '00T0H000056dff2UAA', '00T0H00004vO8sAUAS', '00T0H00004wlEaKUAU', '00T0H00004wl8vjUAA',
                        '00T0H00004wlH7OUAU', '00T0H00004t0SudUAE', '00T0H00004wlKJOUA2', '00T0H00004vNVASUA4', '00T0H00004weFtMUAU' )
       AND mco_flag = 'Compliant Open'; 
"""

if __name__ == '__main__':
    sf, INSTANCE_URL = getSession()
    CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
    PATIENTS = CONNECTION.execute(PATIENT_QUERY).fetchall()
    TODAY = datetime.now().strftime("%Y%m%d")
    for patient in PATIENTS:
        print patient
        patient_id = patient[0]
        dob = patient[1]
        mco = patient[2]
        try:
            sf.Contact.update(patient_id, {
                'birthdate': dob,
                'health_plan_carriers__c': mco,
            })
        except Exception as e:
            print(row, str(e))

    TASKS = CONNECTION.execute(TASK_QUERY).fetchall()
    for task in TASKS:
        print task
        task_id = task[0]
        measure = task[1]
        try:
            sf.Task.update(
                task_id, {
                    'measure__c':
                    measure,
                    'status':
                    'Closed',
                    'Care_Gap_Comments_Part_2__c':
                    "{} automated - standardized measure update".format(TODAY)
                })
        except Exception as e:
            print(task_id, str(e))
