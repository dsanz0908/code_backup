# -*- coding: utf-8 -*-
import sys
import os
reload(sys)
sys.setdefaultencoding("utf-8")
from datetime import datetime
import requests
from simple_salesforce import Salesforce
from fuzzywuzzy import fuzz
from collections import defaultdict
import pyodbc


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)

if __name__ == '__main__':
    sf, instance_url = getSession()
    phones = [row.rstrip() for row in open('../temp/phones.txt', 'r').readlines()]
    for row in phones:
        contact = row.split('|')[0]
        phone = row.split('|')[2]
        print contact, phone
	try:
	    sf.Contact.update(
		contact, {
		    'phone': phone
		})
	except Exception as e:
	    print(row, str(e))
