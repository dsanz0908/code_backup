from collections import defaultdict
from fuzzywuzzy import fuzz
import pyodbc

if __name__ == "__main__":
    CONNECTION = pyodbc.connect(dsn='somos_redshift_1')
    SNEAKERNET_QUERY = """
    SELECT Substring(s3_key, Len(s3_key) - Charindex('/', Reverse(s3_key)) + 2, Len(s3_key)) AS filename,
	   t, 
	   status,
           npi,
	   NAME                                                                              AS practice_name,
	   segment_lead, 
	   team_lead, 
	   team_member, 
	   gatekeeper 
    FROM   (SELECT s3_key, 
		   timestamp AS t, 
		   'success' AS status 
	    FROM   etl_new.success_new 
	    UNION 
	    SELECT s3_key, 
		   timestamp AS t, 
		   'fail' 
	    FROM   etl_new.fail_new) AS a 
	   JOIN sneakernet_assignments AS b 
	     ON s3_key LIKE '%' + b.npi + '%' 
    WHERE  t >= '2019-04-01' 
    """
    SNEAKERNET_FILES = CONNECTION.execute(SNEAKERNET_QUERY).fetchall()
    SNEAKERNET_DICT = defaultdict(list)
    for sneakernet_file in SNEAKERNET_FILES:
        filename = sneakernet_file[0]
        quarter = filename.split('_')[0]
        project_diagnosis = ''.join(filename.split('_')[-2]).split('.')[0]
        uniqueness = quarter + project_diagnosis
        npi = sneakernet_file[3]
        SNEAKERNET_DICT[npi].append({uniqueness:filename})

    for dict_npi, dict_endings in SNEAKERNET_DICT.items():
        print dict_npi, dict_endings
