import pyodbc
import pandas as pd
import csv

CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)
ICD_QUERY_CREATE = """
WITH cte_patients
     AS (SELECT cc_patient_id
         FROM   t_chargecapture
                JOIN t_patient
                  ON pat_id = cc_patient_id
                JOIN provider_master
                  ON prov_id = pat_responsible_provider_id
         WHERE  cc_delete_ind = 'N'
                AND pat_delete_ind = 'N'
                AND cc_amount IS NOT NULL
                AND cc_date_of_service BETWEEN '2019-01-01' AND '2019-07-01'
         GROUP  BY cc_patient_id
         HAVING ( Sum(cc_amount) > 2000 )),
     cte_icd
     AS (SELECT icd10_code
         FROM   (SELECT icd10_code,
                        Row_number()
                          OVER (
                            ORDER BY Count(*) DESC) AS rn
                 FROM   t_assessment
                        JOIN cte_patients
                          ON cc_patient_id = patient_id
                 WHERE  assessment_date >= '2018-01-01'
                        AND assessment_date < '2019-01-01'
                        AND icd10_code IS NOT NULL
                 GROUP  BY icd10_code) AS temp
         WHERE  rn <= 1000)
SELECT DISTINCT Concat('sum(case when icd10_code = ''', t_assessment.icd10_code, ''' then 1 else 0 end) ')
FROM   t_assessment
       JOIN cte_icd
         ON t_assessment.icd10_code = cte_icd.icd10_code 
"""

ICD_QUERY_TEXT = ', '.join([
    row[0] for row in CONNECTION_ARCADIA.execute(ICD_QUERY_CREATE).fetchall()
])

ICD_QUERY = """
WITH cte_pat AS 
( 
         SELECT TOP 100000 
                  pat_id 
         FROM     t_patient --where pat_modify_timestamp >= '2018-10-01'
         ORDER BY Rand()) 
SELECT   patient_id, 
         {} 
FROM     cte_pat 
JOIN     t_assessment 
ON       pat_id = patient_id 
WHERE    assessment_date >= \'2017-01-01\' 
--AND      assessment_date < \'2019-03-01\' 
AND      patient_id IS NOT NULL 
AND      delete_ind = \'N\' 
GROUP BY patient_id
""".format(ICD_QUERY_TEXT)

ICD_QUERY = """
SELECT b.*, 
         {} 
FROM     ( 
         SELECT cc_patient_id, case when Sum(cc_amount) > 2000 then 'Y' else 'N' end as expensive
         FROM   t_chargecapture
                JOIN t_patient
                  ON pat_id = cc_patient_id
                JOIN provider_master
                  ON prov_id = pat_responsible_provider_id
         WHERE  cc_delete_ind = 'N'
                AND pat_delete_ind = 'N'
                AND cc_amount IS NOT NULL
                AND cc_date_of_service BETWEEN '2019-01-01' AND '2019-07-01'
         GROUP  BY cc_patient_id
         ) AS b 
JOIN     t_assessment 
ON       patient_id = cc_patient_id
WHERE    assessment_date >= \'2018-01-01\' 
AND      assessment_date < \'2019-01-01\'
AND      patient_id IS NOT NULL 
AND      delete_ind = \'N\' 
GROUP BY cc_patient_id, expensive
""".format(ICD_QUERY_TEXT)

ICD_DF = pd.read_sql(ICD_QUERY, CONNECTION_ARCADIA)
ICD_DF.to_csv('predict_death_with_arcadia1.csv', sep=',', header=False, index=False)
