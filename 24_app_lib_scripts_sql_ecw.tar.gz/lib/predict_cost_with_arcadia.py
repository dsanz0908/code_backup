import pyodbc
import pandas as pd
import csv

CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)
ICD_QUERY_CREATE = """
WITH cte_icd
     AS (SELECT icd10_code
         FROM   (SELECT icd10_code,
                        Row_number()
                          OVER (
                            ORDER BY Count(*) DESC) AS rn
                 FROM   t_assessment
                 WHERE  assessment_date >= '2018-01-01'
                        AND assessment_date < '2018-07-01'
                        AND icd10_code IS NOT NULL
                        AND delete_ind = 'N'
                 GROUP  BY icd10_code) AS temp
         WHERE  rn <= 500)
SELECT DISTINCT Concat('sum(case when icd10_code = ''', t_assessment.icd10_code, ''' then 1 else 0 end) ')
FROM   t_assessment
       JOIN cte_icd
         ON t_assessment.icd10_code = cte_icd.icd10_code
"""

ICD_QUERY_TEXT = ', '.join([
    row[0] for row in CONNECTION_ARCADIA.execute(ICD_QUERY_CREATE).fetchall()
])
ICD_QUERY = """
SELECT   patient_id,
         {} from
(select top 250000 * FROM     t_assessment 
WHERE    assessment_date >= \'2018-10-01\' 
AND      assessment_date < \'2019-04-01\' 
AND      patient_id IS NOT NULL 
AND      delete_ind = \'N\' order by rand() ) as a
GROUP BY patient_id
""".format(ICD_QUERY_TEXT)

ICD_QUERY = """
SELECT b.*, 
         {} 
FROM     ( 
                SELECT pat_id, 
                       pat_expired_ind 
                FROM   t_patient 
                WHERE  pat_expired_ind = 'Y' 
                AND    pat_death_date >= '2018-07-01' 
                AND    pat_death_date < '2019-01-01' 
                UNION 
                SELECT * FROM 
                       ( 
                                SELECT TOP 100000 
                                         pat_id, 
                                         pat_expired_ind 
                                FROM     t_patient 
                                WHERE    pat_expired_ind = 'N' 
                                AND      pat_modify_timestamp >= '2018-07-01' 
                                AND      pat_modify_timestamp < '2019-01-01' 
                                ORDER BY Rand()) AS a) AS b 
JOIN     t_assessment 
ON       pat_id = patient_id 
WHERE    assessment_date >= \'2018-01-01\' 
AND      assessment_date < \'2019-07-01\' 
AND      pat_id IS NOT NULL 
AND      delete_ind = \'N\' 
GROUP BY pat_id, pat_expired_ind
""".format(ICD_QUERY_TEXT)


ICD_DF = pd.read_sql(ICD_QUERY, CONNECTION_ARCADIA)
ICD_DF.to_csv('predict_death_with_arcadia.csv', sep=',', header=False, index=False)
