import pyodbc
import pandas as pd
import csv

CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)
ICD_QUERY_CREATE = """
WITH cte_patients 
     AS (SELECT DISTINCT pat_id 
         FROM   t_patient 
         WHERE  pat_delete_ind = 'N' 
                AND pat_expired_ind = 'Y' 
                AND pat_death_date BETWEEN '2019-01-01' AND '2019-07-01'), 
     cte_icd 
     AS (SELECT icd10_code 
         FROM   (SELECT icd10_code, 
                        Row_number() 
                          OVER ( 
                            ORDER BY Count(*) DESC) AS rn 
                 FROM   t_assessment 
                        JOIN cte_patients 
                          ON pat_id = patient_id 
                 WHERE  assessment_date BETWEEN '2017-01-01' AND '2019-01-01' 
                        AND icd10_code IS NOT NULL
                 GROUP  BY icd10_code) AS temp 
         WHERE  rn <= 500) 
SELECT DISTINCT Concat('max(case when icd10_code = ''', t_assessment.icd10_code, ''' then 1 else 0 end) ')
FROM   t_assessment 
       JOIN cte_icd 
         ON t_assessment.icd10_code = cte_icd.icd10_code 
"""

ICD_QUERY_TEXT = ', '.join([
    row[0] for row in CONNECTION_ARCADIA.execute(ICD_QUERY_CREATE).fetchall()
])

ICD_QUERY = """
select pat_id, {} from (SELECT TOP 100 *
                FROM   (SELECT DISTINCT pat_id
                        FROM   t_encounter
                               JOIN t_patient
                                 ON enc_patient_id = pat_id
                        WHERE  pat_delete_ind = 'N'
                               AND enc_timestamp between '2018-01-01' and '2019-01-01') AS a
                ORDER  BY Newid()) as b  join t_assessment on pat_id = patient_id where assessment_date between '2018-01-01' and '2019-01-01' group by pat_id
""".format(ICD_QUERY_TEXT)

ICD_QUERY = """
SELECT pat_id, pat_expired_ind, 
       {}
FROM   (SELECT DISTINCT pat_id, 
                        pat_expired_ind 
        FROM   t_patient 
        WHERE  pat_delete_ind = 'N' 
               AND pat_expired_ind = 'Y' 
               AND pat_death_date BETWEEN '2019-01-01' AND '2019-07-01' 
        UNION 
        SELECT * 
        FROM   (SELECT TOP 100000 * 
                FROM   (SELECT DISTINCT pat_id, 
                                        pat_expired_ind 
                        FROM   t_encounter 
                               JOIN t_patient 
                                 ON enc_patient_id = pat_id 
                        WHERE  pat_delete_ind = 'N' 
                               AND pat_expired_ind = 'N' 
                               AND enc_timestamp between '2017-01-01' and '2019-01-01') AS a 
                ORDER  BY Newid()) AS b) AS c join t_assessment on pat_id = patient_id where assessment_date between '2017-01-01' and '2019-01-01' group by pat_id, pat_expired_ind
""".format(ICD_QUERY_TEXT)

ICD_DF = pd.read_sql(ICD_QUERY, CONNECTION_ARCADIA)
ICD_DF.to_csv('predict_death_with_arcadia1.csv', sep=',', header=False, index=False)
