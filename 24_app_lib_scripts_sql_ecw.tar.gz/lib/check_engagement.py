# coding: utf-8
import boto3
import datetime
import pytz
import sys
import pyodbc
import smtplib
from html import HTML
import pandas as pd
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.utils import COMMASPACE, formatdate
for_files={}
for_dt = sys.argv[1]
process_date=datetime.datetime.strftime(datetime.datetime.strptime(for_dt,"%Y%m%d") - datetime.timedelta(days=1),"%Y%m%d")
conn=pyodbc.connect(dsn="somos_redshift_1")
def main():
	create_engagementTable()
        new_cnt=list(map(getNewCount,["acp-data","engagement-reporting"]))
	print(sum(new_cnt))
        success,fail=getDBCount(for_dt)
        dbdetails= getDBDetails(for_dt)
        df=processResults(dbdetails,for_dt)
	process_df(df)
        print(new_cnt,success,fail)
        email_report(success,fail,new_cnt,for_dt)

def create_engagementTable():
	query = """ create temp table engagement_report (
				filename	varchar(255),
				success		smallint,
				fail		smallint,
				not_processed	smallint,
				reason		varchar(255) )
		"""       
	conn.execute(query)
def process_output(val_str):
	try:
		ins_query= " insert into engagement_report  "
		conn.execute(ins_query + ' ' + val_str )
		conn.commit()
	except Exception as e:
		print(str(e))
def process_df(df):
	#df=pd.read_sql("select * from engagement_report",conn)
	df.to_csv("/tmp/engagement_report.csv",sep=",",index=False,quotechar='"')
def getNewCount(bucket_name):
        utc=pytz.UTC
        session = boto3.session.Session()
        s3 = session.resource('s3')
	new_cnt=0
       	bucket = s3.Bucket(bucket_name)
	if bucket_name == "acp-data":
       		#f_prefix="Engagement_Reports/Engagement_Files"
		f_prefix="DataAnalytics/ENG-FF/DY4Q4"
	else:
		f_prefix="DY"
       	#for obj in bucket.objects.filter(Prefix=f_prefix.decode(encoding="UTF-8")):
	for obj in bucket.objects.all():
		try:
			if datetime.datetime.strftime(obj.last_modified,"%Y%m%d")  >= process_date and not obj.key.endswith("/") and obj.key.startswith(f_prefix):
				if obj.key in for_files.keys():
                                        for_files[obj.key].append(1)
                               	else:
                                       	for_files[obj.key] = [1]
                               	new_cnt = new_cnt + 1
               	except Exception as e:
                        a=str(e)
       	print(process_date,bucket_name,new_cnt)
        return new_cnt

def getDBCount(process_date):
        query= """
        select sum(success) as success,sum(fail) as fail from (
        select count(*) as success, 0 as fail from etl_new.success_new where for_dt = '{0}'
        union
        select 0, count(*) from etl_new.fail_new where for_dt = '{0}' ) a """
        cur=conn.execute(query.format(process_date))
        res=cur.fetchall()
        cur.close()
        return res[0]

def getDBDetails(process_date):
        query="""
        select s3_key,1 as success, 0 as fail,'' as reason from etl_new.success_new where for_dt = '{0}'
        union
        select s3_key,0 as success, 1 as fail,error as reason from etl_new.fail_new where for_dt = '{0}'
        """
        cur=conn.execute(query.format(process_date))
        res=cur.fetchall()
        cur.close()
        return res

def  processResults(dbdetails,for_dt):
	df=pd.DataFrame(columns=['filename','success','fail','not_processed,reason'])
        total = 0
	print(len(dbdetails))
        for row in dbdetails:
               if row[0] in for_files.keys():
                        for_files[row[0]].append(1) if row[1] == 1 else for_files[row[0]].append(0)
                        for_files[row[0]].append(1) if row[2] == 1 else for_files[row[0]].append(0)
			for_files[row[0]].append(row[3])
        f=open("/home/etl/etl_home/Reports/engagement.html","w")
        h=HTML()
        tbl=h.table(style='font-family:"Calibri";font-size:125%;width:100%')
        r=tbl.tr(style="background-color:#e3e0cc;font-size:125%")
        r.td("FILE NAME")
        r.td("Success Count")
        r.td("Fail Count")
        r.td("Not Processed")
	r.td("Reason")
        for file in for_files.keys():
                total = total + 1
                if len(for_files[file]) == 4:
                        if for_files[file][1] == 1:
                                color = "background-color:#c5d5c5;"
                        else:
                                color = "background-color:#ff6f69;"
                else:
                        color = "background-color:#ffef96"
                r=tbl.tr(style=color)
                r.td(file)
                if len(for_files[file]) == 4:
                        r.td(str(for_files[file][1]))
                        r.td(str(for_files[file][2]))
                        r.td("0")
			r.td(str(for_files[file][3]))
			val_str = "select '{0}',{1},{2},0,'{3}'".format(file,for_files[file][1],for_files[file][2],for_files[file][3][:200])
			ndf=pd.DataFrame({'filename':file,
              				  'success':for_files[file][1], 
              				  'fail':for_files[file][2], 
              				  'not_processed' :0,
             				  'reason':for_files[file][3]}
             				  ,index=[0]
         				)
		  	df=df.append(ndf,ignore_index=False,sort=False)
			#process_output(val_str)				
                else:
                        r.td("0")
                        r.td("0")
                        r.td("1")
        footer = '''<br><br><center><p style="font-family:Calibri;font-size:125%">Total Files: ''' + str(total) + '''</p></center>'''
	if len(dbdetails) > 0:	
        	#header = '<center><b><p style="font-family:Calibri;font-size:125%">Engagement Files Status as of : ' + for_dt + '</p></b></center><br>'
		header='<head><link href="check.css" rel="stylesheet"></head><body><h3>Engagement Files Status as of : ' + for_dt + ' </h3> ' + \
        	''' <div class="content">
		<div class="sidebar">
	  	<ul>
	    	<li><a href="ecw_status.html">ECW Status</a></li>
	    	<li><a href="engagement.html">Engagement Files Status</a></li>
	    	<li><a href="inventory.html">Redshift Inventory Status</a></li>
	  	</ul>
	  	<div class="logo">
	    	<img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
	  	</div>
		</div>'''
        	f.write(header + str(tbl) + footer)
	else:
		#header = '<center><b><p style="font-family:Calibri;font-size:125%">Engagement Files Status as of : ' + for_dt + ' No New files</p></b></center><br>'
		header='<head><link href="check.css" rel="stylesheet"></head><body><h3>Engagement Files Status as of : ' + for_dt + ' No New files </h3> ' + \
        	''' <div class="content">
		<div class="sidebar">
	  	<ul>
	    	<li><a href="ecw_status.html">ECW Status</a></li>
	    	<li><a href="engagement.html">Engagement Files Status</a></li>
	    	<li><a href="inventory.html">Redshift Inventory Status</a></li>
	  	</ul>
	  	<div class="logo">
	    	<img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
	  	</div>
		</div>'''
        	f.write(header + footer)
        f.close()
	return df

         
def email_report(success,fail,new,for_dt):
	to_addr=["ssundararaman@somoscommunitycare.org","dsanz@somoscommunitycare.org","lcolon@somoscommunitycare.org","darslan@somoscommunitycare.org","jdionisio@somoscommunitycare.org","nlopez@somoscommunitycare.org"]
        smtp_user="acpscanner@optimusha.com"
        smtp_pwd="Optimum@2018"
        smtp_server=smtplib.SMTP("west.exch031.serverdata.net",587)
        smtp_server.ehlo()
        smtp_server.starttls()
        smtp_server.ehlo
        smtp_server.login(smtp_user,smtp_pwd)
        #header = "To:" + to_addr + "\n" + "From: " + "etluser@optimusha.net \n" + "Subject: Engagement Satus Report for : " + for_dt + "\n"
        #msg=header + "\n Success Count : " + str(success) +  "\n Failure Count: " + str(fail) + "\n New Count: " + str(new)
        #smtp_server.sendmail("etluser@optimusha.com",to_addr,msg)
        #smtp_server.close()
	msg=MIMEMultipart()
	msg["From"]="etl@optimusha.com"
	msg["To"]=COMMASPACE.join(to_addr)
	msg["Date"]=for_dt
	msg["Subject"]= "Engagement Status Report for : " + for_dt
	msg.attach(MIMEText(" "))
	with open("/tmp/engagement_report.csv","r") as fil:
		part=MIMEApplication(fil.read(),Name="engagement_report.csv")
	part["Content-Disposition"] = "attachment;filename=engagement_report.csv"
	msg.attach(part)
	smtp_server.sendmail("etl@optimusha.com",to_addr,msg.as_string())
	smtp_server.close()

if __name__ == '__main__':
 main()
