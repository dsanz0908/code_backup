import pandas as pd
import numpy as np
import pyodbc
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
tf.compat.v1.enable_eager_execution
CDW_CONNECTION = pyodbc.connect(dsn="claims_dw")

def create_dataset(dataframe, batch_size=32):
    dataframe = dataframe.copy()
    labels = dataframe.pop('target')
    return tf.data.Dataset.from_tensor_slices(
        (dict(dataframe),
         labels)).shuffle(buffer_size=len(dataframe)).batch(batch_size)


TEST_QUERY = """
WITH cte_average_pmpm
     AS (SELECT source,
                year,
                month,
                ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS average_pmpm
         FROM   fact_eligibility AS a
                JOIN dim_date AS b
                  ON a.date_id = b.date_id
                JOIN dim_product AS c
                  ON a.local_product_id = c.local_product_id
         WHERE  eligibility_ind = 1
                AND lob = 'MCD'
         GROUP  BY 1,
                   2,
                   3),
     cte_provider_pmpm
     AS (SELECT local_provider_id,
                source,
                year,
                month,
                Sum(claim_amount)/count(*)                                                          AS claim_amount,
                Sum(rx_claim_amount)/count(*)                                                       AS rx_claim_amount,
                ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS pmpm
         FROM   fact_eligibility AS a
                JOIN dim_date AS b
                  ON a.date_id = b.date_id
                JOIN dim_product AS c
                  ON a.local_product_id = c.local_product_id
         WHERE  eligibility_ind = 1
                AND lob = 'MCD'
         GROUP  BY 1,
                   2,
                   3,
                   4),
     cte_provider_all_targets
     AS (SELECT cte_provider_pmpm.*,
                CASE
                  WHEN pmpm / average_pmpm > 1 THEN 1
                  ELSE 0
                END AS target
         FROM   cte_provider_pmpm
                JOIN cte_average_pmpm
                  ON cte_provider_pmpm.source = cte_average_pmpm.source
                     AND cte_provider_pmpm.year = cte_average_pmpm.year
                     AND cte_provider_pmpm.month = cte_average_pmpm.month
         WHERE  pmpm IS NOT NULL
                AND cte_provider_pmpm.year >= 2017),
     cte_provider_jun2018_targets
     AS (SELECT pal_jun2018.local_provider_id,pal_jun2018.source,
                pal_jun2018.target                 AS jun2018_target,
                pal_sep2018.target                 AS target,
                pal_jun2018.claim_amount           AS claim_amount,
                pal_jun2018.rx_claim_amount        AS rx_claim_amount
         FROM   cte_provider_all_targets AS pal_jun2018
                JOIN cte_provider_all_targets AS pal_sep2018
                  ON pal_jun2018.local_provider_id = pal_sep2018.local_provider_id
                     AND pal_jun2018.source = pal_sep2018.source
         WHERE  pal_jun2018.year = 2018
                AND pal_jun2018.month = 6
                AND pal_sep2018.year = 2018
                AND pal_sep2018.month = 9),
     cte_jun2018_1
     AS (SELECT cte_provider_jun2018_targets.*
         FROM   cte_provider_jun2018_targets
                JOIN dim_provider
                  ON cte_provider_jun2018_targets.local_provider_id = dim_provider.local_provider_id),
     cte_aggregate_member_info as (
     SELECT local_provider_id,
               source,
               Sum(Datediff(year, member_dob, Getdate() - 365)) / Count(*) AS average_age
FROM   fact_eligibility
       JOIN dim_membership
         ON fact_eligibility.local_member_id = dim_membership.local_member_id
       JOIN dim_date
         ON fact_eligibility.date_id = dim_date.date_id
WHERE  year = 2018
       AND month = 6
GROUP  BY 1,
          2 ),
cte_top_service_hold_cd_1 as (SELECT local_pcp_provider_id, 
       source, 
       service_hold_cd_1 
FROM   (SELECT local_pcp_provider_id, 
               source, 
               service_hold_cd_1, 
               Rank() 
                 OVER ( 
                   partition BY local_pcp_provider_id, source 
                   ORDER BY service_hold_cd_1_count DESC) AS rn 
        FROM   (SELECT local_pcp_provider_id, 
                       source, 
                       service_hold_cd_1, 
                       Count(*) AS service_hold_cd_1_count 
                FROM   (SELECT local_pcp_provider_id, 
                               source, 
                               service_hold_cd_1, 
                               service_start_date_id 
                        FROM   fact_claims 
                        UNION 
                        SELECT local_service_provider_id, 
                               source, 
                               service_hold_cd_1, 
                               service_start_date_id 
                        FROM   fact_claims) AS fact_claims 
                       JOIN dim_date 
                         ON fact_claims.service_start_date_id = dim_date.date_id 
                WHERE  year = 2018 
                       AND month = 6 
                       AND service_hold_cd_1 <> '' 
                GROUP  BY 1, 
                          2, 
                          3)) 
WHERE  rn = 1)
SELECT cte_jun2018_1.*, average_age, service_hold_cd_1
FROM   cte_jun2018_1 left outer join cte_aggregate_member_info on cte_jun2018_1.local_provider_id = cte_aggregate_member_info.local_provider_id and cte_jun2018_1.source = cte_aggregate_member_info.source left outer join cte_top_service_hold_cd_1 on
cte_jun2018_1.local_provider_id = cte_top_service_hold_cd_1.local_pcp_provider_id and cte_jun2018_1.source = cte_top_service_hold_cd_1.source

"""


pmpm_df_1 = pd.read_sql(TEST_QUERY, CDW_CONNECTION).fillna('0')
pmpm_df_2 = pd.DataFrame(sorted(pmpm_df_1['service_hold_cd_1'].unique()))
pmpm_df_2.columns = ['service_hold_cd_1']
pmpm_df_2['service_hold_cd_1_count'] = pmpm_df_2.index + 1
pmpm_df_1 = pmpm_df_1.merge(pmpm_df_2, on=['service_hold_cd_1'])
CDW_CONNECTION.close()

feature_columns = []
for header in [
        'jun2018_target', 'claim_amount', 'rx_claim_amount', 'average_age'
]:
    feature_columns.append(tf.feature_column.numeric_column(header))

print pmpm_df_1.corr(method='pearson')

train, test = train_test_split(pmpm_df_1, test_size=0.2, random_state=42)

train_ds = create_dataset(train)
test_ds = create_dataset(test)
model = tf.keras.models.Sequential([
    tf.keras.layers.DenseFeatures(feature_columns=feature_columns),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(rate=0.2),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dense(units=1, activation='sigmoid')
])

model.compile(
    optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

history = model.fit(
    train_ds,
    validation_data=test_ds,
    epochs=100,
    use_multiprocessing=True,
    verbose=False)


predictions = tf.Session().run(tf.round(model.predict(test_ds))).flatten()
real_values = test['target'].values.flatten()
print classification_report(real_values, predictions)
