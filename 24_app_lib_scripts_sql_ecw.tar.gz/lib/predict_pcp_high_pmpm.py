import pandas as pd
import numpy as np
import pyodbc
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
tf.compat.v1.enable_eager_execution
CDW_CONNECTION = pyodbc.connect(dsn="claims_dw")


def create_dataset(dataframe, batch_size=32):
    dataframe = dataframe.copy()
    labels = dataframe.pop('target')
    return tf.data.Dataset.from_tensor_slices(
        (dict(dataframe),
         labels)).shuffle(buffer_size=len(dataframe)).batch(batch_size)


TEST_QUERY = """
WITH cte_average_pmpm
     AS (SELECT source,
                year,
                month,
                ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS average_pmpm
         FROM   fact_eligibility AS a
                JOIN dim_date AS b
                  ON a.date_id = b.date_id
                JOIN dim_product AS c
                  ON a.local_product_id = c.local_product_id
                JOIN dim_provider as d
                  ON a.local_provider_id = d.local_provider_id
         WHERE  eligibility_ind = 1
                AND lob = 'MCD' and provider_type = 'PCP'
         GROUP  BY 1,
                   2,
                   3),
     cte_provider_pmpm
     AS (SELECT a.local_provider_id,
                source,
                year,
                month,
                Sum(claim_amount)/count(*)                                                          AS claim_amount,
                Sum(rx_claim_amount)/count(*)                                                       AS rx_claim_amount,
                ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS pmpm
         FROM   fact_eligibility AS a
                JOIN dim_date AS b
                  ON a.date_id = b.date_id
                JOIN dim_product AS c
                  ON a.local_product_id = c.local_product_id
                    JOIN dim_provider as d
                  ON a.local_provider_id = d.local_provider_id
         WHERE  eligibility_ind = 1
                AND lob = 'MCD' and provider_type = 'PCP'
         GROUP  BY 1,
                   2,
                   3,
                   4),
     cte_provider_all_targets
     AS (SELECT cte_provider_pmpm.*,
                CASE
                  WHEN pmpm / average_pmpm > 1 THEN 1
                  ELSE 0
                END AS target
         FROM   cte_provider_pmpm
                JOIN cte_average_pmpm
                  ON cte_provider_pmpm.source = cte_average_pmpm.source
                     AND cte_provider_pmpm.year = cte_average_pmpm.year
                     AND cte_provider_pmpm.month = cte_average_pmpm.month
         WHERE  pmpm IS NOT NULL and average_pmpm > 0),
     cte_provider_jun2018_targets
     AS (SELECT pal_jun2018.local_provider_id,pal_jun2018.source,
                pal_jun2018.target                 AS jun2018_target,
                pal_sep2018.target                 AS target,
                pal_jun2018.claim_amount           AS claim_amount,
                pal_jun2018.rx_claim_amount        AS rx_claim_amount
         FROM   cte_provider_all_targets AS pal_jun2018
                JOIN cte_provider_all_targets AS pal_sep2018
                  ON pal_jun2018.local_provider_id = pal_sep2018.local_provider_id
                     AND pal_jun2018.source = pal_sep2018.source
         WHERE  pal_jun2018.year = 2018
                AND pal_jun2018.month = 6
                AND pal_sep2018.year = 2018
                AND pal_sep2018.month = 12),
     cte_jun2018_1
     AS (SELECT cte_provider_jun2018_targets.*
         FROM   cte_provider_jun2018_targets
                JOIN dim_provider
                  ON cte_provider_jun2018_targets.local_provider_id = dim_provider.local_provider_id),
     cte_aggregate_member_info as (
     SELECT local_provider_id,
               source,
               Sum(Datediff(year, member_dob, Getdate() - 365)) / Count(*) AS average_age
FROM   fact_eligibility
       JOIN dim_membership
         ON fact_eligibility.local_member_id = dim_membership.local_member_id
       JOIN dim_date
         ON fact_eligibility.date_id = dim_date.date_id
WHERE  year = 2018
       AND month = 6
GROUP  BY 1,
          2 ),
cte_expensive_drug_counts as (
select local_pcp_prov_id, count(*) as count_expensive_drugs, count(distinct local_drug_id) as distinct_expensive_drugs from fact_pharmacy_claims where effective_date = '2018-06-01' and avg_wholesale_price > 200 group by 1
), cte_expensive_service_providers 
     AS (SELECT local_service_provider_id, 
                Rank() 
                  OVER ( 
                    ORDER BY Sum(billed_amount)/Count(*)) AS rnk 
         FROM   fact_claims 
         WHERE  local_pcp_provider_id <> local_service_provider_id 
                AND effective_date = '2018-06-01' 
         GROUP  BY 1 
         HAVING Count(*) > 10),
cte_expensive_service_providers_aggregate as (         
SELECT local_pcp_provider_id, 
       Sum(rnk) / Count(*) AS average_expensive_service_provider, 
       Sum(rnk)            AS total_expensive_service_provider, 
       Count(*)            AS count_service_providers 
FROM   (SELECT DISTINCT local_pcp_provider_id, 
                        rnk 
        FROM   fact_claims 
               JOIN cte_expensive_service_providers 
                 ON fact_claims.local_service_provider_id = 
                    cte_expensive_service_providers.local_service_provider_id 
        WHERE  fact_claims.local_pcp_provider_id <> 
               fact_claims.local_service_provider_id 
               AND effective_date = '2018-06-01') 
GROUP  BY 1)
SELECT cte_jun2018_1.*, average_age, count_expensive_drugs, total_expensive_service_provider, count_service_providers
FROM   cte_jun2018_1 left outer join cte_aggregate_member_info on cte_jun2018_1.local_provider_id = cte_aggregate_member_info.local_provider_id and cte_jun2018_1.source = cte_aggregate_member_info.source
left outer join cte_expensive_drug_counts on cte_jun2018_1.local_provider_id = cte_expensive_drug_counts.local_pcp_prov_id
left outer join cte_expensive_service_providers_aggregate on cte_jun2018_1.local_provider_id = cte_expensive_service_providers_aggregate.local_pcp_provider_id
"""

TEST_QUERY = """
WITH cte_average_pmpm
     AS (SELECT source,
                the_date,
                ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS average_pmpm
         FROM   fact_eligibility AS a
                JOIN dim_date AS b
                  ON a.date_id = b.date_id
                JOIN dim_product AS c
                  ON a.local_product_id = c.local_product_id
                JOIN dim_provider AS d
                  ON a.local_provider_id = d.local_provider_id
         WHERE  eligibility_ind = 1
                AND lob = 'MCD'
                AND provider_type = 'PCP'
         GROUP  BY 1,
                   2),
     cte_provider_pmpm
     AS (SELECT a.local_provider_id,
                source,
                the_date,
                Sum(claim_amount) / Count(*)                                               AS claim_amount,
                Sum(rx_claim_amount) / Count(*)                                            AS rx_claim_amount,
                ( Sum(claim_amount) + Sum(rx_claim_amount) ) / Sum(membership_month_count) AS pmpm
         FROM   fact_eligibility AS a
                JOIN dim_date AS b
                  ON a.date_id = b.date_id
                JOIN dim_product AS c
                  ON a.local_product_id = c.local_product_id
                JOIN dim_provider AS d
                  ON a.local_provider_id = d.local_provider_id
         WHERE  eligibility_ind = 1
                AND lob = 'MCD'
                AND provider_type = 'PCP'
         GROUP  BY 1,
                   2,
                   3),
     cte_current_targets
     AS (SELECT cte_provider_pmpm.*,
                CASE
                  WHEN pmpm / average_pmpm > 1 THEN 1
                  ELSE 0
                END AS target
         FROM   cte_provider_pmpm
                JOIN cte_average_pmpm
                  ON cte_provider_pmpm.source = cte_average_pmpm.source
                     AND cte_provider_pmpm.the_date = cte_average_pmpm.the_date
         WHERE  pmpm IS NOT NULL
                AND average_pmpm > 0),
     cte_current_future
     AS (SELECT current_targets.local_provider_id,
                current_targets.source,
                current_targets.the_date,
                current_targets.claim_amount,
                current_targets.rx_claim_amount,
                current_targets.target AS expensive_now,
                future_targets.target  AS target
         FROM   cte_current_targets AS current_targets
                JOIN cte_current_targets AS future_targets
                  ON current_targets.local_provider_id = future_targets.local_provider_id
                     AND current_targets.source = future_targets.source
         WHERE  Months_between(future_targets.the_date, current_targets.the_date) = 6),
     cte_average_age
     AS (SELECT local_provider_id,
                the_date,
                Sum(Datediff(year, member_dob, the_date)) / Count(*) AS average_age
         FROM   fact_eligibility
                JOIN dim_membership
                  ON fact_eligibility.local_member_id = dim_membership.local_member_id
                JOIN dim_date
                  ON fact_eligibility.date_id = dim_date.date_id
         GROUP  BY 1,
                   2),
     cte_most_expensive_service_providers
     AS (SELECT local_service_provider_id,
                effective_date,
                Rank()
                  OVER (
                    partition BY effective_date
                    ORDER BY Sum(billed_amount)/Count(*)) AS rnk
         FROM   fact_claims
         WHERE  local_pcp_provider_id <> local_service_provider_id
         GROUP  BY 1,
                   2
         HAVING Count(*) > 0),
     cte_expensive_pcp_service
     AS (SELECT DISTINCT local_pcp_provider_id,
                         local_service_provider_id,
                         effective_date
         FROM   fact_claims),
     cte_service_providers
     AS (SELECT local_pcp_provider_id,
                cte_most_expensive_service_providers.effective_date,
                Sum(rnk) AS total_service_provider_expense
         FROM   cte_most_expensive_service_providers
                JOIN cte_expensive_pcp_service
                  ON cte_most_expensive_service_providers.local_service_provider_id =
                     cte_expensive_pcp_service.local_service_provider_id
                     AND cte_most_expensive_service_providers.effective_date = cte_expensive_pcp_service.effective_date
         GROUP  BY 1,
                   2),
          cte_inpatient_claims_count as (select local_pcp_provider_id, effective_date, count(distinct claim_id) as inpatient_claims from fact_claims where local_place_of_service_id in (1,3,4,13) group by 1,2),
          cte_expensive_drug_count as (select local_pcp_prov_id, effective_date, count(*) as count_expensive_drugs, count(distinct local_drug_id) as distinct_expensive_drugs from fact_pharmacy_claims where avg_wholesale_price > 200 group by 1,2),
          cte_discharge_status as (select 
local_pcp_provider_id, 
effective_date, 
sum(case when local_discharge_status_id = 1 then 1 else 0 end) as d1,
sum(case when local_discharge_status_id = 2 then 1 else 0 end) as d2,
sum(case when local_discharge_status_id = 3 then 1 else 0 end) as d3,
sum(case when local_discharge_status_id = 4 then 1 else 0 end) as d4,
sum(case when local_discharge_status_id = 5 then 1 else 0 end) as d5,
sum(case when local_discharge_status_id = 6 then 1 else 0 end) as d6,
sum(case when local_discharge_status_id = 7 then 1 else 0 end) as d7,
sum(case when local_discharge_status_id = 8 then 1 else 0 end) as d8,
sum(case when local_discharge_status_id = 9 then 1 else 0 end) as d9,
sum(case when local_discharge_status_id = 10 then 1 else 0 end) as d10,
sum(case when local_discharge_status_id = 11 then 1 else 0 end) as d11,
sum(case when local_discharge_status_id = 12 then 1 else 0 end) as d12,
sum(case when local_discharge_status_id = 13 then 1 else 0 end) as d13,
sum(case when local_discharge_status_id = 14 then 1 else 0 end) as d14,
sum(case when local_discharge_status_id = 15 then 1 else 0 end) as d15,
sum(case when local_discharge_status_id = 16 then 1 else 0 end) as d16,
sum(case when local_discharge_status_id = 17 then 1 else 0 end) as d17,
sum(case when local_discharge_status_id = 18 then 1 else 0 end) as d18,
sum(case when local_discharge_status_id = 19 then 1 else 0 end) as d19,
sum(case when local_discharge_status_id = 20 then 1 else 0 end) as d20,
sum(case when local_discharge_status_id = 21 then 1 else 0 end) as d21,
sum(case when local_discharge_status_id = 22 then 1 else 0 end) as d22,
sum(case when local_discharge_status_id = 23 then 1 else 0 end) as d23,
sum(case when local_discharge_status_id = 24 then 1 else 0 end) as d24,
sum(case when local_discharge_status_id = 25 then 1 else 0 end) as d25
from fact_claims
group by 1,2)
SELECT claim_amount,
       rx_claim_amount,
       expensive_now,
       target,
       average_age,
       total_service_provider_expense,
       inpatient_claims, distinct_expensive_drugs, 
d1,d2,d3,d4,d5,d6,d7,d9,d10,
d11,d12,d13,d14,d15,d17,d19,
d20,d21
FROM   cte_current_future
       LEFT OUTER JOIN cte_average_age
                    ON cte_current_future.local_provider_id = cte_average_age.local_provider_id
                       AND cte_current_future.the_date = cte_average_age.the_date
       LEFT OUTER JOIN cte_service_providers
                    ON cte_current_future.local_provider_id = cte_service_providers.local_pcp_provider_id
                       AND cte_current_future.the_date = cte_service_providers.effective_date
LEFT OUTER JOIN cte_inpatient_claims_count
         ON cte_current_future.local_provider_id =
            cte_inpatient_claims_count.local_pcp_provider_id
            AND cte_current_future.the_date = cte_inpatient_claims_count.effective_date
LEFT OUTER JOIN cte_expensive_drug_count
         ON cte_current_future.local_provider_id =
            cte_expensive_drug_count.local_pcp_prov_id
            AND cte_current_future.the_date = cte_expensive_drug_count.effective_date
LEFT OUTER JOIN cte_discharge_status
         ON cte_current_future.local_provider_id =
            cte_discharge_status.local_pcp_provider_id
            AND cte_current_future.the_date = cte_discharge_status.effective_date

"""

pmpm_df_1 = pd.read_sql(TEST_QUERY,
                        CDW_CONNECTION).fillna('0').astype(np.int64)
#pmpm_df_1['count_expensive_drugs'] = pmpm_df_1['count_expensive_drugs'].astype(np.int64)
#pmpm_df_1['total_expensive_service_provider'] = pmpm_df_1['total_expensive_service_provider'].astype(np.int64)
#pmpm_df_1['count_service_providers'] = pmpm_df_1['count_service_providers'].astype(np.int64)
print pmpm_df_1.corr()
#pmpm_df_2 = pd.DataFrame(sorted(pmpm_df_1['service_hold_cd_1'].unique()))
#pmpm_df_2.columns = ['service_hold_cd_1']
#pmpm_df_2['service_hold_cd_1_count'] = pmpm_df_2.index + 1
#pmpm_df_1 = pmpm_df_1.merge(pmpm_df_2, on=['service_hold_cd_1'])
CDW_CONNECTION.close()

feature_columns = []
for header in [
        'expensive_now', 'claim_amount', 'rx_claim_amount', 'average_age', 'total_service_provider_expense', 'inpatient_claims', 'distinct_expensive_drugs'
]:
    feature_columns.append(tf.feature_column.numeric_column(header))

train, test = train_test_split(pmpm_df_1, test_size=0.2, random_state=42)

train_ds = create_dataset(train)
test_ds = create_dataset(test)
model = tf.keras.models.Sequential([
    tf.keras.layers.DenseFeatures(feature_columns=feature_columns),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(rate=0.2),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dense(units=1, activation='sigmoid')
])

model.compile(
    optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

history = model.fit(
    train_ds,
    validation_data=test_ds,
    epochs=100,
    use_multiprocessing=False,
    verbose=False)

predictions = tf.Session().run(tf.round(model.predict(test_ds))).flatten()
real_values = test['target'].values.flatten()
print classification_report(real_values, predictions)
