import pandas as pd
import numpy as np
import pyodbc
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
tf.compat.v1.enable_eager_execution
CDW_CONNECTION = pyodbc.connect(dsn="claims_dw")


def create_dataset(dataframe, batch_size=512):
    dataframe = dataframe.copy()
    labels = dataframe.pop('target')
    return tf.data.Dataset.from_tensor_slices(
        (dict(dataframe),
         labels)).shuffle(buffer_size=len(dataframe)).batch(batch_size)


TEST_QUERY = """
WITH cte_source_membermonths 
     AS (SELECT the_date, 
                a.source, 
                Sum(membership_month_count) AS membership_month_count 
         FROM   fact_eligibility AS a 
                JOIN dim_date AS b 
                  ON a.date_id = b.date_id 
                JOIN dim_product AS c 
                  ON a.local_product_id = c.local_product_id 
                JOIN dim_provider AS d 
                  ON a.local_provider_id = d.local_provider_id 
         WHERE  lob = 'MCD' 
                AND provider_type = 'PCP' 
         GROUP  BY 1, 
                   2), 
     cte_source_claim_amount 
     AS (SELECT effective_date, 
                source, 
                Sum(to_pay_amount) AS claim_amount 
         FROM   fact_claims AS a 
                JOIN dim_product AS c 
                  ON a.local_product_id = c.local_product_id 
                JOIN dim_provider AS d 
                  ON a.local_pcp_provider_id = d.local_provider_id 
         WHERE  lob = 'MCD' 
                AND provider_type = 'PCP' 
         GROUP  BY 1, 
                   2), 
     cte_source_rx_claim_amount 
     AS (SELECT effective_date, 
                source, 
                Sum(to_pay_amount) AS rx_claim_amount 
         FROM   fact_pharmacy_claims AS a 
                JOIN dim_product AS c 
                  ON a.local_product_id = c.local_product_id 
                JOIN dim_provider AS d 
                  ON a.local_pcp_prov_id = d.local_provider_id 
         WHERE  lob = 'MCD' 
                AND provider_type = 'PCP' 
         GROUP  BY 1, 
                   2), 
     cte_source_pmpm 
     AS (SELECT cte_source_membermonths.*, 
                ( claim_amount + rx_claim_amount ) / membership_month_count AS average_pmpm 
         FROM   cte_source_membermonths 
                JOIN cte_source_claim_amount 
                  ON cte_source_membermonths.the_date = cte_source_claim_amount.effective_date 
                     AND cte_source_membermonths.source = cte_source_claim_amount.source 
                JOIN cte_source_rx_claim_amount 
                  ON cte_source_membermonths.the_date = cte_source_rx_claim_amount.effective_date
                     AND cte_source_membermonths.source = cte_source_rx_claim_amount.source), 
     cte_provider_membermonths 
     AS (SELECT the_date, 
                a.source, 
                a.local_provider_id, 
                Sum(membership_month_count) AS membership_month_count 
         FROM   fact_eligibility AS a 
                JOIN dim_date AS b 
                  ON a.date_id = b.date_id 
                JOIN dim_product AS c 
                  ON a.local_product_id = c.local_product_id 
                JOIN dim_provider AS d 
                  ON a.local_provider_id = d.local_provider_id 
         WHERE  lob = 'MCD' 
                AND provider_type = 'PCP' 
         GROUP  BY 1, 
                   2, 
                   3), 
     cte_provider_claim_amount 
     AS (SELECT effective_date, 
                source, 
                a.local_pcp_provider_id, 
                Sum(to_pay_amount) AS claim_amount 
         FROM   fact_claims AS a 
                JOIN dim_product AS c 
                  ON a.local_product_id = c.local_product_id 
                JOIN dim_provider AS d 
                  ON a.local_pcp_provider_id = d.local_provider_id 
         WHERE  lob = 'MCD' 
                AND provider_type = 'PCP' 
         GROUP  BY 1, 
                   2, 
                   3), 
     cte_provider_rx_claim_amount 
     AS (SELECT effective_date, 
                source, 
                a.local_pcp_prov_id, 
                Sum(to_pay_amount) AS rx_claim_amount 
         FROM   fact_pharmacy_claims AS a 
                JOIN dim_product AS c 
                  ON a.local_product_id = c.local_product_id 
                JOIN dim_provider AS d 
                  ON a.local_pcp_prov_id = d.local_provider_id 
         WHERE  lob = 'MCD' 
                AND provider_type = 'PCP' 
         GROUP  BY 1, 
                   2, 
                   3), 
     cte_provider_pmpm 
     AS (SELECT cte_provider_membermonths.*, 
                claim_amount, 
                rx_claim_amount, 
                ( claim_amount + rx_claim_amount ) / membership_month_count AS pmpm 
         FROM   cte_provider_membermonths 
                JOIN cte_provider_claim_amount 
                  ON cte_provider_membermonths.the_date = cte_provider_claim_amount.effective_date
                     AND cte_provider_membermonths.source = cte_provider_claim_amount.source 
                     AND cte_provider_membermonths.local_provider_id = cte_provider_claim_amount.local_pcp_provider_id
                JOIN cte_provider_rx_claim_amount 
                  ON cte_provider_membermonths.the_date = cte_provider_rx_claim_amount.effective_date
                     AND cte_provider_membermonths.source = cte_provider_rx_claim_amount.source
                     AND cte_provider_membermonths.local_provider_id = cte_provider_rx_claim_amount.local_pcp_prov_id), cte_current_targets as (
SELECT local_provider_id, 
       cte_source_pmpm.the_date, 
       cte_source_pmpm.source, 
       claim_amount, 
       rx_claim_amount, 
       pmpm, 
       CASE 
         WHEN pmpm / average_pmpm > 2 THEN 1 
         ELSE 0 
       END AS target 
FROM   cte_source_pmpm 
       JOIN cte_provider_pmpm 
         ON cte_source_pmpm.the_date = cte_provider_pmpm.the_date 
            AND cte_source_pmpm.source = cte_provider_pmpm.source 
WHERE  cte_provider_pmpm.membership_month_count > 100 and cte_source_pmpm.the_date >= '2017-01-01'),
 cte_current_future
     AS (SELECT current_targets.local_provider_id,
                current_targets.the_date,
                current_targets.claim_amount,
                current_targets.rx_claim_amount,
                current_targets.target AS expensive_now,
                future_targets.target  AS target
         FROM   cte_current_targets AS current_targets
                JOIN cte_current_targets AS future_targets
                  ON current_targets.local_provider_id = future_targets.local_provider_id
         WHERE  Months_between(future_targets.the_date, current_targets.the_date) between 3 and 12),
     cte_average_age
     AS (SELECT local_provider_id,
                the_date,
                Sum(Datediff(year, member_dob, the_date)) / Count(*) AS average_age
         FROM   fact_eligibility
                JOIN dim_membership
                  ON fact_eligibility.local_member_id = dim_membership.local_member_id
                JOIN dim_date
                  ON fact_eligibility.date_id = dim_date.date_id
         GROUP  BY 1,
                   2),
     cte_most_expensive_service_providers
     AS (SELECT local_service_provider_id,
                effective_date,
                Rank()
                  OVER (
                    partition BY effective_date
                    ORDER BY Sum(billed_amount)/Count(*)) AS rnk
         FROM   fact_claims
         WHERE  local_pcp_provider_id <> local_service_provider_id
         GROUP  BY 1,
                   2
         HAVING Count(*) > 0),
     cte_expensive_pcp_service
     AS (SELECT DISTINCT local_pcp_provider_id,
                         local_service_provider_id,
                         effective_date
         FROM   fact_claims),
     cte_service_providers
     AS (SELECT local_pcp_provider_id,
                cte_most_expensive_service_providers.effective_date,
                Sum(rnk) AS total_service_provider_expense
         FROM   cte_most_expensive_service_providers
                JOIN cte_expensive_pcp_service
                  ON cte_most_expensive_service_providers.local_service_provider_id =
                     cte_expensive_pcp_service.local_service_provider_id
                     AND cte_most_expensive_service_providers.effective_date = cte_expensive_pcp_service.effective_date
         GROUP  BY 1,
                   2),
     cte_expensive_drug_count
     AS (SELECT local_pcp_prov_id,
                effective_date,
                Count(*)                      AS count_expensive_drugs,
                Count(DISTINCT local_drug_id) AS distinct_expensive_drugs
         FROM   fact_pharmacy_claims
         WHERE  avg_wholesale_price > 200
         GROUP  BY 1,
                   2),
     cte_umr_category
     AS (SELECT local_pcp_provider_id,
                effective_date,
                Sum(CASE
                      WHEN umr_category_cd IN ( 'OPRB', 'N/A' ) THEN 1
                      ELSE 0
                    END) AS umr
         FROM   fact_claims
                JOIN dim_umr_category
                  ON fact_claims.local_umr_category_id = dim_umr_category.local_umr_category_id
         GROUP  BY 1,
                   2),
     cte_service_type
     AS (SELECT local_pcp_provider_id,
                effective_date,
                Sum(CASE
                      WHEN service_cd_type IN ( 'HC', 'HG', 'CP', 'RV' ) THEN 1
                      ELSE 0
                    END) AS service_type
         FROM   fact_claims
                JOIN dim_service_type
                  ON fact_claims.local_service_id = dim_service_type.local_service_id
         GROUP  BY 1,
                   2),
     cte_expensive_procedures
     AS (SELECT cpt_code,
                Row_number()
                  OVER (
                    ORDER BY per_unit) AS rnk
         FROM   (SELECT cpt_code,
                        Sum(to_pay_amount) / Count(*) AS per_unit
                 FROM   fact_claims
                 WHERE  cpt_code IS NOT NULL
                        AND Trim(cpt_code) <> ''
                 GROUP  BY 1
                 HAVING Count(*) > 10)),
     cte_pcp_expensive_procedures
     AS (SELECT local_pcp_provider_id,
                effective_date,
                Sum(to_pay_amount) AS total_cpt_cost
         FROM   fact_claims
                JOIN cte_expensive_procedures
                  ON fact_claims.cpt_code = cte_expensive_procedures.cpt_code
         WHERE  rnk > 200
         GROUP  BY 1,
                   2),
     cte_most_zipcode
     AS (SELECT local_provider_id,
                top_zipcodes.the_date,
                Count(*) AS zipcode_sum
         FROM   fact_eligibility
                JOIN dim_membership
                  ON fact_eligibility.local_member_id = dim_membership.local_member_id
                JOIN dim_date
                  ON fact_eligibility.date_id = dim_date.date_id
                JOIN (SELECT the_date,
                             member_zip,
                             Row_number()
                               OVER (
                                 partition BY the_date
                                 ORDER BY Sum(claim_amount) + Sum(rx_claim_amount) desc) AS rnk
                      FROM   fact_eligibility
                             JOIN dim_membership
                               ON fact_eligibility.local_member_id = dim_membership.local_member_id
                             JOIN dim_date
                               ON fact_eligibility.date_id = dim_date.date_id
                      GROUP  BY 1,
                                2
                      HAVING Sum(claim_amount) + Sum(rx_claim_amount) > 0) AS top_zipcodes
                  ON top_zipcodes.the_date = dim_date.the_date
                     AND dim_membership.member_zip = top_zipcodes.member_zip
         WHERE  rnk <= 20
         GROUP  BY 1,
                   2), cte_all as (
SELECT claim_amount,
rx_claim_amount,
       expensive_now,
       target,
       average_age,
       distinct_expensive_drugs,
       umr,
       service_type,
       total_service_provider_expense,
       total_cpt_cost,
       zipcode_sum
FROM   cte_current_future
       LEFT OUTER JOIN cte_average_age
                    ON cte_current_future.local_provider_id = cte_average_age.local_provider_id
                       AND cte_current_future.the_date = cte_average_age.the_date
       LEFT OUTER JOIN cte_service_providers
                    ON cte_current_future.local_provider_id = cte_service_providers.local_pcp_provider_id
                       AND cte_current_future.the_date = cte_service_providers.effective_date
       LEFT OUTER JOIN cte_expensive_drug_count
                    ON cte_current_future.local_provider_id = cte_expensive_drug_count.local_pcp_prov_id
                       AND cte_current_future.the_date = cte_expensive_drug_count.effective_date
       LEFT OUTER JOIN cte_umr_category
                    ON cte_current_future.local_provider_id = cte_umr_category.local_pcp_provider_id
                       AND cte_current_future.the_date = cte_umr_category.effective_date
       LEFT OUTER JOIN cte_service_type
                    ON cte_current_future.local_provider_id = cte_service_type.local_pcp_provider_id
                       AND cte_current_future.the_date = cte_service_type.effective_date
       LEFT OUTER JOIN cte_pcp_expensive_procedures
                    ON cte_current_future.local_provider_id = cte_pcp_expensive_procedures.local_pcp_provider_id
                       AND cte_current_future.the_date = cte_pcp_expensive_procedures.effective_date
       LEFT OUTER JOIN cte_most_zipcode
                    ON cte_current_future.local_provider_id = cte_most_zipcode.local_provider_id
                       AND cte_current_future.the_date = cte_most_zipcode.the_date)
select * from cte_all
"""

TEST_QUERY2 = """
WITH cte_claims 
     AS (SELECT local_member_id, 
                date_part(year, effective_date) as y , 
                to_pay_amount 
         FROM   fact_claims 
         WHERE  date_part(year, effective_date) >= 2017
               AND to_pay_amount IS NOT NULL), 
     cte_rx_claims 
     AS (SELECT local_member_id, 
                date_part(year, effective_date),
                to_pay_amount 
         FROM   fact_pharmacy_claims 
         WHERE  date_part(year, effective_date) >= 2017
                AND to_pay_amount IS NOT NULL), 
     cte_member_costs 
     AS (SELECT local_member_id, 
                y, 
                Sum(to_pay_amount) AS cost 
         FROM   (SELECT * 
                 FROM   cte_claims 
                 UNION ALL 
                 SELECT * 
                 FROM   cte_rx_claims) 
         GROUP  BY 1, 
                   2), 
     cte_expensive_now_target 
     AS (SELECT a.local_member_id, 
                a.y, 
                CASE 
                  WHEN a.cost > 5000 THEN 1 
                  ELSE 0 
                END AS expensive_now, 
                CASE 
                  WHEN b.cost > 5000 THEN 1 
                  ELSE 0 
                END AS target 
         FROM   cte_member_costs AS a 
                JOIN cte_member_costs AS b 
                  ON a.local_member_id = b.local_member_id 
         WHERE  a.y <= 2018 and b.y = 2019),
     cte_claims_detail as (SELECT local_member_id, 
       date_part(year, effective_date), 
       Count(DISTINCT local_service_provider_id) AS distinct_service_providers, 
       Count(DISTINCT local_place_of_service_id) AS distinct_pos,
       count(distinct local_discharge_status_id) as distinct_discharge_statuses,
       count(distinct local_umr_category_id) as distinct_umr,
       count(distinct admit_date) as distinct_admits,
       sum(avg_service_len) as sum_service_len,
       count(distinct local_service_id) as distinct_service_id
FROM   fact_claims 
WHERE  date_part(year, effective_date) <= 2018
group by 1,2),
cte_pharmacy_detail as (SELECT local_member_id,
       date_part(year, effective_date),
       Count(DISTINCT local_pharmacy_id) AS distinct_pharmacys,
       Count(DISTINCT local_prescriber_id) AS distinct_prescribers,       
       Count(DISTINCT local_drug_id) AS distinct_drugs,              
       Count(DISTINCT local_therapeutic_class_id) AS distinct_therapeutic_classes
FROM   fact_pharmacy_claims
WHERE  date_part(year, effective_date) <= 2018
group by 1,2),
     cte_final 
     AS (SELECT expensive_now, 
                target, 
                distinct_service_providers,distinct_pos,distinct_discharge_statuses,distinct_umr,
                distinct_service_id,distinct_pharmacys,distinct_prescribers,
                distinct_drugs,distinct_therapeutic_classes
         FROM   cte_expensive_now_target AS a 
                JOIN dim_membership AS b 
                  ON a.local_member_id = b.local_member_id
                   JOIN cte_claims_detail AS c 
                  ON a.local_member_id = c.local_member_id
                   JOIN cte_pharmacy_detail AS d
                  ON a.local_member_id = d.local_member_id
) 
SELECT *
FROM   cte_final order by random()
"""

pmpm_df_1 = pd.read_sql(TEST_QUERY2,
                        CDW_CONNECTION).fillna('0').astype(np.int64)
CDW_CONNECTION.close()

print pmpm_df_1.corr()
features = list(pmpm_df_1.corr().query('target >= .0')['target'].index)
print features
features.remove('target')
for feature in features:
    #if feature == 'expensive_now':
    #    continue
    f_min = pmpm_df_1[feature].min()
    f_max = pmpm_df_1[feature].max()
    pmpm_df_1[feature] = (pmpm_df_1[feature] - f_min) / (f_max - f_min)
    #pmpm_df_1[feature] = pmpm_df_1[feature].round().astype(np.int64)

#data["sex"] = data["sex"].apply(str)
#sex = tf.feature_column.categorical_column_with_vocabulary_list(
#      'sex', ['0', '1'])
#sex_one_hot = tf.feature_column.indicator_column(sex)
#feature_columns.append(sex_one_hot)


feature_columns = []
for header in features:
    feature_columns.append(tf.feature_column.numeric_column(header))

train, test = train_test_split(pmpm_df_1, test_size=0.2, random_state=42)

train_ds = create_dataset(train)
test_ds = create_dataset(test)
model = tf.keras.models.Sequential([
    tf.keras.layers.DenseFeatures(feature_columns=feature_columns),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(rate=0.2),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dense(units=1, activation='sigmoid')
])

model.compile(
    optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

history = model.fit(
    train_ds,
    validation_data=test_ds,
    epochs=5,
    use_multiprocessing=True)

predictions = tf.Session().run(tf.round(model.predict(test_ds))).flatten()
real_values = test['target'].values.flatten()
print classification_report(real_values, predictions)
print model.evaluate(test_ds)

