from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


TASK_QUERY_A = """
create temp table a
(
ownerid varchar(255),
cin varchar(255),
pcpid varchar(255));

copy a
from 's3://sftp_test/20200317_nicole_sf.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 0
ignoreheader 1
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;
"""

TASK_QUERY_B = """
select distinct a.ownerid, salesforce_patients.id, pcp__c from a join salesforce_patients on cin = cin__c
"""

sf, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
CONNECTION.execute(TASK_QUERY_A)
TASKS = CONNECTION.execute(TASK_QUERY_B).fetchall()
TODAY = datetime.now().strftime("%Y%m%d")
for task in TASKS[1:]:
    try:
        print task
	sf.Task.create({
	    'ownerid': task[0],
	    'measure__c': 'Special Outreach Project',
	    'whoid': task[1],
	    'pcp__c': task[2],
	    'recordtypeid': '012f4000000FcmzAAC',
	    'procedure__c': '',
	    'subject': 'Special Outreach Project (2020)',
	    'project_end_date__c': '2020-06-30',
	    'source_created_by__c': 'derek/juan sop upload - 20200317',
	    'status': 'Open'
	})
    except Exception as e:
        print(task, str(e))

CONNECTION.close()
