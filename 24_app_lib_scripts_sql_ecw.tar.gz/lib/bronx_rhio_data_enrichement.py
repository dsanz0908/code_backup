import pyodbc
import psycopg2
from sqlalchemy import create_engine
import pandas as pd
import numpy as np
import argparse
import pdb
from datetime import date, datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.utils import COMMASPACE, formatdate
import smtplib


def main():
    parser = argparse.ArgumentParser(description='BronxRHIO Push')
    parser.add_argument(
        'filename', action='store', help='File provided by BronxRHIO everyday')
    args = parser.parse_args()
    conn_somos = create_engine(
        'postgresql+psycopg2://etluser:jobs12Etl1!@edw-01.c0jl6w6zborh.us-east-1.redshift.amazonaws.com:5439/dev'
    )
    conn_arcadia = pyodbc.connect(
        "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
    )
    filepath = '/home/etl/etl_home/input/RHIO_to_Rapid/' + args.filename
    temp_df = pd.read_csv(filepath, delimiter='|')
    temp_df.columns = [
        column.replace(' ', '_').lower() for column in temp_df.columns
    ]
    mrn_list = temp_df["local_mrn"].dropna()
    npi_list = temp_df["somos_provider_npi"].replace(
        'UNKNOWN', np.NaN).dropna().apply(lambda x: '{:.0f}'.format(x))
    temp_df["attending_provider_npi"].replace('UNKNOWN', np.NaN, inplace=True)
    new_mrn_list = set(mrn_list)
    new_npi_list = set(npi_list)
    arcadia_query = """ select t1.*, t2.prov_npi Assigned_pcpNPI, t2.prov_fullname Assigned_PCP ,t5.HCCRiskScore,t5.CDPSRiskscore, t5.HCCRiskTotal, t5.CDPSRiskTotal, 
    t4.pmpy from ACPPS_WAREHOUSE_PRD01.mpi.v_person_patient_demographics t1 
    join ACPPS_WAREHOUSE_PRD01.dbo.provider_master t2 
    on t2.prov_id = t1.pat_responsible_provider_id
    left join ACPPS_CLIENT_PRD01.dbo.riskStratification t4 
    on t4.personId = t1.person_id
    left join 
    (select  personID, max(HCCriskScore) HCCRiskScore, max(CDPSRiskScore) CDPSRiskscore, max( HCCRiskTotal) HCCRiskTotal, max(CDPSRiskTotal) CDPSRiskTotal  from 
    (select personId, 
    case when riskAlgorithm = 'HCC' then riskScore else NULL end as HCCRiskScore, 
    case when riskAlgorithm = 'CDPS' then riskSCore else NULL end as CDPSRiskscore,
    case when riskAlgorithm = 'HCC' then risktotal else null end as HCCRiskTotal,  
    case when riskAlgorithm = 'CDPS' then risktotal else null end as CDPSRiskTotal
    from ACPPS_CLIENT_PRD01.dbo.personRisk 
    where condition = 'Demographics'
    ) a
    group by personId) t5
    on t5.personId = t1.person_id
    where t1.pat_medical_record_number in ({})
    and t2.prov_npi in ({}); """.format(
        str(new_mrn_list)[5:-2],
        str(new_npi_list)[5:-2])
    arcadia_df = pd.read_sql(arcadia_query, conn_arcadia)
    new_df = pd.merge(
        temp_df,
        arcadia_df,
        how='left',
        left_on=['local_mrn', 'somos_provider_npi'],
        right_on=['pat_medical_record_number', 'Assigned_pcpNPI'])
    final_df = new_df[[
        "patient_class", "master_patient_id", "local_mrn",
        "patient_first_name", "patient_last_name", "patient_dob",
        "patient_sex", "patient_phone", "somos_practice_name",
        "somos_provider_name", "somos_provider_npi", "admit_facility",
        "admit_facility_location", "encounter_id", "attending_provider_name",
        "attending_provider_npi", "medicaid_plan", "medicaid_id",
        "admit_datetime", "discharge_datetime", "discharge_disposition",
        "days_since_discharge", "diagnosis_type", "diagnosis_code",
        "diagnosis_qualifier", "diagnosis_description",
        "count_of_ip_visits_in_last_1_year",
        "count_of_er_visits_in_last_1_year", "pat_phone_1", "pat_phone_2",
        "pat_email_address", "pat_address_1", "pat_address_2", "pat_city",
        "pat_state", "pat_zip", "pat_race", "pat_ethnicity", "pat_language",
        "pat_sex", "pat_date_of_birth", "Assigned_pcpNPI", "Assigned_PCP",
        "HCCRiskScore", "CDPSRiskscore", "HCCRiskTotal", "CDPSRiskTotal",
        "pmpy"
    ]]
    sql_df = final_df
    delete_query = "delete from bronx_rhio_enriched_cen where filename = \'{}\';"
    cursor = conn_somos.execute(delete_query.format(args.filename))
    cursor.close()
    for_date_list = args.filename.split('_')[-1].split('.')
    for_date = "{}{}{}".format(for_date_list[2], for_date_list[0],
                               for_date_list[1])
    sql_df['filename'] = args.filename
    sql_df['for_date'] = for_date
    sql_df['added_tz'] = datetime.now()
    sql_df.to_sql(
        con=conn_somos,
        name='bronx_rhio_enriched_cen',
        index=False,
        if_exists='append')
    excel_path = '/home/etl/etl_home/input/RHIO_to_Rapid_Excel/' + args.filename[:
                                                                                 -4] + '.xlsx'
    #pdb.set_trace()
    final_df.to_excel(excel_path)
    #email_report(excel_path)


def email_report(excel_path):
    to_addr = [
        "jdionisio@somoscommunitycare.org", "mkordit@somoscommunitycare.org",
        "nmitek@somoscommunitycare.org",
        "ssundararaman@somoscommunitycare.org", "dsanz@somoscommunitycare.org"
    ]
    smtp_user = "acpscanner@optimusha.com"
    smtp_pwd = "Optimum@2018"
    smtp_server = smtplib.SMTP("west.exch031.serverdata.net", 587)
    smtp_server.ehlo()
    smtp_server.starttls()
    smtp_server.ehlo
    smtp_server.login(smtp_user, smtp_pwd)
    msg = MIMEMultipart()
    msg["From"] = "etl@optimusha.com"
    msg["To"] = COMMASPACE.join(to_addr)
    msg["Date"] = str(date.today())
    msg["Subject"] = "(Testing)Bronx RHIO daily Report for : " + str(
        date.today())
    msg.attach(MIMEText("Test email"))
    with open(excel_path, "r") as fil:
        part = MIMEApplication(
            fil.read(), Name="Bronx_RHIO_Enhanced_Report.xls")
    part[
        "Content-Disposition"] = "attachment;filename=Bronx_RHIO_Enhanced_Report.xls"
    msg.attach(part)
    smtp_server.sendmail("etl@optimusha.com", to_addr, msg.as_string())
    smtp_server.close()


if __name__ == '__main__':
    main()
