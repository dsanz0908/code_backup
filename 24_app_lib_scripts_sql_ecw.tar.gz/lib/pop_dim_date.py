import datetime
import pyodbc
conn=pyodbc.connect(dsn="somos_redshift_1")

def main():
	query="""
	insert into DIM_DATE ( the_date,day_of_week,day_of_week_name,day_of_year,week_of_year,
                month,month_name,quarter,quarter_name,year)
	SELECT TRUNC(cast('{0}' as date)), datepart(dow,cast('{0}' as date)) as day_of_week, 
    	case  when datepart(dow,cast('{0}' as date)) = 1 then 'MON'
          when datepart(dow,cast('{0}' as date)) = 2 then 'TUE'
          when datepart(dow,cast('{0}' as date)) = 3 then 'WED'
          when datepart(dow,cast('{0}' as date)) = 4 then 'THU'
          when datepart(dow,cast('{0}' as date)) = 5 then 'FRI'
          when datepart(dow,cast('{0}' as date)) = 6 then 'SAT'
          when datepart(dow,cast('{0}' as date)) = 0 then 'SUN' END AS DAY_OF_WEEK_NAME,
     	datepart(doy,cast('{0}' as date)) as day_of_year,
     	datepart(w,cast('{0}' as date)) as week_of_year,
     	datepart(mon,cast('{0}' as date)) as month,
     	case when datepart(mon,cast('{0}' as date)) = 1 then 'JAN'
            when datepart(mon,cast('{0}' as date)) = 2 then 'FEB'
            when datepart(mon,cast('{0}' as date)) = 3 then 'MAR'
            when datepart(mon,cast('{0}' as date)) = 4 then 'APR'
            when datepart(mon,cast('{0}' as date)) = 5 then 'MAY'
            when datepart(mon,cast('{0}' as date)) = 6 then 'JUN'
            when datepart(mon,cast('{0}' as date)) = 7 then 'JUL'
            when datepart(mon,cast('{0}' as date)) = 8 then 'AUG'
            when datepart(mon,cast('{0}' as date)) = 9 then 'SEP'
            when datepart(mon,cast('{0}' as date)) = 10 then 'OCT'
            when datepart(mon,cast('{0}' as date)) = 11 then 'NOV'
            when datepart(mon,cast('{0}' as date)) = 12 then 'DEC' END MONTH_NAME,
    	datepart(qtr,cast('{0}' as date)) as quarter,
     	'Q' || datepart(qtr,cast('{0}' as date)) as quarter_name,
    	datepart(year,cast('{0}' as date)) as year
	"""
	start_date = datetime.datetime.strptime("20100101",'%Y%m%d')
	end_date = datetime.datetime.strptime("20201231",'%Y%m%d')
	while start_date <= end_date:
    		conn.execute(query.format(datetime.datetime.strftime(start_date,'%Y%m%d')))
    		start_date = start_date + datetime.timedelta(days=1)
	conn.commit()
	conn.close()   

if __name__ == '__main__':
	main()
