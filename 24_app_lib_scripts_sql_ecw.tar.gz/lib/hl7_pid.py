from datetime import datetime
import pyodbc
from hl7apy.core import Message, Segment, Field


def get_hl7_encounters(encounters):
    for i, encounter in enumerate(encounters[0]):
        print i, encounter
    for encounter in encounters:
        encounter_message = get_message(encounter)
        encounter_event = get_event(encounter)
        encounter_patient_id = get_patient_id(encounter)
        encounter_patient_visit_1 = get_patient_visit_1(encounter)
        print encounter_message.to_er7()
        print encounter_event.to_er7()
        print encounter_patient_id.to_er7()
        print encounter_patient_visit_1.to_er7()


def get_message(enc):
    message = Message()
    message.msh.msh_1 = '|'
    message.msh.msh_2 = '^~\&'
    message.msh.msh_3 = enc[143] if enc[143] else 'eClinical Works'
    message.msh.msh_4 = 'SOMOS'
    message.msh.msh_9 = 'ADT^A08'
    message.msh.msh_10 = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
    message.msh.msh_11 = 'T'
    message.msh.msh_12 = '2.5'
    return message


def get_event(enc):
    event = Segment("EVN")
    event.evn_1 = 'A08'
    event.evn_2 = enc[99].strftime("%Y%m%d%H%M%S")
    return event


def get_patient_id(enc):
    patient_id = Segment("PID")
    mrn = Field("PID_3")
    mrn.pid_3_1 = 'MPI_PLACEHOLDER'  #enc[104]
    mrn.pid_3_4 = 'SOMOS'
    mrn.pid_3_5 = 'MPI'
    patient_id.add(mrn)
    mrn2 = Field("PID_3")
    mrn2.pid_3_1 = enc[104]
    mrn2.pid_3_4 = enc[143] if enc[143] else 'eClinical Works'
    mrn2.pid_3_5 = 'MRN'
    patient_id.add(mrn2)
    pid_5 = Field("PID_5")
    pid_5.pid_5_1 = enc[66]
    pid_5.pid_5_2 = enc[67]
    pid_5.pid_5_3 = xstr(enc[68])
    patient_id.add(pid_5)
    patient_id.pid_7 = enc[86].strftime('%Y%m%d')
    patient_id.pid_8 = enc[87]
    pid_10 = Field("PID_10")
    pid_10.pid_10_1 = enc[105]
    pid_10.pid_10_3 = enc[80]
    pid_10.pid_10_4 = enc[82]
    pid_10.pid_10_5 = enc[83]
    patient_id.add(pid_10)
    patient_id.pid_24 = 'N'
    return patient_id


def get_patient_visit_1(enc):
    patient_visit_1 = Segment("PV1")
    patient_visit_1.pv1_1 = '1'
    return patient_visit_1


def xstr(s):
    return '' if s is None else str(s)


if __name__ == '__main__':
    CONNECTION_ARCADIA = pyodbc.connect(
        "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
    )
    PATIENTS_QUERY = """
    SELECT TOP 10 * 
    FROM   t_encounter AS a 
	   JOIN t_patient AS b 
	     ON enc_patient_id = pat_id 
	   LEFT JOIN site_master AS c 
		  ON enc_site_id = site_id 
    WHERE  Cast(enc_updated_timestamp AS DATE) = (SELECT Max(Cast(enc_updated_timestamp AS DATE)) 
						  FROM   t_encounter) 
    """
    ARCADIA_CURSOR = CONNECTION_ARCADIA.execute(PATIENTS_QUERY)
    PATIENTS = ARCADIA_CURSOR.fetchall()
    CONNECTION_ARCADIA.close()
    get_hl7_encounters(PATIENTS)
