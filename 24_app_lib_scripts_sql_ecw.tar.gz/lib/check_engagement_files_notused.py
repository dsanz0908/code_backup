# coding: utf-8
import boto3
import datetime
import pytz
import sys
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
for_files={}
def main():
	for_dt = sys.argv[1]
	prev_dt = datetime.datetime.strftime(datetime.datetime.strptime(for_dt,"%Y%m%d") - datetime.timedelta(days=1),"%Y%m%d")
	conn=pyodbc.connect(dsn="somos_redshift_1")
	new_cnt=getNewCount(prev_dt)
	success,fail=getDBCount(for_dt,conn)
	dbdetails= getDBDetails(for_dt,conn)
	table=processResults(dbdetails)
	#print(new_cnt,success,fail)
	email_report(success,fail,new_cnt,for_dt,table)

def getNewCount(process_date):
 	utc=pytz.UTC
 	session = boto3.session.Session()
 	s3 = session.resource('s3')
 	bucket = s3.Bucket("acp-data")
	f_prefix="Engagement_Reports/Engagement_Files"
	new_cnt=0
 	for obj in bucket.objects.filter(Prefix=f_prefix.decode(encoding="UTF-8")):
 		try:
			if datetime.datetime.strftime(obj.last_modified,"%Y%m%d")  >= process_date:
				if obj.key in for_files.keys():
					for_files[obj.key].append(1) 
				else: 
					for_files[obj.key] = [1]
				new_cnt = new_cnt + 1	
		except Exception as e:
			a=str(e)
	print(process_date,new_cnt)
	return new_cnt
def getDBCount(process_date,conn):
	query= """
	select sum(success) as success,sum(fail) as fail from (
	select count(*) as success, 0 as fail from etl_new.success_new where for_dt = '{0}'
	union
	select 0, count(*) from etl_new.fail_new where for_dt = '{0}' ) a """
	cur=conn.execute(query.format(process_date))
	res=cur.fetchall()
	cur.close()
	return res[0]
def getDBDetails(process_date,conn):
	query="""
	select s3_key,1 as success, 0 as fail from etl_new.success_new where for_dt = '{0}'
	union
	select s3_key,0 as success, 1 as fail from etl_new.fail_new where for_dt = '{0}'
	"""
	cur=conn.execute(query.format(process_date))
	res=cur.fetchall()
	cur.close()
	return res
def  processResults(dbdetails):
	if len(dbdetails) == 0:
		return None
	for row in dbdetails:
		if row[0] in for_files.keys():
			for_files[row[0]].append(1) if row[1] == 1 else for_files[row[0]].append(0)
			for_files[row[0]].append(1) if row[2] == 1 else for_files[row[0]].append(0)
	f=open("/home/etl/etl_home/Reports/EngagementReport.html","w")
	h=HTML()
	tbl=h.table(style='font-family:Arial;font-size:70%')
	r=tbl.tr(style="background-color:#AEB6BF")
	r.td("FILE NAME")
        r.td("Sucess Count")
        r.td("Fail Count")
        r.td("Not Processed")
	for file in for_files.keys():
		bgcolor= "background-color:#117864" if len(for_files[file]) == 3 and for_files[file][1] == 1 else "background-color:#F7DC6F"
		r=tbl.tr(style=bgcolor)
		r.td(file)
		if len(for_files[file]) == 3:
			r.td(str(for_files[file][1]))
			r.td(str(for_files[file][2]))
			r.td("0")
		else:
			r.td("0")
			r.td("0")
			r.td("1")
	f.write(str(tbl))
	f.close()
	return tbl
def email_report(success,fail,new,for_dt,table):
	to_addr="ssundararaman@somoscommunitycare.org"
	smtp_user="acpscanner@optimusha.com"
	smtp_pwd="Optimum@2018"
	smtp_server=smtplib.SMTP("west.exch031.serverdata.net",587)
	smtp_server.ehlo()
	smtp_server.starttls()
	smtp_server.ehlo
	smtp_server.login(smtp_user,smtp_pwd)
	#header = "To:" + to_addr + "\n" + "From: " + "etluser@optimusha.net \n" + "Subject: Engagement Satus Report for : " + for_dt + "\n"
	#msg=header + "\n Success Count : " + str(success) +  "\n Failure Count: " + str(fail) + "\n New Count: " + str(new) 
	msg=email.message.Message()
	msg["Subject"]= "Subject: Engagement Satus Report for : " + for_dt + " Total Success Count: " + str(success) + " Total Fail Count: " + str(fail) + " Total Count: " + str(new)
	msg["From"]="etluser@optimusha.net"
	msg["To"]=to_addr
	msg.add_header("Content-Type","text/html")
	#msg.set_payload(str(table))
	msg=MIMEText(str(table))
	#smtp_server.sendmail("etluser@optimusha.com",to_addr,msg)
	smtp_server.sendmail("etluser@optimusha.com",to_addr,msg.as_string())
	smtp_server.close()
if __name__ == '__main__':
 main()
