# -*- coding: utf-8 -*-

from datetime import datetime
import pyodbc
from hl7apy.core import Message, Segment, Field


def get_hl7_encounters(encounters):
    final_string = ''
    for i, encounter in enumerate(encounters[0]):
        pass #print i, encounter
    for encounter_index, encounter in enumerate(encounters):
        print (encounter_index*100)/len(encounters)
        encounter_message = get_message(encounter, encounter_index)
        encounter_event = get_event(encounter)
        encounter_patient_id = get_patient_id(encounter)
        encounter_patient_visit_1 = get_patient_visit_1(encounter)
        encounter_patient_visit_2 = get_patient_visit_2(encounter)
        encounter_insurance_1 = get_insurance_1(encounter)
        final_string += encounter_message.to_er7() + '\n'
        final_string += encounter_event.to_er7() + '\n'
        final_string += encounter_patient_id.to_er7() + '\n'
        final_string += encounter_patient_visit_1.to_er7() + '\n'
        epv2 = encounter_patient_visit_2
        if epv2:
            final_string += epv2.to_er7() + '\n'
        final_string += get_observation(encounter[0])
        final_string += get_diagnosis_1(encounter[0])
        final_string += encounter_insurance_1.to_er7() + '\n'
    with open('20190523_hl7_encounters_test.txt', 'w') as hl7_test_file:
        hl7_test_file.write(final_string)


def get_message(enc, enc_id):
    message = Message()
    message.msh.msh_1 = '|'
    message.msh.msh_2 = '^~\&'
    message.msh.msh_3 = enc[143] if enc[143] else 'eClinicalWorks'
    message.msh.msh_4 = 'SOMOS'
    message.msh.msh_5 = 'HealthShare'
    message.msh.msh_6 = 'Healthfirst'
    message.msh.msh_7 = datetime.now().strftime('%Y%m%d%H%M%S')
    message.msh.msh_9 = 'ADT^A08'
    message.msh.msh_10 = "{}{}".format(datetime.now().strftime('%Y%m%d%H%M%S'),
                                       enc_id + 1)
    message.msh.msh_11 = 'T'
    message.msh.msh_12 = '2.5'
    return message


def get_event(enc):
    event = Segment("EVN")
    event.evn_1 = 'A08'
    event.evn_2 = enc[26].strftime("%Y%m%d%H%M%S")
    return event


def get_patient_id(enc):
    patient_id = Segment("PID")
    patient_id.pid_1 = '1'
    mpi = Field("PID_3")
    mpi.pid_3_1 = xstr(enc[4])
    mpi.pid_3_4 = 'SOMOS'
    mpi.pid_3_5 = 'MPI'
    patient_id.add(mpi)
    mrn = Field("PID_3")
    mrn.pid_3_1 = xstr(enc[104])
    mrn.pid_3_4 = enc[143] if enc[143] else 'eClinicalWorks'
    mrn.pid_3_5 = 'MRN'
    patient_id.add(mrn)
    hf_num = Field("PID_3")
    hf_num.pid_3_1 = xstr(enc[201])
    hf_num.pid_3_4 = 'HealthFirst'
    hf_num.pid_3_5 = xstr(enc[201])
    patient_id.add(hf_num)
    pid_5 = Field("PID_5")
    pid_5.pid_5_1 = enc[66]
    pid_5.pid_5_2 = enc[67]
    pid_5.pid_5_3 = xstr(enc[68])
    patient_id.add(pid_5)
    patient_id.pid_7 = enc[86].strftime('%Y%m%d')
    patient_id.pid_8 = enc[87]
    patient_id.pid_10 = xstr(enc[69])
    pid_11 = Field("PID_11")
    pid_11.pid_11_1 = xstr(enc[105])
    pid_11.pid_11_3 = enc[80]
    pid_11.pid_11_4 = enc[82]
    pid_11.pid_11_5 = enc[83]
    patient_id.add(pid_11)
    patient_id.pid_13 = xstr(enc[84])
    patient_id.pid_15 = xstr(enc[73])
    patient_id.pid_19 = xstr(enc[88])
    patient_id.pid_21 = enc[201] if 'natural' in xstr(enc[214]).lower() else ''
    patient_id.pid_22 = xstr(enc[70])
    return patient_id


def get_patient_visit_1(enc):
    patient_visit_1 = Segment("PV1")
    patient_visit_1.pv1_1 = '1'
    patient_visit_1.pv1_2 = 'O'
    pv1_3 = Field("PV1_3")
    pv1_3.pv1_3_1 = 'OP'
    pv1_3.pv1_3_4 = enc[134]
    patient_visit_1.add(pv1_3)
    patient_visit_1.pv1_4 = 'ROUTINE'
    pv1_7 = Field("PV1_7")
    pv1_7.pv1_7_2 = xstr(enc[165])
    pv1_7.pv1_7_3 = xstr(enc[166])
    pv1_7.pv1_7_4 = xstr(enc[167])
    patient_visit_1.add(pv1_7)
    patient_visit_1.pv1_10 = xstr(enc[171])
    #patient_visit_1.pv1_14 = '9'
    pv1_17 = Field("PV1_17")
    pv1_17.pv1_17_2 = xstr(enc[217])
    pv1_17.pv1_17_3 = xstr(enc[216])
    pv1_17.pv1_17_4 = xstr(enc[218])
    patient_visit_1.add(pv1_17)
    patient_visit_1.pv1_18 = 'O'
    patient_visit_1.pv1_19 = enc[0]
    patient_visit_1.pv1_36 = 'Unknown'
    patient_visit_1.pv1_37 = 'Unknown'
    patient_visit_1.pv1_44 = xstr(
        enc[4].strftime("%Y%m%d%H%M%S")) if enc[4] else ''
    patient_visit_1.pv1_45 = xstr(
        enc[17].strftime("%Y%m%d%H%M%S")) if enc[17] else ''
    return patient_visit_1


def get_patient_visit_2(enc):
    if enc[9] or enc[16]:
        patient_visit_2 = Segment("PV2")
        patient_visit_2.pv2_3 = xstr(enc[9])[:250]
        patient_visit_2.pv2_12 = xstr(enc[16])[:250]
        return patient_visit_2
    else:
        return


def get_observation(enc_id):
    connection_arcadia = pyodbc.connect(
        "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
    )
    observation_query = """
    SELECT DISTINCT * 
    FROM   (SELECT 'HEIGHT'           AS identifier, 
		   vitals_height      AS value, 
		   vitals_height_unit AS unit, 
		   vitals_date        AS d 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION 
	    SELECT 'WEIGHT', 
		   vitals_weight, 
		   vitals_weight_unit, 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION 
	    SELECT 'BMI', 
		   vitals_bmi, 
		   'kg/m2', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION 
	    SELECT 'SYSTOLIC', 
		   vitals_systolic, 
		   'mmHg', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION 
	    SELECT 'DIASTOLIC', 
		   vitals_diastolic, 
		   'mmHg', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION 
	    SELECT 'TEMPERATURE', 
		   vitals_temperature, 
		   vitals_temperature_units, 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION 
	    SELECT 'HEART RATE', 
		   vitals_heart_rate, 
		   'bmp', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION 
	    SELECT 'SP02', 
		   vitals_spo2, 
		   '%', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}') AS a 
    WHERE  value IS NOT NULL 
    ORDER  BY d, 
	      identifier 
    """.format(enc_id)
    arcadia_cursor = connection_arcadia.execute(observation_query)
    observations = arcadia_cursor.fetchall()
    arcadia_cursor.close()
    temp_string = ''
    for observation_id, observation in enumerate(observations):
        obx = Segment("OBX")
        obx.obx_1 = str(observation_id + 1)
        obx.obx_3 = observation[0]
        obx.obx_5 = str(observation[1])
        obx.obx_6 = observation[2]
        obx.obx_11 = 'F'
        obx.obx_14 = observation[3].strftime("%Y%m%d%H%M%S")
        temp_string += obx.to_er7() + '\n'
    return temp_string


def get_diagnosis_1(enc_id):
    connection_arcadia = pyodbc.connect(
        "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
    )
    diagnosis_query = """
    SELECT DISTINCT Row_number() 
		      OVER ( 
			ORDER BY primary_diagnosis_ind DESC), 
		    icd10_code, 
		    description, 
		    assessment_date 
    FROM   t_assessment AS a 
	   LEFT JOIN lookup.code AS b 
	     ON icd10_code = code_value 
    WHERE  encounter_id = '{}' 
	   AND code_set = 'ICD10' 
    """.format(enc_id)
    arcadia_cursor = connection_arcadia.execute(diagnosis_query)
    diagnoses = arcadia_cursor.fetchall()
    arcadia_cursor.close()
    temp_string = ''
    for diagnosis in diagnoses:
        diagnosis_1 = Segment("DG1")
        diagnosis_1.dg1_1 = str(diagnosis[0])
        diagnosis_1.dg1_2 = 'ICD-10'
        diagnosis_1.dg1_3 = xstr(diagnosis[1])
        diagnosis_1.dg1_4 = diagnosis[2].rstrip()
        diagnosis_1.dg1_5 = diagnosis[3].strftime("%Y%m%d%H%M%S")
        diagnosis_1.dg1_6 = 'Primary' if diagnosis[0] == 1 else 'Other'
        temp_string += diagnosis_1.to_er7() + '\n'
    return temp_string


def get_insurance_1(enc):
    insurance_1 = Segment("IN1")
    insurance_1.in1_1 = '1'
    insurance_1.in1_2 = 'Healthfirst'
    insurance_1.in1_3 = 'Healthfirst'
    insurance_1.in1_4 = 'HealthFirst'
    insurance_1.in1_36 = xstr(enc[201])
    return insurance_1


def xstr(s):
    return '' if s is None or s == 'Needs Update' else str(s)


if __name__ == '__main__':
    CONNECTION_ARCADIA = pyodbc.connect(
        "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
    )
    print 'connected'
    PATIENTS_QUERY = """
    SELECT * 
    FROM   (SELECT *, 
		   Row_number() 
		     OVER ( 
		       partition BY enc_id 
		       ORDER BY policy_nbr DESC) AS rn 
	    FROM   t_encounter AS a 
		   INNER JOIN t_patient AS b 
			   ON enc_patient_id = pat_id 
		   LEFT JOIN site_master AS c 
			  ON enc_site_id = site_id 
		   LEFT JOIN provider_master AS d 
			  ON enc_rendering_provider_id = prov_id 
		   INNER JOIN t_payer AS e 
			   ON enc_patient_id = patient_id 
		   LEFT JOIN (SELECT prov_id          AS responsible_prov_id, 
				     prov_first_name  AS responsible_prov_first_name, 
				     prov_last_name   AS responsible_prov_last_name, 
				     prov_middle_name AS responsible_prov_middle_name 
			      FROM   provider_master) AS g 
			  ON pat_responsible_provider_id = responsible_prov_id 
	    WHERE  Datediff(day, enc_timestamp, Getdate()) < 7 
		   AND enc_timestamp < Getdate() 
		   AND Datediff(day, enc_modify_timestamp, Getdate()) = 4 
		   AND ( payer_name_unscrubbed LIKE '%health first%' 
			  OR payer_name_unscrubbed LIKE '%healthfirst%' ) 
		   AND enc_delete_ind = 'N' 
		   AND payer_delete_ind = 'N' 
		   AND ( policy_end_dt IS NULL 
			  OR policy_end_dt > enc_timestamp )) AS f 
    WHERE  rn = 1 
    """
    ARCADIA_CURSOR = CONNECTION_ARCADIA.execute(PATIENTS_QUERY)
    PATIENTS = ARCADIA_CURSOR.fetchall()
    CONNECTION_ARCADIA.close()
    print 'query done'
    get_hl7_encounters(PATIENTS)
