# -*- coding: utf-8 -*-

from datetime import datetime
import pyodbc
import socket
from hl7apy.core import Message, Segment, Field


CONNECTION_ARCADIA = pyodbc.connect(
    "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
)

HOST = '40.143.139.138'
PORT = 4014

def get_hl7_encounters(encounters):
    for i, encounter in enumerate(encounters[0]):
        pass #print i, encounter
    ack = ''
    HF_SOCKET = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    HF_SOCKET.connect((HOST,PORT))
    for encounter_index, encounter in enumerate(encounters):
        final_string = ''
        encounter_message = get_message(encounter, encounter_index)
        encounter_event = get_event(encounter)
        encounter_patient_id = get_patient_id(encounter)
        encounter_patient_visit_1 = get_patient_visit_1(encounter)
        encounter_patient_visit_2 = get_patient_visit_2(encounter)
        encounter_insurance_1 = get_insurance_1(encounter)
        final_string += chr(11)
        final_string += encounter_message.to_er7()  + chr(13)
        final_string += encounter_event.to_er7()+ chr(13)
        final_string += encounter_patient_id.to_er7() + chr(13)
        final_string += encounter_patient_visit_1.to_er7() + chr(13)
        epv2 = encounter_patient_visit_2
        if epv2:
            final_string += epv2.to_er7() + chr(13)
        final_string += get_observation(encounter[36])
        final_string += get_diagnosis_1(encounter[36])
        final_string += encounter_insurance_1.to_er7() + chr(13)
        final_string += chr(28)
        final_string += chr(13)
        with open('/data/output/20190716_healthfirst_hl7_validation_test.txt', 'a') as hl7_validation:
            hl7_validation.write(final_string)
        HF_SOCKET.send(final_string)
	temp_ack = HF_SOCKET.recv(131072)
        ack += temp_ack
    HF_SOCKET.close()

    with open('/data/output/{}_healthfirst_hl7_ack.txt'.format(datetime.now().strftime("%Y%m%d%H%M")), 'w') as hl7_test_file:
        hl7_test_file.write(ack)


def get_message(enc, enc_id):
    message = Message()
    message.msh.msh_1 = '|'
    message.msh.msh_2 = '^~\&'
    message.msh.msh_3 = 'SOMOS'
    message.msh.msh_4 = 'SOMOS'
    message.msh.msh_5 = 'HealthShare'
    message.msh.msh_6 = 'Healthfirst'
    message.msh.msh_7 = datetime.now().strftime('%Y%m%d%H%M%S')
    message.msh.msh_9 = 'ADT^A08'
    message.msh.msh_10 = "{}{}".format(datetime.now().strftime('%Y%m%d%H%M%S'),
                                       enc_id + 1)
    message.msh.msh_11 = 'T'
    message.msh.msh_12 = '2.5'
    return message


def get_event(enc):
    event = Segment("EVN")
    event.evn_1 = 'A08'
    event.evn_2 = enc[0].strftime("%Y%m%d%H%M%S")
    return event


def get_patient_id(enc):
    patient_id = Segment("PID")
    patient_id.pid_1 = '1'
    mpi = Field("PID_3")
    mpi.pid_3_1 = "84751" #"{}-{}".format(xstr(enc[2]), xstr(enc[34]))
    mpi.pid_3_4 = 'SOMOS'
    mpi.pid_3_5 = 'MPI'
    patient_id.add(mpi)
    mrn = Field("PID_3")
    mrn.pid_3_1 = "84751-1922565241" #xstr(enc[1])
    mrn.pid_3_4 = enc[3] if enc[3] else 'eClinicalWorks'
    mrn.pid_3_5 = 'MRN'
    patient_id.add(mrn)
    pid_5 = Field("PID_5")
    pid_5.pid_5_1 = 'EGEONU' #'NEWYORK' #enc[4]
    pid_5.pid_5_2 = 'MILAGRO' #'NAME' #enc[5]
    pid_5.pid_5_3 = 'O' #xstr(enc[6])
    patient_id.add(pid_5)
    patient_id.pid_7 = '19880615' #"00000000" #enc[7].strftime('%Y%m%d')
    patient_id.pid_8 = 'Male' #enc[8]
    patient_id.pid_10 = xstr(enc[9])
    pid_11 = Field("PID_11")
    pid_11.pid_11_1 = '357 MARCUS GARVEY BLVD' #'000 EAST 000TH STREET' #xstr(enc[10])
    pid_11.pid_11_2 = 'APT 309' # TEST TEST TEST
    pid_11.pid_11_3 = 'BROOKLYN' #enc[11]
    pid_11.pid_11_4 = 'NY' #enc[12]
    pid_11.pid_11_5 = '11221' #enc[13]
    patient_id.add(pid_11)
    patient_id.pid_13 = '000-000-0000' #xstr(enc[14])
    patient_id.pid_15 = xstr(enc[15])
    patient_id.pid_19 = '000-00-0000' #xstr(enc[16])
    pid_21 = Field("PID_21")
    pid_21.pid_21_1 = 'NEWYORK' #enc[17]
    pid_21.pid_21_2 = 'NAME' #enc[18]
    pid_21.pid_21_3 = xstr(enc[19])
    patient_id.add(pid_21)
    patient_id.pid_22 = xstr(enc[20])
    return patient_id


def get_patient_visit_1(enc):
    patient_visit_1 = Segment("PV1")
    patient_visit_1.pv1_1 = '1'
    patient_visit_1.pv1_2 = 'O'
    pv1_3 = Field("PV1_3")
    pv1_3.pv1_3_1 = 'OP'
    pv1_3.pv1_3_4 = enc[21]
    patient_visit_1.add(pv1_3)
    patient_visit_1.pv1_4 = 'ROUTINE'
    pv1_7 = Field("PV1_7")
    pv1_7.pv1_7_2 = 'NEW' #xstr(enc[22])
    pv1_7.pv1_7_3 = 'YORK' #xstr(enc[23])
    pv1_7.pv1_7_4 = xstr(enc[24])
    patient_visit_1.add(pv1_7)
    patient_visit_1.pv1_10 = xstr(enc[25])
    patient_visit_1.pv1_14 = 'ROUTINE'
    pv1_17 = Field("PV1_17")
    pv1_17.pv1_17_2 = 'NEW' #xstr(enc[26])
    pv1_17.pv1_17_3 = 'YORK' #xstr(enc[27])
    pv1_17.pv1_17_4 = xstr(enc[28])
    patient_visit_1.add(pv1_17)
    patient_visit_1.pv1_18 = 'O'
    patient_visit_1.pv1_19 = '8541122135' #'00000-00' #"{}-{}".format(enc[29],enc[35])
    patient_visit_1.pv1_44 = '20190701084500' #xstr(
        #enc[0].strftime("%Y%m%d%H%M%S")) if enc[0] else ''
    if enc[30]:
        patient_visit_1.pv1_45 = xstr(enc[30].strftime("%Y%m%d%H%M%S"))
        patient_visit_1.pv1_36 = 'Unknown'
        patient_visit_1.pv1_37 = 'Unknown'
    else:
        patient_visit_1.pv1_45 = ''
    patient_visit_1.pv1_45 = ''
    return patient_visit_1


def get_patient_visit_2(enc):
    if enc[31] or enc[32]:
        patient_visit_2 = Segment("PV2")
        patient_visit_2.pv2_3 = xstr(enc[31])[:250]
        patient_visit_2.pv2_12 = xstr(enc[32])[:250]
        return patient_visit_2
    else:
        return


def get_observation(enc_id):
    observation_query = """
    SELECT DISTINCT * 
    FROM   (SELECT 'HEIGHT'           AS identifier, 
		   vitals_height      AS value, 
		   vitals_height_unit AS unit, 
		   vitals_date        AS d 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION ALL 
	    SELECT 'WEIGHT', 
		   vitals_weight, 
		   vitals_weight_unit, 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION ALL 
	    SELECT 'BMI', 
		   vitals_bmi, 
		   'kg/m2', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION ALL 
	    SELECT 'SYSTOLIC', 
		   vitals_systolic, 
		   'mmHg', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION ALL 
	    SELECT 'DIASTOLIC', 
		   vitals_diastolic, 
		   'mmHg', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION ALL 
	    SELECT 'TEMPERATURE', 
		   vitals_temperature, 
		   vitals_temperature_units, 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION ALL 
	    SELECT 'HEART RATE', 
		   vitals_heart_rate, 
		   'bmp', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}' 
	    UNION ALL 
	    SELECT 'SP02', 
		   vitals_spo2, 
		   '%', 
		   vitals_date 
	    FROM   t_vitals 
	    WHERE  vitals_enc_id = '{0}') AS a 
    WHERE  value IS NOT NULL 
    ORDER  BY d, 
	      identifier 
    """.format(enc_id)
    arcadia_cursor = CONNECTION_ARCADIA.execute(observation_query)
    observations = arcadia_cursor.fetchall()
    arcadia_cursor.close()
    temp_string = ''
    for observation_id, observation in enumerate(observations):
        obx = Segment("OBX")
        obx.obx_1 = str(observation_id + 1)
        obx.obx_3 = observation[0]
        obx.obx_5 = str(observation[1])
        obx.obx_6 = observation[2]
        obx.obx_11 = 'F'
        obx.obx_14 = observation[3].strftime("%Y%m%d%H%M%S")
        temp_string += obx.to_er7() + chr(13)
    return temp_string


def get_diagnosis_1(enc_id):
    diagnosis_query = """
    SELECT DISTINCT Row_number() 
		      OVER ( 
			ORDER BY primary_diagnosis_ind DESC), 
		    icd10_code, 
		    description, 
		    assessment_date 
    FROM   t_assessment AS a 
	   LEFT JOIN lookup.code AS b 
	     ON icd10_code = code_value 
    WHERE  encounter_id = '{}' 
	   AND code_set = 'ICD10' 
    """.format(enc_id)
    arcadia_cursor = CONNECTION_ARCADIA.execute(diagnosis_query)
    diagnoses = arcadia_cursor.fetchall()
    arcadia_cursor.close()
    temp_string = ''
    for diagnosis in diagnoses:
        diagnosis_1 = Segment("DG1")
        diagnosis_1.dg1_1 = str(diagnosis[0])
        diagnosis_1.dg1_2 = 'I10'
        dg1_3 = Field("DG1_3")
        dg1_3.dg1_3_1 = xstr(diagnosis[1])
        dg1_3.dg1_3_2 = diagnosis[2].rstrip()
        diagnosis_1.add(dg1_3)
        diagnosis_1.dg1_4 = diagnosis[2].rstrip()
        diagnosis_1.dg1_5 = diagnosis[3].strftime("%Y%m%d%H%M%S")
        diagnosis_1.dg1_6 = 'Primary' if diagnosis[0] == 1 else 'Other'
        temp_string += diagnosis_1.to_er7() + chr(13)
    return temp_string


def get_insurance_1(enc):
    insurance_1 = Segment("IN1")
    insurance_1.in1_1 = '1'
    insurance_1.in1_2 = 'Healthfirst'
    insurance_1.in1_3 = 'Healthfirst'
    insurance_1.in1_4 = 'Healthfirst'
    in1_16 = Field("IN1_16")
    in1_16.in1_16_1 = 'NEWYORK' #enc[17]
    in1_16.in1_16_2 = 'NAME' #enc[18]
    in1_16.in1_16_3 = xstr(enc[19])
    insurance_1.add(in1_16)
    insurance_1.in1_18 = enc[37].strftime("%Y%m%d") if enc[37] else ''
    insurance_1.in1_36 = 'KP53972Q' #'000000000' #xstr(enc[33])
    insurance_1.in1_43 = xstr(enc[38])
    return insurance_1


def xstr(s):
    return '' if s is None or s == 'Needs Update' else str(s)


if __name__ == '__main__':
    print('connected')
    PATIENTS_QUERY = """
    WITH cte_latest_healthfirst_members 
	 AS (SELECT * 
	     FROM   (SELECT *, 
			    Rank() 
			      OVER ( 
				partition BY CASE WHEN loaded_from_file LIKE '%somos%' THEN 1 WHEN loaded_from_file LIKE '%corinthian%' THEN 2 END
				ORDER BY modify_timestamp DESC) AS plan_member_elig_rn 
		     FROM   plan_member_elig 
		     WHERE  source_id = 1002 
			    AND delete_ind = 'N') AS all_healthfirst_members 
	     WHERE  plan_member_elig_rn = 1), 
	 cte_latest_distinct_members 
	 AS (SELECT DISTINCT cte_latest_healthfirst_members.orig_member_id, 
			     first_name, 
			     middle_name, 
			     last_name, 
			     dob, 
			     sex 
	     FROM   cte_latest_healthfirst_members 
		    JOIN plan_member 
		      ON cte_latest_healthfirst_members.orig_member_id = plan_member.orig_member_id
	     WHERE  end_date = (SELECT Max(end_date) 
				FROM   cte_latest_healthfirst_members)), 
	 cte_latest_practice_encounter_date 
	 AS (SELECT enc_site_id, 
		    Cast(Max(enc_timestamp) AS DATE) AS latest_enc 
	     FROM   t_encounter 
	     WHERE  LEFT(t_encounter.enc_loaded_from_file, 10) = (SELECT Max(LEFT(enc_loaded_from_file, 10))
								  FROM   t_encounter) 
		    AND Datediff(dd, t_encounter.enc_timestamp, CONVERT(DATETIME, Replace(Substring(t_encounter.enc_loaded_from_file, 1, 10), '_', '')))
			BETWEEN 1 
			AND 2 
	     GROUP  BY enc_site_id) 
    SELECT top 1 *
    FROM   (SELECT DISTINCT t_encounter.enc_timestamp, 
			    t_patient.pat_original_id, 
			    t_patient.pat_medical_record_number, 
			    site_master.site_emr_name, 
			    t_patient.pat_last_name, 
			    t_patient.pat_first_name, 
			    t_patient.pat_middle_name, 
			    t_patient.pat_date_of_birth, 
			    t_patient.pat_sex, 
			    t_patient.pat_race, 
			    t_patient.pat_address_1, 
			    t_patient.pat_city, 
			    t_patient.pat_state, 
			    t_patient.pat_zip, 
			    t_patient.pat_phone_1, 
			    t_patient.pat_language, 
			    t_patient.pat_ssn, 
			    cte_latest_distinct_members.last_name        AS payer_last_name, 
			    cte_latest_distinct_members.first_name       AS payer_first_name, 
			    cte_latest_distinct_members.middle_name      AS payer_middle_name, 
			    t_patient.pat_ethnicity, 
			    site_master.site_center_name, 
			    provider_master.prov_last_name, 
			    provider_master.prov_first_name, 
			    provider_master.prov_middle_name, 
			    provider_master.prov_specialty_1, 
			    responsible_provider_master.prov_last_name   AS responsible_prov_last_name,
			    responsible_provider_master.prov_first_name  AS responsible_prov_first_name,
			    responsible_provider_master.prov_middle_name AS responsible_prov_middle_name,
			    t_encounter.enc_original_id, 
			    t_encounter.enc_discharge_timestamp, 
			    t_encounter.enc_type_description, 
			    t_encounter.enc_reason, 
			    t_payer.policy_nbr, 
			    responsible_provider_master.prov_npi, 
			    site_master.site_orig_site_id, 
			    t_encounter.enc_id, 
			    cte_latest_distinct_members.dob              AS payer_dob, 
			    cte_latest_distinct_members.sex              AS payer_sex, 
			    Row_number() 
			      OVER( 
				partition BY t_encounter.enc_id 
				ORDER BY t_payer.modify_timestamp DESC)  AS encounter_rn 
	    FROM   cte_latest_distinct_members 
		   INNER JOIN t_payer 
			   ON cte_latest_distinct_members.orig_member_id = t_payer.policy_nbr 
		   INNER JOIN t_encounter 
			   ON t_payer.patient_id = t_encounter.enc_patient_id 
		   INNER JOIN t_patient 
			   ON t_encounter.enc_patient_id = t_patient.pat_id 
		   LEFT JOIN site_master 
			  ON t_encounter.enc_site_id = site_master.site_id 
		   LEFT JOIN provider_master 
			  ON t_encounter.enc_rendering_provider_id = provider_master.prov_id 
		   LEFT JOIN provider_master AS responsible_provider_master 
			  ON t_patient.pat_responsible_provider_id = responsible_provider_master.prov_id
	    WHERE  EXISTS (SELECT 1 
			   FROM   cte_latest_practice_encounter_date 
			   WHERE  t_encounter.enc_site_id = enc_site_id 
				  AND Cast(enc_timestamp AS DATE) = latest_enc) 
		   AND t_encounter.enc_delete_ind = 'N' 
		   AND t_payer.payer_delete_ind = 'N' 
		   AND t_patient.pat_delete_ind = 'N' 
		   AND t_patient.pat_medical_record_number IS NOT NULL) AS final_rows 
    WHERE  encounter_rn = 1 
    ORDER  BY enc_timestamp
    """
    ARCADIA_CURSOR = CONNECTION_ARCADIA.execute(PATIENTS_QUERY)
    for column_index, column in enumerate(ARCADIA_CURSOR.description):
        pass #print column_index, column
    ENCOUNTERS = ARCADIA_CURSOR.fetchall()
    print('query done')
    get_hl7_encounters(ENCOUNTERS)
    print('sent')
    

CONNECTION_ARCADIA.close()
