# -*- coding: utf-8 -*-

from datetime import datetime
import pyodbc
from hl7apy.core import Message, Segment, Field


def get_hl7_encounters(encounters):
    for i, encounter in enumerate(encounters[0]):
        print i, encounter
    for encounter in encounters:
        encounter_message = get_message(encounter)
        encounter_event = get_event(encounter)
        encounter_patient_id = get_patient_id(encounter)
        encounter_patient_visit_1 = get_patient_visit_1(
            encounter)
        encounter_insurance_1 = get_insurance_1(encounter)
        print encounter_message.to_er7()
        print encounter_event.to_er7()
        print encounter_patient_id.to_er7()
        print encounter_patient_visit_1.to_er7()
        get_diagnosis_1(encounter[0])
        print encounter_insurance_1.to_er7()


def get_message(enc):
    message = Message()
    message.msh.msh_1 = '|'
    message.msh.msh_2 = '^~\&'
    message.msh.msh_3 = enc[143] if enc[143] else 'eClinical Works'
    message.msh.msh_4 = 'SOMOS'
    message.msh.msh_9 = 'ADT^A08'
    message.msh.msh_10 = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
    message.msh.msh_11 = 'T'
    message.msh.msh_12 = '2.5'
    return message


def get_event(enc):
    event = Segment("EVN")
    event.evn_1 = 'A08'
    event.evn_2 = enc[26].strftime("%Y%m%d%H%M%S")
    return event


def get_patient_id(enc):
    patient_id = Segment("PID")
    mpi = Field("PID_3")
    mpi.pid_3_1 = 'MPI_PLACEHOLDER'  #enc[104]
    mpi.pid_3_4 = 'SOMOS'
    mpi.pid_3_5 = 'MPI'
    patient_id.add(mpi)
    mrn = Field("PID_3")
    mrn.pid_3_1 = enc[104]
    mrn.pid_3_4 = enc[143] if enc[143] else 'eClinical Works'
    mrn.pid_3_5 = 'MRN'
    patient_id.add(mrn)
    hf_num = Field("PID_3")
    hf_num.pid_3_1 = 'HF#_PLACEHOLDER'  #enc[104]
    hf_num.pid_3_4 = 'HealthFirst'
    hf_num.pid_3_5 = 'XX'
    patient_id.add(hf_num)
    pid_5 = Field("PID_5")
    pid_5.pid_5_1 = enc[66]
    pid_5.pid_5_2 = enc[67]
    pid_5.pid_5_3 = xstr(enc[68])
    patient_id.add(pid_5)
    patient_id.pid_7 = enc[86].strftime('%Y%m%d')
    patient_id.pid_8 = enc[87]
    pid_11 = Field("PID_11")
    pid_11.pid_11_1 = enc[105]
    pid_11.pid_11_3 = enc[80]
    pid_11.pid_11_4 = enc[82]
    pid_11.pid_11_5 = enc[83]
    patient_id.add(pid_11)
    patient_id.pid_24 = 'N'
    return patient_id


def get_patient_visit_1(enc):
    patient_visit_1 = Segment("PV1")
    patient_visit_1.pv1_1 = '1'
    patient_visit_1.pv1_2 = 'O'
    pv1_3 = Field("PV1_3")
    pv1_3.pv1_3_1 = 'OP'
    pv1_3.pv1_3_4 = enc[134]
    patient_visit_1.add(pv1_3)
    patient_visit_1.pv1_4 = 'R'
    pv1_7 = Field("PV1_7")
    pv1_7.pv1_7_2 = xstr(enc[165])
    pv1_7.pv1_7_3 = xstr(enc[166])
    pv1_7.pv1_7_4 = xstr(enc[167])
    patient_visit_1.pv1_10 = 'MED'
    patient_visit_1.pv1_14 = '9'
    patient_visit_1.pv1_18 = 'OP'
    patient_visit_1.pv1_19 = enc[0]
    patient_visit_1.pv1_36 = '01'
    patient_visit_1.pv1_44 = xstr(
        enc[4].strftime("%Y%m%d%H%M%S")) if enc[4] else ''
    patient_visit_1.pv1_45 = xstr(
        enc[17].strftime("%Y%m%d%H%M%S")) if enc[17] else ''
    patient_visit_1.add(pv1_7)
    return patient_visit_1


def get_diagnosis_1(enc_id):
    connection_arcadia = pyodbc.connect(
        "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
    )
    diagnosis_query = """
    SELECT DISTINCT Row_number() 
		      OVER ( 
			ORDER BY primary_diagnosis_ind DESC), 
		    icd10_code, 
		    assessment_description, 
		    assessment_date 
    FROM   t_assessment 
    WHERE  encounter_id = '{}' 
    """.format(enc_id)
    arcadia_cursor = connection_arcadia.execute(diagnosis_query)
    diagnoses = arcadia_cursor.fetchall()
    arcadia_cursor.close()
    for diagnosis in diagnoses:
        diagnosis_1 = Segment("DG1")
        diagnosis_1.dg1_1 = str(diagnosis[0])
        diagnosis_1.dg1_2 = 'I10'
        diagnosis_1.dg1_3 = xstr(diagnosis[1])
        diagnosis_1.dg1_4 = diagnosis[2]
        diagnosis_1.dg1_5 = diagnosis[3].strftime("%Y%m%d%H%M%S")
        diagnosis_1.dg1_6 = 'F'
        print diagnosis_1.to_er7()
    return


def get_insurance_1(enc):
    insurance_1 = Segment("IN1")
    insurance_1.in1_1 = '1'
    insurance_1.in1_3 = 'HFPLAN'
    insurance_1.in1_4 = 'HealthFirst'
    insurance_1.in1_36 = 'HealthFirst_ID_PLACEHOLDER'
    return insurance_1


def xstr(s):
    return '' if s is None else str(s)


if __name__ == '__main__':
    CONNECTION_ARCADIA = pyodbc.connect(
        "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
    )
    PATIENTS_QUERY = """
    SELECT TOP 10 * 
    FROM   t_encounter AS a 
	   JOIN t_patient AS b 
	     ON enc_patient_id = pat_id 
	   LEFT JOIN site_master AS c 
		  ON enc_site_id = site_id 
	   LEFT JOIN provider_master AS d 
		  ON enc_rendering_provider_id = prov_id 
    WHERE  LEFT(enc_loaded_from_file, 10) = (SELECT Max(LEFT(enc_loaded_from_file, 10)) 
					     FROM   t_encounter) 
    """
    ARCADIA_CURSOR = CONNECTION_ARCADIA.execute(PATIENTS_QUERY)
    PATIENTS = ARCADIA_CURSOR.fetchall()
    CONNECTION_ARCADIA.close()
    print 'done'
    get_hl7_encounters(PATIENTS)
