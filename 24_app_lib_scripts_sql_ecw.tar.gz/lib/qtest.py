import pyodbc

def main():
	process_date='20190410'
	conn=pyodbc.connect(dsn="somos_redshift_1")
	query="""
        select s3_key,1 as success, 0 as fail,'' as reason from etl_new.success_new where for_dt = '{0}'
        union
        select s3_key,0 as success, 1 as fail,error as reason from etl_new.fail_new where for_dt = '{0}'
        """
        cur=conn.execute(query.format(process_date))
        res=cur.fetchall()
        cur.close()
	for row in res:
		print(row)

if __name__ == '__main__':
	main()

