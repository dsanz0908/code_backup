import datetime
import pytz
import sys
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
#from fuzzywuzzy import fuzz
f=open("/home/etl/etl_home/Reports/inventory.html","w")
header='''<head><link href="check.css" rel="stylesheet"></head><body>   <h3>MCO Inventory</h3>
        <div class="content">
        <div class="sidebar">
          <ul>
            <li><a href="ecw_status.html">ECW Status</a></li>
            <li><a href="engagement.html">Engagement Files Status</a></li>
            <li><a href="inventory.html">Redshift Inventory Status</a></li>
          </ul>

          <div class="logo">
            <img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
          </div>
        </div>'''
f.write(header)
def main():
	conn=pyodbc.connect(dsn="somos_redshift_1")
	get_roster_details(conn)
	get_claim_details(conn)
	get_pharmacy_details(conn)
	f.close()

def get_roster_details(conn):
	query="""
	select * from (
        SELECT 'Health First' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) as Latest_month,
        ( select count(distinct member_id) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2'
        and received_month in (select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) Last_received
         union all
        SELECT 'Health First' As MCO, 'Excelsior' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) as Total_count,
        ( select min(datepart(year,effective_period) || lpad(datepart(month,effective_period),2,'0'))
        from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) as Latest_month,
        ( select count(distinct member_id) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1'
        and received_month in (select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' )
         ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) Last_received
        union all
        SELECT 'Health First' As MCO, 'SOMOS' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) as Total_count,
        ( select min(datepart(year,effective_period) || lpad(datepart(month,effective_period),2,'0'))
        from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) as Latest_month,
        ( select count(distinct member_id) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%'
        and received_month in (select max(received_month) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'CMI' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'CMI' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'CMI') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'CMI'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'CMI' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'CMI' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'Excelsior' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'EX1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EX1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EX1') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'EX1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EX1' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'EX1' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'BalanceMed' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'VR1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'VR1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'VR1') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'VR1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'VR1' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'VR1' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'ECAP' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'EC1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EC1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EC1') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'EC1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EC1' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'EC1' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'SOMOS' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_SOMOS_all_demographics where master_ipa = 'SOMOS' ) Last_received
        union all
        SELECT 'Affinity' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.affinity_corinthian_all_rosters  ) as Total_count,
        ( select min(period) from payor.affinity_corinthian_all_rosters ) as Earliest_month,
        ( select max(period) from payor.affinity_corinthian_all_rosters ) as Latest_month,
        ( select count(distinct affinity_subscriber_number) from payor.affinity_corinthian_all_rosters
        where period in (select max(period) from payor.affinity_corinthian_all_rosters )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.affinity_corinthian_all_rosters ) Last_received
        union all
        SELECT 'Affinity' As MCO, 'Somos' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.affinity_somos_roster_all  ) as Total_count,
        ( select min(period) from payor.affinity_somos_roster_all ) as Earliest_month,
        ( select max(period) from payor.affinity_somos_roster_all ) as Latest_month,
        ( select count(distinct affinity_subscriber_number) from payor.affinity_somos_roster_all
        where period in (select max(period) from payor.affinity_somos_roster_all ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.affinity_somos_roster_all ) Last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Somos' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.empire_bcbs_healthplus_somos_all_roster  ) as Total_count,
        ( select min(received_month) from payor.empire_bcbs_healthplus_somos_all_roster ) as Earliest_month,
        ( select max(received_month) from payor.empire_bcbs_healthplus_somos_all_roster ) as Latest_month,
        ( select count(distinct empire_subscriber_id) from payor.empire_bcbs_healthplus_somos_all_roster
        where received_month in (select max(received_month) from payor.empire_bcbs_healthplus_somos_all_roster ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_bcbs_healthplus_somos_all_roster ) Last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.anthem_corinthian_all_rosters  ) as Total_count,
        ( select min(received_month) from payor.anthem_corinthian_all_rosters ) as Earliest_month,
        ( select max(received_month) from payor.anthem_corinthian_all_rosters ) as Latest_month,
        ( select count(distinct empire_subscriber_id) from payor.anthem_corinthian_all_rosters
        where received_month in (select max(received_month) from payor.anthem_corinthian_all_rosters ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.anthem_corinthian_all_rosters ) Last_received
         union all
        SELECT 'United' As MCO, 'Somos' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.uhc_somos_all_membership  ) as Total_count,
        ( select min(received_month) from payor.uhc_somos_all_membership ) as Earliest_month,
        ( select max(received_month) from payor.uhc_somos_all_membership ) as Latest_month,
        ( select count(distinct subscriber_id) from payor.uhc_somos_all_membership
        where received_month in (select max(received_month) from payor.uhc_somos_all_membership ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.uhc_somos_all_membership ) Last_received  
	union all
	SELECT 'NYDOH' AS SOURCE,'NYDOH' AS IPA, 'Roster' AS FEED_TYPE,(SELECT COUNT(*) FROM nydoh.all_rosters_all_columns ) as total_count,
        (select substring(replace(cast(min(attribution_run_date) as varchar(20)),'-',''),1,6) from nydoh.all_rosters_all_columns) as earliest_month,
        (select substring(replace(cast(max(attribution_run_date) as varchar(20)),'-',''),1,6) from nydoh.all_rosters_all_columns) as latest_month,
        (select count(*) from nydoh.all_rosters_all_columns where received_month = ( select max(received_month) from nydoh.all_rosters_all_columns) ) as latest_month,
        ( select cast(cast(max(received_month) || '01' as date) as varchar(20)) from nydoh.all_rosters_all_columns ) as Last_received
	) a
        order by 1
	"""
	try:
		cur=conn.execute(query)
		result=cur.fetchall()
		cur.close()
		processResults(result,"Latest Month Member Count")
	except Exception as e:
		print(str(e))

def get_claim_details(conn):
	query="""
	select * from (
        SELECT 'Empire/Anthem' As MCO, 'Corinthian' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.anthem_corinthian_all_claims  ) as Total_count,
        ( select min(received_month) from payor.anthem_corinthian_all_claims ) as Earliest_month,
        ( select max(received_month) from payor.anthem_corinthian_all_claims ) as Latest_month,
        ( select count(distinct claim_number ) from payor.anthem_corinthian_all_claims
        where received_month in (select max(received_month) from payor.anthem_corinthian_all_claims ) ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.anthem_corinthian_all_claims ) as last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Somos' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.empire_bcbs_healthplus_somos_all_claims  ) as Total_count,
        ( select min(received_month) from payor.empire_bcbs_healthplus_somos_all_claims ) as Earliest_month,
        ( select max(received_month) from payor.empire_bcbs_healthplus_somos_all_claims ) as Latest_month,
        ( select count(distinct claim_number ) from payor.empire_bcbs_healthplus_somos_all_claims
        where received_month in (select max(received_month) from payor.empire_bcbs_healthplus_somos_all_claims ) ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_bcbs_healthplus_somos_all_claims ) as last_received
        union all
        SELECT 'Health First' As MCO, 'Corinthian' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2'
        and received_month in (select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as last_received
        union all
        SELECT 'Health First' As MCO, 'Excelsior' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1'
        and received_month in (select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as last_received
        union all
        SELECT 'Health First' As MCO, 'Somos' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%'
        and received_month in (select max(received_month) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as last_received
         union all
        SELECT 'United' As MCO, 'Somos' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.uhc_somos_all_claims where claim_type != 'PHARM'  ) as Total_count,
        ( select min(received_month) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) as Earliest_month,
        ( select max(received_month) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) as Latest_month,
        ( select count(distinct claim_number) from payor.uhc_somos_all_claims
        where received_month in (select max(received_month) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) and claim_type != 'PHARM' ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Corinthian' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'CMI' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'CMI' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'CMI') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'CMI'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'CMI' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'CMI' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Excelsior' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'EX1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EX1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EX1') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'EX1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EX1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'EX1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'BalanceMed' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'VR1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'VR1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'VR1') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'VR1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'VR1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'VR1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'ECAP' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'EC1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EC1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EC1') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'EC1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EC1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'EC1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'SOMOS' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' ) as last_received 
	union all
	SELECT 'NYDOH' AS SOURCE,'NYDOH' AS IPA, 'Claims' AS FEED_TYPE,(SELECT COUNT(*) FROM nydoh.all_claims ) as total_count,
	(select substring(replace(cast(min(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_claims) as earliest_month,
	(select substring(replace(cast(max(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_claims) as latest_month,
	(select count(*) from nydoh.all_claims where received_month = ( select max(received_month) from nydoh.all_claims) ) as latest_month,
	( select cast(cast(max(received_month) || '01' as date) as varchar(20)) from nydoh.all_claims ) as Last_received
	) a
        order by 1
	"""
	cur=conn.execute(query)
        result=cur.fetchall()
        cur.close()
	processResults(result,"Latest Month Claim Count")
        return result

def get_pharmacy_details(conn):
	query="""
	select * from (
        SELECT 'Empire/Anthem' As MCO, 'Corinthian' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.anthem_corinthian_all_rx ) as Total_count,
        ( select min(received_month) from payor.anthem_corinthian_all_rx ) as Earliest_month,
        ( select max(received_month) from payor.anthem_corinthian_all_rx ) as Latest_month,
        ( select count(distinct claim_number ) from payor.anthem_corinthian_all_rx
        where received_month in (select max(received_month) from payor.anthem_corinthian_all_rx ) ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.anthem_corinthian_all_rx) as last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Somos' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.empire_bcbs_healthplus_somos_all_rx  ) as Total_count,
        ( select min(received_month) from payor.empire_bcbs_healthplus_somos_all_rx ) as Earliest_month,
        ( select max(received_month) from payor.empire_bcbs_healthplus_somos_all_rx ) as Latest_month,
        ( select count(distinct claim_number ) from payor.empire_bcbs_healthplus_somos_all_rx
        where received_month in (select max(received_month) from payor.empire_bcbs_healthplus_somos_all_rx ) ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_bcbs_healthplus_somos_all_rx) as last_received
        union all
        SELECT 'Health First' As MCO, 'Corinthian' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2'
        and received_month in (select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2') as last_received
        union all
        SELECT 'Health First' As MCO, 'Excelsior' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1'
        and received_month in (select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1') as last_received
        union all
        SELECT 'Health First' As MCO, 'Somos' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%'
        and received_month in (select max(received_month) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%') as last_received
        union all
        SELECT 'United' As MCO, 'Somos' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.uhc_somos_all_claims  where claim_type = 'PHARM' ) as Total_count,
        ( select min(received_month) from payor.uhc_somos_all_claims  where claim_type = 'PHARM' ) as Earliest_month,
        ( select max(received_month) from payor.uhc_somos_all_claims  where claim_type = 'PHARM' ) as Latest_month,
        ( select count(distinct claim_number) from payor.uhc_somos_all_claims
        where received_month in (select max(received_month) from payor.uhc_somos_all_claims 
	where claim_type = 'PHARM' ) AND claim_type = 'PHARM' ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.uhc_somos_all_claims where claim_type = 'PHARM' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Corinthian' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'CMI' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'CMI' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'CMI') as Latest_month,
        ( select count(distinct prescription_number || date_filled ) from payor.wellcare_all_rx where master_ipa = 'CMI'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'CMI' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'CMI' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Excelsior' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'EX1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EX1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EX1') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_all_rx where master_ipa = 'EX1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EX1' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'EX1' ) as last_received
         union all
        SELECT 'Wellcare' As MCO, 'BalanceMed' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'VR1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'VR1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'VR1') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_all_rx where master_ipa = 'VR1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'VR1' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'VR1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'ECAP' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'EC1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EC1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EC1') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_all_rx where master_ipa = 'EC1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EC1' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'EC1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'SOMOS' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' ) as last_received 
	union all
	SELECT 'NYDOH' AS SOURCE,'NYDOH' AS IPA, 'Pharmacy Claims' AS FEED_TYPE,(SELECT COUNT(*) FROM nydoh.all_rx_claims ) as total_count,
	(select substring(replace(cast(min(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_rx_claims) as earliest_month,
	(select substring(replace(cast(max(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_rx_claims) as latest_month,
	(select count(*) from nydoh.all_rx_claims where received_month = ( select max(received_month) from nydoh.all_rx_claims) ) as latest_month,
	( select cast(cast(max(received_month) || '01' as date) as varchar(20)) from nydoh.all_rx_claims ) as Last_received
	) a
        order by 1
	"""
	cur=conn.execute(query)
        result=cur.fetchall()
        cur.close()
	processResults(result,"Latest Month Pharmacy Claim Count")
        return result

def  processResults(dbdetails,count_detail):
	if len(dbdetails) == 0:
		return None
	#f=open("/home/etl/etl_home/Reports/inventory.html","w")
	h=HTML()
	tbl=h.table(style='font-family:Calibri;font-size:100%;width:100%')
	r=tbl.tr(style="background-color:#e3e0cc;font-size:200%")
	r.td("MCO")
        r.td("IPA")
        r.td("Feed Type")
        r.td("Total Count")
	r.td("Earliest Month")
	r.td("Latest Month")
	r.td("{0}".format(count_detail))
        r.td("Last Received")
	rnum=0
	for row in dbdetails:
		rnum = rnum + 1
		#rowStyle= "background-color:lightgreen" if rnum %2 == 0 else "background-color:seagreen;color:ivory"
		rowStyle="background-color:#c5d5c5" if rnum %2 == 0 else "background-color:#f0f0f0"
		r=tbl.tr(style=rowStyle)
		r.td(row[0])
		r.td(row[1])
		r.td(row[2])
		r.td(str(row[3]))
		r.td(row[4])
		r.td(row[5])
		r.td(str(row[6]))
		r.td(row[7])
        footer='''<br><center><p style="font-family:'Calibri';font-size:100%">Total: ''' + str(rnum) + \
	'''<br><p style="font-family:'Calibri';font-size:100%">Time of last inventory taken: ''' +  \
	datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + '''</p></center><br><br>'''
	f.write(str(tbl) + footer)
	#f.close()
	return tbl
if __name__ == '__main__':
    main()
