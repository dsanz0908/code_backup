import csv
import datetime
import argparse
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def automation(months_to_grab):
    affinity_homepage = "https://providerportal.affinityplan.org"
    affinity_logout = "https://providerportal.affinityplan.org/Authentication/Logout"
    browser, wait = get_browser()
    login(browser, wait)
    if "ChallengeSecurityQuestion" in browser.current_url:
        validate_user(wait)
    browser.get(affinity_homepage)
    for mtg in range(1, int(months_to_grab)+1):
        get_roster(browser, wait, mtg)
    browser.get(affinity_logout)
    browser.quit()


def get_browser():
    options = Options()
    options.headless = True
    options.add_argument('--disable-infobars')
    options.add_argument('--disable-extensions')
    options.add_argument('--profile-directory=Default')
    options.add_argument("--incognito")
    options.add_argument("--disable-plugins-discovery")
    options.add_argument("--start-maximized")
    profile = webdriver.FirefoxProfile()
    profile.set_preference("browser.download.folderList", 2)
    profile.set_preference("browser.download.manager.showWhenStarting", False)
    profile.set_preference("browser.download.dir", '/home/etl/etl_home/temp/')
    browser = webdriver.Chrome(options=options, profile=profile)
    browser.delete_all_cookies()
    wait = WebDriverWait(browser, 5)
    return browser, wait


def login(browser, wait):
    affinity_portal = "https://identity.affinityplan.org/Account/Login?returnUrl=%2F&portalMode=Provider"
    browser.get(affinity_portal)
    username_element = wait.until(
        EC.presence_of_element_located((By.ID, "Username")))
    password_element = wait.until(
        EC.presence_of_element_located((By.ID, "Password")))
    submit_button_xpath = "/html/body/div[5]/div/form/div/div/div[2]/div[3]/button"
    submit_button_element = wait.until(
        EC.presence_of_element_located((By.XPATH, submit_button_xpath)))
    username_element.send_keys("kemar")
    password_element.send_keys("Mysticalxk01!")
    submit_button_element.submit()
    return


def validate_user(wait):
    question_element_xpath = "/html/body/div[5]/form/div[1]/div[2]/div[1]/div/label"
    question_element = wait.until(
        EC.presence_of_element_located((By.XPATH, question_element_xpath)))
    answer_element = wait.until(
        EC.presence_of_element_located((By.ID, "Answer")))
    submit_button_xpath = "/html/body/div[5]/form/div[2]/input[1]"
    submit_button_element = wait.until(
        EC.presence_of_element_located((By.XPATH, submit_button_xpath)))
    if "mother" in question_element.text:
        answer_element.send_keys("ellis")
    elif "pet" in question_element.text:
        answer_element.send_keys("mittens")
    submit_button_element.submit()
    return


def get_roster(browser, wait, mtg):
    roster_box_xpath = '//*[@id="SelectedRosterDate"]/option[{}]'.format(str(mtg+1))
    print(roster_box_xpath)
    roster_box_element = wait.until(
        EC.presence_of_element_located((By.XPATH, roster_box_xpath)))
    latest_roster_month = roster_box_element.text.lower()
    previous_month = (datetime.date.today().replace(day=mtg) -
                      datetime.timedelta(days=1)).strftime("%B").lower()
    print latest_roster_month
    return


if __name__ == "__main__":
    PARSER = argparse.ArgumentParser(description='grab affinity somos roster')
    PARSER.add_argument(
        'months_to_grab',
        action='store',
        help='Number of missing Affinity Somos roster files')
    ARGS = PARSER.parse_args()
    MONTHS_TO_GRAB = ARGS.months_to_grab
    automation(MONTHS_TO_GRAB)
