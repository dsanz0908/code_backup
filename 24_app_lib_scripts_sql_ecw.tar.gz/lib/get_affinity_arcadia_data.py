CINS = open('../temp/affinity_temp_cins.txt', 'r').read()
import sys
import pandas as pd
import pyodbc

CONNECTION_ARCADIA = pyodbc.connect(
    "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
)

PATIENTS_QUERY = """
select  DISTINCT policy_nbr, pat_original_id,
                pat_first_name,
                pat_last_name,
                pat_middle_name,
                pat_race,
                pat_ethnicity,
                pat_occupation,
                pat_status,
                pat_language,
                pat_city,
                pat_county,
                pat_state,
                pat_zip,
                pat_phone_1,
                pat_phone_2,
                pat_date_of_birth,
                pat_sex,
                pat_ssn,
                pat_email_address,
                pat_orig_site_id,
                pat_expired_ind,
                pat_medical_record_number,
                pat_address_1,
                pat_address_2,
                pat_orig_guarantor_id,
                pat_provider_id_unscrubbed,
                pat_advance_directive_ind,
                pat_opt_in_ind,
                tpatientid,
                pat_mail_address1,
                pat_mail_address2,
                pat_mail_city,
                pat_mail_state,
                pat_mail_zip
 from t_payer as a join t_patient as b on a.patient_id = b.pat_id where policy_nbr in ({}) and payer_delete_ind = 'N' and pat_delete_ind = 'N'
""".format(CINS)

ENCOUNTER_QUERY = """
SELECT DISTINCT TOP 100 enc_original_id,
                enc_timestamp,
                enc_type,
                enc_type_description,
                enc_dept_desc,
                enc_orig_dept_id,
                enc_billable_ind,
                enc_clinical_ind,
                enc_optical_ind,
                enc_status,
                enc_eligibility_check_ind,
                enc_reason,
                enc_discharge_timestamp,
                enc_notes,
                enc_room,
                enc_orig_site_id,
                enc_age_months,
                enc_age_years,
                enc_provider1_name,
                enc_provider2_name,
                enc_provider3_name,
                enc_medical_ind,
                enc_location_unscrubbed,
                enc_locked_ind,
                enc_no_known_allergy_ind,
                enc_no_known_medication_ind,
                enc_no_known_problem_ind,
                enc_appt_original_id,
                enc_dental_ind,
                enc_optometry_ind,
                enc_behavioral_ind,
                enc_enabling_ind,
                enc_locked_timestamp,
                enc_signed_ind,
                enc_signed_timestamp,
                enc_progress_note_ind,
                tencounterid,
                enc_opt_out_ind,
                enc_orig_patient_id,
                enc_orig_rendering_provider_id,
                enc_orig_scrubbed_ind, enc_timestamp
 from t_payer as a join t_encounter as b on a.patient_id = b.enc_patient_id where policy_nbr = 'ZZ31364S' and enc_timestamp > '2017-10-01' """

QUERY = """
WITH cte_diagnosis_capture
     AS (SELECT DISTINCT encounter_id,
                         icd10_code,
                         Dense_rank()
                           OVER (
                             partition BY encounter_id
                             ORDER BY encounter_id, icd10_code ) AS rnumber
         FROM   t_assessment
         WHERE  encounter_id IS NOT NULL
                AND icd10_code IS NOT NULL
                AND primary_diagnosis_ind = 1),
     cte_diagnosis_1
     AS (SELECT encounter_id,
                Max(CASE
                      WHEN rnumber = 1 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code,
                Max(CASE
                      WHEN rnumber = 2 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_1,
                Max(CASE
                      WHEN rnumber = 3 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_2,
                Max(CASE
                      WHEN rnumber = 4 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_3,
                Max(CASE
                      WHEN rnumber = 5 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_4,
                Max(CASE
                      WHEN rnumber = 6 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_5,
                Max(CASE
                      WHEN rnumber = 7 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_6,
                Max(CASE
                      WHEN rnumber = 8 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_7,
                Max(CASE
                      WHEN rnumber = 9 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_8,
                Max(CASE
                      WHEN rnumber = 10 THEN icd10_code
                      ELSE NULL
                    END) AS icd10_code_9
         FROM   cte_diagnosis_capture
         GROUP  BY encounter_id),
     cte_cc_capture
     AS (SELECT cc_enc_id,
                cc_cpt_code AS cpt_code
         FROM   t_chargecapture
         WHERE  cc_enc_id IS NOT NULL
                AND cc_cpt_code IS NOT NULL)
select t3.pat_first_name,
       t3.pat_middle_name,
       t3.pat_last_name,
       pat_date_of_birth,
       pat_sex,
       orig_member_id,
       medicaid_id,
       vitals_height,
       vitals_height_unit,
       vitals_weight,
       vitals_weight_unit,
       vitals_bmi,
       vitals_systolic,
       vitals_diastolic,
       vitals_date,
       site_center_name,
       prov_fullname,
       prov_specialty_1,
       prov_npi,
       prov_address_1,
       prov_address_2,
       prov_city,
       prov_state,
       prov_zip,
       ps.source_desc,
       icd10_code,
       icd10_code_1,
       icd10_code_2,
       icd10_code_3,
       icd10_code_4,
       icd10_code_5,
       icd10_code_6,
       icd10_code_7,
       icd10_code_8,
       icd10_code_9,
       cpt_code,
       t3.pat_address_1,
       t3.pat_address_2,
       t3.pat_city,
       t3.pat_state,
       t3.pat_zip, t3.pat_id
 FROM   t_vitals t1
       INNER JOIN t_encounter t2
               ON t1.vitals_enc_id = t2.enc_id
       INNER JOIN t_patient t3
               ON t2.enc_patient_id = t3.pat_id
       INNER JOIN cte_diagnosis_1 d1
               ON t2.enc_id = d1.encounter_id
       INNER JOIN cte_cc_capture cc
               ON t2.enc_id = cc.cc_enc_id
       --LEFT OUTER JOIN systolic_diastolic sd
       --             ON t2.enc_id = sd.cc_enc_id
       LEFT OUTER JOIN mpi.person_patient pp
                    ON t3.pat_id = pp.pat_id
       INNER JOIN site_master sm
               ON t1.vitals_orig_site_id = sm.site_orig_site_id
       INNER JOIN provider_master prv
               ON t1.vitals_prov_id = prv.prov_id
       LEFT OUTER JOIN mpi.person_member pm
                    ON pp.person_id = pm.person_id
       LEFT OUTER JOIN plan_member plm
                    ON pm.member_id = plm.member_id
                       AND plm.delete_ind = 'N'
       LEFT OUTER JOIN plan_source ps
                    ON plm.source_id = ps.source_id
       inner join t_payer as a on a.patient_id = t3.pat_id
       where enc_timestamp between '2017-10-01' and '2019-01-01' and t3.pat_id = '{}'
"""

QUERY2 = """
select distinct patient_id from t_payer  where policy_nbr in ({}) and payer_delete_ind = 'N' """.format(CINS)
#df = pd.read_sql(QUERY, CONNECTION_ARCADIA)
df2 = pd.read_sql(QUERY2, CONNECTION_ARCADIA)
#print df
df_list = df2['patient_id'].values.tolist()
for i in df_list[:5]:
    temp_df = pd.read_sql(QUERY.format(i), CONNECTION_ARCADIA)
    print temp_df
CONNECTION_ARCADIA.close()

