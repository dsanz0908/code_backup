import pyodbc
import pandas as pd
conn_somos=pyodbc.connect(dsn="somos_redshift_1")
conn_arcadia=pyodbc.connect("dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL")
prov_site_query= """
                        select distinct prov_npi,site_center_name as sitename from provider_master t1, site_master t2
                        where prov_npi is not null
                        and t1.prov_orig_site_id = t2.site_orig_site_id
                        """
salient_query="""
            select cast(pcp_npi as bigint) as pcp_npi, measure as  measure,
            0 as universe,monthly_member_denominator as denominator,monthly_member_numerator as numerator
            from DSRIP_Scorecard_Measures
            where pcp_npi != ''
            and lower(measure) not in (
            'adolescent immunizations combo 1',
            'adult access preventive (20 - 44)',
            'adult access preventive (45 - 64)',
            'adult access preventive (65 and older)',
            'alcohol screening',
            'alcohol screening results',
            'annual dental visit',
            'asthma action plan',
            'asthma diagnosis',
            'bmi assessment',
            'bmi cpt',
            'bmi icd',
            'breast cancer screening',
            'cv monitoring (cv & schizophrenia)',
            'cervical cancer screening',
            'child access - primary care (12 to 19)',
            'child access - primary care (12 to 24 months)',
            'child access - primary care (25 months to 6)',
            'child access - primary care (7 to 11)',
            'child adhd medication f/u (continuation)',
            'child adhd medication f/u (initiation)',
            'chlamydia screening in women',
            'clinical depression screening',
            'clinical depression screening results',
            'colorectal cancer screen',
            'control blood pressure',
            'copd diagnosis',
            'diabetes - foot exam',
            'diabetes - nephropathy screening',
            'diabetes diagnosis',
            'diabetes foot exam',
            'dm eye exam',
            'dm hba1c testing',
            'drug assessment',
            'hpv vaccination',
            'immunizations for adolescents: meningococcal',
            'immunizations for adolescents: tdap',
            'preventive care and screening: body mass index (bmi) screening and follow- up plan',
            'tobacco preventive care and screening: tobacco use: screening and cessation intervention',
            'tobacco use assessment',
            'tobacco use assessment result',
            'use of spirometry testing in the assessment and diagnosis of copd',
            'weight assessment and counseling for nutrition and physical activity for children and adolescents',
            'well-child (15 mo 5+ visits)' )
            and added_tz = ( select max(added_tz) from dsrip_scorecard_measures )
            """
salient_df=pd.read_sql(salient_query,conn_somos)
prov_site_df=pd.read_sql(prov_site_query,conn_arcadia)
mdf=salient_df.merge(prov_site_df,how="inner",left_on=["pcp_npi"],right_on=["prov_npi"])
mdf["universe"]=mdf["universe"].astype(int)
mdf["denominator"]=mdf["denominator"].astype(int)
mdf["numerator"]=mdf["numerator"].astype(int)
gdf=mdf.groupby(["sitename","measure"],as_index=False).sum().reset_index()            
gdf.drop(columns=["index","pcp_npi","prov_npi"],inplace=True)
