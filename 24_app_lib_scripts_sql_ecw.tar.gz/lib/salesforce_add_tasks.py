from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


TASK_QUERY = """ 
SELECT  '005f4000000nXJTAA2'                                         AS contact_assigned_chw__c,
                measure_sf,
                t3.id as patient_contact_id,
                provider_contact_id,
                '0120H000001QWhSQAW' as record_type_id,
                CASE
                  WHEN measure_type = 'Access to Care' THEN ''
                  ELSE measure_type
                END                                                            AS procedure,
                'Access Care Gap (2019)' as subject,
                '2019-12-31' AS project_end_date,
                'hhc_measures from misa 20191218'                                       AS source,
                'Open'                                                       AS status,
                notes
FROM   sf_hhc_measures t1
inner join ( select min(id) as provider_contact_id, individual_npi__c from salesforce_providers group by individual_npi__c) t2
on t1.pcp_npi = individual_npi__c
inner join salesforce_patients t3
on t1.cin_plan_id = cin__c 
"""

sf, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
TASKS = CONNECTION.execute(TASK_QUERY).fetchall()
TODAY = datetime.now().strftime("%Y%m%d")
for task in TASKS:
    print task
    try:
	sf.Task.create({
	    'ownerid': task[0],
	    'measure__c': task[1],
	    'whoid': task[2],
	    'pcp__c': task[3],
	    'recordtypeid': task[4],
	    'procedure__c': task[5],
	    'subject': task[6],
	    'project_end_date__c': task[7],
	    'source_created_by__c': task[8],
	    'status': task[9],
	    'Care_Gap_Comments_Part_2__c':task[10],
	})
    except Exception as e:
        print(task, str(e))

CONNECTION.close()
