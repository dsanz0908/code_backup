import datetime as dt
from dateutil.relativedelta import relativedelta
import pandas as pd
import numpy as np
import pyodbc
import warnings
from statsmodels.tsa.arima_model import ARIMA
warnings.simplefilter(action='ignore')

if __name__ == '__main__':
    CONNECTION_CDW = pyodbc.connect(dsn="claims_dw")
    CDW_QUERY = """
    SELECT source, 
	   the_date, 
	   Count(DISTINCT local_member_id) as num_members,
           'real' as state
    FROM   fact_eligibility 
	   JOIN dim_date 
	     ON fact_eligibility.date_id = dim_date.date_id 
    WHERE  eligibility_ind = 1 
    GROUP  BY 1, 
	      2 
    ORDER  BY 1, 
	      2 
    """
    ALL_DF = pd.DataFrame()
    RESULTS = pd.read_sql(CDW_QUERY, CONNECTION_CDW)
    SOURCES = RESULTS['source'].unique()
    for source in SOURCES:
        source_rows = RESULTS[RESULTS['source'] == source]
        start_date = source_rows['the_date'].max() + relativedelta(months=1)
        end_date = start_date + relativedelta(months=5)
        forecast_temp = pd.DataFrame(
            pd.date_range(start_date, end_date, freq='MS'),
            columns=['the_date'])
        forecast_temp['the_date'] = forecast_temp['the_date'].dt.date
        forecast_temp.insert(0, 'source', source)
        X = source_rows[['the_date', 'num_members']]
        X.set_index('the_date', inplace=True)
        model = ARIMA(X, order=(5, 1, 0))
        model_fit = model.fit(disp=0)
        output = model_fit.forecast(steps=6)
        forecast_dates = pd.concat([
            forecast_temp,
            pd.DataFrame(data=output[0], columns=['num_members'])
        ],
                                   axis=1)
        forecast_dates['state'] = 'forecast'
        df = source_rows.append(forecast_dates)
        df.set_index('the_date', inplace=True)
        ALL_DF = ALL_DF.append(df)

    print ALL_DF
