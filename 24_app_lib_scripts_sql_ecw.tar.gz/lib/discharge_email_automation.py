from os import listdir, path
from datetime import datetime
import re
import csv
import imaplib
import email
import xlrd

EXCEL_DIRECTORY = "/home/etl/etl_home/downloads/discharge_email_excel/"
CSV_DIRECTORY = "/home/etl/etl_home/downloads/discharge_email_csv/"


def get_discharge_emails():
    conn = imaplib.IMAP4_SSL("outlook.office365.com")
    conn.login('dsanz@optimusha.com', 'Bacalao2')
    conn.select('Inbox')
    return_code, msgs = conn.search(None, '(SUBJECT "ACP Discharges")')
    return conn, msgs[0].split()


def get_processed_message(conn, msg):
    result, data = conn.fetch(msg, "(RFC822)")
    email_body = data[0][1]
    pmail = email.message_from_string(email_body)
    return pmail


def save_excel_attachment(msg):
    if msg.get_content_maintype() != 'multipart':
        return
    for part in msg.walk():
        if part.get_content_maintype() == 'multipart':
            continue
        if part.get('Content-Disposition') is None:
            continue
        filename = part.get_filename()
        original_date_regex = re.compile(ur'\d\d\s...\s20\d\d')
        if 'xlsx' in filename.lower():
            original_date_regex_list = re.findall(
                original_date_regex, part.get('Content-Disposition'))
            if original_date_regex_list:
                original_email_date = str(original_date_regex_list[0]).replace(
                    ' ', '')
                excel_save_path = path.join(
                    EXCEL_DIRECTORY, "{}_{}".format(original_email_date,
                                                    filename))
                with open(excel_save_path, 'wb') as opened_file:
                    opened_file.write(part.get_payload(decode=True))
    return


def excel_to_csv(excel_basename):
    excel_path = path.join(EXCEL_DIRECTORY, excel_basename)
    workbook = xlrd.open_workbook(excel_path)
    sheet = workbook.sheet_by_name('Sheet1')
    csv_path = path.join(CSV_DIRECTORY, excel_basename.replace('xlsx', 'csv'))
    csvfile = open(csv_path, 'w')
    writer = csv.writer(csvfile, quoting=csv.QUOTE_ALL)
    header = sheet.row_values(0)
    writer.writerow(header)
    for row_number in range(sheet.nrows)[1:]:
        row = sheet.row_values(row_number)
        row[2] = xlrd.xldate_as_datetime(row[2], 0) if row[2] else None
        row[4] = xlrd.xldate_as_datetime(row[4], 0) if row[4] else None
        row[5] = xlrd.xldate_as_datetime(row[5], 0) if row[5] else None
        row[6] = xlrd.xldate_as_datetime(row[6], 0) if row[6] else None
        writer.writerow(row)

    csvfile.close()
    return


if __name__ == '__main__':
    CONNECTION, MESSAGES = get_discharge_emails()
    for message in MESSAGES:
        processed_email = get_processed_message(CONNECTION, message)
        save_excel_attachment(processed_email)

    CONNECTION.close()
    CONNECTION.logout()
    del CONNECTION

    for excel_file in listdir(EXCEL_DIRECTORY):
        excel_to_csv(excel_file)
