import pandas as pd
import pyodbc
conn= pyodbc.connect("dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL")

arcadia_objs={"allergy":"select * from t_allergy where allergy_orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"appointment":"select * from t_appointment where appt_orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"assessment":"select * from t_assemssment where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"chargecapture":"select * from t_chargecapture where cc_orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"encounter":"select * from t_encounter where enc_site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"immunization":"select * from t_immunization where orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"maintenance":"select * from t_maintenance where maint_orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"medication":"select * from t_medicationlist where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"orders":"select * from t_order where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"patients":"select * from t_patient where pat_orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"payer":"select * from t_payer where payer_orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"prescription":"select * from t_prescription where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"problm":"select * from t_problem where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"results":"select * from t_result where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"vitals":"select * from t_vitals where vitals_orig_site_id in ( select site_orig_site_id from site_master where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1') ",
"contactinfo":"select * from t_contactinfo where site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1'",
"relationship":"select * from t_contactinfo_relationship" }

for obj,query in arcadia_objs.items():
    df=pd.read_sql(query,conn)
    df.to_csv("/home/etl/etl_home/downloads/arcadia_ccn/ccn_"+obj+".csv",header=True,index=False,sep=",")
