import csv
import datetime
import time
import argparse
from pyvirtualdisplay import Display
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from grab_affinity_corinthian_roster import get_browser, login, validate_user


def change_from_date(browser, wait):
    from_date_element_xpath = "//*[@id='FromDate']"
    from_date_element = wait.until(
        EC.presence_of_element_located((By.XPATH, from_date_element_xpath)))
    from_date_element.send_keys("01/01/2018")
    return


def get_excel(browser, wait):
    excel_element_xpath = "/html/body/div[1]/div/span/a"
    excel_element = wait.until(
        EC.presence_of_element_located((By.XPATH, excel_element_xpath)))
    excel_element.click()
    return


if __name__ == "__main__":
    affinity_alerts_page = "https://providerportal.affinityplan.org/Alerts"
    affinity_logout = "https://providerportal.affinityplan.org/Authentication/Logout"
    display = Display(visible=0, size=(800, 600))
    display.start()
    browser, wait = get_browser()
    login(browser, wait)
    if "ChallengeSecurityQuestion" in browser.current_url:
        validate_user(browser, wait)
    browser.get(affinity_alerts_page)
    time.sleep(10)
    change_from_date(browser, wait)
    time.sleep(10)
    get_excel(browser, wait)
    time.sleep(10)
    browser.get(affinity_logout)
    browser.quit()
    display.stop()
