import pyodbc
import pandas as pd
from datetime import datetime

conn_arcadia = pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")

QUERY = """
SELECT Cast(Max(enc_updated_timestamp) AS DATE)             AS "Latest Encounter Date",
       site_emr_name                                      AS EMR,
       Datediff(day, Max(enc_updated_timestamp), Getdate())-4 AS Lag,
       site_center_name                                   AS "Practice Name"
FROM   t_encounter t1
       INNER JOIN site_master t2
               ON t1.enc_site_id = t2.site_id
GROUP  BY site_emr_name,
          site_center_name
HAVING Datediff(day, Max(enc_updated_timestamp), Getdate()) between 5 and 60
ORDER  BY 2,4
"""

df = pd.read_sql(QUERY, conn_arcadia)
df.to_csv('/data/output/{}_arcadia_lag.csv'.format(datetime.today().strftime('%Y%m%d')), index=False)

conn_arcadia.close()
