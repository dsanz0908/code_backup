import boto3

def main():
        try:
                session = boto3.Session()
		s3=session.resource("s3")
		bucket = s3.Bucket("engagement-reporting")
		file_key="DY4Q2/139 Medical Facility PC/DY4Q2_1235301631_139 Medical Facility PC_$3418 Broadway$_Insurance Report6.csv"
		obj=s3.Object(bucket_name="engagement-reporting",key=file_key)
		data=obj.get()["Body"].read()
		print(obj,data)
        except Exception as e:
                print(str(e))

if __name__ == '__main__':
	main()
