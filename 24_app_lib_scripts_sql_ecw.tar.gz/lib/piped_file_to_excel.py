import pandas as pd
import argparse

if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description='Convert CSV File to Excel')
    PARSER.add_argument('filepath_in', action='store', help='CSV filepath')
    PARSER.add_argument('filepath_out', action='store', help='Excel filepath')
    ARGS = PARSER.parse_args()
    pd.read_csv(ARGS.filepath_in, delimiter='|').to_excel(ARGS.filepath_out, index=False)
