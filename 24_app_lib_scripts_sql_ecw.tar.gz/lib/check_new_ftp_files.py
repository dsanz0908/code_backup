import pysftp
import datetime
sites=[[{"name":"Empire_excelsior","host":"ftp2.amerigroup.com","user":"Excelsior_Medical","passwd":"@x4Pb29F","dir":"Amerigroup_sftp/Outbound"}],
      [{"name":"Empire_corinthian","host":"ftp2.amerigroup.com","user":"Corinthian_Medical","passwd":"@$c5uLZf","dir":"Amerigroup_sftp/Outbound"}],
      [{"name":"Empire_innovator","host":"ftp2.amerigroup.com","user":"SOMOS_IPA_DOA","passwd":"Yqv7&PeIy","dir":"Amerigroup_sftp/Outbound/DelegationOversight"}],
      [{"name":"evolent_somos","host":"ftps.valencehealth.com","user":"somos","passwd":"TnyTt44e?M^h","dir":"/ftp_directories/somos/Production/outbound"}],
      [{"name":"evolent_anthem","host":"ftps.valencehealth.com","user":"somos","passwd":"TnyTt44e?M^h","dir":"/ftp_directories/somos/anthem_prod/outbound"}],
      [{"name":"evolent_emblem","host":"ftps.valencehealth.com","user":"somos","passwd":"TnyTt44e?M^h","dir":"/ftp_directories/somos/emblem_prod/outbound"}],
      [{"name":"garage","host":"garagefs.extreme-cloud.com","user":"somos_data","passwd":"Av&5HdrA","dir":"Files/OutBound"}],
      [{"name":"Empire_innovator","host":"ftp2.amerigroup.com","user":"SOMOS_IPA_DOA","passwd":"Yqv7&PeIy","dir":"Amerigroup_sftp/Outbound/DelegationOversight"}],
      
      [{"name":"hf_excelsior","host":"hfftp.healthfirst.org","user":"viperalta","passwd":"V1ct0r@hf","dir":"/Excelsior/From HF"}],
      [{"name":"hf_corinthian","host":"hfftp.healthfirst.org","user":"corinthianmed","passwd":"W1nter2014","dir":"/CorinthianMed/From HF"}],
      [{"name":"hf_somos","host":"hfftp.healthfirst.org","user":"SOMOS_Fa","passwd":"J0hn@hf$0","dir":"/SOMOS_Fa/From HF"}],
       
      ]
for site in sites:
    print(site[0]["name"])
    with pysftp.Connection(site[0]["host"], username=site[0]["user"], password=site[0]["passwd"]) as sftp:
        files_attr=sftp.listdir_attr(site[0]["dir"])
        for item in files_attr:
            if (datetime.datetime.now() - datetime.datetime.fromtimestamp(item.st_mtime)).days <= 7:
                print(site[0]["name"],item.filename,  datetime.datetime.fromtimestamp(item.st_mtime))
