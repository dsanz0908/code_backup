from datetime import datetime
import requests
import pandas as pd
import pyodbc
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': "ssundararaman@optimusha.com",
        'password': "OptimusSomos1yDsjYPT1d9QJYnq9n6UKdkG97"
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


PROVIDER_QUERY = """
SELECT DISTINCT '005f40000041BB1AAM' AS contact_assigned_chw__c,
                '005f4000000noQqAAI' AS lead_supervisor__c,
                '012f4000000MAVbAAO' AS recordtypeid,
                pcp_npi,
                pcp_first_name,
                pcp_last_name,
                pcp_full_name,
                case when ipa = 'COR2' then 'Corinthian' else '' end as ipa
FROM   salesforce.mco_gaps_groundzero1
WHERE  complaint = 'Compliant'
       AND NOT EXISTS (SELECT 1
                       FROM   salesforce_providers
                       WHERE  pcp_npi = individual_npi__c)
"""

sf, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
PROVIDERS = CONNECTION.execute(PROVIDER_QUERY).fetchall()
for provider in PROVIDERS[:1]:
    sf.Contact.create({
        'contact_assigned_chw__c': provider[0],
        'lead_supervisor__c': provider[1],
        'recordtypeid': provider[2],
        'individual_npi__c': provider[3],
        'firstname': provider[4],
        'lastname': provider[5],
        'ipa_group__c': provider[6]
    })
CONNECTION.close()
