from fuzzywuzzy import fuzz
from fuzzywuzzy import process
import pandas as pd
import pyodbc
from multiprocessing import Pool
import json
conn=pyodbc.connect(dsn="somos_redshift_1")
conn_arcadia = pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")
q1=""" 	select pat_first_name + ' ' + pat_last_name as pat_name,pat_date_of_birth,pat_id
	from t_patient where pat_date_of_birth is not null
	 """

q2="""
SELECT member_first_name || ' ' || member_last_name as member_name,cast(member_dob as date) as dob,member_medicaid_number, empire_subscriber_id, 'Anthem Corinthian' as source, 
pcp_npi, '' as address,'' as phone
from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat
WHERE RECEIVED_MONTH IN ( SELECT MAX(RECEIVED_MONTH) FROM PAYOR.EMPIRE_BCBS_HEALTHPLUS_LEGACY_ALL_ROSTER_OLDFORMAT )
AND MEMBERSHIP_MONTH IN ( SELECT MAX(MEMBERSHIP_MONTH) FROM PAYOR.EMPIRE_BCBS_HEALTHPLUS_LEGACY_ALL_ROSTER_OLDFORMAT 
                            WHERE RECEIVED_MONTH IN (SELECT MAX(RECEIVED_MONTH) FROM PAYOR.EMPIRE_BCBS_HEALTHPLUS_LEGACY_ALL_ROSTER_OLDFORMAT))
union all
select member_name,dob,member_medicaid_number,health_card_identifier,source,pcp_npi,address,phone
from (
select distinct first_name || ' ' || last_name as member_name,cast(date_of_birth as date) as dob,medicaid_could_contain_ssn as member_medicaid_number,
health_card_identifier,'Anthem Somos' as source,responsible_npi as pcp_npi, '' as address, '' as phone,
row_number() over( partition by medicaid_could_contain_ssn order by dob ) as rnumber
from payor.empire_somos_member 
where received_month in ( select max(received_month) from payor.empire_somos_member ) ) a
where rnumber = 1
"""
#q1_test="select distinct pat_first_name + ' ' + pat_last_name, pat_date_of_birth,enc_patient_id from ACPPS_sandbox_PRD01..cbp_1"
cur1=conn_arcadia.execute(q1)
res1=cur1.fetchall()
cur1.close()
cur2=conn.execute(q2)
res2=cur2.fetchall()
cur2.close()

def target_extract(data):
    res_dict={}
    for row in data:
        if row[1].strftime("%Y%m%d") in res_dict.keys():
            res_dict[row[1].strftime("%Y%m%d")].append((row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7]))
        else:
            res_dict[row[1].strftime("%Y%m%d")]=[(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7])]
    return res_dict
res_dict = target_extract(res2)

def check_data(arcadia_data):
    ret_data=[]
    arcadia_name=arcadia_data[0]
    arcadia_dob=arcadia_data[1].strftime("%Y%m%d")
    arcadia_pat_id=arcadia_data[2]
    if arcadia_dob in res_dict.keys():
        res=res_dict[arcadia_dob]
        for hf_data in res:
            mco_name=hf_data[0]
	    mco_dob=hf_data[1].strftime("%Y%m%d")
            mco_cin=hf_data[2]
            mco_source=hf_data[3]
            mco_npi = hf_data[4] if hf_data[4] != None else ''
            mco_address=hf_data[5] if hf_data[5] != None else ''
            mco_phone=hf_data[6] if hf_data[6] != None else ''
            mco_month=hf_data[7] if hf_data[7] != None else ''
            #score=fuzz.token_set_ratio(arcadia_name,mco_name)
            score=fuzz.WRatio(arcadia_name,mco_name)
            if score > 90 :
                #print(arcadia_name,arcadia_dob,arcadia_pat_id,':',mco_name,mco_cin,mco_dob,mco_source,mco_npi,mco_address,mco_phone,mco_month,score)
		ret_data.append(arcadia_name + "|" + arcadia_dob + "|" + arcadia_pat_id + "|" + mco_name + "|" + mco_dob  + '|' + mco_cin + "|" +  \
		mco_source + "|" + mco_npi + "|" + mco_address + "|" + mco_phone + "|" + mco_month + "~!" )
    return ret_data
def main():
    #p=Pool(2)
    #Data=p.map(check_data,res1)
    Data=map(check_data,res1)
    f=open("/home/etl/etl_home/output/pat_cin_match_anthem.txt","w")
    for row in Data:
        if len(row) > 0:
            f.write(json.dumps(row).replace('"','').replace("[","").replace("~!]","\n ").replace("~!, ","\n"))
    f.close()

if __name__ == '__main__':
    main()
