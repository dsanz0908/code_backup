import datetime
import pytz
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText


def main():
    conn_24 = pyodbc.connect(dsn="postgres_24")
    conn_67 = pyodbc.connect(dsn="postgres_67")
    res_24 = getDBDetails(conn_24)
    res_67 = getDBDetails(conn_67)
    for i in res_67:
        print i[0]


def getDBDetails(conn):
    query = """
    WITH cte_failed_dag_run 
	 AS (SELECT dag_id, 
		    execution_date, 
		    start_date, 
		    state 
	     FROM   dag_run 
	     WHERE  ( dag_id LIKE 'ecw%' 
		       OR dag_id = 'bronx_rhio_daily_pull' 
		       OR dag_id = 'arcadia_bronxrhio_pull' ) 
		    AND start_date >= CURRENT_DATE), 
	 cte_max_start_date_state 
	 AS (SELECT dag_id, 
		    Max(start_date) AS mx_date 
	     FROM   dag_run 
	     WHERE  ( dag_id LIKE 'ecw%' 
		       OR dag_id = 'bronx_rhio_daily_pull' 
		       OR dag_id = 'arcadia_bronxrhio_pull' ) 
	     GROUP  BY dag_id), 
	 cte_max_success_state 
	 AS (SELECT dag_id, 
		    Max(start_date) AS last_success_date 
	     FROM   dag_run 
	     WHERE  ( dag_id LIKE 'ecw%' 
		       OR dag_id = 'bronx_rhio_daily_pull' 
		       OR dag_id = 'arcadia_bronxrhio_pull' ) 
		    AND state = 'success' 
	     GROUP  BY dag_id) 
    SELECT DISTINCT 'airflow trigger_dag ' || t1.dag_id || ';'
    FROM   dag_run t1 
	   INNER JOIN cte_failed_dag_run cte 
		   ON t1.dag_id = cte.dag_id 
	   INNER JOIN cte_max_start_date_state mx 
		   ON t1.dag_id = mx.dag_id 
		      AND t1.start_date = mx.mx_date 
	   LEFT OUTER JOIN cte_max_success_state scs 
			ON t1.dag_id = scs.dag_id 
    where t1.state = 'failed'
        """

    cur = conn.execute(query)
    res = cur.fetchall()
    cur.close()
    return res


if __name__ == '__main__':
    main()
