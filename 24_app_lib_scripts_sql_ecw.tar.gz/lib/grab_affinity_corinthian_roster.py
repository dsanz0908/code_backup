import csv
import datetime
import time
import argparse
from pyvirtualdisplay import Display
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def automation(month_to_grab):
    affinity_homepage = "https://providerportal.affinityplan.org"
    affinity_logout = "https://providerportal.affinityplan.org/Authentication/Logout"
    roster_file_link = "https://providerportal.affinityplan.org/Reports/DownloadPcpRoster?SelectedRosterDate={}".format(
        month_to_grab)
    display = Display(visible=0, size=(800, 600))
    display.start()
    browser, wait = get_browser()
    login(browser, wait)
    if "ChallengeSecurityQuestion" in browser.current_url:
        validate_user(browser, wait)
    browser.get(affinity_homepage)
    browser.get(roster_file_link)
    time.sleep(10)
    browser.get(affinity_logout)
    browser.quit()
    display.stop()
    


def get_browser():
    options = Options()
    options.headless = True
    options.add_argument('--disable-infobars')
    options.add_argument('--disable-extensions')
    options.add_argument('--profile-directory=Default')
    options.add_argument("--incognito")
    options.add_argument("--disable-plugins-discovery")
    options.add_argument("--start-maximized")
    options.add_argument("--headless")
    browser = webdriver.Chrome(options=options)
    browser.command_executor._commands["send_command"] = (
        "POST", '/session/$sessionId/chromium/send_command')
    params = {
        'cmd': 'Page.setDownloadBehavior',
        'params': {
            'behavior': 'allow',
            'downloadPath': "/home/etl/etl_home/temp"
        }
    }
    command_result = browser.execute("send_command", params)
    browser.delete_all_cookies()
    wait = WebDriverWait(browser, 10)
    return browser, wait


def login(browser, wait):
    affinity_portal = "https://identity.affinityplan.org/Account/Login?returnUrl=%2F&portalMode=Provider"
    browser.get(affinity_portal)
    username_element = wait.until(
        EC.presence_of_element_located((By.ID, "Username")))
    password_element = wait.until(
        EC.presence_of_element_located((By.ID, "Password")))
    submit_button_xpath = "/html/body/div[5]/div/form/div/div/div[2]/div[3]/button"
    submit_button_element = wait.until(
        EC.presence_of_element_located((By.XPATH, submit_button_xpath)))
    username_element.send_keys("jdionisiocmipa")
    password_element.send_keys("Youdo33!")
    submit_button_element.submit()
    return


def validate_user(browser, wait):
    question_element_xpath = "/html/body/div[5]/form/div[1]/div[2]/div[1]/div/label"
    question_element = wait.until(
        EC.presence_of_element_located((By.XPATH, question_element_xpath)))
    answer_element = wait.until(
        EC.presence_of_element_located((By.ID, "Answer")))
    submit_button_xpath = "/html/body/div[5]/form/div[2]/input[1]"
    submit_button_element = wait.until(
        EC.presence_of_element_located((By.XPATH, submit_button_xpath)))
    if "mother" in question_element.text:
	answer_element.send_keys("batara")
        submit_button_element.submit()
    elif "pet" in question_element.text:
	login(browser, wait)
	validate_user(browser, wait)
    return


if __name__ == "__main__":
    PARSER = argparse.ArgumentParser(description='grab affinity corinthian roster')
    PARSER.add_argument(
        'month_to_grab',
        action='store',
        help='Missing Affinity Somos roster month')
    ARGS = PARSER.parse_args()
    MONTH_TO_GRAB = ARGS.month_to_grab
    automation(MONTH_TO_GRAB)
