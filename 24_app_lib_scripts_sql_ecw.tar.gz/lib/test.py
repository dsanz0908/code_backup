from email.utils import COMMASPACE, formatdate
send_to=["ssundararaman@somoscommunitycare.org","vjoshi@somoscommunitycare.org"]
print(COMMASPACE.join(send_to))
