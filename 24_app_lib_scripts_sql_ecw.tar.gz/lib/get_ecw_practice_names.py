import pandas as pd
import pyodbc

PRACTICE_QUERY = """
SELECT TOP 1 s.database_name, 
             m.physical_device_name 
FROM   msdb.dbo.backupset s 
       INNER JOIN msdb.dbo.backupmediafamily m 
               ON s.media_set_id = m.media_set_id 
WHERE  s.database_name = '{}' 
ORDER  BY backup_start_date DESC, 
          backup_finish_date
"""

SERVER_DICT = {
    '': 'SQL Server 2012 at 10.10.10.48',
    '_2016': 'SQL Server 2016 at 10.10.10.201',
    '_2017': 'SQL Server 2017 at 10.10.10.201'
}


def get_practice_names(conn_type):
    connection_string = "arcadia_sql_02{};uid=dev-etl;pwd=2aUK*BSy&z295sD"
    connection = pyodbc.connect(dsn=connection_string.format(conn_type))
    databases = get_database_names(connection)
    practices = []
    for database in databases:
        cursor = connection.execute(PRACTICE_QUERY.format(database))
        practices.append([[
            result_row[0], result_row[1].split('\\')[1], SERVER_DICT[conn_type]
        ] for result_row in cursor.fetchall()][0])
        cursor.close()
    return practices


def get_database_names(conn):
    database_query = "select name from master..sysdatabases where status = 2163712"
    cursor = conn.execute(database_query)
    database_names = [db[0] for db in cursor.fetchall()]
    cursor.close()
    return database_names


ALL_PRACTICES = pd.concat([
    pd.DataFrame.from_records(
        get_practice_names(version),
        columns=['Database Name', 'ECW Name', 'Location'])
    for version in ['', '_2016', '_2017']
])
ALL_PRACTICES.to_csv(
    '/home/etl/etl_home/output/20200102_ecw_practice_info.csv', index=False)
