from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc
import sys

filename = sys.argv[1]
arcadia_members = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_members_with_encounters.txt',
    sep='|',
    error_bad_lines=False,
    names=['pat_id', 'fname', 'lname', 'DOB', 'dos'])
filename_df = pd.read_csv(
    '/home/etl/etl_home/temp/{}'.format(filename),
    sep='|',
    error_bad_lines=False)
merged_df = pd.merge(arcadia_members, filename_df, on='DOB')
merged_list = merged_df.values.tolist()
pat_ids = []
for ml in merged_list:
    score = fuzz.WRatio('{},{}'.format(ml[2], ml[1]), ml[5])
    if score > 90:
        pat_ids.append(ml[0])

query = "select pat_first_name,pat_middle_name,pat_last_name,pat_race,pat_ethnicity,pat_language,pat_city,pat_zip,pat_phone_1,pat_phone_2,pat_date_of_birth,pat_sex,pat_medical_record_number,pat_address_1,pat_address_2 from t_patient where pat_id in ('{}') order by pat_last_name, pat_first_name"
final_query = query.format("','".join(pat_ids))
conn_arcadia = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)
rows = conn_arcadia.execute(final_query).fetchall()
df = pd.DataFrame.from_records(
    rows,
    columns=[
        'pat_first_name', 'pat_middle_name', 'pat_last_name', 'pat_race',
        'pat_ethnicity', 'pat_language', 'pat_city', 'pat_zip', 'pat_phone_1',
        'pat_phone_2', 'pat_date_of_birth', 'pat_sex',
        'pat_medical_record_number', 'pat_address_1', 'pat_address_2'
    ])
df.to_csv(
    '20200220_{}_members_from_arcadia.csv'.format(
        filename.replace('.txt', '')),
    index=False)
conn_arcadia.close()
