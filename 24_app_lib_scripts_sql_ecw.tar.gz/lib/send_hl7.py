import socket
import time

host = '40.143.139.138'
port = 4014
FILENAME = '/home/etl/etl_home/output/20190702_hl7_encounters_test.txt'
hl7 = open(FILENAME, 'r').read()
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((host,port))
    s.send(hl7)
    s.recv(1024)
    #s.send((bytes(hl7, 'latin-1')))
    #s.send((bytes(hl7, 'latin-1')))
    s.close()



"""
hl7 = open(FILENAME, 'r').read().split('MSH')
for j in ['MSH'+i for i in hl7[1:]]:
    s = socket.socket()
    s.connect((host,port))
    s.send(j)
    s.send('\r\n')
    s.close()
    time.sleep(2)


with open(FILENAME, 'r') as f:
    while True:
	read_data = f.read(1000).encode('utf-8')
	if not read_data:
	    break
	s.send(read_data)
        print read_data
print hl7
for i in hl7:
    print i
    s.send(i)
"""


