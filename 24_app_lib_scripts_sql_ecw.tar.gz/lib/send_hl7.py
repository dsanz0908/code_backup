import socket
import time

host = '40.143.139.138'
port = 4014
HF_SOCKET = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
HF_SOCKET.connect((host,port))
HF_SOCKET.send('hi')
#s.recv(1024)
HF_SOCKET.close()


