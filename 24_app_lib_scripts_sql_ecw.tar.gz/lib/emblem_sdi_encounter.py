# -*- coding: utf-8 -*-

from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

CORINTHIAN = pd.read_excel('20200107_emblem_corinthian_caregaps.xlsx')
CORINTHIAN['dob'] = CORINTHIAN['Member DOB'].dt.date.astype(str)
CIS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_cis.txt',
    sep='|',
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'npi', 'provider', 'specialty'
    ])
CIS['dob'] = CIS['pat_date_of_birth'].astype(str)
CIS_MERGED = pd.merge(
    CORINTHIAN[CORINTHIAN['Measure'].str.contains("Childhood")], CIS,
    on='dob').values.tolist()
CORINTHIAN_CIS_FINAL_LIST = []
for cis_item in CIS_MERGED:
    cis_score = fuzz.WRatio(cis_item[5], '{}, {}'.format(
        cis_item[19], cis_item[18]))
    print cis_score, cis_item[5], '{}, {}'.format(cis_item[19], cis_item[18])
    if cis_score > 90:
        CORINTHIAN_CIS_FINAL_LIST.append([
            cis_item[4], cis_item[18], cis_item[19], cis_item[17],
            int(cis_item[23]), cis_item[24], cis_item[25], cis_item[21],
            'Z12.31', cis_item[22]
        ])
pd.DataFrame(
    CORINTHIAN_CIS_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB',
        'Servicing Provider NPI', 'Servicing Provider Name',
        'Provider Specialty', 'DOS', 'Dx Codes', 'CPT Code'
    ]).to_csv(
        '20200109_emblem_corinthian_cis.txt', sep='|', index=False)
