# -*- coding: utf-8 -*-

from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

CORINTHIAN = pd.read_excel('20200107_emblem_balance_caregaps.xlsx')
CORINTHIAN['dob'] = CORINTHIAN['Member DOB'].dt.date.astype(str)
PRENATAL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_prenatal.txt',
    sep='|',
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'npi', 'provider', 'specialty'
    ])
PRENATAL['dob'] = PRENATAL['pat_date_of_birth'].astype(str)
PRENATAL_MERGED = pd.merge(
    CORINTHIAN[CORINTHIAN['Measure'].str.contains("Prenatal")], PRENATAL,
    on='dob').values.tolist()
CORINTHIAN_PRENATAL_FINAL_LIST = []
for prenatal_item in PRENATAL_MERGED:
    prenatal_score = fuzz.WRatio(prenatal_item[5], '{}, {}'.format(
        prenatal_item[19], prenatal_item[18]))
    print prenatal_score, prenatal_item[5], '{}, {}'.format(prenatal_item[19], prenatal_item[18])
    if prenatal_score > 90:
        CORINTHIAN_PRENATAL_FINAL_LIST.append([
            prenatal_item[4], prenatal_item[18], prenatal_item[19], prenatal_item[17],
            prenatal_item[23], prenatal_item[24], prenatal_item[25], prenatal_item[21],
            'Z12.31', prenatal_item[22]
        ])
pd.DataFrame(
    CORINTHIAN_PRENATAL_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB',
        'Servicing Provider NPI', 'Servicing Provider Name',
        'Provider Specialty', 'DOS', 'Dx Codes', 'CPT Code'
    ]).to_csv(
        '20200110_emblem_balance_prenatal.txt', sep='|', index=False)
