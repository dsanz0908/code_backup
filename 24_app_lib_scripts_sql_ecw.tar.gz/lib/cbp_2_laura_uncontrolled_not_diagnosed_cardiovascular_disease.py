import pyodbc
import pandas as pd
conn_arcadia=pyodbc.connect("dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL")
conn_somos=pyodbc.connect(dsn="somos_redshift_1")
months=[('20190601','20190630'),]
sql_pat_cin_tbl = """ 
create temporary table fuzz_test (
arcadia_name		varchar(255),
arcadia_dob			date,
arcadia_pat_id		varchar(100),
mco_name			varchar(255),
mco_dob       date,
mco_cin				varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));


copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';
"""
conn_somos.execute(sql_pat_cin_tbl)
pat_cin_sql= """
with cte_select as (select arcadia_pat_id,mco_cin,
case  when mco_source = 'Healthfirst Corinthian'  then 1
      when mco_source = 'Healthfirst Somos'  then 2
      when mco_source = 'WellCare Non Somos'  then 3
      when mco_source = 'Empire Somos'  then 4
      when mco_source = 'Anthem Corinthian'  then 5
      when mco_source = 'United Somos'  then 6
      when mco_source = 'Affinity Corinthian'  then 7
      when mco_source = 'Affinity Somos'  then 8
      when mco_source = 'nydoh'  then 9
      else 0
      END  AS SELECTED_SOURCE
from fuzz_test t2
WHERE SUBSTRING(MCO_CIN,1,2) ~ '[A-Z][A-Z]'
 ) ,
cte_min_selected as ( select arcadia_pat_id ,min(selected_source) as min_selected from cte_select  group by arcadia_pat_id ) ,

CTE_CIN AS ( SELECT CT1.ARCADIA_PAT_ID,MCO_CIN
  FROM CTE_SELECT CT1
  INNER JOIN
  CTE_MIN_SELECTED CT2
  ON CT1.ARCADIA_PAT_ID = CT2.ARCADIA_PAT_ID
  AND CT1.SELECTED_SOURCE = CT2.MIN_SELECTED  )
select * from cte_cin
"""
pat_cin_df=pd.read_sql(pat_cin_sql,conn_somos)
cbp_query="""
with cte_data_1 as (
	select distinct enc_id,t2.enc_patient_id,t2.enc_site_id, icd10_code as primary_icd_code
	from t_assessment t1 
	inner join t_encounter t2
	on t1.encounter_id = t2.enc_id
	where enc_timestamp between '{0}' and '{1}'
	and not exists ( select 1 from t_encounter i1, t_assessment i2 
					 where i1.enc_id = i2.encounter_id
					 and icd10_code in ( 'I13.10','I12.9','I11.9','I10' ,'I11.0','I11.9','I60','I69','I10','I12.0','I15','I15.8',
                     'I15.9','I15.2','010.11','I13.1','I15.1','I16.0','I16.1' )
					 and year(i1.enc_timestamp) = 2018
					 and t2.enc_patient_id = i1.enc_patient_id
					 ) ),

cte_icd as ( select patient_id,icd10_code as other_icd_code,cd.DESCRIPTION, ROW_NUMBER() over ( partition by patient_id order by assessment_date desc ) as rnumber
from t_assessment tas
inner join lookup.code cd
on tas.icd10_code = cd.code_value
and cd.code_set = 'ICD10'
where patient_id in ( select distinct enc_patient_id from cte_data_1 )
and   icd10_code not in ( 'I13.10', 'I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40','I50.41','I50.42','I50.43','I50.9','I50.1','I50.20','I50.21',
	'I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40','I50.41','I50.42','I50.43','I50.9','E78.4','E78.5','I09.2','I05.0','I06.0','I08.0','I07.0','I07.1','I07.2','I07.8',
	'I07.9','I09.0','I21.09','I25.2','I20.8', 'I25.10','I20.9','I21.09','I21.3','I25.10','I25.2','I25.84','I25.9','I10','I11.0','I11.9','I25.10','I48.91','I50.9','I63.9',
	'I65.23','I65.29','I67.2','I67.9','I73.9' ) ),

cte_data as (
select enc_id,pat_first_name,pat_last_name,pat_date_of_birth,pat_sex,site_Center_Name,prov_first_name,prov_last_name,prov_npi,prov_specialty_1,vitals_date,vitals_systolic,vitals_diastolic,person_id,primary_icd_code,
row_number() over ( partition by pat_first_name,pat_last_name,pat_date_of_birth  order by vitals_date desc )  as  rid,
t4.pat_id from cte_data_1 t1
inner join t_vitals t3
on t1.enc_id = t3.vitals_enc_id
inner join t_patient t4
on t1.enc_patient_id = t4.pat_id
inner join site_master t5
on t1.enc_site_id = t5.Site_ID
inner join provider_master t6
on t4.pat_responsible_provider_id = t6.prov_id
inner join mpi.person_patient t7
on t4.pat_id = t7.pat_id
and vitals_systolic > 139
and vitals_diastolic > 89
and t7.active_ind = 'Y' 
) , 

cte_2 as ( 
select distinct person_id,medicaid_id from mpi.person_member c1
	inner join plan_member c2
	on c1.member_id = c2.member_id
	where c1.active_ind = 'Y'
	and c2.delete_ind = 'N'
	and medicaid_id is not null ),

cte_3 as ( select pat_id,pat_first_name,pat_last_name,pat_date_of_birth,pat_sex,site_Center_Name,prov_first_name,prov_last_name,
prov_npi,prov_specialty_1,MAX(PRIMARY_ICD_CODE) AS PRIMARY_ICD_CODE,
MAX(vitals_date_1) as vitals_date_1,MAX(vitals_systolic_1) as vitals_systolic_1,MAX(vitals_diastolic_1) as vitals_diastolic_1,
MAX(vitals_date_2) as vitals_date_2,MAX(vitals_systolic_2) as vitals_systolic_2,MAX(vitals_diastolic_2) as vitals_diastolic_2,
MAX(icd_code_1) as ICD_CODE_1,MAX(ICD_DESCRIPTION_1) AS ICD_DESC_1, MAX(ICD_CODE_2) AS ICD_CODE_2 , MAX(ICD_DESCRIPTION_2) AS ICD_DESC_2, MAX(ICD_CODE_3) AS ICD_CODE_3, MAX(ICD_DESCRIPTION_3) AS ICD_DESC_3, 
MAX(ICD_CODE_4) AS ICD_CODE_4,MAX(ICD_DESCRIPTION_4) AS ICD_DESC_4,person_id
from (
select pat_id,pat_first_name,pat_last_name,pat_date_of_birth,pat_sex,site_Center_Name,prov_first_name,prov_last_name,prov_npi,
prov_specialty_1,person_id, 
case when rid = 1 then vitals_date end as vitals_date_1,
case when rid = 1 then vitals_systolic end as vitals_systolic_1,
case when rid = 1 then vitals_diastolic end as vitals_diastolic_1,
case when rid = 2 then vitals_date end as vitals_date_2,
case when rid = 2 then vitals_systolic end as vitals_systolic_2,
case when rid = 2 then vitals_diastolic end as vitals_diastolic_2,
primary_icd_code,
case when rnumber = 1 then other_icd_code else NULL end as icd_code_1,
case when rnumber = 2 then other_icd_code else NULL end as icd_code_2,
case when rnumber = 3 then other_icd_code else NULL end as icd_code_3,
case when rnumber = 4 then other_icd_code else NULL end as icd_code_4,
case when rnumber = 1 then description else NULL end as icd_description_1,
case when rnumber = 2 then description else NULL end as icd_description_2,
case when rnumber = 3 then description else NULL end as icd_description_3,
case when rnumber = 4 then description else NULL end as icd_description_4
from cte_data t1 
left outer join cte_icd t2
on t1.pat_id = t2.patient_id
where rid in (1,2)
and rnumber <= 4) a
group by pat_first_name,pat_last_name,pat_date_of_birth,pat_sex,site_Center_Name,prov_first_name,prov_last_name,prov_npi,prov_specialty_1,person_id,pat_id )

select cte_3.*,medicaid_id 
from cte_3 
left outer join cte_2 ct2
on cte_3.person_id = ct2.person_id
order by 1
"""
def func(row):
    if row["mco_cin"] is not None and row["medicaid_id"] is None:
        return row["mco_cin"]
    else:
        return row["medicaid_id"]

for month in months:
    adf=pd.read_sql(cbp_query.format(month[0],month[1]),conn_arcadia)
    mdf=adf.merge(pat_cin_df,how="left",left_on=["pat_id"],right_on=["arcadia_pat_id"])
    mdf["mcin"]=mdf.apply(func,axis=1)
    mdf.drop(columns=["medicaid_id","arcadia_pat_id","mco_cin"],inplace=True)
    writer = pd.ExcelWriter('/home/etl/etl_home/Reports/cbp_2_uncontrolled_non_cardiovascular_' + month[0] + '_' + month[1] + '.xlsx')
    mdf.to_excel(writer,'sheet1',index=False)
    writer.save()
