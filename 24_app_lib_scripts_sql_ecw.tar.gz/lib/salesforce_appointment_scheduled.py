from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)
FUZZ_QUERY = """
create temporary table fuzz_test (
arcadia_name		varchar(255),
arcadia_dob			date,
arcadia_pat_id		varchar(100),
mco_name			varchar(255),
mco_dob       date,
mco_cin				varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';
"""

DIRECT_MATCH = """
create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
removequotes
MAXERROR 100
region 'us-east-1'
dateformat 'auto'
delimiter  ',';
"""

APPOINTMENT_QUERY = """
SELECT DISTINCT arcadia_pat_id, 
                t1.id
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) t1 
       INNER JOIN salesforce_patients t3 
               ON t3.contact_id_18_characters__c = t1.whoid 
       INNER JOIN (SELECT pat_id,
                          policy_nbr
                   FROM   direct_match
                   UNION
                   SELECT arcadia_pat_id,
                          mco_cin
                   FROM   fuzz_test)
               ON policy_nbr = cin__c
       INNER JOIN fuzz_test t4 
               ON cin__c = mco_cin 
WHERE  status NOT IN ( 'Closed', 'Completed', 'Completed - Awaiting Claim Submission', 
                       'Completed - Awaiting Coding Correction', 
                       'Pending - Appointment Scheduled', 
                       'Issue - Patient refused' )
       AND t1.project_end_date__c LIKE '2020-06-30%' 
       AND cin__c != '' 
       AND rn = 1 
"""

ARC_QUERY = """
SELECT pat_id, min(cast(appt_date as date)) as appt_date
FROM   t_appointment t1 
       INNER JOIN t_patient t2 
               ON t1.appt_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
       INNER JOIN provider_master t3 
               ON t1.appt_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
       INNER JOIN site_master t4 
               ON t1.appt_orig_site_id = t4.site_orig_site_id 
                  AND t4.site_delete_ind = 'N' 
       INNER JOIN location_master t5 
               ON t1.appt_location_id = t5.location_id 
                  AND t5.activeind = 'Y' 
WHERE  appt_delete_ind = 'N' 
       AND appt_date BETWEEN Getdate() AND '20200630' 
       group by pat_id
"""

CONNECTION.execute(FUZZ_QUERY)
CONNECTION.execute(DIRECT_MATCH)
DF_REDSHIFT = pd.read_sql(APPOINTMENT_QUERY, CONNECTION)
DF_ARCADIA = pd.read_sql(ARC_QUERY, CONNECTION_ARCADIA)
DF = DF_REDSHIFT.merge(
    DF_ARCADIA, how="inner", left_on="arcadia_pat_id", right_on="pat_id")
DF.drop(labels=["pat_id", "arcadia_pat_id"], axis=1, inplace=True)
DF['appt_date'] = DF['appt_date'].astype(str)
TODAY = datetime.now().strftime("%Y%m%d")
sf, instance_url = getSession()
for task_id in DF.values.tolist():
    print task_id
    try:
        sf.Task.update(
            task_id[0], {
                'status':
                'Pending - Appointment Scheduled',
                'appointment_scheduled_for__c': task_id[1],
                'Care_Gap_Comments_Part_2__c':
                "{} automated - appointment scheduled".format(TODAY)
            })
    except Exception as e:
        print task_id, str(e)
