import shlex
import csv
import argparse

if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(
        description='Convert Space Delimited File to CSV')
    PARSER.add_argument('filepath_in', action='store', help='TXT filepath')
    PARSER.add_argument('filepath_out', action='store', help='CSV filepath')
    ARGS = PARSER.parse_args()
    FILE_LIST = []
    with open(ARGS.filepath_in, 'r') as opened_file:
        ROWS = opened_file.readlines()

    for row in ROWS:
        FILE_LIST.append(list(shlex.shlex(row)))

    with open(ARGS.filepath_out, "wb") as opened_zip_file:
        WRITER = csv.writer(opened_zip_file)
        WRITER.writerows(FILE_LIST)
