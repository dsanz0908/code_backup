from datetime import datetime
import pandas as pd
import pyodbc
from fuzzywuzzy import fuzz

CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)

sf = """
SELECT DISTINCT full_name__c, 
                To_date(birthdate, 'YYYY-MM-DD') as birthdate, 
                Replace(Replace(Replace(Replace(phone, '-', ''), '(', ''), ')', ''), ' ', '') AS phone 
FROM   salesforce_patients 
       JOIN (SELECT *, 
                    Row_number() 
                      OVER ( 
                        partition BY id 
                        ORDER BY added_tz DESC) AS rn 
             FROM   salesforce_tasks) AS salesforce_tasks 
         ON salesforce_patients.id = whoid 
WHERE  rn = 1 
       AND cin__c != '' 
       AND status = 'Issue - Phone wrong/disconnected/out of service' 
       AND salesforce_tasks.isdeleted = 'FALSE' 
       AND salesforce_tasks.project_end_date__c LIKE '2019-12-31%' 
       AND pilot_initiative__c = 'TRUE' 
"""

arc = """
SELECT DISTINCT Concat(pat_first_name, ' ', pat_middle_name, ' ', pat_last_name) AS NAME, 
                Cast(pat_date_of_birth AS DATE) as birthdate, 
                pat_phone_1 
FROM   t_patient 
"""

a = pd.read_sql(sf, CONNECTION)
b = pd.read_sql(arc, CONNECTION_ARCADIA)
c = a.merge(b, on='birthdate')
d = c.values.tolist()
e = []
for i in d:
    score = fuzz.WRatio(i[0], i[3])
    if score > 86:
        e.append(i)
f = pd.DataFrame(
    e, columns=['sf_name', 'dob', 'sf_phone', 'arcadia_name', 'arcadia_phone'])
f.to_csv('20191217_sf_arcadia_phones.csv', index=False)

CONNECTION.close
CONNECTION_ARCADIA.close()
