from time import time
from fuzzywuzzy import fuzz
import pyodbc

conn = pyodbc.connect(dsn="somos_redshift_1")
demo_new_elig_query = """
    SELECT * 
    FROM   (SELECT DISTINCT pat_f_name, 
			    pat_l_name, 
			    pat_birthdate :: DATE AS pat_birthdate, 
			    primary_ins_subscriber_no, 
			    npi_1 
	    FROM   etl_new.demo_new 
	    WHERE  filename LIKE '%DY4Q4%' 
		   AND tomorrow >= '2019-04-02' 
		   AND ( pat_birthdate = '01/01/1111' 
			  OR Regexp_instr(primary_ins_subscriber_no, '[A-Za-z][A-Za-z][0-9][0-9][0-9][0-9][0-9][A-Za-z]') = 
			     0 
			  OR Len(primary_ins_subscriber_no) <> 8 )) AS a 
	   join (SELECT DISTINCT member_first_name, 
				 member_last_name, 
				 member_dob :: DATE AS member_dob, 
				 medicaid_id, 
				 pcp_npi 
		 FROM   (SELECT *, 
				Row_number() 
				  over ( 
				    PARTITION BY medicaid_id 
				    ORDER BY received_month DESC) AS rn 
			 FROM   reference.sed 
			 WHERE  Regexp_instr(medicaid_id, '[A-Za-z][A-Za-z][0-9][0-9][0-9][0-9][0-9][A-Za-z]') = 1 
				AND Len(medicaid_id) = 8) 
		 WHERE  rn = 1 
			AND member_first_name IS NOT NULL) AS b 
	     ON pat_birthdate = member_dob 
"""

cursor = conn.execute(demo_new_elig_query)
results = cursor.fetchall()
cursor.close()
count = 0

for i, result in enumerate(results):
    try:
	#if i % 100000 == 0:
	#    print i, time()
	demo_name = ' '.join(result[:2])
	elig_name = ' '.join(result[5:7])
	score = fuzz.WRatio(demo_name, elig_name)
	if score > 90:
            count += 1
    except:
        pass
print count
