from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce
"""
MY5 = 2018-07-01 to 2019-06-30
MY6 = 2019-07-01 to 2020-06-30

run SQL query recall_my6_accesstocare_open.sql
"""

COPY_QUERY = """
create temp table recall_my6_accesstocare_open (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_address varchar(255),
pat_city varchar(255),
pat_state varchar(255),
pat_zip varchar(255),
phone varchar(255),
dob date,
pat_sex varchar(255),
prov_npi varchar(255),
prov_first_name varchar(255),
prov_last_name varchar(255),
measure varchar(255));
                
copy recall_my6_accesstocare_open
from 's3://sftp_test/recall_my6_accesstocare_open.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';
"""

ADD_PATIENTS_QUERY = """
SELECT * 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY policy_nbr 
                   ORDER BY payer DESC) AS rn 
        FROM   (SELECT DISTINCT to_char(dob, 'YYYY-MM-DD') as dob, 
                                policy_nbr, 
                                salesforce_providers.contact_assigned_chw__c, 
                                pat_first_name, 
                                pat_last_name, 
                                CASE 
                                  WHEN payer ILIKE '%affinity%' THEN 'Affinity' 
                                  WHEN payer ILIKE '%united%' THEN 'United Healthcare' 
                                  WHEN payer ILIKE '%fidelis%' THEN 'Fidelis' 
                                  WHEN payer ILIKE '%healthfirst%' 
                                        OR payer ILIKE '%health first%' THEN 'Healthfirst' 
                                  WHEN payer ILIKE '%anthem%' 
                                        OR payer ILIKE '%empire%' THEN 'Anthem' 
                                  WHEN payer ILIKE '%metroplus%' 
                                        OR payer ILIKE '%metro plus%' THEN 'Metroplus' 
                                  WHEN payer ILIKE '%wellcare%' 
                                        OR payer ILIKE '%well care%' THEN 'Metroplus' 
                                  WHEN payer ILIKE '%wellcare%' 
                                        OR payer ILIKE '%well care%' THEN 'Metroplus' 
                                  ELSE '' 
                                END AS payer, 
                                pat_sex, 
                                pat_address, 
                                pat_city, 
                                pat_zip, 
                                a.phone, 
                                pat_state, 
                                salesforce_providers.id, 
                                '012f4000000MBgDAAW' 
                FROM   recall_my6_accesstocare_open AS a 
                       INNER JOIN (SELECT pat_id, 
                                          policy_nbr, 
                                          payer 
                                   FROM   direct_match 
                                   UNION 
                                   SELECT arcadia_pat_id, 
                                          mco_cin, 
                                          mco_source 
                                   FROM   fuzz_test) AS b 
                               ON a.pat_id = b.pat_id 
                       LEFT JOIN salesforce_patients 
                              ON policy_nbr = salesforce_patients.cin__c 
                       JOIN salesforce_providers 
                         ON prov_npi = individual_npi__c 
                WHERE  salesforce_patients.cin__c IS NULL 
                       AND Regexp_substr(policy_nbr, '[A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][A-Z]') <> '' 
                       AND Len(policy_nbr) = 8 
                       AND NOT EXISTS (SELECT 1 
                                       FROM   salesforce_patients 
                                       WHERE  ( policy_nbr = salesforce_patients.cin__c ) 
                                               OR ( dob = birthdate 
                                                    AND Lower(pat_last_name) = Lower(lastname) ))))
WHERE  rn = 1
"""

READD_QUERY = """
SELECT DISTINCT contact_assigned_chw__c,
                measure,
                id,
                pcp__c,
                '012f4000000BsVeAAK'         AS recordtypeid,
                ''                           AS procedure,
                'Recall Access (MY6)'        AS subject,
                '2020-06-30'                 AS project_end_date__c,
                '20200130 recall access my6' AS source_created_by__c,
                'Open'                       AS status
FROM   recall_my6_accesstocare_open AS a
       INNER JOIN (SELECT pat_id,
                          policy_nbr,
                          payer
                   FROM   direct_match
                   UNION
                   SELECT arcadia_pat_id,
                          mco_cin,
                          mco_source
                   FROM   fuzz_test) AS b
               ON a.pat_id = b.pat_id
       JOIN salesforce_patients
         ON policy_nbr = cin__c where cin__c not in ('N/A', '0') and trim(pcp__c) <> '' and createddate >= '2020-01-29'
"""


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


SF, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect('dsn=somos_redshift_1')
CONNECTION.execute(COPY_QUERY)
READD_TASKS = CONNECTION.execute(READD_QUERY).fetchall()
CONNECTION.close()
"""
ADD_PATIENTS_TEMP = CONNECTION.execute(ADD_PATIENTS_QUERY).fetchall()
ADD_PATIENTS = [p[:14] for p in ADD_PATIENTS_TEMP]
PATIENTS_COLUMNS = ['birthdate','cin__c','contact_assigned_chw__c','firstname','lastname','health_plan_carriers__c','gender__c','mailingstreet','mailingcity','mailingpostalcode','phone','mailingstate','pcp__c','recordtypeid']
PATIENTS = []
for patient in ADD_PATIENTS:
    PATIENTS.append(dict(zip(PATIENTS_COLUMNS, patient)))
    if len(PATIENTS) == 10000:
        SF.bulk.Contact.insert(PATIENTS)
        PATIENTS = []
SF.bulk.Contact.insert(PATIENTS)

"""

TASK_COLUMNS = [
    'ownerid', 'measure__c', 'whoid', 'pcp__c', 'recordtypeid', 'procedure__c',
    'subject', 'project_end_date__c', 'source_created_by__c', 'status'
]
TASKS = []
for task in READD_TASKS:
    TASKS.append(dict(zip(TASK_COLUMNS, task)))
    if len(TASKS) == 10000:
        SF.bulk.Task.insert(TASKS)
        TASKS = []
SF.bulk.Task.insert(TASKS)
