from datetime import datetime
import requests
import pandas as pd
import os
import pyodbc
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


connection = pyodbc.connect('dsn=somos_redshift_1')
query = """
WITH a 
     AS (SELECT DISTINCT whoid 
         FROM   (SELECT *, 
                        Row_number() 
                          OVER ( 
                            partition BY id 
                            ORDER BY added_tz DESC) AS rn 
                 FROM   salesforce_tasks) salesforce_tasks 
         WHERE  status IN ( 'Closed', 'Completed', 'Completed - Awaiting Claim Submission', 'Completed - Awaiting Coding Correction' )
                AND salesforce_tasks.project_end_date__c ILIKE '2019-12-31%' 
                AND rn = 1 
                AND measure__c ILIKE '%access%' 
                AND isdeleted = 'FALSE') 
SELECT distinct case when isactive = 'TRUE' then ownerid else '005f40000041BB1AAM' end, replace(measure__c, '?', '-'), salesforce_tasks.whoid, pcp__c, recordtypeid, case when status ilike '%access%' then 'Recall Access (2020)' else 'Recall Screening (2020)' end, '2020-06-30',
trunc(getdate()) || ' automated - recall upload', 'Open'
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) salesforce_tasks 
       JOIN a 
         ON salesforce_tasks.whoid = a.whoid 
       JOIN salesforce_users 
         ON ownerid = salesforce_users.id 
WHERE  ( ( status IN ( 'Closed', 'Completed', 'Completed - Awaiting Claim Submission', 'Completed - Awaiting Coding Correction' )
           AND measure__c ILIKE '%access%' ) 
          OR ( status = 'Open' 
               AND measure__c ILIKE '%screen%' ) ) 
       AND salesforce_tasks.project_end_date__c ILIKE '2019-12-31%' 
       AND rn = 1 
       AND isdeleted = 'FALSE'
"""

#rows = connection.execute(query).fetchall()
connection.close()
sf, INSTANCE_URL = getSession()

todelete_query = "select id from task where subject like '%2020%'"
rows = sf.query_all(todelete_query)['records']
tasks = []
for row in rows:
    tasks.append({'Id': row['Id']})
sf.bulk.task.delete(tasks)

"""
for row in rows:
    sf.task.create({
        'ownerid': row[0],
        'measure__c': row[1],
        'whoid': row[2],
        'pcp__c': row[3],
        'recordtypeid': row[4],
        'subject': row[5],
        'project_end_date__c': row[6],
        'source_created_by__c': row[7],
        'status': row[8],
        'procedure__c': ''
    })
"""
