from datetime import datetime
import requests
import pandas as pd
import os
import pyodbc
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


connection = pyodbc.connect('dsn=somos_redshift_1')
query = """
WITH a 
     AS (SELECT DISTINCT whoid 
         FROM   (SELECT *, 
                        Row_number() 
                          OVER ( 
                            partition BY id 
                            ORDER BY added_tz DESC) AS rn 
                 FROM   salesforce_tasks) salesforce_tasks 
         WHERE  status IN ( 'Closed', 'Completed', 'Completed - Awaiting Claim Submission', 'Completed - Awaiting Coding Correction' )
                AND salesforce_tasks.project_end_date__c ILIKE '2019-12-31%' 
                AND rn = 1 
                AND measure__c ILIKE '%access%' 
                AND isdeleted = 'FALSE') 
SELECT distinct case when isactive = 'TRUE' then ownerid else '005f40000041BB1AAM' end, replace(measure__c, '?', '-'), salesforce_tasks.whoid, pcp__c, recordtypeid, case when status ilike '%access%' then 'Recall Access (2020)' else 'Recall Screening (2020)' end, '2020-06-30',
trunc(getdate()) || ' automated - recall upload', 'Open'
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) salesforce_tasks 
       JOIN a 
         ON salesforce_tasks.whoid = a.whoid 
       JOIN salesforce_users 
         ON ownerid = salesforce_users.id 
WHERE  ( ( status IN ( 'Closed', 'Completed', 'Completed - Awaiting Claim Submission', 'Completed - Awaiting Coding Correction' )
           AND measure__c ILIKE '%access%' ) 
          OR ( status = 'Open' 
               AND measure__c ILIKE '%screen%' ) ) 
       AND salesforce_tasks.project_end_date__c ILIKE '2019-12-31%' 
       AND rn = 1 
       AND isdeleted = 'FALSE'
"""

query = """
WITH cte_a 
     AS (SELECT cin__c, 
                measure__c, 
                Count(*) 
         FROM   (SELECT *, 
                        Row_number() 
                          OVER ( 
                            partition BY salesforce_tasks.id 
                            ORDER BY added_tz DESC) AS rn 
                 FROM   salesforce_tasks) AS salesforce_tasks 
                JOIN salesforce_patients 
                  ON salesforce_patients.id = whoid 
         WHERE  salesforce_tasks.project_end_date__c = '2020-06-30' 
                AND rn = 1 
                AND salesforce_tasks.isdeleted = 'FALSE' 
         GROUP  BY 1, 
                   2 
         HAVING Count(*) > 1) 
SELECT DISTINCT id 
FROM   (SELECT salesforce_tasks.id, 
               cte_a.cin__c, 
               cte_a.measure__c, 
               salesforce_tasks.createddate, 
               Row_number() 
                 OVER ( 
                   partition BY cte_a.cin__c, cte_a.measure__c 
                   ORDER BY salesforce_tasks.createddate) AS r 
        FROM   salesforce_tasks 
               JOIN salesforce_patients 
                 ON salesforce_patients.id = whoid 
               JOIN cte_a 
                 ON salesforce_patients.cin__c = cte_a.cin__c 
                    AND salesforce_tasks.measure__c = cte_a.measure__c 
        WHERE  salesforce_tasks.project_end_date__c = '2020-06-30') 
WHERE  r > 1 
"""
#rows = connection.execute(query).fetchall()
connection.close()
sf, INSTANCE_URL = getSession()

todelete_query = "select id from task where project_end_date__c = 2020-06-30 and care_gap_comments_part_2__c like '%appointment%' and appointment_scheduled_for__c > 2001-01-01"
rows = sf.query_all(todelete_query)['records']
print len(rows)
tasks = []
for row in rows:
    tasks.append({'Id': row['Id'], 'Status': 'Open', 'care_gap_comments_part_2__c': ''})
#sf.bulk.task.update(tasks)

"""
for row in rows:
    sf.task.create({
        'ownerid': row[0],
        'measure__c': row[1],
        'whoid': row[2],
        'pcp__c': row[3],
        'recordtypeid': row[4],
        'subject': row[5],
        'project_end_date__c': row[6],
        'source_created_by__c': row[7],
        'status': row[8],
        'procedure__c': ''
    })
"""



"""
select dob, policy_nbr, salesforce_providers.contact_assigned_chw__c, pat_first_name, pat_last_name, payer, *
FROM   recall_my6_accesstocare_open AS a
       INNER JOIN (SELECT pat_id,
                          policy_nbr,
                          payer
                   FROM   direct_match
                   UNION
                   SELECT arcadia_pat_id,
                          mco_cin,
                          mco_source
                   FROM   fuzz_test) AS b
               ON a.pat_id = b.pat_id
       LEFT JOIN salesforce_patients
         ON policy_nbr = salesforce_patients.cin__c 
       join salesforce_providers on prov_npi = individual_npi__c          
where salesforce_patients.cin__c is null and Regexp_substr(policy_nbr, '[A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][A-Z]') <> '' and len(policy_nbr) = 8
and not exists (select 1 from salesforce_patients where policy_nbr = salesforce_patients.cin__c)
"""
