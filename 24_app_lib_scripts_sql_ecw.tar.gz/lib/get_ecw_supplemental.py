import pandas as pd
import pyodbc

SERVER_DICT = {
    '': 'SQL Server 2012 at 10.10.10.48',
    '_2016': 'SQL Server 2016 at 10.10.10.201',
    '_2017': 'SQL Server 2017 at 10.10.10.201'
}

DIAGNOSES_QUERY = """
SELECT DISTINCT subscriberno, 
                Cast(enc.date AS DATE) AS date, 
                npi, 
                code 
FROM   db_nyshmp..enc 
       JOIN db_nyshmp..diagnosis 
         ON enc.encounterid = diagnosis.encounterid 
       JOIN db_nyshmp..items 
         ON diagnosis.itemid = items.itemid 
       JOIN db_nyshmp..icd 
         ON items.itemname = icd.longdesc 
       JOIN db_nyshmp..insurancedetail 
         ON insurancedetail.pid = enc.patientid 
       JOIN db_nyshmp..doctors 
         ON doctors.doctorid = enc.doctorid 
WHERE  Year(enc.date) = 2019 
       AND codetype = 10 
       AND validto IS NULL 
       AND insid = 8 
       AND insurancedetail.deleteflag = 0 
       AND subscriberno <> '' 
ORDER  BY subscriberno, 
          npi, 
          date, 
          code
"""

def get_diagnoses():
    connection_string = "arcadia_sql_02;uid=dev-etl;pwd=2aUK*BSy&z295sD"
    connection = pyodbc.connect(dsn=connection_string)
    diagnoses = pd.read_sql(DIAGNOSES_QUERY, connection)
    a = diagnoses.groupby('subscriberno')
    print a

def get_database_names(conn):
    database_query = "select name from master..sysdatabases where status = 2163712"
    cursor = conn.execute(database_query)
    database_names = [db[0] for db in cursor.fetchall()]
    cursor.close()
    return database_names

get_diagnoses()
