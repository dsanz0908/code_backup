import pyodbc
import datetime
from html import HTML


def get_max_encounter_dates(conn_type):
    connection_string = "arcadia_sql_02{};uid=dev-etl;pwd=2aUK*BSy&z295sD"
    connection = pyodbc.connect(dsn=connection_string.format(conn_type))
    databases = get_database_names(connection)
    encounter_dates = {}
    for database in databases:
        encounter_dates[database] = get_dates(connection, database)
    return encounter_dates


def get_database_names(conn):
    database_query = "select name from master..sysdatabases where status = 2163712"
    cursor = conn.execute(database_query)
    database_names = [db[0] for db in cursor.fetchall()]
    cursor.close()
    return database_names


def get_dates(conn, db):
    max_encounter_date_query = """
    SELECT Max(d) 
    FROM   (SELECT date AS d 
	    FROM   {}..enc 
	    WHERE  date <= Getdate() 
	    GROUP  BY date 
	    HAVING Count(*) > 10) AS table1 
    """.format(db)
    cursor = conn.execute(max_encounter_date_query)
    max_encounter = cursor.fetchone()[0]
    cursor.close()
    return max_encounter


if __name__ == '__main__':
    FILE = open("/home/etl/etl_home/Reports/encounter_report.html", "w")
    HTML = HTML()
    TABLE = HTML.table(
        style=
        'font-family:Calibri;font-size:100%;width:150%;display:block;overflow:auto;-webkit-print-color-adjust:exact;'
    )
    ROW = TABLE.tr(
        style="background-color:#e3e0cc;font-size:80%;text-align: center;")
    ROW.td("SQL SERVER VERSION")
    ROW.td("DATABASE NAME")
    ROW.td("LATEST ENCOUNTER DATE")
    ROW_COUNT = 0

    SQL_SERVER_VERSIONS = {}
    SQL_SERVER_VERSIONS['2012'] = get_max_encounter_dates("")
    SQL_SERVER_VERSIONS['2016'] = get_max_encounter_dates("_2016")
    SQL_SERVER_VERSIONS['2017'] = get_max_encounter_dates("_2017")
    for sql_server_version, db_data in sorted(SQL_SERVER_VERSIONS.items()):
        for db_name, max_date in sorted(db_data.items()):
            ROW = TABLE.tr(
                style="background-color:white;font-size:80%;text-align: center;"
            )
            ROW.td(sql_server_version)
            ROW.td(db_name)
            gap = datetime.datetime.now() - max_date
            if gap.days > 7:
                ROW.td(
                    max_date.strftime("%Y-%m-%d"),
                    style='background-color:#B22222;')
            else:
                ROW.td(max_date.strftime("%Y-%m-%d"))
            ROW_COUNT += 1

    HEADER = '''<head><link href="check.css" rel="stylesheet"></head><body>     <h3>ENCOUNTER REPORT</h3>
        <div class="content">
        <div class="sidebar">
          <ul>
            <li><a href="ecw_status.html">ECW Status</a></li>
            <li><a href="engagement.html">Engagement Files Status</a></li>
            <li><a href="inventory.html">Redshift Inventory Status</a></li>
            <li><a href="encounter_report.html">Encounter Report</a></li>
          </ul>

          <div class="logo">
            <img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
          </div>
        </div>'''
    FOOTER = '''<br><center><p style="font-family:'Calibri';font-size:125%">Total: ''' + str(
        ROW_COUNT
    ) + '''<br><p style="font-family:'Calibri';font-size:125%">Time of latest report: ''' + datetime.datetime.now(
    ).strftime("%Y-%m-%d %H:%M:%S") + '''</p></center><br><br>'''
    FILE.write(HEADER + str(TABLE) + FOOTER)
    FILE.close()
