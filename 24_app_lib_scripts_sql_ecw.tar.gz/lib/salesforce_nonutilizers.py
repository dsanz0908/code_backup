from datetime import datetime
import requests
import pandas as pd
import pyodbc
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': "ssundararaman@optimusha.com",
        'password': "OptimusSomos1yDsjYPT1d9QJYnq9n6UKdkG97"
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
CONNECTION_CDW = pyodbc.connect(dsn="claims_dw")
CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)
FUZZ_QUERY = """
create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';
"""


SALESFORCE_CINS_QUERY = """
SELECT DISTINCT salesforce_tasks.id, 
                cin__c 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY salesforce_tasks.id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) AS salesforce_tasks 
       INNER JOIN salesforce_patients 
               ON contact_id_18_characters__c = whoid 
WHERE  rn = 1 
       AND measure__c = 'Non-Utilizer' 
       AND status <> 'Closed'
"""

CDW_IDS_QUERY = """
SELECT DISTINCT member_cin as cin__c
FROM   fact_claims
       JOIN dim_membership
         ON fact_claims.local_member_id = dim_membership.local_member_id
WHERE  service_start_date >= '2017-11-01'
UNION
SELECT DISTINCT member_cin
FROM   fact_claims
       JOIN dim_membership
         ON fact_claims.local_member_id = dim_membership.local_member_id
WHERE  service_start_date >= '2017-11-01'
UNION
SELECT DISTINCT member_cin
FROM   fact_claims
       JOIN dim_membership
         ON fact_claims.local_member_id = dim_membership.local_member_id
WHERE  service_start_date >= '2017-11-01'
"""

SALESFORCE_ARCADIA_IDS_QUERY = """
SELECT DISTINCT salesforce_tasks.id, 
                arcadia_pat_id 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY salesforce_tasks.id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) AS salesforce_tasks 
       INNER JOIN salesforce_patients 
               ON contact_id_18_characters__c = whoid 
       INNER JOIN fuzz_test 
               ON mco_cin = cin__c 
WHERE  rn = 1 
       AND measure__c = 'Non-Utilizer' 
       AND status <> 'Closed' 
       AND status NOT ILIKE 'completed%'
"""

ARCADIA_IDS_QUERY = """
SELECT DISTINCT enc_patient_id AS arcadia_pat_id 
FROM   t_encounter 
WHERE  enc_delete_ind = 'N' 
       AND enc_timestamp >= '2017-11-01' 
"""

sf, instance_url = getSession()
CONNECTION.execute(FUZZ_QUERY)
SALESFORCE_ARCADIA_IDS = pd.read_sql(SALESFORCE_ARCADIA_IDS_QUERY, CONNECTION)
ARCADIA_IDS = pd.read_sql(ARCADIA_IDS_QUERY, CONNECTION_ARCADIA)
COMPLETED_TASK_IDS = pd.merge(SALESFORCE_ARCADIA_IDS, ARCADIA_IDS, on='arcadia_pat_id').id.tolist()
print len(COMPLETED_TASK_IDS)
"""
for row in COMPLETED_TASK_IDS:
    try:
        sf.Task.update(
            row, {
                'status':
                'Completed - Awaiting Claim Submission',
                'Care_Gap_Comments_Part_2__c':
                '20191031 automated from non-utilizers in ehr data'
            })
    except Exception as e:
        print row, str(e)

SALESFORCE_CINS = pd.read_sql(SALESFORCE_CINS_QUERY, CONNECTION)
CDW_IDS = pd.read_sql(CDW_IDS_QUERY, CONNECTION_CDW)
CLOSED_TASK_IDS = pd.merge(SALESFORCE_CINS, CDW_IDS, on='cin__c').id.tolist()
for row in CLOSED_TASK_IDS:
    try:
	sf.Task.update(
	    row, {
		'status':
		'Closed',
		'closed_by_source__c':
		'20191031 automated from non-utilizers in claims data'
	    })
    except Exception as e:
	print row, str(e)
"""
