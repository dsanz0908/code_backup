# -*- coding: utf-8 -*-

import sys
from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

EXCEL = sys.argv[1]
SHEETS = pd.ExcelFile(EXCEL)
DFS = {
    sheet_name: SHEETS.parse(sheet_name)
    for sheet_name in SHEETS.sheet_names
}
FULL = pd.merge(DFS['Score Detail'], DFS['HEDIS 2020 GIC Detail'], on='HCID')
MMS = FULL.loc[FULL['NUMERATOR'] == 0]
MMS['MEM_DOB_x'] = pd.to_datetime(MMS['MEM_DOB_x'], errors='coerce')
MMS['dob'] = MMS['MEM_DOB_x'].dt.date.astype(str)
MMS.fillna('', inplace=True)

ABA = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_aba.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'icd'
    ])
ABA['dob'] = ABA['pat_date_of_birth'].astype(str)
ABA_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("ABA")], ABA, on='dob').values.tolist()
MMS_ABA_FINAL_LIST = []

for aba_item in ABA_MERGED:
    aba_score = fuzz.WRatio('{} {}'.format(aba_item[2], aba_item[3]),
                            '{}, {}'.format(aba_item[93], aba_item[94]))
    if aba_score > 90:
        MMS_ABA_FINAL_LIST.append(
            [aba_item[1]] + aba_item[18:23] + aba_item[24:29] +
            [aba_item[38]] + [aba_item[35]] + [aba_item[40]] + aba_item[96:98])

DF_ABA = pd.DataFrame(
    MMS_ABA_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'ICD  DxPri'
    ])

BCS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_bcs.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
BCS['dob'] = BCS['pat_date_of_birth'].astype(str)
BCS_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("BCS")], BCS, on='dob').values.tolist()

MMS_BCS_FINAL_LIST = []

for bcs_item in BCS_MERGED:
    bcs_score = fuzz.WRatio('{} {}'.format(bcs_item[2], bcs_item[3]),
                            '{}, {}'.format(bcs_item[93], bcs_item[94]))
    if bcs_score >= 90:
        MMS_BCS_FINAL_LIST.append(
            [bcs_item[1]] + bcs_item[18:23] + bcs_item[24:29] +
            [bcs_item[38]] + [bcs_item[35]] + [bcs_item[40]] + bcs_item[96:98])

DF_BCS = pd.DataFrame(
    MMS_BCS_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'Procedure'
    ])

CBP = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_cbp.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos',
        'systolic', 'diastolic', 'cpt1', 'cpt2', 'rn'
    ])
CBP['dob'] = CBP['pat_date_of_birth'].astype(str)
CBP_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("CBP")], CBP, on='dob').values.tolist()

MMS_CBP_FINAL_LIST = []

for cbp_item in CBP_MERGED:
    cbp_score = fuzz.WRatio('{} {}'.format(cbp_item[2], cbp_item[3]),
                            '{}, {}'.format(cbp_item[93], cbp_item[94]))
    if cbp_score >= 90:
        MMS_CBP_FINAL_LIST.append([cbp_item[1]] + cbp_item[18:23] +
                                  cbp_item[24:29] + [cbp_item[38]] +
                                  [cbp_item[35]] + [cbp_item[40]] +
                                  cbp_item[96:101])

DF_CBP = pd.DataFrame(
    MMS_CBP_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service',
        'Systolic Blood Pressure', 'Diastolic Blood Pressure',
        'Procedure', 'CVX Code'
    ])

DF_CBP = DF_CBP[DF_CBP['Systolic Blood Pressure'] < 140]
DF_CBP = DF_CBP[DF_CBP['Diastolic Blood Pressure'] < 90]

EYE = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_eye.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
EYE['dob'] = EYE['pat_date_of_birth'].astype(str)
EYE_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("Eye")], EYE, on='dob').values.tolist()

MMS_EYE_FINAL_LIST = []

for eye_item in EYE_MERGED:
    eye_score = fuzz.WRatio('{} {}'.format(eye_item[2], eye_item[3]),
                            '{}, {}'.format(eye_item[93], eye_item[94]))
    if eye_score >= 90:
        MMS_EYE_FINAL_LIST.append(
            [eye_item[1]] + eye_item[18:23] + eye_item[24:29] +
            [eye_item[38]] + [eye_item[35]] + [eye_item[40]] + eye_item[96:98])

DF_EYE = pd.DataFrame(
    MMS_EYE_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'Procedure'
    ])

A1C = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_a1c.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'result'
    ])
A1C['dob'] = A1C['pat_date_of_birth'].astype(str)
A1C_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("A1c")], A1C, on='dob').values.tolist()

MMS_A1C_FINAL_LIST = []

for a1c_item in A1C_MERGED:
    a1c_score = fuzz.WRatio('{} {}'.format(a1c_item[2], a1c_item[3]),
                            '{}, {}'.format(a1c_item[93], a1c_item[94]))
    if a1c_score >= 90:
        MMS_A1C_FINAL_LIST.append(
            [a1c_item[1]] + a1c_item[18:23] + a1c_item[96:98] + ['%'])

DF_A1C = pd.DataFrame(
    MMS_A1C_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Date of Service', 'Result_Value', 'Units'
    ])

DF_A1C = DF_A1C[DF_A1C['Result_Value'].convert_objects(
    convert_numeric=True) <= 9]

NEPHROPATHY = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_nephropathy.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
NEPHROPATHY['dob'] = NEPHROPATHY['pat_date_of_birth'].astype(str)
NEPHROPATHY_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("Nephro")], NEPHROPATHY,
    on='dob').values.tolist()

MMS_NEPHROPATHY_FINAL_LIST = []

for nephropathy_item in NEPHROPATHY_MERGED:
    nephropathy_score = fuzz.WRatio(
        '{} {}'.format(nephropathy_item[2], nephropathy_item[3]),
        '{}, {}'.format(nephropathy_item[93], nephropathy_item[94]))
    if nephropathy_score >= 90:
        MMS_NEPHROPATHY_FINAL_LIST.append(
            [nephropathy_item[1]] + nephropathy_item[18:23] +
            nephropathy_item[24:29] + [nephropathy_item[38]] +
            [nephropathy_item[35]] + [nephropathy_item[40]] +
            nephropathy_item[96:98])

DF_NEPHROPATHY = pd.DataFrame(
    MMS_NEPHROPATHY_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'Procedure'
    ])

FUNCTIONAL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_functional.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
FUNCTIONAL['dob'] = FUNCTIONAL['pat_date_of_birth'].astype(str)
FUNCTIONAL_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("COA_FSA")], FUNCTIONAL,
    on='dob').values.tolist()

MMS_FUNCTIONAL_FINAL_LIST = []

for functional_item in FUNCTIONAL_MERGED:
    functional_score = fuzz.WRatio(
        '{} {}'.format(functional_item[2], functional_item[3]),
        '{}, {}'.format(functional_item[93], functional_item[94]))
    if functional_score >= 90:
        MMS_FUNCTIONAL_FINAL_LIST.append(
            [functional_item[1]] + functional_item[18:23] +
            functional_item[24:29] + [functional_item[38]] +
            [functional_item[35]] + [functional_item[40]] +
            functional_item[96:98])

DF_FUNCTIONAL = pd.DataFrame(
    MMS_FUNCTIONAL_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'Procedure'
    ])

PAIN = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_pain.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
PAIN['dob'] = PAIN['pat_date_of_birth'].astype(str)
PAIN_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("COA_PS")], PAIN,
    on='dob').values.tolist()

MMS_PAIN_FINAL_LIST = []

for pain_item in PAIN_MERGED:
    pain_score = fuzz.WRatio('{} {}'.format(pain_item[2], pain_item[3]),
                             '{}, {}'.format(pain_item[93], pain_item[94]))
    if pain_score >= 90:
        MMS_PAIN_FINAL_LIST.append([pain_item[1]] + pain_item[18:23] +
                                   pain_item[24:29] + [pain_item[38]] +
                                   [pain_item[35]] + [pain_item[40]] +
                                   pain_item[96:98])

DF_PAIN = pd.DataFrame(
    MMS_PAIN_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'Procedure'
    ])

MEDICATIONREVIEW = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_medicationreview.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
MEDICATIONREVIEW['dob'] = MEDICATIONREVIEW['pat_date_of_birth'].astype(str)
MEDICATIONREVIEW_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("COA_MR")], MEDICATIONREVIEW,
    on='dob').values.tolist()

MMS_MEDICATIONREVIEW_FINAL_LIST = []

for medicationreview_item in MEDICATIONREVIEW_MERGED:
    medicationreview_score = fuzz.WRatio(
        '{} {}'.format(medicationreview_item[2], medicationreview_item[3]),
        '{}, {}'.format(medicationreview_item[93], medicationreview_item[94]))
    if medicationreview_score >= 90:
        MMS_MEDICATIONREVIEW_FINAL_LIST.append(
            [medicationreview_item[1]] + medicationreview_item[18:23] +
            medicationreview_item[24:29] + [medicationreview_item[38]] +
            [medicationreview_item[35]] + [medicationreview_item[40]] +
            medicationreview_item[96:98])

DF_MEDICATIONREVIEW = pd.DataFrame(
    MMS_MEDICATIONREVIEW_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'Procedure'
    ])

COL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_col.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
COL['dob'] = COL['pat_date_of_birth'].astype(str)
COL_MERGED = pd.merge(
    MMS[MMS['MEASURE'].str.contains("COL")], COL, on='dob').values.tolist()

MMS_COL_FINAL_LIST = []

for col_item in COL_MERGED:
    col_score = fuzz.WRatio('{} {}'.format(col_item[2], col_item[3]),
                            '{}, {}'.format(col_item[93], col_item[94]))
    if col_score >= 90:
        MMS_COL_FINAL_LIST.append(
            [col_item[1]] + col_item[18:23] + col_item[24:29] +
            [col_item[38]] + [col_item[35]] + [col_item[40]] + col_item[96:98])

DF_COL = pd.DataFrame(
    MMS_COL_FINAL_LIST,
    columns=[
        'Medicare HIC', 'Medicaid ID', 'Member Last Name', 'Member First Name',
        'DOB', 'Gender', 'Address 1', 'Address 2', 'City', 'State', 'Zipcode',
        'Rendering Provider Name', 'Rendering Provider NPI',
        'Rendering Provider Specialty 1', 'Date of Service', 'Procedure'
    ])

DF = pd.concat([
    DF_ABA, DF_BCS, DF_CBP, DF_EYE, DF_NEPHROPATHY, DF_FUNCTIONAL,
    DF_PAIN, DF_MEDICATIONREVIEW
],
               ignore_index=True)
DF['Place of Service'] = '11'

final_columns = [
    'Line of Business', 'Member ID', 'Medicare HIC', 'Medicaid ID',
    'Member Last Name', 'Member First Name', 'Address 1', 'Address 2', 'City',
    'State', 'Zipcode', 'Gender', 'DOB', 'Rendering Provider Name',
    'Rendering Provider NPI', 'Rendering Provider Tax ID ',
    'Provider License Number', 'Rendering Provider Specialty 1',
    'Rendering Provider Specialty 2', 'Date of Service', 'ICD  DxPri',
    'ICD-DxSec1', 'ICD-DxSec2', 'ICD-DxSec3', 'ICD-DxSec4', 'ICD-DxSec5',
    'ICD-DxSec6', 'ICD-DxSec7', 'ICD-DxSec8', 'Procedure', 'CVX Code',
    'Place of Service', 'Height', 'Height Measurement Unit', 'Weight',
    'Weight Measurement Unit', 'Systolic Blood Pressure',
    'Diastolic Blood Pressure', 'Miscellaneous 1', 'Miscellaneous 2'
]

DF['DOB'] = pd.to_datetime(DF['DOB']).apply(lambda x: x.strftime('%m/%d/%Y'))
DF['Date of Service'] = pd.to_datetime(
    DF['Date of Service']).apply(lambda x: x.strftime('%m/%d/%Y'))

DF = DF.reindex(
    final_columns, axis=1).to_csv(
        '20200220_anthem_medicare_sdi_encounter.txt', index=False, sep='|')

lab_columns = ['Line of Business','Member ID','Medicare HIC','Medicaid ID','Member Last Name','Member First Name','Gender','DOB','Provider_Group','Lab Provider Name','Date of Service','LOINC','CPT ','Result_Value','Units','Test_Name ','Ordering Provider NPI','Miscellaneous','Miscellaneous2']

DF_LAB = pd.concat([DF_A1C], ignore_index=True)

DF_LAB['Date of Service'] = pd.to_datetime(
    DF_LAB['Date of Service']).apply(lambda x: x.strftime('%m/%d/%Y'))
DF_LAB = DF_LAB.reindex(
    lab_columns, axis=1).to_csv(
        '20200220_anthem_medicare_sdi_lab.txt', index=False, sep='|')


