import pandas as pd
import pyodbc
from dateutil.relativedelta import relativedelta
from statsmodels.tsa.arima_model import ARIMA
import warnings
warnings.simplefilter(action='ignore')

CONNECTION_CDW = pyodbc.connect(dsn="claims_dw")
ALL = []

QUERY = """
SELECT top 10000 *
FROM   (SELECT local_provider_id,
               local_product_id,
               'Source' as type_,
               source as value,
               effective_date,
               SUM(membership_month_count) AS member_months
        FROM   fact_eligibility
        GROUP  BY 1,2,3,4,5
        UNION
        SELECT local_provider_id,
               local_product_id,
               'Age',
               Datediff(year, member_dob, effective_date) :: text,
               effective_date,
               SUM(membership_month_count)
        FROM   fact_eligibility
               join dim_membership
                 ON fact_eligibility.local_member_id = dim_membership.local_member_id
        GROUP  BY 1,2,3,4,5
        UNION
        SELECT local_provider_id,
               local_product_id,
               'Zipcode',
               member_zip :: text,
               effective_date,
               SUM(membership_month_count)
        FROM   fact_eligibility
               join dim_membership
                 ON fact_eligibility.local_member_id = dim_membership.local_member_id
        GROUP  BY 1,2,3,4,5
        UNION
        SELECT local_provider_id,
               local_product_id,
               'Sex',
               member_sex :: text,
               effective_date,
               SUM(membership_month_count)
        FROM   fact_eligibility
               join dim_membership
                 ON fact_eligibility.local_member_id = dim_membership.local_member_id
        GROUP  BY 1,2,3,4,5
        UNION
        SELECT local_provider_id,
               local_product_id,
               'local_provider_org_id',
               local_provider_org_id :: text,
               effective_date,
               SUM(membership_month_count)
        FROM   fact_eligibility
        GROUP  BY 1,2,3,4,5)
WHERE  effective_date >= '2017-01-01' and type_ is not null and trim(type_) <> ''
ORDER  BY 2,1,3,4
"""

RESULTS = pd.read_sql(QUERY, CONNECTION_CDW)
FIELDS = RESULTS.groupby(
    ['local_provider_id', 'local_product_id', 'type_', 'value'],
    as_index=False).first()[[
        'local_provider_id', 'local_product_id', 'type_', 'value'
    ]].values.tolist()

for local_provider_id, local_product_id, type_, value in FIELDS:
    rows = RESULTS[(RESULTS['local_provider_id'] == local_provider_id)
                   & (RESULTS['local_product_id'] == local_product_id) &
                   (RESULTS['type_'] == type_) & (RESULTS['value'] == value)]
    start_date = rows['effective_date'].max() - relativedelta(months=6)
    end_date = start_date + relativedelta(months=19)
    forecast_temp = pd.DataFrame(
        pd.date_range(start_date, end_date, freq='MS'),
        columns=['effective_date'])
    forecast_temp['effective_date'] = forecast_temp['effective_date'].dt.date
    forecast_temp.insert(0, 'local_provider_id', local_provider_id)
    forecast_temp.insert(0, 'local_product_id', local_product_id)
    forecast_temp.insert(0, 'type_', type_)
    forecast_temp.insert(0, 'value', value)
    X = rows[['effective_date', 'member_months']]
    X.set_index('effective_date', inplace=True)
    try:
        model = ARIMA(X, order=(1, 1, 0))
        model_fit = model.fit(disp=0)
    except:
        continue
    output = model_fit.forecast(steps=20)
    forecast_dates = pd.concat([
        forecast_temp,
        pd.DataFrame(data=output[0], columns=['member_months'])
    ],
                               axis=1)
    forecast_dates['state'] = 'forecast'
    rows['state'] = 'real'
    df = rows.append(forecast_dates)
    df.loc[df['member_months'] < 0.0, 'member_months'] = 0.0
    df_accuracy_1 = df[df.duplicated(subset='effective_date', keep=False)]
    df_accuracy = pd.merge(
        df_accuracy_1[df_accuracy_1['state'] == 'real'],
        df_accuracy_1[df_accuracy_1['state'] == 'forecast'],
        on='effective_date')
    df_accuracy['percentage'] = (
        abs(df_accuracy['member_months_x'] - df_accuracy['member_months_y']) *
        100) / df_accuracy['member_months_x']
    score = 100 - df_accuracy.percentage.mean()
    if score > 90:
        ALL.append(forecast_dates)

ALL_DF = pd.concat(ALL)
ALL_DF['member_months'] = ALL_DF['member_months'].fillna(0).round().astype(int)
del ALL_DF['state']
ALL_DF.to_sql(
    con=CONNECTION_CDW,
    name='forecast_provider_membermonths',
    index=False,
    if_exists='replace')
