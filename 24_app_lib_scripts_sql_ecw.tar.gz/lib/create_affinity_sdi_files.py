# -*- coding: utf-8 -*-

import sys
from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

EXCEL = sys.argv[1]
MMS = pd.read_excel(EXCEL)
MMS['Member DOB'] = pd.to_datetime(MMS['Member DOB'], errors='coerce')
MMS['dob'] = MMS['Member DOB'].dt.date.astype(str)
MMS.fillna('', inplace=True)

NPI = pd.read_csv('../temp/affinity_provider_id_npi.txt', sep='|')
NPI['Servicing Provider NPI'] = NPI['Servicing Provider NPI'].astype(int)
MMS = pd.merge(MMS, NPI, on='Affinity Practitioner ID', how='left')

BCS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_bcs.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
BCS['dob'] = BCS['pat_date_of_birth'].astype(str)
BCS_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains(
        "Breast Cancer Screening")],
    BCS,
    on='dob').values.tolist()
MMS_BCS_FINAL_LIST = []

for i, j in enumerate(BCS_MERGED[0]):
    print i, j

for bcs_item in BCS_MERGED:
    bcs_score = fuzz.WRatio('{} {}'.format(bcs_item[2], bcs_item[3]),
                            '{}, {}'.format(bcs_item[45], bcs_item[46]))
    if bcs_score > 90:
        MMS_BCS_FINAL_LIST.append(bcs_item[:9] + [bcs_item[44]] +
                                  [bcs_item[38], bcs_item[48], bcs_item[49]])

DF_BCS = pd.DataFrame(
    MMS_BCS_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'CPT code'
    ])

CCS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_ccs.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
CCS['dob'] = CCS['pat_date_of_birth'].astype(str)
CCS_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains(
        "Cervical Cancer Screening")],
    CCS,
    on='dob').values.tolist()
MMS_CCS_FINAL_LIST = []

for ccs_item in CCS_MERGED:
    ccs_score = fuzz.WRatio('{} {}'.format(ccs_item[2], ccs_item[3]),
                            '{}, {}'.format(ccs_item[45], ccs_item[46]))
    if ccs_score > 90:
        MMS_CCS_FINAL_LIST.append(ccs_item[:9] + [ccs_item[44]] +
                                  [ccs_item[38], ccs_item[48], ccs_item[49]])

DF_CCS = pd.DataFrame(
    MMS_CCS_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'CPT code'
    ])

CHL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_chl.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
CHL['dob'] = CHL['pat_date_of_birth'].astype(str)
CHL_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains(
        "Colorectal Cancer Screening")],
    CHL,
    on='dob').values.tolist()
MMS_CHL_FINAL_LIST = []

for chl_item in CHL_MERGED:
    chl_score = fuzz.WRatio('{} {}'.format(chl_item[2], chl_item[3]),
                            '{}, {}'.format(chl_item[45], chl_item[46]))
    if chl_score > 90:
        MMS_CHL_FINAL_LIST.append(chl_item[:9] + [chl_item[44]] +
                                  [chl_item[38], chl_item[48], chl_item[49]])

DF_CHL = pd.DataFrame(
    MMS_CHL_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'CPT code'
    ])

COL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_col.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
COL['dob'] = COL['pat_date_of_birth'].astype(str)
COL_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains(
        "Colorectal Cancer Screening")],
    COL,
    on='dob').values.tolist()
MMS_COL_FINAL_LIST = []

for col_item in COL_MERGED:
    col_score = fuzz.WRatio('{} {}'.format(col_item[2], col_item[3]),
                            '{}, {}'.format(col_item[45], col_item[46]))
    if col_score > 90:
        MMS_COL_FINAL_LIST.append(col_item[:9] + [col_item[44]] +
                                  [col_item[38], col_item[48], col_item[49]])

DF_COL = pd.DataFrame(
    MMS_COL_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'CPT code'
    ])
EYE = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_eye.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
EYE['dob'] = EYE['pat_date_of_birth'].astype(str)
EYE_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains("Eye")],
    EYE,
    on='dob').values.tolist()
MMS_EYE_FINAL_LIST = []

for eye_item in EYE_MERGED:
    eye_score = fuzz.WRatio('{} {}'.format(eye_item[2], eye_item[3]),
                            '{}, {}'.format(eye_item[45], eye_item[46]))
    if eye_score > 90:
        MMS_EYE_FINAL_LIST.append(eye_item[:9] + [eye_item[44]] +
                                  [eye_item[38], eye_item[48], eye_item[49]])

DF_EYE = pd.DataFrame(
    MMS_EYE_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'CPT code'
    ])

A1C = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_a1c.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'result'
    ])
A1C['dob'] = A1C['pat_date_of_birth'].astype(str)
A1C_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains("A1c")],
    A1C,
    on='dob').values.tolist()
MMS_A1C_FINAL_LIST = []

for a1c_item in A1C_MERGED:
    a1c_score = fuzz.WRatio('{} {}'.format(a1c_item[2], a1c_item[3]),
                            '{}, {}'.format(a1c_item[45], a1c_item[46]))
    if a1c_score > 90:
        MMS_A1C_FINAL_LIST.append(a1c_item[:9] + [a1c_item[44]] +
                                  [a1c_item[38], a1c_item[48], a1c_item[49]])

DF_A1C = pd.DataFrame(
    MMS_A1C_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'Result value 1'
    ])
DF_A1C = DF_A1C[DF_A1C['Result value 1'].convert_objects(
    convert_numeric=True) <= 9]

CBP = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_cbp.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos',
        'systolic', 'diastolic', 'cpt1', 'cpt2', 'rn'
    ])
CBP['dob'] = CBP['pat_date_of_birth'].astype(str)
CBP_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains(
        "Controlling High Blood Pressure")],
    CBP,
    on='dob').values.tolist()
MMS_CBP_FINAL_LIST = []

for cbp_item in CBP_MERGED:
    cbp_score = fuzz.WRatio('{} {}'.format(cbp_item[2], cbp_item[3]),
                            '{}, {}'.format(cbp_item[45], cbp_item[46]))
    if cbp_score > 90:
        MMS_CBP_FINAL_LIST.append(cbp_item[:9] + [cbp_item[44]] +
                                  [cbp_item[38]] + cbp_item[48:53])

DF_CBP = pd.DataFrame(
    MMS_CBP_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'Result value 1', 'Result value 2', 'CPT code', 'CPT II code'
    ])

DF_CBP = DF_CBP[DF_CBP['Result value 1'] < 144]
DF_CBP = DF_CBP[DF_CBP['Result value 2'] < 90]

WCC = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_wcc.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
WCC['dob'] = WCC['pat_date_of_birth'].astype(str)
WCC_MERGED = pd.merge(
    MMS[MMS['Test/Screening name or Clinical Parameter'].str.contains(
        "Weight Assessment and Counseling")],
    WCC,
    on='dob').values.tolist()
MMS_WCC_FINAL_LIST = []

for wcc_item in WCC_MERGED:
    wcc_score = fuzz.WRatio('{} {}'.format(wcc_item[2], wcc_item[3]),
                            '{}, {}'.format(wcc_item[45], wcc_item[46]))
    if wcc_score > 90:
        MMS_WCC_FINAL_LIST.append(wcc_item[:9] + [wcc_item[44]] +
                                  [wcc_item[38], wcc_item[48], wcc_item[49]])

DF_WCC = pd.DataFrame(
    MMS_WCC_FINAL_LIST,
    columns=[
        'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
        'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
        'Affinity Practitioner ID', 'Servicing Provider NPI',
        'Test/Screening name or Clinical Parameter', 'Date of service',
        'CPT code'
    ])

DF = pd.concat(
    [DF_BCS, DF_CCS, DF_CHL, DF_COL, DF_EYE, DF_A1C, DF_CBP, DF_WCC],
    ignore_index=True)

DF = pd.concat([DF_BCS, DF_CCS, DF_COL], ignore_index=True)
DF['Place of service'] = '11'
DF['ICD Version Indicator'] = '0'

final_columns = [
    'Source ID', 'Member ID', 'Member Last  Name', 'Member First Name',
    'Secondary Member ID', 'Member SSN', 'Member DOB', 'Member Gender',
    'Affinity Practitioner ID', 'Servicing Provider NPI',
    'Servicing Provider Name', 'Servicing Zip Code', 'Place of service',
    'Date of service', 'Primary Diagnosis Code', 'Secondary Diagnosis Code1',
    'Secondary Diagnosis Code2', 'Secondary Diagnosis Code3',
    'Secondary Diagnosis Code4', 'Secondary Diagnosis Code5',
    'Secondary Diagnosis Code6', 'Secondary Diagnosis Code7',
    'Secondary Diagnosis Code8', 'Secondary Diagnosis Code9',
    'PrincipalProcedureCode', 'Other Procedure Code1', 'Other Procedure Code2',
    'Other Procedure Code3', 'Other Procedure Code4', 'Other Procedure Code5',
    'Other Procedure Code6', 'Other Procedure Code7', 'Other Procedure Code8',
    'Other Procedure Code9', 'ICD Version Indicator', 'CPT code',
    'CPT II code', 'LOINC code', 'Test/Screening name or Clinical Parameter',
    'Result name (for labs)', 'Result value 1', 'Result value 2', 'Result unit'
]

DF['Member ID'] = DF['Member ID'].astype(str).str.zfill(11)
DF['Affinity Practitioner ID'] = DF['Affinity Practitioner ID'].astype(
    str).str.zfill(12)

DF = DF.reindex(final_columns, axis=1).to_csv('abc2.csv', index=False)
