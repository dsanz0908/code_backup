import requests

ICD_CHAPTER_WEBSITE = "https://icd.codes/icd10cm/chapter{}"

if __name__ == '__main__':
    for chapter in range(1,17):
        chapter_link = ICD_CHAPTER_WEBSITE.format(str(chapter))
        
