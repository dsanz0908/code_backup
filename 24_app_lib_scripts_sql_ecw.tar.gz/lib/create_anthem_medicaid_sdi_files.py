# -*- coding: utf-8 -*-

import sys
from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

def create_df_lab_result(file_string, measure_string, units):
    measure = pd.read_csv(
        '/home/etl/etl_home/temp/arcadia_{}.txt'.format(file_string),
        sep='|',
        index_col=False,
        names=[
            'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos',
            'result'
        ])
    measure['dob'] = measure['pat_date_of_birth'].astype(str)
    measure['dos2'] = pd.to_datetime(
        measure['dos'], errors='coerce').dt.strftime("%m/%d/%Y")
    measure_MERGED = pd.merge(
        MMS[MMS['Measure'].str.contains(measure_string)], measure,
        on='dob').values.tolist()

    MMS_measure_FINAL_LIST = []

    for measure_item in measure_MERGED:
        measure_score = fuzz.WRatio(
            measure_item[6], '{}, {}'.format(measure_item[35],
                                             measure_item[34]))
        if measure_score > 90:
            MMS_measure_FINAL_LIST.append(
                [measure_item[5]] + measure_item[6].split(',') +
                [measure_item[7]] + [measure_item[10]] + [measure_item[33]] +
                measure_item[38:40] + [units, measure_string])

    DF_measure = pd.DataFrame(
        MMS_measure_FINAL_LIST,
        columns=[
            'member_id', 'member_last_name', 'member_first_name', 'gender',
            'lob', 'dob', 'result_value',
            'date_of_service', 'result_units', 'test_name'
        ])
    return DF_measure

def create_df_enc_proc(file_string, measure_string):
    measure = pd.read_csv(
        '/home/etl/etl_home/temp/arcadia_{}.txt'.format(file_string),
        sep='|',
        index_col=False,
        names=[
            'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos',
            'cpt'
        ])
    measure['dob'] = measure['pat_date_of_birth'].astype(str)
    measure['dos2'] = pd.to_datetime(
        measure['dos'], errors='coerce').dt.strftime("%m/%d/%Y")
    measure_MERGED = pd.merge(
        MMS[MMS['Measure'].str.contains(measure_string)], measure,
        on='dob').values.tolist()

    MMS_measure_FINAL_LIST = []

    for measure_item in measure_MERGED:
        measure_score = fuzz.WRatio(
            measure_item[6], '{}, {}'.format(measure_item[35],
                                             measure_item[34]))
        if measure_score > 90:
            MMS_measure_FINAL_LIST.append(
                [measure_item[5]] + measure_item[6].split(',') +
                [measure_item[7]] + [measure_item[10]] + measure_item[12:16] +
                [measure_item[19]] + measure_item[21:23] + [measure_item[33]] +
                measure_item[38:40])

    DF_measure = pd.DataFrame(
        MMS_measure_FINAL_LIST,
        columns=[
            'member_id', 'member_last_name', 'member_first_name', 'gender',
            'lob', 'address_1', 'city', 'state', 'zipcode',
            'rendering_provider_name', 'rendering_provider_npi',
            'rendering_provider_specialty_1', 'dob', 'procedure_cd',
            'date_of_service'
        ])
    return DF_measure


def create_df_enc_diag(file_string, measure_string):
    measure = pd.read_csv(
        '/home/etl/etl_home/temp/arcadia_{}.txt'.format(file_string),
        sep='|',
        index_col=False,
        names=[
            'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos',
            'icd'
        ])
    measure['dob'] = measure['pat_date_of_birth'].astype(str)
    measure['dos2'] = pd.to_datetime(
        measure['dos'], errors='coerce').dt.strftime("%m/%d/%Y")
    measure_MERGED = pd.merge(
        MMS[MMS['Measure'].str.contains(measure_string)], measure,
        on='dob').values.tolist()

    MMS_measure_FINAL_LIST = []

    for measure_item in measure_MERGED:
        measure_score = fuzz.WRatio(
            measure_item[6], '{}, {}'.format(measure_item[35],
                                             measure_item[34]))
        if measure_score > 90:
            MMS_measure_FINAL_LIST.append(
                [measure_item[5]] + measure_item[6].split(',') +
                [measure_item[7]] + [measure_item[10]] + measure_item[12:16] +
                [measure_item[19]] + measure_item[21:23] + [measure_item[33]] +
                measure_item[38:40])

    DF_measure = pd.DataFrame(
        MMS_measure_FINAL_LIST,
        columns=[
            'member_id', 'member_last_name', 'member_first_name', 'gender',
            'lob', 'address_1', 'city', 'state', 'zipcode',
            'rendering_provider_name', 'rendering_provider_npi',
            'rendering_provider_specialty_1', 'dob', 'icd_dx_pri',
            'date_of_service'
        ])
    return DF_measure


def create_df_enc_both(file_string, measure_string):
    measure = pd.read_csv(
        '/home/etl/etl_home/temp/arcadia_{}.txt'.format(file_string),
        sep='|',
        index_col=False,
        names=[
            'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos',
            'cpt', 'icd'
        ])
    measure['dob'] = measure['pat_date_of_birth'].astype(str)
    measure['dos2'] = pd.to_datetime(
        measure['dos'], errors='coerce').dt.strftime("%m/%d/%Y")
    measure_MERGED = pd.merge(
        MMS[MMS['Measure'].str.contains(measure_string)], measure,
        on='dob').values.tolist()

    MMS_measure_FINAL_LIST = []

    for measure_item in measure_MERGED:
        measure_score = fuzz.WRatio(
            measure_item[6], '{}, {}'.format(measure_item[35],
                                             measure_item[34]))
        if measure_score > 90:
            MMS_measure_FINAL_LIST.append(
                [measure_item[5]] + measure_item[6].split(',') +
                [measure_item[7]] + [measure_item[10]] + measure_item[12:16] +
                [measure_item[19]] + measure_item[21:23] + [measure_item[33]] +
                measure_item[38:41])

    DF_measure = pd.DataFrame(
        MMS_measure_FINAL_LIST,
        columns=[
            'member_id', 'member_last_name', 'member_first_name', 'gender',
            'lob', 'address_1', 'city', 'state', 'zipcode',
            'rendering_provider_name', 'rendering_provider_npi',
            'rendering_provider_specialty_1', 'dob', 'procedure_cd',
            'icd_dx_pri', 'date_of_service'
        ])
    return DF_measure


def create_df_enc_cbp():
    cbp = pd.read_csv(
        '/home/etl/etl_home/temp/arcadia_cbp.txt',
        sep='|',
        index_col=False,
        names=[
            'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos',
            'systolic', 'diastolic', 'cpt1', 'cpt2', 'rn'
        ])
    cbp['dob'] = cbp['pat_date_of_birth'].astype(str)
    cbp['dos2'] = pd.to_datetime(
        cbp['dos'], errors='coerce').dt.strftime("%m/%d/%Y")
    cbp_MERGED = pd.merge(
        MMS[MMS['Measure'].str.contains('CBP')], cbp,
        on='dob').values.tolist()

    MMS_cbp_FINAL_LIST = []

    for cbp_item in cbp_MERGED:
        cbp_score = fuzz.WRatio(cbp_item[6], '{}, {}'.format(
            cbp_item[35], cbp_item[34]))
        if cbp_score > 90:
            MMS_cbp_FINAL_LIST.append(
                [cbp_item[5]] + cbp_item[6].split(',') + [cbp_item[7]] +
                [cbp_item[10]] + cbp_item[12:16] + [cbp_item[19]] +
                cbp_item[21:23] + [cbp_item[33]] + cbp_item[38:40] +
                ['/'.join(cbp_item[40:42])] + [cbp_item[43]])

    DF_cbp = pd.DataFrame(
        MMS_cbp_FINAL_LIST,
        columns=[
            'member_id', 'member_last_name', 'member_first_name', 'gender',
            'lob', 'address_1', 'city', 'state', 'zipcode',
            'rendering_provider_name', 'rendering_provider_npi',
            'rendering_provider_specialty_1', 'dob', 'systolic_blood_pressure',
            'diastolic_blood_pressure', 'procedure_cd', 'date_of_service'
        ])
    DF_cbp = DF_cbp[DF_cbp['systolic_blood_pressure'] < 140]
    DF_cbp = DF_cbp[DF_cbp['diastolic_blood_pressure'] < 90]
    return DF_cbp


EXCEL = sys.argv[1]
MMS = pd.read_excel(EXCEL, skiprows=[0])

MMS = MMS.loc[MMS['NUMERCNT'] == 0]
MMS['DOB'] = pd.to_datetime(MMS['DOB'], errors='coerce')
MMS['dob'] = MMS['DOB'].dt.date.astype(str)
MMS['dob2'] = MMS['DOB'].dt.strftime("%m/%d/%Y")
MMS['Member Key'] = MMS['Member Key'].astype(int)
MMS['PCP Provider NPI'] = MMS['PCP Provider NPI'].astype(int)
MMS.fillna('', inplace=True)

"""
DF_BCS = create_df_enc_proc('bcs', 'BCS')
DF_CHL = create_df_enc_proc('chl', 'CHL')
DF_NEPHROPATHY = create_df_enc_proc('nephropathy', 'Neph')
DF_CIS = create_df_enc_proc('cis', 'Combo 3')
DF_ABA = create_df_enc_diag('aba', 'ABA')
DF_ART = create_df_enc_both('art', 'ART')
DF_WCC = create_df_enc_both('wcc', 'WCC')
DF_W15 = create_df_enc_both('w15', 'W15')
DF_AWC = create_df_enc_both('awc', 'AWC')
DF_W34 = create_df_enc_both('w34', 'W34')
DF_CCS = create_df_enc_both('ccs', 'CCS')

DF = pd.concat([
    DF_BCS, DF_CHL, DF_ART, DF_NEPHROPATHY, DF_CIS, DF_ABA, DF_WCC, DF_W15,
    DF_AWC, DF_W34, DF_CCS
],
               ignore_index=True)

DF_AAP = create_df_enc_both('aap', 'AAP')
DF_CAP = create_df_enc_both('cap', 'CAP')
DF_APM = create_df_enc_both('apm', 'APM')
DF_CBP = create_df_enc_cbp()

DF = pd.concat([DF_AAP, DF_CAP, DF_APM, DF_CBP], ignore_index=True)

DF['place_of_service'] = '11'

final_columns = [
    'lob', 'member_id', 'medicare_hic', 'medicaid_id', 'member_last_name',
    'member_first_name', 'address_1', 'address_2', 'city', 'state', 'zipcode',
    'gender', 'dob', 'rendering_provider_name', 'rendering_provider_npi',
    'rendering_provider_tax_id', 'rendering_provider_license_number',
    'rendering_provider_specialty_1', 'rendering_provider_specialty_2',
    'date_of_service', 'icd_dx_pri', 'icd_dx_sec_1', 'icd_dx_sec_2',
    'icd_dx_sec_3', 'icd_dx_sec_4', 'icd_dx_sec_5', 'icd_dx_sec_6',
    'icd_dx_sec_7', 'icd_dx_sec_8', 'procedure_cd', 'cvx_code',
    'place_of_service', 'height', 'height_measurement_unit', 'weight',
    'weight_measurement_unit', 'systolic_blood_pressure',
    'diastolic_blood_pressure', 'miscellaneous_1', 'miscellaneous_2',
    'emr_name'
]

DF = DF.reindex(
    final_columns, axis=1).to_csv(
        'Anthem_EMR_CORINTHIAN_2020_02_25.txt', index=False, sep='|')

"""

lab_columns = ['lob','member_id','medicare_hic','medicaid_id','member_last_name','member_first_name','gender','dob','provider_group','lab_provider_name','date_of_service','loinc_code','cpt','result_value','result_units','test_name','provider_npi','misc_1','misc_2']

DF_A1C = create_df_lab_result('a1c', 'A1c', '%') 
DF_A1C = DF_A1C[DF_A1C['result_value'].convert_objects(
    convert_numeric=True) <= 9]

DF_LAB = pd.concat([DF_A1C], ignore_index=True)

DF_LAB = DF_LAB.reindex(
    lab_columns, axis=1).to_csv(
        'Anthem_LAB_SOMOS_2020_02_25.txt', index=False, sep='|')

