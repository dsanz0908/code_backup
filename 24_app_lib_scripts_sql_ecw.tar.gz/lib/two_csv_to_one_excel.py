import sys
from pyexcel.cookbook import merge_all_to_a_book

if __name__ == '__main__':
    CSV_FILE_1 = sys.argv[1]
    CSV_FILE_2 = sys.argv[2]
    EXCEL_NAME = sys.argv[3]
    print [CSV_FILE_1, CSV_FILE_2]
    merge_all_to_a_book([CSV_FILE_1, CSV_FILE_2], EXCEL_NAME)

