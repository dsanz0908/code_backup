import datetime
import pytz
import sys
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
from fuzzywuzzy import fuzz

final_res = []


def main():
    conn = pyodbc.connect(dsn="somos_redshift_1")
    results = get_db_details(conn)
    processResults(results)

def get_db_details(conn):
    query = open('/home/etl/etl_home/sql/macro_chw_engagement_report.sql', 'r').read()
    cur=conn.execute(query)
    res=cur.fetchall()
    cur.close()
    return res

def processResults(dbdetails):
    if len(dbdetails) == 0:
        return None
    f = open("/home/etl/etl_home/Reports/macro_engagement.html", "w")
    h = HTML()
    tbl = h.table(style='font-family:Calibri;font-size:100%;width:150%;display:block;overflow:auto;-webkit-print-color-adjust:exact;')
    r = tbl.tr(style="background-color:#e3e0cc;font-size:80%;text-align: center;")
    r.td("NPI")
    r.td("Practice Name")
    r.td("EMR")
    r.td("Last Pass")
    r.td("Segment Lead")
    r.td("Team Lead")
    r.td("Gatekeeper")
    r.td("Team Member")
    r.td("Total Submitted")
    r.td("Total Processed")
    r.td("Total Errors")
    r.td("Unresolved Errors")
    r.td("Total Cleanup")
    r.td("Unresolved Cleanup")
    r.td("Last Modified")
    r.td("Status")
    for row in dbdetails:
        r = tbl.tr(style="background-color:white;font-size:80%;text-align: center;")
	r.td(row[0])
	r.td(row[1])
	r.td(row[2])
	r.td(row[3])
	r.td(row[4])
	r.td(row[5])
	r.td(row[6])
	r.td(row[7])
	r.td(row[8])
	r.td(row[9])
	r.td(row[10])
	r.td(row[11])
	r.td(row[12])
	r.td(row[13])
        if not row[14]:
            r.td(' ')
        else:
            r.td(row[14])

        if int(row[10]) + int(row[12]) == 0 and row[8] != '0':
            r.td(' Complete ', style='background-color:#7CFC00')
        elif int(row[9]) < int(row[8]):
            r.td(' Incomplete ', style='background-color:orange')
        else:
            r.td(' ')

    header = '''<head><link href="check.css" rel="stylesheet"></head><body>	<h3>CHW Report</h3>
        <div class="content">
	<div class="sidebar">
	  <ul>
	    <li><a href="ecw_status.html">ECW Status</a></li>
	    <li><a href="engagement.html">Engagement Files Status</a></li>
	    <li><a href="inventory.html">Redshift Inventory Status</a></li>
	    <li><a href="macro_chw_engagement.html">Macro Engagement Report</a></li>
	  </ul>
	  
	  <div class="logo">
	    <img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
	  </div>
	</div>'''
    footer = '''<br><center><p style="font-family:'Calibri';font-size:125%">Total: ''' + str(
        len(dbdetails)
    ) + '''<br><p style="font-family:'Calibri';font-size:125%">Time of latest report: ''' + datetime.datetime.now(
    ).strftime("%Y-%m-%d %H:%M:%S") + '''</p></center><br><br>'''
    f.write(header + str(tbl) + footer)
    f.close()
    return tbl


if __name__ == '__main__':
    main()
