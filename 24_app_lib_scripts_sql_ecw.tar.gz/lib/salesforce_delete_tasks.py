from datetime import datetime
import requests
import pandas as pd
import os
import pyodbc
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


connection = pyodbc.connect('dsn=somos_redshift_1')
query = """
select distinct id from salesforce_tasks where project_end_date__c = '2020-06-30' and subject ilike '%subset%' and measure__c = 'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan'
"""


rows = connection.execute(query).fetchall()
connection.close()
sf, INSTANCE_URL = getSession()

#todelete_query = "select id from task where project_end_date__c = 2020-06-30 and care_gap_comments_part_2__c like '%appointment%' and appointment_scheduled_for__c > 2001-01-01"
#rows = sf.query_all(todelete_query)['records']
print len(rows)
tasks = []
for i, row in enumerate(rows):
    tasks.append({'Id': row[0]})
    if i == 10000:
        print i
        sf.bulk.task.delete(tasks)
        tasks = []

#print tasks
sf.bulk.task.delete(tasks)
