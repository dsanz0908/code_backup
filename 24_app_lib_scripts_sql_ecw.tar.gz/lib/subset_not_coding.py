import pyodbc
import pandas as pd
conn_arcadia=pyodbc.connect("dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL")
import datetime

subsetnots_sql = """ 
CREATE TABLE #TEMP_SUBSET_NOTS (
pat_id varchar(50),
CIN					VARCHAR(20),
PAT_FIRST_NAME		VARCHAR(100),
PAT_LAST_NAME		VARCHAR(100),
PAT_DATE_OF_BIRTH	DATETIME,
PHONE_NO			VARCHAR(20),
PAT_ADDR_1			VARCHAR(100),
PAT_ADDR_2			VARCHAR(100),
PAT_CITY			VARCHAR(50),
PAT_STATE			VARCHAR(20),
PAT_ZIP				VARCHAR(20),
PROV_FIRST_NAME		VARCHAR(100),
PROV_LAST_NAME		VARCHAR(100),
PROV_NPI			VARCHAR(20),
MEASURE				VARCHAR(100));

with cte_mx_person_member as (select person_id,MAX(entry_timestamp) as max_entrytime from mpi.person_member group by person_id ) ,
cte_person_member as (
select person_id,max(member_id) as member_id  from mpi.person_member pm  
		where exists  ( select 1 from cte_mx_person_member ct where ct.person_id = pm.person_id and ct.max_entrytime = pm.entry_timestamp ) 
			and active_ind = 'Y'
			group by person_id),

cte_mx_patient as ( select pat_first_name,pat_last_name,pat_date_of_birth,MAX(pat_entry_timestamp) mx_entrytime,MAX(pat_updated_timestamp) as mx_update_time ,max(pat_id) as mx_pat_id
					from t_patient 
					where pat_delete_ind = 'N'
					and   pat_expired_ind = 'N'
					and   pat_status != 'inActive'
					group by pat_first_name,pat_last_name,pat_date_of_birth ) ,

cte_patient as ( select pat_id,max(pat_first_name) as pat_first_name,max(pat_last_name) as pat_last_name,max(pat_date_of_birth) as pat_date_of_birth,
				max(pat_phone_1) as pat_phone_1,max(pat_address_1) as pat_address_1,max(pat_address_2) as pat_address_2,max(pat_city) as pat_city,max(pat_state) as pat_state,
				max(pat_zip) as pat_zip,max(pat_responsible_provider_id) pat_responsible_provider_id from t_patient tp 
				where exists ( select 1 from cte_mx_patient ctp 
									where ctp.pat_first_name = tp.pat_first_name
									and   ctp.pat_last_name = tp.pat_last_name 
									and   ctp.mx_entrytime = tp.pat_entry_timestamp 
									and   pat_updated_timestamp = mx_update_time
 									and   ctp.mx_pat_id = tp.pat_id)  
				group by pat_id),
cte_person_pat as ( select person_id,MAX(entry_timestamp) as mx_entrytime from mpi.person_patient where active_ind = 'Y' group by person_id ),

cte_person_patient as ( select person_id,pat_id from mpi.person_patient pp  
				where exists ( select 1 from cte_person_pat cpp where pp.person_id = cpp.person_id and pp.entry_timestamp = cpp.mx_entrytime ) )  ,
cte_plan_member as (
select max(person_id) as person_id,t1.member_id,max(individual_no) as individual_no,max(first_name) as first_name,max(last_name) as last_name,max(dob) as dob
	from cte_person_member t1
	inner join plan_member t2
	on t1.member_id = t2.member_id
	where t2.delete_ind = 'N'
	and   t2.loaded_from_file like 'nydoh%'
	group by t1.member_id
union all	
select max(person_id) as person_id,t1.member_id,max(medicaid_id) as individual_no,max(first_name) as first_name,max(last_name) as last_name,max(dob) as dob
	from cte_person_member t1
	inner join plan_member t2
	on t1.member_id = t2.member_id
	where t2.delete_ind = 'N'
	and   medicaid_id is not null
	group by t1.member_id )

select t2.person_id,MAX(t1.pat_id) as pat_id,MAX(t1.pat_first_name) as pat_first_name,MAX(t1.pat_last_name) as pat_last_name,MAX(t1.pat_date_of_birth) as pat_date_of_birth,
MAX(t4.first_name) as first_name,MAX(t4.last_name) as last_name,MAX(t4.dob) as dob,MAX(t4.individual_no) as individual_no,
	MAX(pat_phone_1) as pat_phone_1,MAX(pat_address_1) as pat_address_1,MAX(pat_address_2) as pat_address_2,MAX(pat_city) as pat_city,MAX(pat_state) as pat_state,
	MAX(pat_zip) as pat_zip,MAX(pat_responsible_provider_id) as pat_responsible_provider_id
into #temp_patient_member
	from cte_patient t1
	inner join cte_person_patient t2
	on t1.pat_id = t2.pat_id
	inner join cte_person_member t3
	on t2.person_id = t3.person_id

	left outer join cte_plan_member t4
	on t3.person_id = t4.person_id
	and t3.member_id = t4.member_id  
	GROUP BY T2.PERSON_ID
	order by 2,3 ;
select 'patient_info'    ;

--Child Access - Primary Care (12 to 24 Months)
with cte_pat  as ( select pat_id from t_patient where datediff(mm,pat_date_of_birth,GETDATE()) between 12 and 24 and pat_delete_ind = 'N' and pat_expired_ind = 'N' and   pat_status != 'inActive'
					and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and getdate() 
					and enc_patient_id in ( select pat_id from cte_pat ) ) ,

 cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402')
  and cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (12 to 24 Months)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 2,3 desc;


-- Child Access - Primary Care (25 Months to 6)

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(mm,pat_date_of_birth,GETDATE()) > 24 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 5 and pat_delete_ind = 'N' and pat_expired_ind = 'N' 
					and   pat_status != 'inActive'
					and pat_id in ( select distinct pat_id from #temp_patient_member )  ),

cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402') 
		and cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (25 Months to 6)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'child access 1';
-- Child Access - Primary Care (7 to 11)
with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 6 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 11 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
					and   pat_status != 'inActive' 
					and pat_id in ( select distinct pat_id from #temp_patient_member )  ),

cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402') 
	and cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS

select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (7 to 11)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;	

select 'child access 2';
-- Child Access - Primary Care (12 to 19)

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 11 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 19 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
		and   pat_status != 'inActive'
		and pat_id in ( select distinct pat_id from #temp_patient_member )  ),
cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402') and
			cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (12 to 19)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;	
select 'child access 3';
-- Well Care Visits - 5+ visits In first 15 months

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(mm,pat_date_of_birth,GETDATE()) <= 15 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
					and   pat_status != 'inActive'
					and pat_id in ( select distinct pat_id from #temp_patient_member ) 
					),
cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402') 
		and cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Well Care Visits - 5+ visits In first 15 months'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;	
select 'wellcare 1';
--Adult Access Preventive (20 - 44)
with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 19 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 44 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
			and   pat_status != 'inActive' AND pat_id IN ( select pat_id from #temp_patient_member )
		 ),
cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402') 
		and cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Adult Access Preventive (20 - 44)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;

select 'Adult Access 1';
--Adult Access Preventive (45 - 64)

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 44 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 64 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
					and   pat_status != 'inActive' AND pat_id IN ( select pat_id from #temp_patient_member )
				),
cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402')
		and cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Adult Access Preventive (45 - 64)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'Adult Acces 2';
--Adult Access Preventive (65 and Older)
with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) >= 65 and pat_delete_ind = 'N' and pat_expired_ind = 'N' 
					and   pat_status != 'inActive' AND pat_id IN ( select pat_id from #temp_patient_member )),

cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','G0438','G0439','G0402') 
	and cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Adult Access Preventive (65 and Older)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;

select 'Adult Access 3';
-- Cardiovacular  Diagnosis

with cte_assessment  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('I13.10','I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40',
	'I50.41','I50.42','I50.43','I50.9','I50.1','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33',
	'I50.40','I50.41','I50.42','I50.43','I50.9',' E78.4',' E78.5','I09.2','I05.0','I06.0','I08.0','I07.0','I07.1','I07.2',
	'I07.8','I07.9','I09.0','I21.09','I25.2','I20.8','I25.10','I20.9','I21.09','I21.3','I25.10','I25.2','I25.84','I25.9',
	'I10','I11.0','I11.9','I25.10','I48.91','I50.9','I63.9','I65.23','I65.29','I67.2','I67.9','I73.9' )
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,
cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select patient_id from cte_assessment ) ) ,
cte_numerator as  ( 
	select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()
	and cc_patient_id in ( select enc_patient_id from cte_denominator )  )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Cardiovacular  Diagnosis'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'cardio vasuclar';
-- Control Blood Pressure Coding

with cte_assessment  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('I13.10','I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40',
	'I50.41','I50.42','I50.43','I50.9','I50.1','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33',
	'I50.40','I50.41','I50.42','I50.43','I50.9',' E78.4',' E78.5','I09.2','I05.0','I06.0','I08.0','I07.0','I07.1','I07.2',
	'I07.8','I07.9','I09.0','I21.09','I25.2','I20.8','I25.10','I20.9','I21.09','I21.3','I25.10','I25.2','I25.84','I25.9',
	'I10','I11.0','I11.9','I25.10','I48.91','I50.9','I63.9','I65.23','I65.29','I67.2','I67.9','I73.9' )
	AND assessment_date	between '20190101' and GETDATE() ) ,
cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()),

cte_vitals as ( select distinct vitals_patient_id from t_vitals where vitals_date between '20190101' and GETDATE() and vitals_systolic <= 140 and vitals_diastolic <= 90 )  ,
cte_denominator as ( 
						select distinct cta.patient_id 
						from cte_assessment cta
						inner join cte_chargecapture ctc
						on cta.patient_id = ctc.cc_patient_id
						inner join cte_vitals 
						on cta.patient_id = vitals_patient_id ) ,
						
cte_numerator as ( select cc_patient_id from t_chargecapture where cc_cpt_Code in ('3074F','3075F','3078F','3079F','G8752','G8754') 
					and cc_date_of_service  between '20190101' and GETDATE()
					and cc_patient_id in ( select patient_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Control Blood Pressure Coding'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'cbp';
--Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('I13.10','I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40',
	'I50.41','I50.42','I50.43','I50.9','I50.1','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33',
	'I50.40','I50.41','I50.42','I50.43','I50.9',' E78.4',' E78.5','I09.2','I05.0','I06.0','I08.0','I07.0','I07.1','I07.2',
	'I07.8','I07.9','I09.0','I21.09','I25.2','I20.8','I25.10','I20.9','I21.09','I21.3','I25.10','I25.2','I25.84','I25.9',
	'I10','I11.0','I11.9','I25.10','I48.91','I50.9','I63.9','I65.23','I65.29','I67.2','I67.9','I73.9')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,
cte_assessment_2 as ( select distinct patient_id from t_assessment where icd10_code in ( 'F20.0','F20.1','F20.2','F20.3','F20.4','F20.5','F20.81', 'F20.89', 'F20.9', 'F25.0', 'F25.1', 'F25.8', 'F25.9' )
	and assessment_date >= DATEADD(yy,-3,getdate())),

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )
					and enc_patient_id in ( select patient_id from cte_assessment_2 )  ) ,

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()),

cte_denominator as ( 
						select distinct cta.enc_patient_id  as patient_id
						from cte_encounter cta
						inner join cte_chargecapture ctc
						on cta.enc_patient_id = ctc.cc_patient_id
						) ,
cte_results as  ( select distinct pat_id from t_result where lab_type in ('LDL','LIPID PANEL') and collection_date between '20190101' and GETDATE() )  ,						

cte_numerator as ( select cc_patient_id from t_chargecapture 
					inner join cte_results 
						on cc_patient_id = pat_id 
					where cc_cpt_Code in ('3048F','3049F','3050F') 
					and cc_date_of_service  between '20190101' and GETDATE()
					and cc_patient_id in ( select patient_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;

select 'cardio 2';
--Lipid Management for patients with Cardiovascular disease

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('I13.10','I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40',
	'I50.41','I50.42','I50.43','I50.9','I50.1','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33',
	'I50.40','I50.41','I50.42','I50.43','I50.9',' E78.4',' E78.5','I09.2','I05.0','I06.0','I08.0','I07.0','I07.1','I07.2',
	'I07.8','I07.9','I09.0','I21.09','I25.2','I20.8','I25.10','I20.9','I21.09','I21.3','I25.10','I25.2','I25.84','I25.9',
	'I10','I11.0','I11.9','I25.10','I48.91','I50.9','I63.9','I65.23','I65.29','I67.2','I67.9','I73.9')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,


cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )) ,

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()),


cte_denominator as ( 
						select distinct cta.enc_patient_id  as patient_id
						from cte_encounter cta
						inner join cte_chargecapture ctc
						on cta.enc_patient_id = ctc.cc_patient_id ) ,
cte_results as  ( select distinct pat_id from t_result where lab_type in ('LDL','LIPID PANEL') and collection_date between '20190101' and GETDATE() )  ,
						
cte_numerator as ( select distinct cc_patient_id from t_chargecapture
					inner join cte_results 
					on cc_patient_id = pat_id
					where cc_cpt_Code in ('3048F','3049F','3050F') 
					and cc_date_of_service  between '20190101' and GETDATE()
					)

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Lipid Management for patients with Cardiovascular disease'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'lipid management';
-- Asthma Diagnosis 

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('J45.20','J45.21','J45.22','J45.30','J45.31','J45.32','J45.40','J45.41','J45.42','J45.50','J45.51','J45.52','J45.901','J45.902','J45.909','J45.990','J45.991',
							'J45.998','J45.2','J45.3','J45.4','J45.5','J45.9','J45.90','J45.99')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_assessment_2  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('J45.20','J45.21','J45.22','J45.30','J45.31','J45.32','J45.40','J45.41','J45.42','J45.50','J45.51','J45.52','J45.901','J45.902','J45.909','J45.990','J45.991',
							'J45.998','J45.2','J45.3','J45.4','J45.5','J45.9','J45.90','J45.99')
	AND assessment_date	 between '20190101' and GETDATE()),

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()),

cte_denominator as ( select distinct patient_id from cte_assessment_1 ) ,
						
cte_numerator as ( select patient_id from cte_assessment_2 inner join cte_chargecapture on patient_id = cc_patient_id  where patient_id in ( select patient_id from cte_denominator ))

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Asthma Diagnosis'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc;
select 'asthma 1';
--Asthma Action Plan

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('J45.20','J45.21','J45.22','J45.30','J45.31','J45.32','J45.40','J45.41','J45.42','J45.50','J45.51','J45.52','J45.901','J45.902','J45.909','J45.990','J45.991',
							'J45.998','J45.2','J45.3','J45.4','J45.5','J45.9','J45.90','J45.99')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )),

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) ),

cte_denominator as ( select distinct enc_patient_id 
						from cte_encounter
						inner join cte_chargecapture
						on enc_patient_id = cc_patient_id ) ,
						
cte_numerator as ( select cc_patient_id from t_chargecapture where cc_cpt_Code = 'AST01' AND cc_date_of_service between '20190101' and GETDATE() AND cc_patient_id in ( select enc_patient_id from cte_denominator ))

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Asthma Action Plan'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'asthma 2';
--COPD Diagnosis
with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('J41.0', 'J41.1', 'J41.8', 'J42', 'J43.0', 'J43.1', 'J43.2', 'J43.8', 'J43.9', 'J44.0', 'J44.1', 'J44.9')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_assessment_2  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('J41.0', 'J41.1', 'J41.8', 'J42', 'J43.0', 'J43.1', 'J43.2', 'J43.8', 'J43.9', 'J44.0', 'J44.1', 'J44.9')
	AND assessment_date	 between '20190101' and GETDATE()),

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()),

cte_denominator as ( select distinct patient_id from cte_assessment_1 ) ,
						
cte_numerator as ( select patient_id from cte_assessment_2 inner join cte_chargecapture on patient_id = cc_patient_id  )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'COPD Diagnosis'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc;
select 'copd';
-- Use of Spirometry Testing in the Assessment and Diagnosis of COPD

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('J41.0', 'J41.1', 'J41.8', 'J42', 'J43.0', 'J43.1', 'J43.2', 'J43.8', 'J43.9', 'J44.0', 'J44.1', 'J44.9')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )),

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service >= DATEADD(yy,-3,getdate())),

cte_denominator as ( select distinct enc_patient_id 
						from cte_encounter
						inner join cte_chargecapture
						on enc_patient_id = cc_patient_id ) ,
						
cte_numerator as ( select cc_patient_id from t_chargecapture where cc_cpt_Code in ('94010','94014','94015','94016','94060','94070','94375','94620')
 AND cc_date_of_service between '20190101' and GETDATE() AND cc_patient_id in ( select enc_patient_id from cte_denominator ))

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Use of Spirometry Testing in the Assessment and Diagnosis of COPD'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'spirometry';
-- Diabetes Diagnosis
with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319',
	'E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329',
	'E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339',
	'E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41',
	'E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59',
	'E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69',
	'E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628',
	'E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349',
	'E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51',
	'E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
	'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_assessment_2  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319',
	'E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329',
	'E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339',
	'E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41',
	'E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59',
	'E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69',
	'E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628',
	'E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349',
	'E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51',
	'E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
	'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND assessment_date	 between '20190101' and GETDATE()),

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()),

cte_denominator as ( select distinct patient_id from cte_assessment_1 ) ,
						
cte_numerator as ( select patient_id from cte_assessment_2 inner join cte_chargecapture on patient_id = cc_patient_id  )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Diabetes Diagnosis'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc;

select 'diabetes 1';


-- Diabetes - Dialated Eye Exam

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319',
	'E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329',
	'E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339',
	'E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41',
	'E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59',
	'E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69',
	'E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628',
	'E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349',
	'E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51',
	'E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
	'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )),

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) ),

cte_denominator as ( select distinct enc_patient_id 
						from cte_encounter
						inner join cte_chargecapture
						on enc_patient_id = cc_patient_id ) ,
						
cte_numerator as ( select cc_patient_id from t_chargecapture where cc_cpt_Code in ('2022F','3073F','2024F','2026F','S0620','S0621','S3000')
 AND cc_date_of_service between '20190101' and GETDATE() AND cc_patient_id in ( select enc_patient_id from cte_denominator ))

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Diabetes - Dialated Eye Exam'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
select 'diabetes 2';

--Diabetes - Foot Exam

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319',
	'E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329',
	'E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339',
	'E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41',
	'E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59',
	'E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69',
	'E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628',
	'E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349',
	'E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51',
	'E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
	'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )) ,

cte_chargecapture as ( 
	select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' )
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) )   ,

cte_denominator as ( 
select distinct enc_patient_id 
						from cte_encounter
						inner join cte_chargecapture
						on enc_patient_id = cc_patient_id ) 



INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Diabetes - Foot Exam'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from t_chargecapture cc where cc_cpt_Code in 	( '2028F','G8404','G8405','G8406' ) and cc_date_of_service between '20190101' and GETDATE() and t2.pat_id = cc_patient_id )
	order by 1 desc;
select 'diabetes 3';

-- Diabetes - Nephropathy screening Coding 
with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319',
	'E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329',
	'E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339',
	'E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41',
	'E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59',
	'E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69',
	'E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628',
	'E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349',
	'E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51',
	'E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
	'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )) ,

cte_chargecapture as ( 
	select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' )
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) )   ,

cte_denominator as ( 
select distinct enc_patient_id 
						from cte_encounter
						inner join cte_chargecapture
						on enc_patient_id = cc_patient_id ) 



INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Diabetes - Nephropathy screening Coding'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from t_chargecapture cc where cc_cpt_Code in 	( '3060F', '3061F', '3062F','3066F' ) and cc_date_of_service between '20190101' and GETDATE() and t2.pat_id = cc_patient_id )
	order by 1 desc;
select 'diabetes 4';

-- Hemoglobin A1C
with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319',
	'E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329',
	'E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339',
	'E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41',
	'E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59',
	'E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69',
	'E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628',
	'E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349',
	'E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51',
	'E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
	'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )) ,

cte_chargecapture as ( 
	select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' )
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) )   ,

cte_a1c as  ( select pat_id from t_result where lab_type = 'A1C' and collection_date between '20190101' and getdate() ),

cte_denominator as ( 
select distinct enc_patient_id 
						from cte_encounter
						inner join cte_chargecapture
						on enc_patient_id = cc_patient_id ) ,

cte_numerator as ( select distinct cc_patient_id 
		from t_chargecapture
		inner join cte_a1c
		on cc_patient_id = pat_id 
		where cc_cpt_Code in 	('3044F','3045F','3046F') 
		and cc_date_of_service between '20190101' and GETDATE() 
		and cc_patient_id in ( select enc_patient_id from cte_denominator) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Hemoglobin A1C'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator where cc_patient_id = t2.pat_id ) 
	order by 1 desc;
select 'hemoglobin';
-- Lipid Management for patients with Diabetes
with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319',
	'E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329',
	'E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339',
	'E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41',
	'E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59',
	'E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69',
	'E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628',
	'E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349',
	'E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51',
	'E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
	'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,

cte_encounter as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() 
					and enc_patient_id in ( select patient_id from cte_assessment_1 )) ,

cte_chargecapture as ( 
	select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' )
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) )   ,

cte_a1c as  ( select pat_id from t_result where lab_type in ('LDL','LIPID PANEL') and collection_date between '20190101' and getdate() ),

cte_denominator as ( 
select distinct enc_patient_id 
						from cte_encounter
						inner join cte_chargecapture
						on enc_patient_id = cc_patient_id ) ,
cte_numerator as  ( select distinct cc_patient_id 
						from t_chargecapture
						inner join cte_a1c
						on cc_patient_id = pat_id 
						where cc_cpt_Code in ('3048F', '3049F','3050F') 
						and cc_date_of_service between '20190101' and GETDATE() )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Lipid Management for patients with Diabetes'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator where cc_patient_id = t2.pat_id)
	order by 1 desc;
select 'lipid 2';
-- BMI Assessment
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 2
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member )) ,
cte_numerator as ( 
select distinct cc_patient_id from t_chargecapture where cc_date_of_service between '20190101' and getdate() 
						and cc_patient_id in ( select pat_id from cte_denominator )
						and cc_cpt_code = '3008F' )
INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'BMI Assessment'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;
select 'bmi 1';
--BMI ICD
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 2
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),
cte_numerator as ( select distinct patient_id from t_assessment where assessment_date between '20190101' and getdate() 
						and patient_id in ( select pat_id from cte_denominator )
						and icd10_code in ('Z68.1', 'Z68.20','Z68.21','Z68.22','Z68.23','Z68.24','Z68.25','Z68.26',
						'Z68.27','Z68.28','Z68.29','Z68.30','Z68.31','Z68.32','Z68.33','Z68.34',
						'Z68.35','Z68.36','Z68.37','Z68.38','Z68.39', 'Z68.41','Z68.42','Z68.43','Z68.44','Z68.45', 
						'Z68.51','Z68.52','Z68.53','Z68.54','V85.1', 'V85.21','V85.22','V85.23','V85.24','V85.25', 
						'V85.30','V85.31','V85.32','V85.33','V85.34','V85.35','V85.36','V85.37','V85.38','V85.39',
						'V85.41','V85.42','V85.43','V85.44','V85.45', 'V85.51','V85.52','V85.53','V85.54' ) )
INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'BMI ICD'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = patient_id )
	order by 1 desc;
select 'bmi 2';
-- BMI CPT
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 18
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),
cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_date_of_service between '20190101' and getdate() 
						and cc_patient_id in ( select pat_id from cte_denominator )
						and cc_cpt_code in ( 'G8417','G8418', 'G8420' ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'BMI CPT'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;
select 'bmi 3';
-- Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan

with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 18
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),
cte_nutri_counseling as ( SELECT distinct patient_id from t_assessment where icd10_code = 'Z71.3' and assessment_date between '20190101' and GETDATE()
							  union
							  select distinct cc_patient_id from t_chargecapture 
								where cc_cpt_Code IN ( '97802','97803','92804','G0270','G0271','G0447','S9449','S9451','S9452','S9470')
								and cc_date_of_service  between '20190101' and GETDATE() ),
cte_bmi as (SELECT distinct patient_id from t_assessment where icd10_code like 'Z68.%' and assessment_date between '20190101' and GETDATE() ),

cte_phya_counseling as ( select distinct patient_id from t_assessment where icd10_code in ('Z71.82','Z02.5') and assessment_date between '20190101' and GETDATE()
						   union
						   select distinct cc_patient_id from t_chargecapture
						   where cc_cpt_code in ('G0447','S9451')
						   and cc_date_of_service  between '20190101' and GETDATE() ),

cte_numerator as ( select distinct ctn.patient_id 
					from cte_nutri_counseling ctn
					inner join cte_bmi  ctb 
					on ctn.patient_id = ctb.patient_id
					inner join cte_phya_counseling ctp
					on ctn.patient_id = ctp.patient_id
					where ctn.patient_id in ( select pat_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = patient_id )
	order by 1 desc;

select 'preventive care';
--Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents

with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 3 and 17
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),
cte_nutri_counseling as ( SELECT distinct patient_id from t_assessment where icd10_code = 'Z71.3' and assessment_date between '20190101' and GETDATE()
							  union
							  select distinct cc_patient_id from t_chargecapture 
								where cc_cpt_Code IN ( '97802','97803','92804','G0270','G0271','G0447','S9449','S9451','S9452','S9470')
								and cc_date_of_service  between '20190101' and GETDATE() ),
cte_bmi as (SELECT distinct patient_id from t_assessment where icd10_code like 'Z68.%' and assessment_date between '20190101' and GETDATE() ),

cte_phya_counseling as ( select distinct patient_id from t_assessment where icd10_code in ('Z71.82','Z02.5') and assessment_date between '20190101' and GETDATE()
						   union
						   select distinct cc_patient_id from t_chargecapture
						   where cc_cpt_code in ('G0447','S9451')
						   and cc_date_of_service  between '20190101' and GETDATE() ),

cte_numerator as ( select distinct ctn.patient_id 
					from cte_nutri_counseling ctn
					inner join cte_bmi  ctb 
					on ctn.patient_id = ctb.patient_id
					inner join cte_phya_counseling ctp
					on ctn.patient_id = ctp.patient_id
					where ctn.patient_id in ( select pat_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = patient_id )
	order by 1 desc;
select 'weight assessment';
--Chlamydia Screening in women

with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 16 and 24 AND pat_sex = 'F'
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),



cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture 
					where cc_cpt_Code in ('87110','87270','87320','87490','87491','87492','87810','G9820','G9821' )
					and cc_date_of_service between '20190101' and GETDATE() 
					and cc_patient_id in ( select pat_id from cte_denominator ) )


INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Chlamydia Screening in women'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

select 'chlamydia screening';
--Cervical Cancer Screening 
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 21 and 64 AND pat_sex = 'F'
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),


cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture 
					where cc_cpt_Code in ('3015F','88141','88142','88143','88147','88148','88150','88152','88153','88154','88164','88165','88166','88167','88174','88175',
											'G0123', 'G0124', 'G0141', 'G0143','G0144','G0145','G0147','G0148','P3000','P3001','Q0091' )
					and cc_date_of_service >= dateadd(yy,-3,getdate())
					and cc_patient_id in ( select pat_id from cte_denominator ) )


INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Cervical Cancer Screening'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

select 'cervical screening';
--Breast Cancer Screening

with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 50 and 74 AND pat_sex = 'F'
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),


cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture 
					where cc_cpt_Code in ('3014F','77055','77056','77057','77061','77062','77063','77065','77066','77067','G0202','G0204','G0206')
					and cc_date_of_service >= dateadd(yy,-2,getdate())
					and cc_patient_id in ( select pat_id from cte_denominator ) )


INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Breast Cancer Screening'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

select 'breast cancer';
--Colorectal Cancer Screening

with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 50 and 74 
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_fobt as ( select distinct cc_patient_id,cc_date_of_service from t_chargecapture where cc_cpt_code in ('3017F','82270','82274','G0328') and DATEDIFF(yy,cc_date_of_service,getdate()) <= 1  and cc_patient_id is not null ),
cte_fit_dna as (select distinct cc_patient_id,cc_date_of_service from t_chargecapture where cc_cpt_code in ('81528','G0464') and DATEDIFF(yy,cc_date_of_service,getdate()) <= 1  and cc_patient_id is not null ) ,
cte_sigmoidoscopy as (select distinct cc_patient_id,cc_date_of_service from t_chargecapture where cc_cpt_code in ('3017F','G0104') and DATEDIFF(yy,cc_date_of_service,getdate()) <= 5  and cc_patient_id is not null ),
cte_colonoscopy as  (select distinct cc_patient_id,cc_date_of_service from t_chargecapture where cc_cpt_code in ('3017F','G0105', 'G0121') and DATEDIFF(yy,cc_date_of_service,getdate()) <= 10  and cc_patient_id is not null ),


cte_numerator as (	select * from ( select cc_patient_id from cte_fobt 
					union
					select cc_patient_id from cte_fit_dna
					union
					select cc_patient_id from cte_sigmoidoscopy
					union
					select cc_patient_id from cte_colonoscopy )  a
					where cc_patient_id in ( select pat_id from cte_denominator ) )


INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Colorectal Cancer Screening'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;
select 'colorectal screening';
--Alcohol Screening
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12 
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code = '3016F'
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select pat_id from cte_denominator ) )


INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Alcohol Screening'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

select 'alcohol screening';
--Alcohol Screening Results

with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12 
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_denominator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code = '3016F'
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select pat_id from cte_denominator_pop ) ),

cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code in ('G9621','G9622')
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select cc_patient_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Alcohol Screening Results'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.cc_patient_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

--Drug Assessment
with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12 
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_denominator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code = '3016F'
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select pat_id from cte_denominator_pop ) ),

cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code in ('H0001')
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select cc_patient_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Drug Assessment'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.cc_patient_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

--Clinical Depression Screening
with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12 
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_denominator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code = '3016F'
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select pat_id from cte_denominator_pop ) ),

cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code in ('3725F')
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select cc_patient_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Clinical Depression Screening'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.cc_patient_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

--Clinical Depression Screening Results
with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12 
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_denominator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code = '3725F'
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select pat_id from cte_denominator_pop ) ),

cte_numerator as ( select distinct cc_patient_id 
					from t_chargecapture
					where cc_cpt_Code in ('G8510','G8431','G8511')
					and   cc_date_of_service between '20190101' and GETDATE()
					and cc_patient_id in ( select cc_patient_id from cte_denominator ) )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Clinical Depression Screening Results'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.cc_patient_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

--Child ADHD Medications Initiation 
with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 6 and 12
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,
cte_adhd as  ( select distinct patient_id from t_assessment where icd10_code in ('F90.0','F90.1','F90.2','F90.8','F90.9') and patient_id in ( select pat_id from cte_denominator_pop ) ),
cte_chargecapture as ( 
	select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' )
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) ) ,

cte_denominator as ( select patient_id from cte_adhd inner join cte_chargecapture on patient_id = cc_patient_id ),

cte_minencounter as ( select enc_patient_id,MIN(enc_timestamp) as min_enctimestamp 
						from t_encounter where enc_timestamp between '20190101' and GETDATE() 
						and enc_patient_id in ( select patient_id from cte_denominator ) group by enc_patient_id ) ,

cte_numerator as ( select distinct t1.enc_patient_id from t_encounter t1
	inner join cte_minencounter t2
	on t1.enc_patient_id = t2.enc_patient_id
	and t1.enc_timestamp > min_enctimestamp
	and DATEDIFF(dd,min_enctimestamp,enc_timestamp) between 1 and 30 )

INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child ADHD Medications Initiation'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = enc_patient_id )
	order by 1 desc;
    
--Child ADHD Medications Continuation
with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 6 and 12
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,
cte_adhd as  ( select distinct patient_id from t_assessment where icd10_code in ('F90.0','F90.1','F90.2','F90.8','F90.9') and patient_id in ( select pat_id from cte_denominator_pop ) ),
cte_chargecapture as ( 
	select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' )
	and cc_date_of_service >= DATEADD(yy,-3,getdate()) ) ,

cte_denominator as ( select patient_id from cte_adhd inner join cte_chargecapture on patient_id = cc_patient_id ),

cte_minencounter as ( select enc_patient_id,MIN(enc_timestamp) as min_enctimestamp 
						from t_encounter where enc_timestamp between '20190101' and GETDATE() 
						and enc_patient_id in ( select patient_id from cte_denominator ) group by enc_patient_id )  ,

cte_numerator_rank as ( 
	select distinct t1.enc_patient_id,min_enctimestamp,convert(varchar(10),enc_timestamp,101) as enc_timestamp, rank() over( partition by t1.enc_patient_id order by convert(varchar(10),enc_timestamp,101) ) as rnk  from t_encounter t1
	inner join cte_minencounter t2
	on t1.enc_patient_id = t2.enc_patient_id
	and t1.enc_timestamp > min_enctimestamp
	and DATEDIFF(mm,min_enctimestamp,convert(varchar(10),enc_timestamp,101)) between 2 and 9
	),
cte_numerator as ( select distinct enc_patient_id from cte_numerator_rank where rnk > 1 )


INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child ADHD Medications Continuation'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = enc_patient_id )
	order by 1 desc;

-- Immunizations for Adolescents: Meningococcal
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 11 and 13
							and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
											and pat_id = enc_patient_id )
							and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,
cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code = '90734'
					and cc_patient_id in ( select pat_id from cte_denominator ) )
INSERT #TEMP_SUBSET_NOTS
select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Immunizations for Adolescents: Meningococcal'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
	order by 1 desc;

--Immunizations for Adolescents: Tdap

	with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 10 and 13
								and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
												and pat_id = enc_patient_id )
								and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,
	cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code = '90715'
						and cc_patient_id in ( select pat_id from cte_denominator ) )
	INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'Immunizations for Adolescents: Tdap'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;
--HPV Vaccination
	with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 9 and 13
								and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
												and pat_id = enc_patient_id )
								and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,
	cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('90649','90650','90651')
						and cc_patient_id in ( select pat_id from cte_denominator ) )
	INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'HPV Vaccination'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;
--Adolescent Immunizations Combo 1
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 10 and 13
								and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
												and pat_id = enc_patient_id )
								and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,
	cte_Meningococcal as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code = '90734'
					and cc_patient_id in ( select pat_id from cte_denominator ) ),
	cte_tdap as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code = '90715'
						and cc_patient_id in ( select pat_id from cte_denominator ) ),
	cte_numerator as ( select distinct cte1.cc_patient_id from cte_meningococcal cte1 inner join cte_tdap cte2 on cte1.cc_patient_id = cte2.cc_patient_id)
INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'Adolescent Immunizations Combo 1'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;

--Flu Shots for Adults Ages 18 – 64
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 18 and 64
								and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
												and pat_id = enc_patient_id )
								and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,
	cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('90655','90657','90661','90662','90673','90685','90686','90687','90688','G0008' ) 
						and cc_date_of_service between '20190101' and getdate() )
INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'Flu Shots for Adults Ages 18 – 64'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;
-- Claims/Encounter Submissions
with cte_denominator as ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and getdate() ) ,
cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_submitted_date is not null and cc_date_of_service between '20190101' and getdate()  )

INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'Claims/Encounter Submissions'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;
--Tobacco Use Assessment
with cte_denominator as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12
								and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
												and pat_id = enc_patient_id )
								and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,

cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('1000F','1031F') and cc_date_of_service between '20190101' and getdate()  )

INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'Tobacco Use Assessment'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;

--Tobacco Use Assessment Results
with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12
								and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
												and pat_id = enc_patient_id )
								and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,

cte_denominator as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('1000F','1031F') and cc_date_of_service between '20190101' and getdate()  ),
cte_numerator as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('1032F','1033F','1034F','1035F','1036F') and cc_date_of_service between '20190101' and getdate()  )

INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'Tobacco Use Assessment Results'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.cc_patient_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;

-- Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention

with cte_denominator_pop as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) >= 12
								and exists ( select 1 from t_encounter where enc_timestamp between '20190101' and getdate()
												and pat_id = enc_patient_id )
								and pat_id in ( select distinct pat_id from #temp_patient_member ) ) ,

cte_cpt as (select distinct cc_patient_id from t_chargecapture where cc_cpt_Code in ('1032F','1033F','1034F','1035F')
                and cc_date_of_service between '20190101' and getdate() ),
cte_icd as (select distinct patient_id from t_assessment 
                where icd10_code in ('F17.200', 'F17.201', 'F17.210', 'F17.211', 'F17.220', 'F17.221', 'F17.290', 'F17.291')  
                and assessment_date between '20190101' and getdate()),
cte_denominator as ( select cc_patient_id from cte_cpt 
                    inner join cte_icd on cc_patient_id = patient_id 
                    where cc_patient_id in ( select pat_id from  cte_denominator_pop ) ), 
					
cte_numerator as ( select  cc_patient_id from t_chargecapture where cc_cpt_code in ('99406','99407','4000F','4001F','4004F','S9075','S9453','G0436','G0437')  and cc_date_of_service between '20190101' and getdate())


INSERT #TEMP_SUBSET_NOTS
	select distinct pat_id,individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
				prov_first_name,prov_last_name,prov_npi,'Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention'  as measure
		from #temp_patient_member t2
		inner join provider_master prov
		on pat_responsible_provider_id = prov_id
		where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.cc_patient_id )
		and  not exists ( select 1 from cte_numerator where t2.pat_id = cc_patient_id )
		order by 1 desc;        

"""    
cur=conn_arcadia.execute(subsetnots_sql)
cur.close()
df=pd.read_sql("select distinct measure from #temp_subset_nots",conn_arcadia)
measures=list(df["measure"])
for measure in measures:
    mdf=pd.read_sql("select * from #temp_subset_nots where measure = '{0}'".format(measure),conn_arcadia)
    output_file_name = 'subsetnots_coding_' + measure.replace("(","_").replace(")","_").replace(":","_").replace(" ","_").replace("-","_") .replace("+","_").replace("/","_")+"_" +datetime.datetime.now().strftime("%Y%m%d") + '.xlsx'
    writer = pd.ExcelWriter('/home/etl/etl_home/Reports/'+ output_file_name)
    mdf.to_excel(writer,'sheet1',index=False)
    writer.save()
    print(measure)
