from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


TASK_QUERY = """
SELECT DISTINCT '005f40000041BB1AAM'                                           AS contact_assigned_chw__c,
                measure_sf,                                                     
                patient_contact_id,
                provider_contact_id, 
                record_type_id, 
                CASE 
                  WHEN measure_type = 'Access to Care' THEN 'Wellness Visit' 
                  ELSE '' 
                END                                                            AS procedure, 
                subject, 
                To_char(To_date(project_end_date, 'MM/DD/YYYY'), 'YYYY-MM-DD') AS project_end_date, 
                'MCO Care Gaps 11/19/19'                                       AS source, 
                'Closed'                                                       AS status 
FROM   salesforce.mco_gaps_groundzero1 
WHERE  activity_id IS NULL 
       AND measure_sf IS NOT NULL 
       AND Trim(measure_sf) <> '' 
       AND Trim(patient_contact_id) <> '' 
       AND Trim(provider_contact_id) <> '' 
       AND complaint = 'Compliant' 
       AND EXISTS (SELECT 1 
                   FROM   (SELECT *, 
                                  Row_number() 
                                    OVER ( 
                                      partition BY id 
                                      ORDER BY added_tz DESC) AS rn 
                           FROM   salesforce_tasks) AS salesforce_tasks 
                   WHERE  project_end_date__c LIKE '2019-12-31%' 
                          AND rn = 1 
                          AND measure_sf = measure__c) 
"""

sf, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
TASKS = CONNECTION.execute(TASK_QUERY).fetchall()
TODAY = datetime.now().strftime("%Y%m%d")
for task in TASKS[:1]:
    print task
    sf.Task.create({
        'ownerid': task[0],
        'measure__c': task[1],
        'whoid': task[2],
        'pcp__c': task[3],
        'recordtypeid': task[4],
        'procedure__c': task[5],
        'subject': task[6],
        'project_end_date__c': task[7],
        'source_created_by__c': task[8],
        'status': task[9],
        '{} automated - task added and closed'.format(TODAY)
    })
CONNECTION.close()
