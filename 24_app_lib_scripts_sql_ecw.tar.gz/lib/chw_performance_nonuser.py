from datetime import datetime
import pandas as pd
import pyodbc
CONNECTION = pyodbc.connect(dsn="somos_redshift_1")

QUERY = """
SELECT   NAME, 
         mco, 
         Count(whoid)                    AS total_gaps, 
         Count(whoid2)                   AS open_gaps, 
         Count(whoid3)                   AS closed_gaps, 
         Count(whoid4)                   AS completed_gaps, 
         Count(whoid5)                   AS completed_awaiting_claim_submission_gaps, 
         Count(whoid6)                   AS completed_awaiting_coding_correction_gaps, 
         Count(whoid9)                   AS excluded_gaps, 
         Count(whoid10)                  AS exclusion_does_not_meet_criteria_verified_by_management_gaps,
         Count(whoid11)                  AS exclusion_moved_out_of_coverage_areaswitched_to_commercial_insurance_gaps,
         Count(whoid12)                  AS exclusion_patient_deceased_gaps, 
         Count(whoid13)                  AS exclusion_patient_switched_to_oon_pcp_gaps, 
         Count(whoid14)                  AS issue_eligibility_needs_review_gaps, 
         Count(whoid15)                  AS issue_ineligible_for_measure_needs_review_gaps, 
         Count(whoid16)                  AS issue_pcp_refused_to_collaborate_gaps, 
         Count(whoid17)                  AS issue_patient_refused_gaps, 
         Count(whoid18)                  AS issue_phone_wrongdisconnectedout_of_service_gaps, 
         Count(whoid19)                  AS issue_referred_to_cbo_for_intervention_gaps, 
         Count(whoid20)                  AS "issue_unable_to_reach_(3)_attempts_needs_management_review_gaps",
         Count(whoid21)                  AS open_no_show_gaps, 
         Count(whoid22)                  AS outreach_unable_to_reach_gaps, 
         Count(whoid25)                  AS pending_appointment_scheduled_gaps, 
         Count(whoid26)                  AS pending_patient_will_call_gaps, 
         Count(whoid27)                  AS pending_practice_will_schedule_gaps, 
         Count(whoid29)                  AS pending_appointment_scheduled_gaps, 
         Count(whoid30)                  AS rx_pending_gaps, 
         Count(DISTINCT patient_visited) AS patients_visited 
FROM     ( 
                SELECT salesforce_users.NAME, 
                       CASE 
                              WHEN health_plan_carriers__c ilike '%healthfirst%' 
                              OR     health_plan_carriers__c ilike '%health first%' 
                              OR     health_plan_carriers__c ilike 'hf%' THEN 'Healthfirst' 
                              WHEN health_plan_carriers__c ilike '%fidelis%' 
                              OR     health_plan_carriers__c ilike '%catholic%' THEN 'Fidelis' 
                              WHEN health_plan_carriers__c ilike '%wellcare%' THEN 'Wellcare' 
                              WHEN health_plan_carriers__c ilike '%affinity%' THEN 'Affinity' 
                              WHEN health_plan_carriers__c ilike '%anthem%' 
                              OR     health_plan_carriers__c ilike '%empire%' THEN 'Empire' 
                              WHEN health_plan_carriers__c ilike '%metroplus%' THEN 'Metroplus'
                              WHEN health_plan_carriers__c ilike '%united%' THEN 'United' 
                              WHEN health_plan_carriers__c ilike '%emblem%' THEN 'Emblem' 
                              ELSE 'Unknown' 
                       END AS mco, 
                       whoid, 
                       CASE 
                              WHEN status = 'Open' THEN whoid 
                              ELSE NULL 
                       END AS whoid2, 
                       CASE 
                              WHEN status = 'Closed' THEN whoid 
                              ELSE NULL 
                       END AS whoid3, 
                       CASE 
                              WHEN status = 'Completed' THEN whoid 
                              ELSE NULL 
                       END AS whoid4, 
                       CASE 
                              WHEN status = 'Completed - Awaiting Claim Submission' THEN whoid 
                              ELSE NULL 
                       END AS whoid5, 
                       CASE 
                              WHEN status = 'Completed - Awaiting Coding Correction' THEN whoid
                              ELSE NULL 
                       END AS whoid6, 
                       CASE 
                              WHEN status = 'Excluded' THEN whoid 
                              ELSE NULL 
                       END AS whoid9, 
                       CASE 
                              WHEN status = 'Exclusion - Does not meet criteria - Verified by Management' THEN whoid
                              ELSE NULL 
                       END AS whoid10, 
                       CASE 
                              WHEN status = 'Exclusion - Moved out of coverage area/Switched to commercial insurance' THEN whoid
                              ELSE NULL 
                       END AS whoid11, 
                       CASE 
                              WHEN status = 'Exclusion - Patient deceased' THEN whoid 
                              ELSE NULL 
                       END AS whoid12, 
                       CASE 
                              WHEN status = 'Exclusion - Patient switched to OON PCP' THEN whoid
                              ELSE NULL 
                       END AS whoid13, 
                       CASE 
                              WHEN status = 'Issue - Eligibility - Needs review' THEN whoid 
                              ELSE NULL 
                       END AS whoid14, 
                       CASE 
                              WHEN status = 'Issue - Ineligible for measure - Needs Review' THEN whoid
                              ELSE NULL 
                       END AS whoid15, 
                       CASE 
                              WHEN status = 'Issue - Patient refused' THEN whoid 
                              ELSE NULL 
                       END AS whoid16, 
                       CASE 
                              WHEN status = 'Issue - PCP refused to collaborate' THEN whoid 
                              ELSE NULL 
                       END AS whoid17, 
                       CASE 
                              WHEN status = 'Issue - Phone wrong/disconnected/out of service' THEN whoid
                              ELSE NULL 
                       END AS whoid18, 
                       CASE 
                              WHEN status = 'Issue - Referred to CBO for intervention' THEN whoid
                              ELSE NULL 
                       END AS whoid19, 
                       CASE 
                              WHEN status = 'Issue - Unable to reach (3) attempts - Needs Management Review' THEN whoid
                              ELSE NULL 
                       END AS whoid20, 
                       CASE 
                              WHEN status = 'Open - No Show' THEN whoid 
                              ELSE NULL 
                       END AS whoid21, 
                       CASE 
                              WHEN status = 'Outreach - Unable to reach' THEN whoid 
                              ELSE NULL 
                       END AS whoid22, 
                       CASE 
                              WHEN status = 'Pending - Appointment Scheduled' THEN whoid 
                              ELSE NULL 
                       END AS whoid25, 
                       CASE 
                              WHEN status = 'Pending - Patient will call' THEN whoid 
                              ELSE NULL 
                       END AS whoid26, 
                       CASE 
                              WHEN status = 'Pending - Practice will schedule' THEN whoid 
                              ELSE NULL 
                       END AS whoid27, 
                       CASE 
                              WHEN status = 'Pending- Appointment Scheduled' THEN whoid 
                              ELSE NULL 
                       END AS whoid29, 
                       CASE 
                              WHEN status = 'Rx - Pending' THEN whoid 
                              ELSE NULL 
                       END AS whoid30, 
                       CASE 
                              WHEN visited_patient_at_home__c = 'TRUE' THEN whoid 
                              ELSE NULL 
                       END AS patient_visited 
                FROM   ( 
                                SELECT   *, 
                                         row_number() OVER ( partition BY salesforce_tasks.id ORDER BY added_tz DESC) AS rn
                                FROM     salesforce_tasks) AS salesforce_tasks 
                JOIN   salesforce_patients 
                ON     contact_id_18_characters__c = whoid 
                JOIN   salesforce_users 
                ON     salesforce_users.id = salesforce_tasks.ownerid 
                WHERE  measure__c = 'Non-Utilizer' 
                AND    rn = 1) 
GROUP BY NAME, 
         mco 
HAVING   count(whoid) > 0 
ORDER BY 2, 
         1
"""

ROWS = pd.read_sql(QUERY, CONNECTION)
SUMMARY = ROWS.groupby(['name'], as_index=False).sum()
with pd.ExcelWriter('/home/etl/etl_home/output/CHW_NONUTILIZER_{}.xlsx'.format(
        datetime.today().strftime('%Y%m%d'))) as writer:
    SUMMARY.to_excel(writer, sheet_name='Summary', index=False)
    for mco in ROWS.mco.unique():
        temp_df = ROWS.loc[(ROWS['mco'] == mco)]
        temp_df.to_excel(writer, sheet_name=mco, index=False)
