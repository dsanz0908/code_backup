import sys
import os
from upload_files_salesforce import getSession, getParentID, getVersion, uploadFeed

if __name__ == '__main__':
    filename = sys.argv[1]
    cin = os.path.basename(filename).split('_')[1]
    sf, instance_url = getSession()
    try:
        parent_id = getParentID(cin, sf)
	version = getVersion(instance_url)
	response = uploadFeed(filename, sf, instance_url, version, parent_id)
	if response['success']:
	    print 0
	else:
	    print 1
    except:
        print 1
