import socket
import time
from hl7apy.parser import parse_message
from hl7apy.mllp import MLLPServer


host = '40.143.139.138'
port = 4014
FILENAME = '/home/etl/etl_home/output/20190625_hl7_encounters_test.txt'
server = MLLPServer('localhost', 2575)

