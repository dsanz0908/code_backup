import pandas as pd
import numpy as pd
import healthcareai

if __name__ == "__main__":
    diabetes = healthcareai.load_diabetes()
    print diabetes
