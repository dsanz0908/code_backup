import pandas as pd
from sqlalchemy import create_engine

engine = create_engine('postgresql://postgres:12345678@18.205.60.74:5432/staging_mdanalytics')
hf_wc_pd = pd.read_csv(
    '/home/etl/etl_home/temp/hc_wc_latest_roster_000', delimiter='|', header=None)

hf_wc_pd.to_sql('latest_roster', engine)


"""
excel_file = pd.ExcelFile('/home/etl/etl_home/temp/elderplan_roster_201911.xlsx')
elderplan_df = pd.read_excel(excel_file, 'Membership Detail')
elderplan_df['plan'] = 'ep'
elderplan_df['member_name'] = elderplan_df['MemberFirstName'] + ' ' + elderplan_df['MemberLastName']
elderplan_df['tin'] = ''
elderplan_df[['MemberId', 'member_name', 'MemberDOB', 'tin', 'ProviderName', 'ProviderNpi', 'plan']].to_csv('/home/etl/etl_home/temp/elderplan_roster.txt', index=False, sep='|', header=False)
"""
