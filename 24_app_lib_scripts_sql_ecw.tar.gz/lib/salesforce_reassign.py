from datetime import datetime
import requests
import pandas as pd
import os
import pyodbc
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


QUERY = """
SELECT id, 
       contact_assigned_chw__c
FROM   (SELECT salesforce_tasks.id, 
               salesforce_providers.contact_assigned_chw__c, 
               Row_number() 
                 OVER ( 
                   partition BY salesforce_tasks.id, salesforce_providers.contact_assigned_chw__c
                   ORDER BY salesforce_providers.lastmodifieddate DESC) AS rn 
        FROM   (SELECT *, 
                       Row_number() 
                         OVER ( 
                           partition BY salesforce_tasks.id 
                           ORDER BY added_tz DESC) AS rn 
                FROM   salesforce_tasks) AS salesforce_tasks 
               JOIN salesforce_providers 
                 ON salesforce_tasks.pcp__c = salesforce_providers.id 
               JOIN salesforce_users 
                 ON salesforce_users.id = salesforce_tasks.ownerid 
        WHERE  rn = 1 
               AND salesforce_tasks.project_end_date__c = '2020-06-30' 
               AND salesforce_tasks.ownerid <> contact_assigned_chw__c and contact_assigned_chw__c <> '') 
WHERE  rn = 1
"""

connection = pyodbc.connect('dsn=somos_redshift_1')
rows = connection.execute(QUERY).fetchall()
connection.close()
sf, INSTANCE_URL = getSession()
tasks = []
for row in rows:
    tasks.append({'Id': row[0], 'OwnerId': row[1]})
    if len(tasks) == 10000:
        print tasks[0]
        sf.bulk.task.update(tasks)
        tasks = []
sf.bulk.task.update(tasks)
print 'done'


