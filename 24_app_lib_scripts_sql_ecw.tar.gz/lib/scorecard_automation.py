import pyodbc
import pandas as pd
import boto3
#conn_arcadia=pyodbc.connect("Driver=SQL Server;server=ACPPSSQLPRD02;Database=acpps_warehouse_prd01; Trusted_Connection=Yes;")
conn_arcadia=pyodbc.connect("dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL")
conn_somos=pyodbc.connect(dsn="somos_redshift_1")
import datetime
cdate=datetime.datetime.now().strftime("%Y%m%d")
output_file_name = 'scorecard_report_' + cdate + '.csv'
output_file_excel = 'scorecard_report_' + cdate + '.xlsx'


def query_db():
	query_custom_measures = """
	IF OBJECT_ID('tempdb..#scorecard') IS NOT NULL 
	    DROP TABLE #SCORECARD;
	    
	CREATE TABLE #SCORECARD (
	sitename	VARCHAR(100) null,
	measure		VARCHAR(100) null,
	universe	INT null,
	denominator INT null,
	numerator	INT null);

	IF OBJECT_ID('tempdb..#PersonsIncluded') IS NOT NULL 
	 drop table #personsincluded;
	/*
	SELECT DISTINCT personId, eventSourceSystem, eventStartDate,ROW_NUMBER() 
	OVER (PARTITION BY personId ORDER BY eventStartDate DESC) seq
	INTO #PersonsIncluded
	FROM acpps_client_prd01.dbo.personEvents pe WITH (NOLOCK) 
	WHERE pe.eventCodeSet = 'Encounter'
	AND pe.eventCodeValue = 'Medical'
	AND pe.eventStartDate BETWEEN DATEADD(MM,-18,GETDATE()) AND GETDATE();
	*/
	select distinct e.personid,eventSourceSystem 
	INTO #PersonsIncluded
	from acpps_client_prd01.dbo.personEvents e
	where e.eventStartDate  between '20190101' and getdate()
	and eventsourcetable = 't_encounter';


	INSERT #SCORECARD
	SELECT  p.eventSourceSystem,  case 
		when pm.measuredisplayName = 'HTN Blood Pressure Control' then 'Control Blood Pressure '
		when pm.measuredisplayname = 'Cardio Monitoring for Schizo' then 'Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia'
		when pm.measuredisplayName = 'COPD Spirometry' then 'Use of Spirometry Testing in the Assessment and Diagnosis of COPD'
	        when pm.measuredisplayname = 'DM Nephropathy' then 'Diabetes - Nephropathy screening'
		when pm.measuredisplayname = 'Adolescent Imm (Combo #1)' then 'Adolescent Immunizations Combo 1'
		when pm.measuredisplayname = 'ADHD Continuation' then 'Child ADHD Medications Continuation'
		when pm.measuredisplayname = 'ADHD Initiation' then 'Child ADHD Medications Initiation'
		when pm.measuredisplayname = 'Anti-Rheumatic Drugs for RA' then 'Anti-Rheumatic Drug Therapy for Rheumatoid Arthritis'
		when pm.measuredisplayname = 'Cervical Cancer Screening' then 'Cervical Cancer Screening '
		when pm.measuredisplayname = 'Chlamydia Screening in (16-24)' then 'Chlamydia Screening in women'
		when pm.measuredisplayname = 'Adolescent Imm (Combo #1)' then 'Adolescent Immunizations Combo 1'
	    when pm.measuredisplayname = 'Child Access (12-24 mo)' then 'Child Access - Primary Care (12 to 24 Months)'
	    when pm.measuredisplayname = 'Child Access (25 mo-6 yr)' then 'Child Access - Primary Care (25 Months to 6)'
	    when pm.measuredisplayname = 'Child Access (7-11 yr)' then 'Child Access - Primary Care (7 to 11)'
	    when pm.measuredisplayname = 'Child Access (12-19 yr)' then 'Child Access - Primary Care (12 to 19)'
	    when pm.measuredisplayname = 'Well-Child (15 mo, 5+ Visits)' then 'Well Care Visits - 5+ visits In first 15 months'
	    when pm.measuredisplayname = 'Adult Access (20-44)' then 'Adult Access Preventive (20 - 44)'
	    when pm.measuredisplayname = 'Adult Access (45-64)' then 'Adult Access Preventive (45 - 64)'
	    when pm.measuredisplayname = 'Adult Access (65+)' then 'Adult Access Preventive (65 and Older)'
	    when pm.measuredisplayname = 'Adolescent Access (12-19 yr)' then 'Child Access - Primary Care (12 to 19)'
		when pm.measuredisplayname = 'DM Eye Exam' then 'Diabetes - Dialated Eye Exam'
		when pm.measuredisplayname = 'DM HbA1c Testing' then 'Hemoglobin A1C' 
		else pm.measuredisplayname end as measure, 0 as Universe,  
	    SUM(CalcDenominator) Denominator, SUM(CalcNumerator) Numerator
	FROM #PersonsIncluded p
	JOIN acpps_client_prd01.dbo.personMeasures pm WITH (NOLOCK)
		ON	pm.PersonId=p.personId
	where pm.MeasureDisplayName in (
		'Child Access (12-24 mo)',
		'Child Access (25 mo-6 yr)',
		'Child Access (7-11 yr)',
		'Child Access (7-11yr)',
		'Adolescent Access (12-19 yr)',
		'Anti-Rheumatic Drugs for RA',
		'Adult Access (20-44)',
		'Adult Access (45-64)',
		'Adult Access (65+)',
		'Breast Cancer Screening',
		'Colorectal Cancer Screen',
		'DM Eye Exam',
		'DM HbA1c Testing',
		'HTN Blood Pressure Control',
		'Cardio Monitoring for Schizo',
		'COPD Spirometry',
		'DM Nephropathy',
		'Cervical Cancer Screening',
		'Chlamydia Screening in (16-24)',
		'ADHD Initiation',
		'Adolescent Imm (Combo #1)',
		'DM Nephropathy',
		'Annual Dental Visit'
		 )
	AND INITIATIVENAME = 'DSRIP YEAR 3'
	AND PERIODNAME = '2019'
	GROUP BY p.eventSourceSystem, pm.InitiativeName, pm.MeasureDisplayName;
	
	--Control Blood Pressure Coding
	with cte_bp_denom as ( select eventsourcesystem,pm.personid,CalcDenominator ,CalcNumerator
	from acpps_client_prd01.dbo.personMeasures pm
	inner join #personsincluded tmp
	on pm.personid = tmp.personid
	where MeasureDisplayName = 'HTN Blood Pressure Control'
	AND INITIATIVENAME = 'DSRIP YEAR 3'
	AND PERIODNAME = '2019'),

	cte_bp_num as ( select distinct eventsourcesystem, personid,1 as numerator from acpps_client_prd01.dbo.personEvents t1 
	where t1.eventStartDate  between '20190101' and getdate()
	and   t1.eventsourcetable = 't_chargecapture'
	and eventcodevalue in ( '3074F','3075F','3078F','3079F','G8752','G8754')  )


	INSERT #SCORECARD
	select eventsourcesystem as sitename,'Control Blood Pressure Coding' as measure,sum(universe) as universe,sum(denominator) as denominator, sum(numerator) as numerator
	from (
	select eventsourcesystem, sum(calcdenominator) as universe, sum(calcnumerator) as denominator, 0 as numerator
		from cte_bp_denom
		group by eventsourcesystem
	union
	select eventsourcesystem, 0 as universe, 0 as denominator, sum(numerator) as numerator
		from cte_bp_num num
		where exists ( select 1 from cte_bp_denom dnm where dnm.eventsourcesystem = num.eventsourcesystem and dnm.personid = num.personid and calcnumerator = 1)
		group by eventsourcesystem	 ) a
	group by eventsourcesystem; 

	--Asthma Diagnosis
	with cte_codes as ( SELECT DISTINCT T2.site_Center_Name,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in ('J45.20','J45.21','J45.22','J45.30','J45.31','J45.32','J45.40','J45.41','J45.42','J45.50','J45.51','J45.52','J45.901','J45.902','J45.909',
	 'J45.990', 'J45.991', 'J45.998','J45.2', 'J45.3', 'J45.4', 'J45.5', 'J45.9', 'J45.90','J45.99')
	AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


	cte_access_to_care as ( 
	SELECT DISTINCT T2.site_Center_Name,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where  enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND CC_CPT_CODE IN ('99381','99382','99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397','G0438', 'G0439',
	'90791', '90792', '90832','90833','90834','90835','90836','90837','90838','90839','90840', '90845','90846','90847', '90849', '90853', '90875', '90876', 
	'98966','98967','98968', '99221','99222','99223', '99231','99232','99233', '99238', '99239', '99251','99252','99253','99254','99255', '99381','99382',
	'99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397', '99441','99442','99443') ),

	cte_eligibile_universe as ( 
	select distinct cte1.site_center_name,cte1.patient_id 
		from cte_codes cte1
		inner join cte_access_to_care cte2
		on cte1.patient_id = cte2.enc_patient_id 
		and cte1.site_center_name = cte2.site_center_name ) ,

	cte_denominator as ( 
	SELECT distinct T2.site_Center_Name,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	where exists  ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE ceu where ceu.site_center_name = t2.site_center_name and ceu.patient_id = t1.enc_patient_id )
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	CTE_numerator as ( 
	SELECT DISTINCT T2.site_Center_Name, PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	where icd10_code in ('J45.20','J45.21','J45.22','J45.30','J45.31','J45.32','J45.40','J45.41','J45.42','J45.50','J45.51','J45.52','J45.901','J45.902','J45.909',
	 'J45.990', 'J45.991', 'J45.998','J45.2', 'J45.3', 'J45.4', 'J45.5', 'J45.9', 'J45.90','J45.99')
	AND ASSESSMENT_DATE  between '20190101' and getdate()
	and exists  ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.patient_id and ctd.site_center_name = t2.site_center_name))
	INSERT #SCORECARD
	select site_center_name,'Asthma Diagnosis' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	--Asthma Action Plan
	with cte_codes as ( SELECT DISTINCT t2.site_center_name,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in ('J45.20','J45.21','J45.22','J45.30','J45.31','J45.32','J45.40','J45.41','J45.42','J45.50','J45.51','J45.52','J45.901','J45.902','J45.909',
	 'J45.990', 'J45.991', 'J45.998','J45.2', 'J45.3', 'J45.4', 'J45.5', 'J45.9', 'J45.90','J45.99')
	AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


	cte_access_to_care as ( SELECT DISTINCT t2.site_center_name,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE  ENC_TIMESTAMP >= DATEADD(YEAR,-3,GETDATE())
	AND CC_CPT_CODE IN ('99381','99382','99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397','G0438', 'G0439',
	'90791', '90792', '90832','90833','90834','90835','90836','90837','90838','90839','90840', '90845','90846','90847', '90849', '90853', '90875', '90876', 
	'98966','98967','98968', '99221','99222','99223', '99231','99232','99233', '99238', '99239', '99251','99252','99253','99254','99255', '99381','99382',
	'99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397', '99441','99442','99443') ),

	cte_eligibile_universe as ( select distinct CTE1.SITE_CENTER_NAME,cte1.patient_id 
		from cte_codes cte1
		inner join cte_access_to_care cte2
		on cte1.patient_id = cte2.enc_patient_id
		AND CTE1.site_Center_Name = CTE2.SITE_CENTER_NAME ) ,

	cte_denominator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE  EXISTS  ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE CTU  WHERE CTU.PATIENT_ID = T1.ENC_PATIENT_ID AND CTU.site_Center_Name = T2.site_Center_Name )
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	CTE_numerator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID AS PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE CC_CPT_CODE = 'AST01'
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and EXISTS  ( select 1 from cte_denominator CTD WHERE T1.ENC_PATIENT_ID = CTD.ENC_PATIENT_ID AND T2.SITE_CENTER_NAME = CTD.SITE_CENTER_NAME ))

	INSERT #SCORECARD
	select site_center_name,'Asthma Action Plan' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	--Cardiovascular  Diagnosis
	with cte_codes as ( SELECT DISTINCT T2.SITE_CENTER_NAME,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in ('I13.10', 'I12.9', 'I11.9', 'I10', 'I50.20', 'I50.21', 'I50.22', 'I50.23', 'I50.30', 'I50.31', 'I50.32', 'I50.33', 'I50.40', 'I50.41', 'I50.42', 'I50.43', 'I50.9', 'I50.1', 'I50.20', 
	'I50.21', 'I50.22', 'I50.23', 'I50.30', 'I50.31', 'I50.32', 'I50.33', 'I50.40', 'I50.41', 'I50.42', 'I50.43', 'I50.9', 'E78.4', 'E78.5', 'I09.2', 'I05.0', 'I06.0', 'I08.0', 'I07.0', 
	'I07.1', 'I07.2', 'I07.8', 'I07.9', 'I09.0', 'I21.09', 'I25.2', 'I20.8', 'I25.10', 'I20.9', 'I21.09', 'I21.3', 'I25.10', 'I25.2', 'I25.84', 'I25.9', 'I10', 'I11.0', 'I11.9', 'I25.10', 
	'I48.91', 'I50.9', 'I63.9', 'I65.23', 'I65.29', 'I67.2', 'I67.9', 'I73.9' )
	AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


	cte_access_to_care as ( SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE  enc_timestamp >= dateadd(yy,-3,getdate())
	AND CC_CPT_CODE IN ('99381','99382','99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397','G0438', 'G0439',
	'90791', '90792', '90832','90833','90834','90835','90836','90837','90838','90839','90840', '90845','90846','90847', '90849', '90853', '90875', '90876', 
	'98966','98967','98968', '99221','99222','99223', '99231','99232','99233', '99238', '99239', '99251','99252','99253','99254','99255', '99381','99382',
	'99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397', '99441','99442','99443') ),

	cte_eligibile_universe as ( select distinct cte1.site_center_name,cte1.patient_id 
		from cte_codes cte1
		inner join cte_access_to_care cte2
		on cte1.patient_id = cte2.enc_patient_id 
		and cte1.site_center_name = cte2.site_center_name) ,

	cte_denominator as ( 
	SELECT distinct T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE ENC_TIMESTAMP  between '20190101' and getdate()
	and EXISTS  ( select 1 from cte_eligibile_universe CTU WHERE CTU.PATIENT_ID = T1.ENC_PATIENT_ID AND CTU.SITE_CENTER_NAME = T2.SITE_CENTER_NAME )),

	CTE_numerator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in ('I13.10', 'I12.9', 'I11.9', 'I10', 'I50.20', 'I50.21', 'I50.22', 'I50.23', 'I50.30', 'I50.31', 'I50.32', 'I50.33', 'I50.40', 'I50.41', 'I50.42', 'I50.43', 'I50.9', 'I50.1', 'I50.20', 
	'I50.21', 'I50.22', 'I50.23', 'I50.30', 'I50.31', 'I50.32', 'I50.33', 'I50.40', 'I50.41', 'I50.42', 'I50.43', 'I50.9', 'E78.4', 'E78.5', 'I09.2', 'I05.0', 'I06.0', 'I08.0', 'I07.0', 
	'I07.1', 'I07.2', 'I07.8', 'I07.9', 'I09.0', 'I21.09', 'I25.2', 'I20.8', 'I25.10', 'I20.9', 'I21.09', 'I21.3', 'I25.10', 'I25.2', 'I25.84', 'I25.9', 'I10', 'I11.0', 'I11.9', 'I25.10', 
	'I48.91', 'I50.9', 'I63.9', 'I65.23', 'I65.29', 'I67.2', 'I67.9', 'I73.9')
	AND ASSESSMENT_DATE  between '20190101' and getdate()
	and EXISTS ( select 1 from cte_denominator CTD WHERE CTD.ENC_PATIENT_ID = T1.PATIENT_ID AND CTD.SITE_CENTER_NAME = T2.SITE_CENTER_NAME ))

	INSERT #SCORECARD

	select site_center_name,'Cardiovascular Diagnosis' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- COPD Diagnosis

	with cte_codes as ( SELECT DISTINCT T2.SITE_CENTER_NAME,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in ('J41.0', 'J41.1', 'J41.8', 'J42', 'J43.0', 'J43.1', 'J43.2', 'J43.8', 'J43.9', 'J44.0', 'J44.1', 'J44.9')
	AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


	cte_access_to_care as ( SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE   enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND CC_CPT_CODE IN ('99381','99382','99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397','G0438', 'G0439',
	'90791', '90792', '90832','90833','90834','90835','90836','90837','90838','90839','90840', '90845','90846','90847', '90849', '90853', '90875', '90876', 
	'98966','98967','98968', '99221','99222','99223', '99231','99232','99233', '99238', '99239', '99251','99252','99253','99254','99255', '99381','99382',
	'99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397', '99441','99442','99443') ),

	cte_eligibile_universe as ( select distinct cte1.site_center_name,cte1.patient_id 
		from cte_codes cte1
		inner join cte_access_to_care cte2
		on cte1.patient_id = cte2.enc_patient_id
		and cte1.site_center_name = cte2.site_center_name ) ,

	cte_denominator as ( 
	SELECT distinct t2.site_center_name,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	where  exists ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE ctu where ctu.patient_id = t1.enc_patient_id and ctu.site_center_name = t2.site_center_name )
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in ('J41.0', 'J41.1', 'J41.8', 'J42', 'J43.0', 'J43.1', 'J43.2', 'J43.8', 'J43.9', 'J44.0', 'J44.1', 'J44.9')
	AND ASSESSMENT_DATE  between '20190101' and getdate()
	and EXISTS  ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.patient_id and ctd.site_center_name = t2.site_center_name))


	INSERT #SCORECARD

	select site_center_name,'COPD Diagnosis' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;




	-- Diabetes diagnosis

	with cte_codes as ( SELECT DISTINCT t2.site_center_name,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641','E09.11','E09.641','E13.11','E13.641','E08.21',
	'E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319','E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311',
	'E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339','E13.341','E13.349','E13.351',
	'E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41','E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44',
	'E13.49','E13.610','E08.51','E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69','E09.618',
	'E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628','E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8',
	'E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01','E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341',
	'E11.349','E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36','E10.39','E11.40','E11.41','E11.42','E11.43',
	'E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630',
	'E11.638','E11.649','E10.618','E10.620','E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


	cte_access_to_care as ( SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE   enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND CC_CPT_CODE IN ('99381','99382','99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397','G0438', 'G0439',
	'90791', '90792', '90832','90833','90834','90835','90836','90837','90838','90839','90840', '90845','90846','90847', '90849', '90853', '90875', '90876', 
	'98966','98967','98968', '99221','99222','99223', '99231','99232','99233', '99238', '99239', '99251','99252','99253','99254','99255', '99381','99382',
	'99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397', '99441','99442','99443') ),

	cte_eligibile_universe as ( select distinct cte1.site_center_name,cte1.patient_id 
		from cte_codes cte1
		inner join cte_access_to_care cte2
		on cte1.patient_id = cte2.enc_patient_id 
		and cte1.site_center_name = cte2.site_center_name) ,

	cte_denominator as ( 
	SELECT distinct t2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE EXISTS ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE CTU WHERE CTU.PATIENT_ID = T1.ENC_PATIENT_ID AND CTU.SITE_CENTER_NAME = T2.SITE_CENTER_NAME )
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	CTE_numerator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in (
	'E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641','E09.11','E09.641','E13.11','E13.641','E08.21',
	'E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319','E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311',
	'E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339','E13.341','E13.349','E13.351',
	'E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41','E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44',
	'E13.49','E13.610','E08.51','E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','08.649','E08.69','E09.618',
	'E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628','E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8',
	'E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01','E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341',
	'E11.349','E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36','E10.39','E11.40','E11.41','E11.42','E11.43',
	'E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630',
	'E11.638','E11.649','E10.618','E10.620','E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8'
	)
	AND ASSESSMENT_DATE  between '20190101' and getdate()
	and EXISTS ( select 1 from cte_denominator CTD WHERE CTD.ENC_PATIENT_ID = T1.PATIENT_ID AND CTD.SITE_CENTER_NAME = T2.SITE_CENTER_NAME ))

	INSERT #SCORECARD

	select site_center_name,'Diabetes diagnosis' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- Diabetes foot exam
	with cte_codes as ( SELECT DISTINCT T2.SITE_CENTER_NAME,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	WHERE icd10_code in (
	'E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641','E09.11','E09.641','E13.11','E13.641','E08.21',
	'E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319','E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39',
	'E09.311','E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339','E13.341',
	'E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41','E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41',
	'E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638',
	'08.649','E08.69','E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622','E13.628','E13.630','E13.638','E13.649','E13.65',
	'E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01','E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321',
	'E11.329','E11.331','E11.339','E11.341','E11.349','E11.351','E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36',
	'E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51','E10.52','E10.59','E11.618',
	'E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620','E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
	AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


	cte_access_to_care as ( SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE   enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND CC_CPT_CODE IN ('99381','99382','99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397','G0438', 'G0439',
	'90791', '90792', '90832','90833','90834','90835','90836','90837','90838','90839','90840', '90845','90846','90847', '90849', '90853', '90875', '90876', 
	'98966','98967','98968', '99221','99222','99223', '99231','99232','99233', '99238', '99239', '99251','99252','99253','99254','99255', '99381','99382',
	'99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397', '99441','99442','99443') ),

	cte_eligibile_universe as ( select distinct cte1.site_center_name,cte1.patient_id 
		from cte_codes cte1
		inner join cte_access_to_care cte2
		on cte1.patient_id = cte2.enc_patient_id
		and cte1.site_center_name = cte2.site_center_name ) ,

	cte_denominator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE  EXISTS  ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE CTU WHERE CTU.PATIENT_ID = T1.ENC_PATIENT_ID AND CTU.SITE_CENTER_NAME = T2.SITE_CENTER_NAME )
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	CTE_numerator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE CC_CPT_code in ( '2028F','G8404', 'G8405', 'G8406')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and EXISTS ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name ))

	insert #scorecard
	select site_center_name,'Diabetes - Foot Exam' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	--Diabetes - Nephropathy screening Coding
	with cte_bp_denom as ( select eventsourcesystem,pm.personid,CalcDenominator ,CalcNumerator
	from acpps_client_prd01.dbo.personMeasures pm
	inner join #personsincluded tmp
	on pm.personid = tmp.personid
	where MeasureDisplayName = 'DM Nephropathy'
	AND INITIATIVENAME = 'DSRIP YEAR 3'
	AND PERIODNAME = '2019'),

	cte_bp_num as ( select distinct eventsourcesystem, personid,1 as numerator from acpps_client_prd01.dbo.personEvents t1 
	where t1.eventStartDate   between '20190101' and getdate()
	and eventsourcetable = 't_chargecapture'
	and eventcodevalue in ( '3060F','3061F','3062F','3066F')  )
	insert #scorecard
	select eventsourcesystem as sitename,'Diabetes - Nephropathy screening Coding' as measure,sum(universe) as universe,sum(denominator) as denominator, sum(numerator) as numerator
	from (
	select eventsourcesystem, sum(calcdenominator) as universe, sum(calcnumerator) as denominator, 0 as numerator
		from cte_bp_denom
		group by eventsourcesystem
	union
	select eventsourcesystem, 0 as universe, 0 as denominator, sum(numerator) as numerator
		from cte_bp_num num
		where exists ( select 1 from cte_bp_denom dnm where dnm.eventsourcesystem = num.eventsourcesystem and dnm.personid = num.personid and calcnumerator = 1)
		group by eventsourcesystem	 ) a
	group by eventsourcesystem;


	--Tobacco use assessment
	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where t1.enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),


	cte_denominator as ( 
	SELECT t2.site_center_name,ENC_PATIENT_ID  FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	where exists ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE ctu where ctu.enc_patient_id = t1.enc_patient_id and ctu.site_center_name = t2.site_center_name)
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id  FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where CC_CPT_code in ( '1000F')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))

	INSERT #SCORECARD
	select site_center_name,'Tobacco use assessment' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- tobacco use assessment result
	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where t1.enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),


	cte_result_universe as ( 
	SELECT distinct t2.site_center_name,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	where  exists ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE ctu where ctu.enc_patient_id = t1.enc_patient_id and ctu.site_center_name = t2.site_center_name)
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	CTE_denominator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where CC_CPT_code in ( '1000F')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_result_universe ctur where ctur.enc_patient_id = t1.enc_patient_id and ctur.site_center_name = t2.site_center_name)),

	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where CC_CPT_code in ( '1031F','1032F','1033F','1034F','1035F','1036F')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))

	INSERT #SCORECARD
	select site_center_name,'Tobacco Use Assessment Results' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_result_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	-- tobacco Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention

	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name, enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where ENC_TIMESTAMP  between '20190101' and getdate()
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),

	cte_result_universe as ( 
	SELECT distinct t2.site_center_name,ENC_PATIENT_ID FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where  exists  ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE cur where cur.enc_patient_id = t1.enc_patient_id and cur.site_center_name = t2.site_center_name) 
	and ENC_TIMESTAMP  between '20190101' and getdate()
	AND CC_CPT_code in ( '1000F')
	 ),

	CTE_denominator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	INNER JOIN T_ASSESSMENT T4
	ON T1.ENC_ID = T4.ENCOUNTER_ID
	WHERE ENC_TIMESTAMP  between '20190101' and getdate()
	and EXISTS ( select 1 from cte_result_universe cru where cru.enc_patient_id = t1.enc_patient_id and cru.site_center_name = t2.site_center_name)
	AND ( T4.ICD10_CODE IN ('F17.200', 'F17.201', 'F17.210', 'F17.211', 'F17.220', 'F17.221', 'F17.290', 'F17.291') OR CC_CPT_code in ( '1032F', '1034F') ) ),

	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id  FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where CC_CPT_code in ( '99406', '99407', '4000F', '4001F', '4004F', 'S9075', 'S9453','G0436', 'G0437')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))

	INSERT #SCORECARD
	select site_center_name,'Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_result_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- BMI Assessment
	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	WHERE t1.enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 2 ),


	CTE_denominator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE ENC_TIMESTAMP  between '20190101' and getdate()
	and EXISTS ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_center_name = t2.site_center_name) ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	WHERE CC_CPT_code in ( '3008F')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and EXISTS ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_Center_Name = t2.site_center_name))

	INSERT #SCORECARD
	select site_center_name,'BMI Assessment' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	-- BMI ICD

	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	WHERE t1.enc_timestamp >= dateadd(yy,-3,getdate())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 2 ),


	CTE_denominator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE ENC_TIMESTAMP  between '20190101' and getdate()
	and EXISTS ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_center_name = t2.site_center_name) ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_ASSESSMENT T4
	ON T1.ENC_ID = T4.ENCOUNTER_ID
	where ICD10_CODE  in ( 'Z68.1', 'Z68.20','Z68.21','Z68.22','Z68.23','Z68.24','Z68.25','Z68.26','Z68.27','Z68.28','Z68.29','Z68.30','Z68.31','Z68.32','Z68.33','Z68.34','Z68.35','Z68.36','Z68.37','Z68.38','Z68.39', 'Z68.41',
	'Z68.42','Z68.43','Z68.44','Z68.45', 'Z68.51','Z68.52','Z68.53','Z68.54','V85.1', 'V85.21','V85.22','V85.23','V85.24','V85.25', 'V85.30','V85.31','V85.32','V85.33','V85.34','V85.35','V85.36','V85.37',
	'V85.38','V85.39', 'V85.41','V85.42','V85.43','V85.44','V85.45', 'V85.51','V85.52','V85.53','V85.54')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))

	INSERT #SCORECARD
	select site_center_name,'BMI ICD' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- BMI CPT

	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	WHERE t1.enc_timestamp >= dateadd(yy,-3,getdate())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 2 ),


	CTE_denominator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_center_name = t2.site_center_name) ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_chargecapture T3
	ON T1.ENC_ID = T3.cc_enc_id
	WHERE cc_cpt_CODE  in ('G8417', 'G8418', 'G8420')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))

	INSERT #SCORECARD
	select site_center_name,'BMI CPT' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	-- Alcohol Screening

	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	WHERE t1.enc_timestamp >= dateadd(yy,-3,getdate())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),


	CTE_denominator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_center_name = t2.site_center_name) ),

	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name, enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_chargecapture T3
	ON T1.ENC_ID = T3.cc_enc_id
	AND cc_cpt_CODE  in ('3016F')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))

	INSERT #SCORECARD
	select site_center_name,'Alcohol Screening' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- Alcohol Screening Results

	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where t1.enc_timestamp  between '20190101' and getdate()
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),


	CTE_denominator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_Center_Name = t2.site_Center_Name) 
	and  cc_cpt_code in('3016F')),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_chargecapture T3
	ON T1.ENC_ID = T3.cc_enc_id
	where cc_cpt_CODE  in ('G9621', 'G9622')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))


	INSERT #SCORECARD
	select site_center_name,'Alcohol Screening Results' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	-- Drug Assessment

	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where t1.enc_timestamp >= DATEADD(YY,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),


	CTE_denominator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	where ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_Center_Name = t2.site_Center_Name) ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_chargecapture T3
	ON T1.ENC_ID = T3.cc_enc_id
	where cc_cpt_CODE  in ('H0001')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_Center_Name = t2.site_Center_Name))


	INSERT #SCORECARD
	select site_center_name,'Drug Assessment' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- Clinical Depression Screening

	with cte_eligibile_universe as ( SELECT DISTINCT T2.SITE_CENTER_NAME,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	WHERE t1.enc_timestamp >= DATEADD(YY,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),


	CTE_denominator as ( 
	SELECT DISTINCT T2.SITE_CENTER_NAME,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	WHERE ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_Center_Name = t2.site_center_name) ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_chargecapture T3
	ON T1.ENC_ID = T3.cc_enc_id
	where cc_cpt_CODE  in ('3725F')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_Center_Name = t2.site_Center_Name))


	INSERT #SCORECARD
	select site_center_name,'Clinical Depression Screening' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	-- Clinical Depression Screening Results

	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	WHERE t1.enc_timestamp  between '20190101' and getdate()
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 12 ),


	CTE_denominator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where ENC_TIMESTAMP  between '20190101' and getdate()
	AND CC_CPT_CODE IN ('3725F')
	and exists ( select 1 from cte_eligibile_universe ceu where ceu.enc_patient_id = t1.enc_patient_id and ceu.site_Center_Name = t2.site_center_name) ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_chargecapture T3
	ON T1.ENC_ID = T3.cc_enc_id
	where cc_cpt_CODE  in ('G8510','G8431','G8511')
	AND ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_Center_Name = t2.site_Center_Name))


	INSERT #SCORECARD
	select site_center_name,'Clinical Depression Screening Results' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- Immunizations for Adolescents: Meningococcal

	with cte_DENOMINATOR as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where t1.enc_timestamp >= DATEADD(YY,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 11 AND DATEDIFF(YY,T4.DATEOFBIRTH,GETDATE()) <= 13 ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_IMMUNIZATION T3
	ON T1.ENC_ID = T3.enc_id
	where cpt_CODE  in ('90734')
	and exists ( select enc_patient_id from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))


	INSERT #SCORECARD
	select site_center_name,'Immunizations for Adolescents: Meningococcal' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,0 as universe,count(distinct enc_patient_id) as denominator ,0 as numerator from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	-- Immunizations for Adolescents: Tdap

	with cte_DENOMINATOR as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where t1.enc_timestamp >= DATEADD(YY,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 10 AND DATEDIFF(YY,T4.DATEOFBIRTH,GETDATE()) <= 13 ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_IMMUNIZATION T3
	ON T1.ENC_ID = T3.enc_id
	where cpt_CODE  in ('90715')
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))



	INSERT #SCORECARD
	select site_center_name,'Immunizations for Adolescents: Tdap' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,0 as universe,count(distinct enc_patient_id) as denominator ,0 as numerator from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;

	-- HPV Vaccination

	with cte_DENOMINATOR as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	WHERE t1.enc_timestamp >= DATEADD(YY,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 9 AND DATEDIFF(YY,T4.DATEOFBIRTH,GETDATE()) <= 13 ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_IMMUNIZATION T3
	ON T1.ENC_ID = T3.enc_id
	WHERE cpt_CODE  in ('90649','90650','90651')
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))


	INSERT #SCORECARD
	select site_center_name,'HPV Vaccination' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,0 as universe,count(distinct enc_patient_id) as denominator ,0 as numerator from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	--Claims/Encounter Submissions
	with cte_DENOMINATOR as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	where t1.enc_timestamp  between '20190101' and getdate() ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN T_CHARGECAPTURE T3
	ON T1.ENC_ID = T3.cc_enc_id
	where ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))


	INSERT #SCORECARD
	select site_center_name,'Claims/Encounter Submissions' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,0 as universe,count(distinct enc_patient_id) as denominator ,0 as numerator from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	--Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents
	with cte_eligibile_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where t1.enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
	AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 3 and DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 3  ),


	cte_denominator as ( 
	SELECT t2.site_center_name,ENC_PATIENT_ID  FROM T_ENCOUNTER T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	where exists ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE ctu where ctu.enc_patient_id = t1.enc_patient_id and ctu.site_center_name = t2.site_center_name)
	and ENC_TIMESTAMP  between '20190101' and getdate() ),

	cte_bmi_assessment as (
	select distinct bmi.encounter_id as bmi_enc_id,bmi.site_id,bmi.patient_id as bmi_patient_id 
		from t_assessment bmi 
		inner join t_encounter enc
		on bmi.encounter_id = enc.enc_id
		where icd10_code in ( 'Z68.51','Z68.52','Z68.53','Z68.54', 'V85.51','V85.52','V85.53','V85.54')
		and enc.enc_timestamp  between '20190101' and getdate()
		),

	cte_nutritional_couselling as (
	select distinct bmi.encounter_id as bmi_enc_id,bmi.site_id,bmi.patient_id as bmi_patient_id 
		from t_assessment bmi 
		inner join t_encounter enc
		on bmi.encounter_id = enc.enc_id
		where icd10_code in ( 'Z71.3')
		and enc.enc_timestamp  between '20190101' and getdate()
	union
	select distinct cc.cc_enc_id as cc_enc_id,enc_site_id,enc_patient_id
		from t_chargecapture cc
		inner join t_encounter enc
		on cc.cc_enc_id = enc.enc_id
		where cc_cpt_code in ( '97802','97803','92804')
		and enc.enc_timestamp  between '20190101' and getdate()
		),
	cte_physical_activity_counselling as (
	select distinct bmi.encounter_id as bmi_enc_id,bmi.site_id,bmi.patient_id as bmi_patient_id 
		from t_assessment bmi 
		inner join t_encounter enc
		on bmi.encounter_id = enc.enc_id
		where icd10_code in ( 'Z02.5', 'Z71.82')
		and enc.enc_timestamp  between '20190101' and getdate()
	union
	select distinct cc.cc_enc_id as cc_enc_id,enc_site_id,enc_patient_id
		from t_chargecapture cc
		inner join t_encounter enc
		on cc.cc_enc_id = enc.enc_id
		where cc_cpt_code in ( 'G0447','S9451')
		and enc.enc_timestamp  between '20190101' and getdate()
		),

	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,t1.bmi_patient_id  as patient_id  
	FROM cte_bmi_assessment T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID
	INNER JOIN cte_nutritional_couselling T3
	ON T1.bmi_ENC_ID = T3.bmi_ENC_ID
	INNER JOIN cte_physical_activity_counselling T4
	ON T1.bmi_ENC_ID = T4.bmi_ENC_ID
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.bmi_patient_id and ctd.site_center_name = t2.site_center_name))


	INSERT #SCORECARD
	select site_center_name,'Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	--Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan


	with cte_universe as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.enc_SITE_ID = T2.SITE_ID
	INNER JOIN MPI.PERSON_PATIENT T3
	ON  T1.ENC_PATIENT_ID = T3.PAT_ID
	INNER JOIN MPI.PERSONDEMOGRAPHIC T4
	ON T3.PERSON_ID = T4.PERSONID
	where DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) between 3 and 17 ),


	CTE_denominator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_universe ctur where ctur.enc_patient_id = t1.enc_patient_id and ctur.site_center_name = t2.site_center_name)),

	cte_bmi_check as (SELECT DISTINCT t2.site_center_name,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID 
	and  icd10_code like 'z68.%' 
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.patient_id and ctd.site_center_name = t2.site_center_name ) ) ,

	cte_nutritional_counselling as ( SELECT DISTINCT t2.site_center_name,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID 
	where  icd10_code = 'z71.3' 
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.patient_id and ctd.site_center_name = t2.site_center_name )
	union 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where CC_CPT_code in ( '97802','97803','97804','G0270', 'G0271','G0447','S9449','S9451','S9452','S9470' ) 
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name )),

	cte_physical_activity_counselling as ( SELECT DISTINCT t2.site_center_name,PATIENT_ID FROM T_ASSESSMENT T1
	INNER JOIN SITE_MASTER T2
	ON T1.SITE_ID = T2.SITE_ID 
	where  icd10_code in ('Z71.82','Z02.5')
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.patient_id and ctd.site_center_name = t2.site_center_name )
	union 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where CC_CPT_code in ( 'G0447','S9451' ) 
	and exists ( select 1 from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name ) ),


	CTE_numerator as ( 
	SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
	INNER JOIN SITE_MASTER T2
	ON T1.ENC_SITE_ID = T2.SITE_ID
	INNER JOIN t_chargecapture T3
	ON T1.ENC_ID = T3.CC_ENC_ID
	where ENC_TIMESTAMP  between '20190101' and getdate()
	and exists ( select 1 from cte_bmi_check bmi where bmi.patient_id = t1.enc_patient_id and bmi.site_center_name = t2.site_center_name)
	and exists ( select 1 from cte_nutritional_counselling bmi where bmi.patient_id = t1.enc_patient_id and bmi.site_center_name = t2.site_center_name)
	and exists ( select 1 from cte_physical_activity_counselling bmi where bmi.patient_id = t1.enc_patient_id and bmi.site_center_name = t2.site_center_name)
	)


	INSERT #SCORECARD
	select site_center_name,'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
	select site_Center_Name,count(distinct enc_patient_id) as universe,0 as denominator,0 as numerator from cte_universe group by site_center_name 
	union all
	select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name 
	union all
	select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
	group by site_center_name;


	--Flu shots for Adults Ages 18-64

        with cte_DENOMINATOR as ( SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID FROM T_encounter T1
        INNER JOIN SITE_MASTER T2
        ON T1.enc_SITE_ID = T2.SITE_ID
        INNER JOIN MPI.PERSON_PATIENT T3
        ON  T1.ENC_PATIENT_ID = T3.PAT_ID
        INNER JOIN MPI.PERSONDEMOGRAPHIC T4
        ON T3.PERSON_ID = T4.PERSONID
        where t1.enc_timestamp >= DATEADD(YY,-3,GETDATE())
        AND DATEDIFF(YY,T4.DATEOFBIRTH,getdate()) >= 18 AND DATEDIFF(YY,T4.DATEOFBIRTH,GETDATE()) <= 64 ),


        CTE_numerator as (
        SELECT DISTINCT t2.site_center_name,enc_PATIENT_ID as patient_id FROM t_encounter T1
        INNER JOIN SITE_MASTER T2
        ON T1.ENC_SITE_ID = T2.SITE_ID
        INNER JOIN T_CHARGECAPTURE T3
        ON T1.ENC_ID = T3.cc_enc_id
        where cc_cpt_CODE  in ('90655','90657','90661','90662','90673','90685','90686','90687','90688','G0008')
	and cc_date_of_service >= '20190101' and cc_date_of_service <= getdate()
        and exists ( select enc_patient_id from cte_denominator ctd where ctd.enc_patient_id = t1.enc_patient_id and ctd.site_center_name = t2.site_center_name))


        INSERT #SCORECARD
        select site_center_name,'Flu shots for Adults Ages 18-64' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
        select site_Center_Name,0 as universe,count(distinct enc_patient_id) as denominator ,0 as numerator from cte_denominator group by site_center_name
        union all
        select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
        group by site_center_name;



 	--Lipid Management for patients with Cardiovascular disease
        with cte_eligibile_universe as ( SELECT DISTINCT T2.SITE_CENTER_NAME,PATIENT_ID FROM T_ASSESSMENT T1
        INNER JOIN SITE_MASTER T2
        ON T1.SITE_ID = T2.SITE_ID
        WHERE icd10_code in ('I13.10', 'I12.9', 'I11.9', 'I10', 'I50.20', 'I50.21', 'I50.22', 'I50.23', 'I50.30', 'I50.31', 'I50.32', 'I50.33', 'I50.40', 'I50.41', 
		'I50.42', 'I50.43', 'I50.9', 'I50.1', 'I50.20',
        'I50.21', 'I50.22', 'I50.23', 'I50.30', 'I50.31', 'I50.32', 'I50.33', 'I50.40', 'I50.41', 'I50.42', 'I50.43', 'I50.9', 'E78.4', 'E78.5', 'I09.2', 'I05.0', 'I06.0', 'I08.0', 'I07.0',
        'I07.1', 'I07.2', 'I07.8', 'I07.9', 'I09.0', 'I21.09', 'I25.2', 'I20.8', 'I25.10', 'I20.9', 'I21.09', 'I21.3', 'I25.10', 'I25.2', 'I25.84', 'I25.9', 'I10', 'I11.0', 'I11.9', 'I25.10',
        'I48.91', 'I50.9', 'I63.9', 'I65.23', 'I65.29', 'I67.2', 'I67.9', 'I73.9' )
        AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


        cte_denominator as (
        SELECT distinct T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
        INNER JOIN SITE_MASTER T2
        ON T1.ENC_SITE_ID = T2.SITE_ID
        WHERE ENC_TIMESTAMP  between '20190101' and getdate()
        and EXISTS  ( select 1 from cte_eligibile_universe CTU WHERE CTU.PATIENT_ID = T1.ENC_PATIENT_ID AND CTU.SITE_CENTER_NAME = T2.SITE_CENTER_NAME )),

		 CTE_numerator as (
        SELECT DISTINCT T2.SITE_CENTER_NAME,PAT_ID as PATIENT_ID FROM T_ORDER T1
        INNER JOIN SITE_MASTER T2
        ON T1.SITE_ID = T2.SITE_ID
        WHERE cpt_code in ('3048F','3049F','3050F')
        AND ordered_DATE  between '20190101' and getdate()
        and EXISTS ( select 1 from cte_denominator CTD WHERE CTD.ENC_PATIENT_ID = T1.PAT_ID AND CTD.SITE_CENTER_NAME = T2.SITE_CENTER_NAME ))

        INSERT #SCORECARD

        select site_center_name,'Lipid Management for patients with Cardiovascular disease' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator 
	from (
        select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name
        union all
        select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name
        union all
        select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
        group by site_center_name;


	--Lipid Management for patients with Diabetes

	with cte_codes as ( SELECT DISTINCT t2.site_center_name,PATIENT_ID FROM T_ASSESSMENT T1
        INNER JOIN SITE_MASTER T2
        ON T1.SITE_ID = T2.SITE_ID
        WHERE icd10_code in ('E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641',
	'E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319','E08.321','E08.329',
	'E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311','E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349',
	'E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331','E13.339','E13.341','E13.349','E13.351','E13.359','E13.36','E13.39',
	'E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41','E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44',
        'E13.49','E13.610','E08.51','E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630',
	'E08.638','08.649','E08.69','E09.618', 'E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622',
	'E13.628','E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01','E10.69',
	'E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349','E11.351','E11.359','E11.36',
	'E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36','E10.39','E11.40','E11.41','E11.42','E11.43',
        'E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620',
	'E11.621','E11.622','E11.628','E11.630', 'E11.638','E11.649','E10.618','E10.620','E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8')
        AND ASSESSMENT_DATE >= DATEADD(YEAR,-3,GETDATE()) ),


        cte_access_to_care as ( SELECT DISTINCT T2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
        INNER JOIN SITE_MASTER T2
        ON T1.ENC_SITE_ID = T2.SITE_ID
        INNER JOIN T_CHARGECAPTURE T3
        ON T1.ENC_ID = T3.CC_ENC_ID
        WHERE   enc_timestamp >= DATEADD(YEAR,-3,GETDATE())
        AND CC_CPT_CODE IN ('99381','99382','99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397','G0438', 'G0439',
        '90791', '90792', '90832','90833','90834','90835','90836','90837','90838','90839','90840', '90845','90846','90847', '90849', '90853', '90875', '90876',
        '98966','98967','98968', '99221','99222','99223', '99231','99232','99233', '99238', '99239', '99251','99252','99253','99254','99255', '99381','99382',
        '99383','99384','99385','99386','99387', '99391','99392','99393','99394','99395','99396','99397', '99441','99442','99443') ),

		 cte_eligibile_universe as ( select distinct cte1.site_center_name,cte1.patient_id
                from cte_codes cte1
                inner join cte_access_to_care cte2
                on cte1.patient_id = cte2.enc_patient_id
                and cte1.site_center_name = cte2.site_center_name) ,

        cte_denominator as (
        SELECT distinct t2.SITE_CENTER_NAME,ENC_PATIENT_ID FROM T_ENCOUNTER T1
        INNER JOIN SITE_MASTER T2
        ON T1.ENC_SITE_ID = T2.SITE_ID
        WHERE EXISTS ( SELECT 1 FROM CTE_ELIGIBILE_UNIVERSE CTU WHERE CTU.PATIENT_ID = T1.ENC_PATIENT_ID AND CTU.SITE_CENTER_NAME = T2.SITE_CENTER_NAME )
        and ENC_TIMESTAMP  between '20190101' and getdate() ),

         CTE_numerator as (
        SELECT DISTINCT T2.SITE_CENTER_NAME,PAT_ID as PATIENT_ID FROM T_ORDER T1
        INNER JOIN SITE_MASTER T2
        ON T1.SITE_ID = T2.SITE_ID
        WHERE cpt_code in ('3048F','3049F','3050F')
        AND ordered_DATE  between '20190101' and getdate()
        and EXISTS ( select 1 from cte_denominator CTD WHERE CTD.ENC_PATIENT_ID = T1.PAT_ID AND CTD.SITE_CENTER_NAME = T2.SITE_CENTER_NAME ))

		INSERT #SCORECARD

        select site_center_name,'Lipid Management for patients with Diabetes' as measure,sum(universe) as universe,sum(denominator) as denominator,sum(numerator) as numerator from (
        select site_Center_Name,count(distinct patient_id) as universe,0 as denominator,0 as numerator from cte_eligibile_universe group by site_center_name
        union all
        select site_Center_Name,0,count(distinct enc_patient_id),0 from cte_denominator group by site_center_name
        union all
        select site_Center_Name,0,0,count(distinct patient_id) from cte_numerator group by site_center_name ) a
        group by site_center_name;

with cte_denom as ( select site_center_name,count(distinct person_id) as denominator from t_encounter t1,mpi.person_patient t2, Site_Master t3
where t1.enc_patient_id= t2.pat_id
and t1.enc_site_id = t3.Site_ID
and t2.active_ind = 'Y'
and enc_timestamp between '20190101' and GETDATE()
group by site_center_name ),

cte_numerator as ( select site_Center_Name,COUNT(distinct person_id) as numerator
from t_chargecapture t1
inner join t_encounter t2
on t1.cc_enc_id = t2.enc_id
inner join Site_Master t3
on t2.enc_site_id = t3.site_id
inner join mpi.person_patient t4
on t1.cc_patient_id = t4.pat_id
and t4.active_ind = 'Y'
where cc_date_of_service between '20190715' and GETDATE()
and cc_cpt_Code in ('hie01','hie02')
group by site_center_name )

insert #SCORECARD 
select ct1.site_center_name,'Bronx Rhio Consents', 0, denominator,numerator
	from cte_denom ct1
	left outer join cte_numerator ct2
	on ct1.site_center_name = ct2.site_center_name;

-- Blood Lead Test
 with cte_denominator as (
	select site_center_name, pat_id ,1 as denominator from t_patient  t1
	inner join Provider_Master t2
	on t1.pat_responsible_provider_id = t2.prov_id
	and prov_delete_ind = 'N'
	inner join  Site_Master t3
	on t2.prov_orig_site_id = t3.site_orig_site_id
	where DATEDIFF(MM,pat_date_of_birth,getdate()) BETWEEN 12 AND 24 
	and pat_status = 'Active' 
	and pat_delete_ind = 'N' 
	and pat_expired_ind = 'N'
	 ),
 
cte_numerator as ( 
select site_center_name,count( distinct cc_patient_id ) as numerator  
	from t_chargecapture t1
	inner join Site_Master t2
	on t1.cc_orig_site_id = t2.site_orig_site_id
	where cc_cpt_Code = '83655'
	and cc_delete_ind = 'N'
	and cc_patient_id in ( select pat_id from cte_denominator ) 
	group by site_center_name)
	

insert #scorecard
 select site_center_name,'Blood Lead Test' as measure,0 as universe,sum(denominator) as denominator,sum(numerator) as numerator 
	from ( SELECT site_center_name, denominator, 0 as numerator from cte_denominator
		   union all
		   select site_center_name,0 as denominator, numerator from cte_numerator ) a
 group by site_center_name; 


with cte_denominator as (
	select distinct site_center_name, pat_id  from t_patient  t1
	inner join t_assessment t2
	on t1.pat_id = t2.patient_id
	and t2.delete_ind = 'N'
	inner join  Site_Master t3
	on t2.site_id = t3.site_id
	where DATEDIFF(YY,pat_date_of_birth,getdate()) BETWEEN 3 AND 18
	and pat_status = 'Active' 
	and pat_delete_ind = 'N' 
	and pat_expired_ind = 'N'
	and icd10_code in ('J02.0','J02.8','J02.9','J03.00','J03.01','J03.80','J03.81','J03.90','J03.91')
	

	 ),
 
cte_numerator as ( 
select distinct site_center_name, pat_id
	from t_order t1
	inner join Site_Master t2
	on t1.site_id = t2.site_id
	where cpt_code in ('87070','87071','87081','87430','87650','87651','87652','87880')
	and delete_ind = 'N'
	and pat_id in ( select pat_id from cte_denominator ) 
	)

insert #scorecard
 select site_center_name,'Strep Test For Pharyngitist' as measure,0 as universe,sum(denominator) as denominator,sum(numerator) as numerator 
	from ( SELECT site_center_name, count(distinct pat_id) as denominator, 0 as numerator from cte_denominator group by site_center_name
		   union all
		   select site_center_name,0 as denominator, count(distinct pat_id) as numerator from cte_numerator group by site_center_name) a
 group by site_center_name;

delete #scorecard where sitename in ('NY State Claims','WellCare');

	"""
	salient_query="""
	    select cast(pcp_npi as bigint) as pcp_npi, measure as  measure,
	    0 as universe,monthly_member_denominator as denominator,monthly_member_numerator as numerator 
	    from DSRIP_Scorecard_Measures 
	    where pcp_npi != ''
	    and lower(measure) not in (
	    'adolescent immunizations combo 1',
	    'adult access preventive (20 - 44)',
	    'adult access preventive (45 - 64)',
	    'adult access preventive (65 and older)',
	    'alcohol screening',
	    'alcohol screening results',
	    'annual dental visit',
	    'asthma action plan',
	    'asthma diagnosis',
	    'bmi assessment',
	    'bmi cpt',
	    'bmi icd',
	    'breast cancer screening',
	    'cv monitoring (cv & schizophrenia)',
	    'cervical cancer screening',
	    'child access - primary care (12 to 19)',
	    'child access - primary care (12 to 24 months)',
	    'child access - primary care (25 months to 6)',
	    'child access - primary care (7 to 11)',
	    'child adhd medication f/u (continuation)',
	    'child adhd medication f/u (initiation)',
	    'chlamydia screening in women',
	    'clinical depression screening',
	    'clinical depression screening results',
	    'colorectal cancer screen',
	    'control blood pressure',
	    'copd diagnosis',
	    'diabetes - foot exam',
	    'diabetes - nephropathy screening',
	    'diabetes diagnosis',
	    'diabetes foot exam',
	    'dm eye exam',
	    'dm hba1c testing',
	    'drug assessment',
	    'hpv vaccination',
	    'immunizations for adolescents: meningococcal',
	    'immunizations for adolescents: tdap',
	    'preventive care and screening: body mass index (bmi) screening and follow- up plan',
	    'tobacco preventive care and screening: tobacco use: screening and cessation intervention',
	    'tobacco use assessment',
	    'tobacco use assessment result',
	    'use of spirometry testing in the assessment and diagnosis of copd',
	    'weight assessment and counseling for nutrition and physical activity for children and adolescents',
	    'well-child (15 mo 5+ visits)' )
	    and added_tz = ( select max(added_tz) from dsrip_scorecard_measures )
	    """

	prov_site_query="""
	                select distinct prov_npi,site_center_name as sitename from provider_master t1, site_master t2
	                where prov_npi is not null 
	                and t1.prov_orig_site_id = t2.site_orig_site_id
	                """
	cur=conn_arcadia.execute(query_custom_measures)
	cur.close()
	df=pd.read_sql("select * from #scorecard",conn_arcadia)
	salient_df=pd.read_sql(salient_query,conn_somos)
	prov_site_df=pd.read_sql(prov_site_query,conn_arcadia)
	mdf=salient_df.merge(prov_site_df,how="inner",left_on=["pcp_npi"],right_on=["prov_npi"])
	mdf["universe"]=mdf["universe"].astype(int)
	mdf["denominator"]=mdf["denominator"].astype(int)
	mdf["numerator"]=mdf["numerator"].astype(int)
	gdf=mdf.groupby(["sitename","measure"],as_index=False).sum().reset_index()
	gdf.drop(columns=["index","pcp_npi","prov_npi"],inplace=True)
	fdf=df.append(gdf,ignore_index=True)
	fdf.sort_values(by=["sitename","measure"],ascending=True,inplace=True)
	fdf["for_date"] = datetime.datetime.strftime(datetime.datetime.now(),"%Y%m%d")
	fdf.to_csv(path_or_buf="/home/etl/etl_home/temp/" + output_file_name , columns=["for_date","sitename","measure","universe","denominator","numerator"],encoding="utf-8",index=False)
	#writer = pd.ExcelWriter('/home/etl/etl_home/temp/'+ output_file_excel)
	#fdf.to_excel(writer,'sheet1',index=False)
	#writer.save()
def copy_to_s3(filename):
	s3_filename=filename.split("/")[5]
	print(s3_filename)
	try:
		session = boto3.Session()
		s3_resource=session.resource('s3')
		s3_resource.Object('sftp_test',s3_filename).put(Body=open(filename, 'rb'))
		load_redshift(s3_filename)
	except Exception as e:
		print(str(e))

def load_redshift(s3_filename):
	rconn=pyodbc.connect(dsn="somos_redshift_1")
	query=""" delete scorecard_report where for_date = '{0}' ;
	copy scorecard_report(for_date,sitename,measure,universe,denominator,numerator)
	from 's3://sftp_test/{1}'
	iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
	TRIMBLANKS
	MAXERROR 30
	ignoreheader 1
	region 'us-east-1'
	dateformat 'auto'
	csv;
	"""
	rconn.execute(query.format(cdate,s3_filename))
	rconn.commit()
	rconn.close()
	

def main():
	query_db()
	copy_to_s3('/home/etl/etl_home/temp/' + output_file_name)
if __name__ == '__main__':
	main()
