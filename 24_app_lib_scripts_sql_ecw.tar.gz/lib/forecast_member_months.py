from datetime import datetime
import pandas as pd
import pyodbc
from dateutil.relativedelta import relativedelta
import warnings
import statsmodels.api as sm
from statsmodels.tsa.arima_model import ARIMA
from math import sqrt
from sqlalchemy import create_engine
warnings.simplefilter(action='ignore')

CONNECTION = create_engine(
    'postgresql://dsanz:Bacalao2@edw-01.c0jl6w6zborh.us-east-1.redshift.amazonaws.com:5439/dev'
)

ALL_DF = pd.read_csv(
    'member_months_forecast.txt',
    delimiter='|',
    names=[
        'mco', 'ipa', 'lob', 'product', 'practice', 'pcp', 'taxonomy', 'age',
        'sex', 'the_date', 'member_months', 'state'
    ])
ALL_DF['the_date'] = pd.to_datetime(ALL_DF['the_date']).dt.date
PCPs = ALL_DF['pcp'].unique()
for df_pcp in PCPs:
    temp_df = ALL_DF[(ALL_DF['pcp'] == df_pcp)]
    FINAL_DF = pd.DataFrame()
    SOURCES = temp_df.groupby([
        'mco', 'ipa', 'lob', 'product', 'practice', 'pcp', 'taxonomy', 'age',
        'sex'
    ],
                              as_index=False).first()[[
                                  'mco', 'ipa', 'lob', 'product', 'practice',
                                  'pcp', 'taxonomy', 'age', 'sex'
                              ]].values.tolist()

    SCORE_LIST = []
    for mco, ipa, lob, product, practice, pcp, taxonomy, age, sex in SOURCES:
        rows = temp_df[(temp_df['mco'] == mco) & (temp_df['ipa'] == ipa) &
                       (temp_df['lob'] == lob) &
                       (temp_df['product'] == product) &
                       (temp_df['practice'] == practice) &
                       (temp_df['pcp'] == pcp) &
                       (temp_df['taxonomy'] == taxonomy) &
                       (temp_df['age'] == age) & (temp_df['sex'] == sex)]
        start_date = rows['the_date'].max() - relativedelta(months=6)
        end_date = start_date + relativedelta(months=13)
        forecast_temp = pd.DataFrame(
            pd.date_range(start_date, end_date, freq='MS'),
            columns=['the_date'])
        forecast_temp['the_date'] = forecast_temp['the_date'].dt.date
        forecast_temp.insert(0, 'mco', mco)
        forecast_temp.insert(0, 'ipa', ipa)
        forecast_temp.insert(0, 'lob', lob)
        forecast_temp.insert(0, 'product', product)
        forecast_temp.insert(0, 'practice', practice)
        forecast_temp.insert(0, 'pcp', pcp)
        forecast_temp.insert(0, 'taxonomy', taxonomy)
        forecast_temp.insert(0, 'age', age)
        forecast_temp.insert(0, 'sex', sex)
        X = rows[['the_date', 'member_months']]
        X.set_index('the_date', inplace=True)
        try:
            model = ARIMA(X, order=(1, 1, 0))
            model_fit = model.fit(disp=0)
        except:
            continue
        output = model_fit.forecast(steps=13)
        forecast_dates = pd.concat([
            forecast_temp,
            pd.DataFrame(data=output[0], columns=['member_months'])
        ],
                                   axis=1)
        forecast_dates['state'] = 'forecast'
        rows['state'] = 'real'
        df = rows.append(forecast_dates)
        df.loc[df['member_months'] < 0.0, 'member_months'] = 0.0
        df_accuracy_1 = df[df.duplicated(subset='the_date', keep=False)]
        df_accuracy = pd.merge(
            df_accuracy_1[df_accuracy_1['state'] == 'real'],
            df_accuracy_1[df_accuracy_1['state'] == 'forecast'],
            on='the_date')
        df_accuracy['percentage'] = (abs(df_accuracy['member_months_x'] -
                                         df_accuracy['member_months_y']) *
                                     100) / df_accuracy['member_months_x']
        score = 100 - df_accuracy.percentage.mean()
        if score > 0:
            df['score'] = score
            df.to_sql(
                con=CONNECTION,
                name='member_months_forecast',
                index=False,
                if_exists='append')
