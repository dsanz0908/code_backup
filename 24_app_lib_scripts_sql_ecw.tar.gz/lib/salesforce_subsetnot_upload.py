# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf8')

from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce

COPY_QUERY = """
create temp table subsetnots(
pat_id varchar(255),
CIN varchar(255),
PAT_FIRST_NAME varchar(255),
PAT_LAST_NAME varchar(255),
PAT_DATE_OF_BIRTH date,
PHONE_NO varchar(255),
PAT_ADDR_1 varchar(255),
PAT_ADDR_2 varchar(255),
PAT_CITY varchar(255),
PAT_STATE varchar(255),
PAT_ZIP varchar(255),
PROV_FIRST_NAME varchar(255),
PROV_LAST_NAME varchar(255),
PROV_NPI varchar(255),
MEASURE varchar(255));

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Preventive_Care_and_Screening__Body_Mass_Index__BMI__Screening_and_Follow__Up_Plan_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

UPDATE subsetnots
SET    cin = mco_cin
FROM   fuzz_test t1
WHERE  t1.arcadia_pat_id = subsetnots.pat_id
       AND cin = '';

UPDATE subsetnots
SET    cin = policy_nbr
FROM   direct_match t1
WHERE  t1.pat_id = subsetnots.pat_id
       AND cin = '';
"""


READD_QUERY = """
WITH cte_subset_nots 
     AS (SELECT *, 
                measure AS sf_measure 
         FROM   subsetnots) 
SELECT contact_assigned_chw__c, 
       sf_measure, 
       id, 
       pcp__c, 
       recordtypeid, 
       procedure, 
       subject, 
       project_end_date__c, 
       source_created_by__c, 
       status 
FROM   (SELECT salesforce_providers.contact_assigned_chw__c, 
               sf_measure, 
               salesforce_patients.id, 
               salesforce_patients.pcp__c, 
               subject_recordtypeid.recordtypeid, 
               ''                        AS procedure, 
               subject_recordtypeid.subject, 
               '2020-06-30'              AS project_end_date__c, 
               '20200212 subset not my6' AS source_created_by__c, 
               'Open'                    AS status, 
               Row_number() 
                 OVER ( 
                   partition BY salesforce_patients.cin__c, sf_measure 
                   ORDER BY salesforce_patients.id)          AS r 
        FROM   cte_subset_nots 
               LEFT JOIN (SELECT pat_id, 
                                 policy_nbr, 
                                 payer 
                          FROM   direct_match 
                          UNION 
                          SELECT arcadia_pat_id, 
                                 mco_cin, 
                                 mco_source 
                          FROM   fuzz_test) AS b 
                      ON cte_subset_nots.pat_id = b.pat_id 
               JOIN salesforce_patients 
                 ON CASE 
                      WHEN Trim(cin) <> '' THEN cin 
                      ELSE policy_nbr 
                    END = salesforce_patients.cin__c
               join salesforce_providers on salesforce_providers.id = salesforce_patients.pcp__c      
               JOIN (SELECT *, 
                            Row_number() 
                              OVER ( 
                                partition BY measure__c 
                                ORDER BY c DESC) AS rn 
                     FROM   (SELECT 'Subset Not Access (MY6)' AS subject, 
                                    measure__c, 
                                    recordtypeid, 
                                    Count(*)                  AS c 
                             FROM   salesforce_tasks 
                             WHERE  project_end_date__c = '2019-12-31' 
                                    AND subject ILIKE '%access%' 
                             GROUP  BY 1, 
                                       2, 
                                       3 
                             UNION 
                             SELECT 'Subset Not Screening (MY6)', 
                                    measure__c, 
                                    recordtypeid, 
                                    Count(*) 
                             FROM   salesforce_tasks 
                             WHERE  project_end_date__c = '2019-12-31' 
                                    AND subject ILIKE '%screening%' 
                             GROUP  BY 1, 
                                       2, 
                                       3 
                             UNION 
                             SELECT 'Subset Not Immunization (MY6)', 
                                    measure__c, 
                                    recordtypeid, 
                                    Count(*) 
                             FROM   salesforce_tasks 
                             WHERE  project_end_date__c = '2019-12-31' 
                                    AND subject ILIKE '%immunization%' 
                             GROUP  BY 1, 
                                       2, 
                                       3)) AS subject_recordtypeid 
                 ON subject_recordtypeid.measure__c = sf_measure 
        WHERE  salesforce_patients.cin__c NOT IN ( 'N/A', '0' ) 
               AND Trim(salesforce_patients.pcp__c) <> '' 
               AND sf_measure IS NOT NULL 
               AND rn = 1) AS t1 
WHERE  r = 1 
       AND NOT EXISTS (SELECT 1 
                       FROM   salesforce_tasks 
                       WHERE  salesforce_tasks.whoid = t1.id 
                              AND sf_measure = measure__c 
                              AND project_end_date__c = '2020-06-30') 
"""


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


SF, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect('dsn=somos_redshift_1')
CONNECTION.execute(COPY_QUERY)
READD_TASKS = CONNECTION.execute(READD_QUERY).fetchall()
CONNECTION.close()

TASK_COLUMNS = [
    'ownerid', 'measure__c', 'whoid', 'pcp__c', 'recordtypeid', 'procedure__c',
    'subject', 'project_end_date__c', 'source_created_by__c', 'status'
]
TASKS = []

for task in READD_TASKS:
    TASKS.append(dict(zip(TASK_COLUMNS, task)))
    if len(TASKS) == 10000:
        SF.bulk.Task.insert(TASKS)
        TASKS = []
SF.bulk.Task.insert(TASKS)
