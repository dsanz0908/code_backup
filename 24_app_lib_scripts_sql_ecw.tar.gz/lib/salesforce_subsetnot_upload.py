from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce

COPY_QUERY = """
create temp table subsetnots(
pat_id varchar(255),
CIN varchar(255),
PAT_FIRST_NAME varchar(255),
PAT_LAST_NAME varchar(255),
PAT_DATE_OF_BIRTH date,
PHONE_NO varchar(255),
PAT_ADDR_1 varchar(255),
PAT_ADDR_2 varchar(255),
PAT_CITY varchar(255),
PAT_STATE varchar(255),
PAT_ZIP varchar(255),
PROV_FIRST_NAME varchar(255),
PROV_LAST_NAME varchar(255),
PROV_NPI varchar(255),
MEASURE varchar(255));


copy subsetnots
from 's3://sftp_test/subsetnots_coding_Adolescent_Immunizations_Combo_1_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Adolescent_Immunizations_Combo_2_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Adult_Access_Preventive__20___44__20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Adult_Access_Preventive__45___64__20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Adult_Access_Preventive__65_and_Older__20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Alcohol_Screening_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Alcohol_Screening_Results_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Asthma_Action_Plan_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Asthma_Diagnosis_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Blood_Lead_Test_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_BMI_Assessment_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_BMI_CPT_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_BMI_ICD_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Breast_Cancer_Screening_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Cardiovacular__Diagnosis_20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Cardiovascular_Monitoring_for_People_with_Cardiovascular_Disease_and_Schizophrenia_20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Cervical_Cancer_Screening_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Child_Access___Primary_Care__12_to_19__20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Child_Access___Primary_Care__12_to_24_Months__20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Child_Access___Primary_Care__25_Months_to_6__20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Child_Access___Primary_Care__7_to_11__20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Child_ADHD_Medications_Continuation_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Child_ADHD_Medications_Initiation_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Childhood_Immunization_Status_Combo_10_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Childhood_Immunization_Status_Combo_3_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Chlamydia_Screening_in_women_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Claims_Encounter_Submissions_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Clinical_Depression_Screening_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Clinical_Depression_Screening_Results_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Colorectal_Cancer_Screening_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Comprehensive_Diabetes_Care_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Control_Blood_Pressure_Coding_20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_COPD_Diagnosis_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Diabetes_Diagnosis_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Diabetes___Dialated_Eye_Exam_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Diabetes___Foot_Exam_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Diabetes_Monitoring_for_People_with_Diabetes_and_Schizophrenia_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Diabetes___Nephropathy_screening_Coding_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Drug_Assessment_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_HPV_Vaccination_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Immunizations_for_Adolescents__Meningococcal_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Immunizations_for_Adolescents__Tdap_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_LBP_Imaging_for_Low_Back_Pain_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Lipid_Management_for_patients_with_Cardiovascular_disease_20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Lipid_Management_for_patients_with_Diabetes_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Preventive_Care_and_Screening__Body_Mass_Index__BMI__Screening_and_Follow__Up_Plan_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Preventive_Care_and_Screening__Tobacco_Use__Screening_and_Cessation_Intervention_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Strep_Test_For_Pharyngitis_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Tobacco_Use_Assessment_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Tobacco_Use_Assessment_Results_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Use_of_Spirometry_Testing_in_the_Assessment_and_Diagnosis_of_COPD_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Weight_Assessment_and_Counseling_for_Nutrition_and_Physical_Activity_for_Children_and_Adolescents_20200130.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';

copy subsetnots
from 's3://sftp_test/subsetnots_coding_Well_Care_Visits___5__visits_In_first_15_months_20200129.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
ignoreheader 1
MAXERROR 30
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';


create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';
"""

ADD_PATIENTS_QUERY = """
SELECT * 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY policy_nbr 
                   ORDER BY payer DESC) AS rn 
        FROM   (SELECT DISTINCT To_char(pat_date_of_birth, 'YYYY-MM-DD') AS dob, 
                                CASE 
                                  WHEN Trim(cin) <> '' THEN cin 
                                  ELSE policy_nbr 
                                END                                      AS policy_nbr, 
                                salesforce_providers.contact_assigned_chw__c, 
                                pat_first_name, 
                                pat_last_name, 
                                CASE 
                                  WHEN payer ILIKE '%affinity%' THEN 'Affinity' 
                                  WHEN payer ILIKE '%united%' THEN 'United Healthcare' 
                                  WHEN payer ILIKE '%fidelis%' THEN 'Fidelis' 
                                  WHEN payer ILIKE '%healthfirst%' 
                                        OR payer ILIKE '%health first%' THEN 'Healthfirst' 
                                  WHEN payer ILIKE '%anthem%' 
                                        OR payer ILIKE '%empire%' THEN 'Anthem' 
                                  WHEN payer ILIKE '%metroplus%' 
                                        OR payer ILIKE '%metro plus%' THEN 'Metroplus' 
                                  WHEN payer ILIKE '%wellcare%' 
                                        OR payer ILIKE '%well care%' THEN 'Metroplus' 
                                  WHEN payer ILIKE '%wellcare%' 
                                        OR payer ILIKE '%well care%' THEN 'Metroplus' 
                                  ELSE '' 
                                END                                      AS payer, 
                                '', 
                                pat_addr_1, 
                                pat_city, 
                                pat_zip, 
                                a.phone_no, 
                                pat_state, 
                                salesforce_providers.id, 
                                '012f4000000MBgDAAW' 
                FROM   subsetnots AS a 
                       INNER JOIN (SELECT pat_id, 
                                          policy_nbr, 
                                          payer 
                                   FROM   direct_match 
                                   UNION 
                                   SELECT arcadia_pat_id, 
                                          mco_cin, 
                                          mco_source 
                                   FROM   fuzz_test) AS b 
                               ON a.pat_id = b.pat_id 
                       LEFT JOIN salesforce_patients 
                              ON CASE 
                                   WHEN Trim(cin) <> '' THEN cin 
                                   ELSE policy_nbr 
                                 END = salesforce_patients.cin__c 
                       JOIN salesforce_providers 
                         ON prov_npi = individual_npi__c 
                WHERE  salesforce_patients.cin__c IS NULL 
                       AND Regexp_substr(CASE 
                                           WHEN Trim(cin) <> '' THEN cin 
                                           ELSE policy_nbr 
                                         END, '[A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][A-Z]') <> ''
                       AND Len(CASE 
                                 WHEN Trim(cin) <> '' THEN cin 
                                 ELSE policy_nbr 
                               END) = 8 
                       AND NOT EXISTS (SELECT 1 
                                       FROM   salesforce_patients 
                                       WHERE  ( CASE 
                                                  WHEN Trim(cin) <> '' THEN cin 
                                                  ELSE policy_nbr 
                                                END = salesforce_patients.cin__c ) 
                                               OR ( dob = birthdate 
                                                    AND Lower(pat_last_name) = Lower(lastname) ))))
WHERE  rn = 1
"""

READD_QUERY = """
WITH cte_subset_nots
     AS (SELECT *,
                case
when measure = 'Adolescent Immunizations Combo 2' then 'Adolescent Immunization Combo 2'
when measure = 'Adolescent Immunizations Combo 1' then 'Adolescent Immunization Combo 1'
when measure = 'Adult Access Preventive (20 - 44)' then 'Adult Access to Preventive or Ambulatory Care - 20 to 44 years'
when measure = 'Adult Access Preventive (45 - 64)' then 'Adult Access to Preventive or Ambulatory Care - 45 to 64 years'
when measure = 'Adult Access Preventive (65 and Older)' then 'Adult Access to Preventive or Ambulatory Care - 65 and older'
when measure = 'Alcohol Screening' then 'Alcohol Screening'
when measure = 'Alcohol Screening Results' then 'Alcohol Screening'
when measure = 'Annual Dental Visit' then 'Annual dental visit'
when measure = 'Anti-Rheumatic Drug Therapy for Rheumatoid Arthritis' then 'Anti-Rheumatic Drug Therapy for Rheumatoid Arthritis'
when measure = 'Antidepressant Medication Mgmt (Acute)' then 'Antidepressant Medication Management - Effective Acute Phase Treatment'
when measure = 'Antidepressant Medication Mgmt (Cont)' then 'Antidepressant Medication Management - Effective Continuation Phase Treatment'
when measure = 'Asthma Medication Ratio (5 - 64 Years)' then 'Asthma Medication Ratio (5 ? 64 Years)'
when measure = 'Blood Lead Test' then 'Blood Lead Test'
when measure = 'BMI Assessment' then 'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan'
when measure = 'BMI CPT' then 'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan'
when measure = 'BMI ICD' then 'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan'
when measure = 'Breast Cancer Screening' then 'Breast Cancer Screening'
when measure = 'Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia' then 'Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia'
when measure = 'Cervical Cancer Screening' then 'Cervical Cancer Screening'
when measure = 'Child Access - Primary Care (12 to 19)' then 'Adolescent Access to Primary Care - 12 to 19 years'
when measure = 'Child Access - Primary Care (12 to 24 Months)' then 'Children''s Access to Primary Care - 12 to 24 months'
when measure = 'Child Access - Primary Care (25 Months to 6)' then 'Children''s Access to Primary Care - 25 months to 6 years'
when measure = 'Child Access - Primary Care (7 to 11)' then 'Children''s Access to Primary Care - 7 to 11 years'
when measure = 'Child ADHD Medications Continuation' then 'Follow-up care for Children Prescribed ADHD Medications ? Continuation Phase'
when measure = 'Child ADHD Medications Initiation' then 'Follow-up care for Children Prescribed ADHD Medications ? Initiation Phase'
when measure = 'Childhood Immunization Status Combo 3' then 'Childhood Immunization Status Combo 3'
when measure = 'Childhood Immunization Status Combo 10' then 'Childhood Immunization Status Combo 10'
when measure = 'Chlamydia Screening in women' then 'Chlamydia Screening for Women'
when measure = 'Clinical Depression Screening' then 'Screening for Clinical Depression and follow-up'
when measure = 'Clinical Depression Screening Results' then 'Screening for Clinical Depression and follow-up'
when measure = 'Colorectal Cancer Screening' then 'Colorectal Cancer Screening'
when measure = 'Comprehensive Diabetes Care' then 'Comprehensive Diabetes screening - All Three Tests (HbA1c, dilated eye exam, and medical attention for nephropathy)'
when measure = 'Control Blood Pressure' then 'Controlling High Blood Pressure'
when measure = 'Control Blood Pressure Coding' then 'Controlling High Blood Pressure'
when measure = 'COPD Diagnosis' then 'Use of Spirometry Testing in the Assessment and Diagnosis of COPD'
when measure = 'Diabetes - Foot Exam' then 'Diabetes Foot Exam'
when measure = 'Diabetes - Nephropathy screening' then 'Diabetes - Nephropathy Screening'
when measure = 'Diabetes - Nephropathy screening Coding' then 'Diabetes - Nephropathy Screening'
when measure = 'Diabetes HbA1c Test' then 'Diabetes HbA1c Test'
when measure = 'Diabetes Monitoring for People with Diabetes and Schizophrenia' then 'Diabetes Monitoring for People with Diabetes and Schizophrenia'
when measure = 'Diabetes Screening (Antipsychotic Medication)' then 'Diabetes Screening for People with Schizophrenia or Bipolar Disease who are Using Antipsychotic Medication'
when measure = 'Drug Assessment' then 'Drug Assessment'
when measure = 'LBP-Imaging for Low Back Pain' then 'LBP-Imaging for Low Back Pain'
when measure = 'Flu Shots for Adults Ages 18 – 64' then 'Flu Shots for Adults Ages 18 - 65'
when measure = 'Flu shots for Adults Ages 18-64' then 'Flu Shots for Adults Ages 18 - 65'
when measure = 'Follow Up after MH Inpatient (30 Days) (Version 2)' then 'Follow-up after hospitalization for Mental Illness ? within 30 days'
when measure = 'Follow Up after MH Inpatient (7 Days) (Version 2)' then 'Follow-up after hospitalization for Mental Illness ? within 7 days'
when measure = 'Hemoglobin A1C' then 'Comprehensive Diabetes Care: Hemoglobin A1c (HbA1c) Poor Control (>9.0%) ?'
when measure = 'HPV Vaccination' then 'HPV Vaccination'
when measure = 'Immunizations for Adolescents: Meningococcal' then 'IMA - Meningococcal'
when measure = 'Immunizations for Adolescents: Tdap' then 'IMA - Tdap/Td'
when measure = 'Lipid Management for patients with Cardiovascular disease' then 'Lipid Management for patients with Cardiovascular disease'
when measure = 'Lipid Management for patients with Diabetes' then 'Lipid Management for patients with Diabetes'
when measure = 'Medication Mgmt for Asthma (50%)' then 'Medication Management for People with Asthma (5 - 64 years) - 50% of Treatment days covered'
when measure = 'Medication Mgmt for Asthma (75%)' then 'Medication Management for People with Asthma (5 - 64 years) - 75% of Treatment days covered'
when measure = 'Non-Utilizer' then 'Non-Utilizer'
when measure = 'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan' then 'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan'
when measure = 'Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention' then 'Tobacco Cessation - Strategies discussion'
when measure = 'Statin Therapy - Received Statin Therapy' then 'Statin Therapy for Patients with Cardiovascular Disease ?Received Statin Therapy'
when measure = 'Statin Therapy - Statin Adherence 80%' then 'Statin Therapy for Patients with Cardiovascular Disease ?Statin Adherence 80%'
when measure = 'Strep Test For Pharyngitis' then 'Strept Test For Pharyngitis'
when measure = 'tobacco Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention' then 'Tobacco Cessation - Strategies discussion'
when measure = 'Tobacco Use Assessment' then 'Tobacco Cessation - Strategies discussion'
when measure = 'Tobacco Use Assessment Results' then 'Tobacco Cessation - Strategies discussion'
when measure = 'Use of Spirometry Testing in the Assessment and Diagnosis of COPD' then 'Use of Spirometry Testing in the Assessment and Diagnosis of COPD'
when measure = 'Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents' then 'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan'
when measure = 'Well Care Visits - 5+ visits In first 15 months' then 'Well Child Visit: 15 months (5+ Visits)'
end AS sf_measure
         FROM   subsetnots)
SELECT DISTINCT contact_assigned_chw__c,
                sf_measure,
                id,
                pcp__c,
                CASE
                  WHEN sf_measure ILIKE '%high blood%'
                        OR sf_measure ILIKE '%cardio%' THEN '012f4000000BsSLAA0'
                  ELSE '012f4000000BsSGAA0'
                END                       AS recordtypeid,
                ''                        AS procedure,
                CASE
                  WHEN sf_measure ILIKE '%high blood%'
                        OR sf_measure ILIKE '%cardio%' THEN 'Subset Not Screening (2019)'
                  ELSE 'Subset Not Access (MY6)'
                END                       AS subject,
                '2020-06-30'              AS project_end_date__c,
                '20200130 subset not my6' AS source_created_by__c,
                'Open'                    AS status
FROM   cte_subset_nots
       LEFT JOIN (SELECT pat_id,
                         policy_nbr,
                         payer
                  FROM   direct_match
                  UNION
                  SELECT arcadia_pat_id,
                         mco_cin,
                         mco_source
                  FROM   fuzz_test) AS b
              ON cte_subset_nots.pat_id = b.pat_id
       JOIN salesforce_patients
         ON CASE
              WHEN Trim(cin) <> '' THEN cin
              ELSE policy_nbr
            END = cin__c
WHERE  cin__c NOT IN ( 'N/A', '0' )
       AND Trim(pcp__c) <> ''
       AND sf_measure IS NOT NULL
       AND NOT EXISTS (select 1 from salesforce_tasks where sf_measure = measure__c and salesforce_patients.id = whoid and project_end_date__c = '2020-06-30')
"""


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


SF, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect('dsn=somos_redshift_1')
CONNECTION.execute(COPY_QUERY)
READD_TASKS = CONNECTION.execute(READD_QUERY).fetchall()
ADD_PATIENTS_TEMP = CONNECTION.execute(ADD_PATIENTS_QUERY).fetchall()
CONNECTION.close()
ADD_PATIENTS = [p[:14] for p in ADD_PATIENTS_TEMP]
PATIENTS_COLUMNS = ['birthdate','cin__c','contact_assigned_chw__c','firstname','lastname','health_plan_carriers__c','gender__c','mailingstreet','mailingcity','mailingpostalcode','phone','mailingstate','pcp__c','recordtypeid']
PATIENTS = []
for patient in ADD_PATIENTS:
    PATIENTS.append(dict(zip(PATIENTS_COLUMNS, patient)))
    if len(PATIENTS) == 10000:
        SF.bulk.Contact.insert(PATIENTS)
        PATIENTS = []
SF.bulk.Contact.insert(PATIENTS)

"""

TASK_COLUMNS = [
    'ownerid', 'measure__c', 'whoid', 'pcp__c', 'recordtypeid', 'procedure__c',
    'subject', 'project_end_date__c', 'source_created_by__c', 'status'
]
TASKS = []
for task in READD_TASKS:
    TASKS.append(dict(zip(TASK_COLUMNS, task)))
    if len(TASKS) == 10000:
        SF.bulk.Task.insert(TASKS)
        TASKS = []
SF.bulk.Task.insert(TASKS)
"""
