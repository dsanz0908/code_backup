from fuzzywuzzy import fuzz
from fuzzywuzzy import process
import pandas as pd
import pyodbc
from multiprocessing import Pool
import json
conn=pyodbc.connect(dsn="somos_redshift_1")
conn_arcadia = pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")
q1=""" 	select pat_first_name + ' ' + pat_last_name as pat_name,pat_date_of_birth,pat_id
	from t_patient where pat_date_of_birth is not null
	 """

q2="""select * from (
select distinct first_name || ' ' || last_name as member_name,cast(dob as date) as dob,cin,'Affinity Corinthian' as source,provider_npi,lower(member_address) as member_address,
replace(replace(replace(member_phone_number,'(',''),') ',''),'-','') as phone,period,
rank() over( partition by cin order by period desc) as rnk
from payor.affinity_corinthian_all_rosters where cin != '' and member_status = 'A'
union all
select distinct first_name || ' ' || last_name as member_name,cast(dob as date) as dob,cin,'Affinity Somos' as source,provider_npi,lower(member_address) as member_address,
replace(replace(replace(member_phone_number,'(',''),') ',''),'-','') as phone,period,
rank() over( partition by cin order by period desc) as rnk
from payor.affinity_somos_roster_all where cin != '' and member_status = 'A'
union all
select top 100 distinct member_first_name || ' ' || member_last_name as member_name,cast(member_dob as date) as dob,member_medicaid_number, 'Anthem Corinthian' as source, pcp_npi, '' as address,'' as phone,
membership_month,rank() over( partition by member_medicaid_number order by membership_month desc ) as rnk from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat
union all
select distinct member_first_name || ' ' || member_last_name as member_name,cast(member_dob as date) as dob,member_medicaid_number, 'Empire Somos' as source, pcp_npi, '' as address, '' as phone,
membership_month,rank() over( partition by member_medicaid_number order by membership_month desc ) as rnk from payor.empire_bcbs_healthplus_somos_all_roster_oldformat
union all
select distinct member_name,cast(member_dob as date) as dob,member_id , 'Healthfirst Corinthian' as source,provider_npi, 
  lower(member_address_1 || ' ' || member_address_2 || ' ' || member_city || ' ' || member_state || ' ' || member_zip) as  member_address,replace(member_home_phone,'-','') as member_phone,received_month,
    rank() over ( partition by member_id order by received_month desc ) as rnk
  from payor.healthfirst_all_eligibility where len(member_dob) > 4
union all
select distinct member_name,cast(member_dob as date) as dob,member_id , 'Healthfirst Somos' as source,provider_npi, 
  lower(member_address_1 || ' ' || member_address_2 || ' ' || member_city || ' ' || member_state || ' ' || member_zip) as  member_address,replace(member_home_phone,'-','') as member_phone,received_month,
    rank() over ( partition by member_id order by received_month desc ) as rnk
  from payor.healthfirst_somos_all_eligibility where len(member_dob) > 4
union all
select distinct memb_first_name || ' ' || memb_last_name as member_name,dob,medicaid_no,'United Somos' as source, national_provider_id,
lower(memb_address_line_1) || ' ' || lower(memb_city) || '  ' || lower(memb_state) || ' ' || memb_zip  as member_address, home_phone_number,received_month,
rank()  over ( partition by medicaid_no order by received_month desc )  
from payor.uhc_somos_all_membership
union all
select  distinct first_name || ' ' || last_name as member_name,date_of_birth,subscriber_id,'WellCare Non Somos' as source,national_provider_id,
lower(address_line_1) || ' ' || lower(address_line_2) || ' ' || lower(city) || ' ' ||  lower(state)  || ' ' || substring(zip,1,5) as member_address,
home_phone_number, receivedmonth,
rank()  over ( partition by subscriber_id order by receivedmonth desc )  as rnk 
from payor.wellcare_all_demographics
union all
select distinct first_name || ' ' || last_name as member_name,date_of_birth,subscriber_id,'WellCare Non Somos' as source,national_provider_id,
lower(address_line_1) || ' ' || lower(address_line_2) || ' ' || lower(city) || ' ' ||  lower(state)  || ' ' || substring(zip,1,5) as member_address,
home_phone_number, receivedmonth,
rank()  over ( partition by subscriber_id order by receivedmonth desc )  as rnk 
from payor.wellcare_somos_all_demographics 
union all
select distinct beneficiary_first_name || ' ' || beneficiary_last_name as member_name,beneficiary_date_of_birth,beneficiary_hic_number,'nydoh' as source,plan_assigned_pcp,
lower(address_line_1) || ' ' || lower(address_line_2) || ' ' || lower(city) || ' ' ||  lower(beneficiary_fips_state_code)  || ' ' || substring(beneficiary_zip_code,1,5) as member_address,
phone_number, received_month ,
rank()  over ( partition by beneficiary_hic_number order by received_month desc )  as rnk
from nydoh.all_rosters_all_columns
where beneficiary_date_of_birth is not null 
and   beneficiary_date_of_birth >= '19000101') a
where rnk = 1
--and cin in ('XQ59042B','134071227')
"""
#q1_test="select distinct pat_first_name + ' ' + pat_last_name, pat_date_of_birth,enc_patient_id from ACPPS_sandbox_PRD01..cbp_1"
cur1=conn_arcadia.execute(q1)
res1=cur1.fetchall()
cur1.close()
cur2=conn.execute(q2)
res2=cur2.fetchall()
cur2.close()

def target_extract(data):
    res_dict={}
    for row in data:
        if row[1].strftime("%Y%m%d") in res_dict.keys():
            res_dict[row[1].strftime("%Y%m%d")].append((row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7]))
        else:
            res_dict[row[1].strftime("%Y%m%d")]=[(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7])]
    return res_dict
res_dict = target_extract(res2)

def check_data(arcadia_data):
    ret_data=[]
    arcadia_name=arcadia_data[0]
    arcadia_dob=arcadia_data[1].strftime("%Y%m%d")
    arcadia_pat_id=arcadia_data[2]
    if arcadia_dob in res_dict.keys():
        res=res_dict[arcadia_dob]
        for hf_data in res:
            mco_name=hf_data[0]
	    mco_dob=hf_data[1].strftime("%Y%m%d")
            mco_cin=hf_data[2]
            mco_source=hf_data[3]
            mco_npi = hf_data[4] if hf_data[4] != None else ''
            mco_address=hf_data[5] if hf_data[5] != None else ''
            mco_phone=hf_data[6] if hf_data[6] != None else ''
            mco_month=hf_data[7] if hf_data[7] != None else ''
            #score=fuzz.token_set_ratio(arcadia_name,mco_name)
            score=fuzz.WRatio(arcadia_name,mco_name)
            if score > 90 :
                #print(arcadia_name,arcadia_dob,arcadia_pat_id,':',mco_name,mco_cin,mco_dob,mco_source,mco_npi,mco_address,mco_phone,mco_month,score)
		ret_data.append(arcadia_name + "|" + arcadia_dob + "|" + arcadia_pat_id + "|" + mco_name + "|" + mco_dob  + '|' + mco_cin + "|" +  \
		mco_source + "|" + mco_npi + "|" + mco_address + "|" + mco_phone + "|" + mco_month + "~!" )
    return ret_data
def main():
    #p=Pool(2)
    #Data=p.map(check_data,res1)
    Data=map(check_data,res1)
    f=open("/home/etl/etl_home/output/pat_cin_match.txt","w")
    for row in Data:
        if len(row) > 0:
            f.write(json.dumps(row).replace('"','').replace("[","").replace("~!]","\n ").replace("~!, ","\n"))
    f.close()

if __name__ == '__main__':
    main()
