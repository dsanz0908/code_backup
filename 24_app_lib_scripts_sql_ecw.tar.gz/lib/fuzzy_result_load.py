import pyodbc

def main():
    conn_arcadia = pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")
    query=""" bulk insert acpps_sandbox_prd01..fuzz_test
		from '/home/etl/etl_home/output/pat_cin_match.txt'
		WITH  ( FIELDTERMINATOR = '|' ) """
    conn_arcadia.execute(query)
    conn_arcadia.close()

if __name__ == '__main__':
    main()
