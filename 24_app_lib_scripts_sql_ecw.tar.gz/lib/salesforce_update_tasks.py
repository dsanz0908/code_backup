from datetime import datetime
import requests
import pandas as pd
import os
import pyodbc
from simple_salesforce import Salesforce


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


connection = pyodbc.connect('dsn=somos_redshift_1')


query = """
SELECT DISTINCT id, 
                'Adult Access to Preventive or Ambulatory Care - 45 to 64 years' AS correct_measure
FROM   salesforce_tasks 
WHERE  project_end_date__c LIKE '2020-06-30%' 
       AND measure__c = 'Adult Access to Preventive or Ambulatory Care - 45 to 54 years' 
"""

#rows = connection.execute(query).fetchall()
connection.close()
sf, INSTANCE_URL = getSession()

toupdate_query = "select id from task where project_end_date__c = 2020-06-30 AND measure__c = 'Adult Access to Preventive or Ambulatory Care - 45 to 54 years'"
toupdate_query = "select id from task where measure__c = 'Special Outreach Project'"
rows = sf.query_all(toupdate_query)['records']
print len(rows)
tasks = []
"""
for row in rows[:10000]:
    tasks.append({'Id': row['Id'], 'measure__c': 'Adult Access to Preventive or Ambulatory Care - 45 to 64 years'})
"""
#sf.bulk.task.update(tasks)
