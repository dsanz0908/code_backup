import pandas as pd
import numpy as np
from datetime import datetime
import pyodbc

def webcreator(data,data1,data2):
    header = """<head id="head" class="dark-mode"><link href="/static/check.css" rel="stylesheet">
    <script type="text/javascript">
      function toggleDarkLight() {
      var body = document.getElementById("body");
      var currentClass = body.className;
      body.className = currentClass == "dark-mode" ? "light-mode" : "dark-mode";
      var nav = document.getElementById("nav");
      nav.className = currentClass == "dark-mode" ? "light-mode" : "dark-mode";
    }
    </script>


    <div class="header">
      <a href="https://somoscommunitycare.org/">
      <img id="logo" src="SOMOS_logo.png" alt="SOMOS Community Care">
      </a>
      <div  class="oval" name="dark_light" onclick="toggleDarkLight()" title="Toggle dark/light mode"><h3><span style="color:#FF0000;">Red</span>shift Inventory</h3></div>
    </div>
    <nav id="navroster" id="nav" class="dark-mode sidebar">
      <ul>
        <li><a href="ecw_status_24.html">DAG Status - 24</a></li>
        <li><a href="ecw_status_67.html">DAG Status - 67</a></li>
        <li><a style="color:#24242b;" href="inventory.html">Redshift Inventory Status</a></li>
        <li><a href="#navroster">Roster</a></li>
        <li><a href="#navclaims">Claims</a></li>
        <li><a href="#navpharmacyclaims">Pharmacy Claims</a></li>
      </ul>

    </nav>
    </head>


    <body id="body" class="dark-mode">
    <h2 class="inventorytabletitle">Feed Type: Roster</h2>
    <br>
    <table class="inventorytable">
    <tr style="background-color:#e3e0cc;"><td style="width:175px">MCO</td><td>IPA</td><td>Total Count</td><td>Earliest Month</td><td>Latest Month</td><td>Member Count</td><td>Last Ingested</td></tr>"""

    length = len(data.index)
    temptable = ""
    x = 0
    for num in range (0,length):
        templine = ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (data["mco"].iloc[x], data["ipa"].iloc[x], data["total_count"].iloc[x], data["earliest_month"].iloc[x], 
				data["latest_month"].iloc[x], data["latest_month_member_count"].iloc[x], data["last_received"].iloc[x]))
        temptable = temptable + templine
        x+=1


    temptable = temptable + """</table>
    <br id="navclaims"><p></p><br><br><br><table class="inventorytable"> <br><br>
    <h2 class="inventorytabletitle">Feed Type: Claims</h2><br><br>
    <tr style="background-color:#e3e0cc;font-size:200%"><td style="width:175px">MCO</td><td>IPA</td><td>Total Count</td><td>Earliest Month</td><td>Latest Month</td><td>Claim Count</td><td>Last Ingested</td></tr>"""


    length = len(data1.index)
    x = 0
    for num in range (0,length):
        templine =("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (data1["mco"].iloc[x], data1["ipa"].iloc[x], data1["total_count"].iloc[x], data1["earliest_month"].iloc[x],
                                data1["latest_month"].iloc[x], data1["latest_month_claim_count"].iloc[x], data1["last_received"].iloc[x]))
        temptable = temptable + templine
        x+=1


    temptable = temptable + """</table><br><br><br><table class="inventorytable">
    <br>
    <br>
    <h2 id = "navpharmacyclaims" class="inventorytabletitle">Feed Type: Pharmacy Claims</h2><br><br>
    <tr style="background-color:#e3e0cc;font-size:200%"><td style="width:175px">MCO</td><td>IPA</td><td>Total Count</td><td>Earliest Month</td><td>Latest Month</td><td>Pharmacy Claim Count</td><td>Last Ingested</td></tr>"""

    length = len(data2.index)
    x = 0
    for num in range (0,length):
        templine =  ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (data2["mco"].iloc[x], data2["ipa"].iloc[x], data2["total_count"].iloc[x], data2["earliest_month"].iloc[x],
                                data2["latest_month"].iloc[x], data2["latest_month_rx_count"].iloc[x], data2["last_received"].iloc[x]))
        temptable = temptable + templine
        x+=1

    finalweb = header + temptable + """</table>
    <br><br><br><br><br>

    </body>"""
    f = open("/home/etl/etl_home/Reports/inventory.html", 'w')
    f.write(finalweb)
    f.close()


def get_roster_details(conn):
    query="""
        select * from (
        SELECT 'Health First' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) as Latest_month,
        ( select count(distinct member_id) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2'
        and received_month in (select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_eligibility where provider_parent_code = 'COR2' ) Last_received
         union all
        SELECT 'Health First' As MCO, 'Excelsior' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) as Total_count,
        ( select min(datepart(year,effective_period) || lpad(datepart(month,effective_period),2,'0'))
        from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) as Latest_month,
        ( select count(distinct member_id) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1'
        and received_month in (select max(received_month) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' )
         ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_eligibility where provider_parent_code = 'EXC1' ) Last_received
        union all
        SELECT 'Health First' As MCO, 'SOMOS' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) as Total_count,
        ( select min(datepart(year,effective_period) || lpad(datepart(month,effective_period),2,'0'))
        from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) as Latest_month,
        ( select count(distinct member_id) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%'
        and received_month in (select max(received_month) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_somos_all_eligibility where provider_parent_code like 'SOM%' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'CMI' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'CMI' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'CMI') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'CMI'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'CMI' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'CMI' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'Excelsior' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'EX1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EX1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EX1') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'EX1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EX1' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'EX1' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'BalanceMed' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'VR1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'VR1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'VR1') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'VR1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'VR1' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'VR1' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'ECAP' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_all_demographics where master_ipa = 'EC1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EC1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EC1') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_all_demographics where master_ipa = 'EC1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_demographics where master_ipa = 'EC1' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_demographics where master_ipa = 'EC1' ) Last_received
        union all
        SELECT 'Wellcare' As MCO, 'SOMOS' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS') as Latest_month,
        ( select count(distinct seq_memb_id) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_somos_all_demographics where master_ipa = 'SOMOS' )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_SOMOS_all_demographics where master_ipa = 'SOMOS' ) Last_received
	union all
        SELECT 'Affinity' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.affinity_corinthian_all_rosters  ) as Total_count,
        ( select min(period) from payor.affinity_corinthian_all_rosters ) as Earliest_month,
        ( select max(period) from payor.affinity_corinthian_all_rosters ) as Latest_month,
        ( select count(distinct affinity_subscriber_number) from payor.affinity_corinthian_all_rosters
        where period in (select max(period) from payor.affinity_corinthian_all_rosters )
        ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.affinity_corinthian_all_rosters ) Last_received
        union all
        SELECT 'Affinity' As MCO, 'Somos' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.affinity_somos_roster_all  ) as Total_count,
        ( select min(period) from payor.affinity_somos_roster_all ) as Earliest_month,
        ( select max(period) from payor.affinity_somos_roster_all ) as Latest_month,
        ( select count(distinct affinity_subscriber_number) from payor.affinity_somos_roster_all
        where period in (select max(period) from payor.affinity_somos_roster_all ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.affinity_somos_roster_all ) Last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Somos' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.empire_somos_member  ) as Total_count,
        ( select min(received_month) from payor.empire_somos_member ) as Earliest_month,
        ( select max(received_month) from payor.empire_somos_member ) as Latest_month,
        ( select count(distinct master_consumer_id) from payor.empire_somos_member
        where received_month in (select max(received_month) from payor.empire_somos_member ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_somos_member ) Last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Corinthian' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat  ) as Total_count,
        ( select min(received_month) from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat ) as Earliest_month,
        ( select max(received_month) from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat ) as Latest_month,
        ( select count(distinct empire_subscriber_id) from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat
        where received_month in (select max(received_month) from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat ) Last_received
	union all
        SELECT 'United' As MCO, 'Somos' as IPA, 'Roster' as FeedType,
        ( select count(*) from payor.uhc_somos_all_membership  ) as Total_count,
        ( select min(received_month) from payor.uhc_somos_all_membership ) as Earliest_month,
        ( select max(received_month) from payor.uhc_somos_all_membership ) as Latest_month,
        ( select count(distinct subscriber_id) from payor.uhc_somos_all_membership
        where received_month in (select max(received_month) from payor.uhc_somos_all_membership ) ) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.uhc_somos_all_membership ) Last_received
        union all
        SELECT 'NYDOH' AS SOURCE,'NYDOH' AS IPA, 'Roster' AS FEED_TYPE,(SELECT COUNT(*) FROM nydoh.all_rosters_all_columns ) as total_count,
        (select substring(replace(cast(min(attribution_run_date) as varchar(20)),'-',''),1,6) from nydoh.all_rosters_all_columns) as earliest_month,
        (select substring(replace(cast(max(attribution_run_date) as varchar(20)),'-',''),1,6) from nydoh.all_rosters_all_columns) as latest_month,
        (select count(*) from nydoh.all_rosters_all_columns where received_month = ( select max(received_month) from nydoh.all_rosters_all_columns) ) as latest_month,
        ( select cast(cast(max(received_month) || '01' as date) as varchar(20)) from nydoh.all_rosters_all_columns ) as Last_received
        union all
        select 'Fidelis' as mco, 'Innovator', 'Roster', 
        (select count(*) from payor.fideliscare_prod_membership_full_somos_all) as total_count,
         ( select min(received_month) from payor.fideliscare_prod_membership_full_somos_all ) as Earliest_month,
        ( select max(received_month) from payor.fideliscare_prod_membership_full_somos_all ) as Latest_month,
        (select count(unique_member_id) from payor.fideliscare_prod_membership_full_somos_all
        where received_month in (select max(received_month) from payor.fideliscare_prod_membership_full_somos_all )) as Latest_month_member_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.fideliscare_prod_membership_full_somos_all ) Last_received
        ) a
        order by 1
    """
    data = pd.read_sql(query,conn)
    return data

def get_claim_details(conn):
    query="""
        select * from (
        SELECT 'Empire/Anthem' As MCO, 'Corinthian' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.empire_bcbs_healthplus_legacy_all_claims_oldformat  ) as Total_count,
        ( select min(received_month) from payor.empire_bcbs_healthplus_legacy_all_claims_oldformat ) as Earliest_month,
        ( select max(received_month) from payor.empire_bcbs_healthplus_legacy_all_claims_oldformat ) as Latest_month,
        ( select count(distinct claim_number ) from payor.empire_bcbs_healthplus_legacy_all_claims_oldformat
        where received_month in (select max(received_month) from payor.empire_bcbs_healthplus_legacy_all_claims_oldformat ) ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_bcbs_healthplus_legacy_all_claims_oldformat ) as last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Somos' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.empire_somos_claim_header  ) as Total_count,
        ( select min(received_month) from payor.empire_somos_claim_header ) as Earliest_month,
        ( select max(received_month) from payor.empire_somos_claim_header ) as Latest_month,
        ( select count(distinct claim_nbr ) from payor.empire_somos_claim_header
        where received_month in (select max(received_month) from payor.empire_somos_claim_header ) ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_somos_claim_header ) as last_received
        union all
        SELECT 'Health First' As MCO, 'Corinthian' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2'
        and received_month in (select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_claims where pcp_parent_code = 'COR2' ) as last_received
        union all
        SELECT 'Health First' As MCO, 'Excelsior' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1'
        and received_month in (select max(received_month) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_claims where pcp_parent_code = 'EXC1' ) as last_received
	union all
        SELECT 'Health First' As MCO, 'Somos' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%'
        and received_month in (select max(received_month) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_somos_all_claims where pcp_parent_code like 'SOM%' ) as last_received
         union all
        SELECT 'United' As MCO, 'Somos' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.uhc_somos_all_claims where claim_type != 'PHARM'  ) as Total_count,
        ( select min(received_month) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) as Earliest_month,
        ( select max(received_month) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) as Latest_month,
        ( select count(distinct claim_number) from payor.uhc_somos_all_claims
        where received_month in (select max(received_month) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) and claim_type != 'PHARM' ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.uhc_somos_all_claims where claim_type != 'PHARM' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Corinthian' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'CMI' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'CMI' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'CMI') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'CMI'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'CMI' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'CMI' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Excelsior' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'EX1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EX1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EX1') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'EX1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EX1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'EX1' ) as last_received
 	union all
        SELECT 'Wellcare' As MCO, 'BalanceMed' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'VR1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'VR1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'VR1') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'VR1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'VR1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'VR1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'ECAP' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_claims where master_ipa = 'EC1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EC1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EC1') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_all_claims where master_ipa = 'EC1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_claims where master_ipa = 'EC1' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_claims where master_ipa = 'EC1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'SOMOS' as IPA, 'Claims' as FeedType,
        ( select count(*) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS') as Latest_month,
        ( select count(distinct claim_number) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' )
        ) as Latest_month_claim_count,
        ( select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_somos_all_claims where master_ipa = 'SOMOS' ) as last_received
        union all
        SELECT 'NYDOH' AS SOURCE,'NYDOH' AS IPA, 'Claims' AS FEED_TYPE,(SELECT COUNT(*) FROM nydoh.all_claims ) as total_count,
        (select substring(replace(cast(min(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_claims) as earliest_month,
        (select substring(replace(cast(max(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_claims) as latest_month,
        (select count(*) from nydoh.all_claims where received_month = ( select max(received_month) from nydoh.all_claims) ) as latest_month,
        ( select cast(cast(max(received_month) || '01' as date) as varchar(20)) from nydoh.all_claims ) as Last_received
        ) a
        order by 1
        """
    data= pd.read_sql(query,conn)
    return data

def get_pharmacy_details(conn):
    query="""
        select * from (
        SELECT 'Empire/Anthem' As MCO, 'Corinthian' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.empire_bcbs_healthplus_legacy_all_rx_oldformat ) as Total_count,
        ( select min(received_month) from payor.empire_bcbs_healthplus_legacy_all_rx_oldformat ) as Earliest_month,
        ( select max(received_month) from payor.empire_bcbs_healthplus_legacy_all_rx_oldformat ) as Latest_month,
        ( select count(distinct claim_number ) from payor.empire_bcbs_healthplus_legacy_all_rx_oldformat
        where received_month in (select max(received_month) from payor.empire_bcbs_healthplus_legacy_all_rx_oldformat ) ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_bcbs_healthplus_legacy_all_rx_oldformat) as last_received
        union all
        SELECT 'Empire/Anthem' As MCO, 'Somos' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.empire_somos_rx_clms_delta  ) as Total_count,
        ( select min(received_month) from payor.empire_somos_rx_clms_delta ) as Earliest_month,
        ( select max(received_month) from payor.empire_somos_rx_clms_delta ) as Latest_month,
        ( select count(distinct claim_number ) from payor.empire_somos_rx_clms_delta
        where received_month in (select max(received_month) from payor.empire_somos_rx_clms_delta ) ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.empire_somos_rx_clms_delta) as last_received
        union all
        SELECT 'Health First' As MCO, 'Corinthian' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2'
        and received_month in (select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_rx_claims where provider_parent_code = 'COR2') as last_received
        union all
        SELECT 'Health First' As MCO, 'Excelsior' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1'
        and received_month in (select max(received_month) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_all_rx_claims where provider_parent_code = 'EXC1') as last_received
        union all
        SELECT 'Health First' As MCO, 'Somos' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' ) as Total_count,
        ( select min(received_month) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' ) as Earliest_month,
        ( select max(received_month) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' ) as Latest_month,
        ( select count(distinct claim_id) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%'
        and received_month in (select max(received_month) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.healthfirst_somos_all_rx_claims where provider_parent_code like 'SOM%') as last_received
        union all
        SELECT 'United' As MCO, 'Somos' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.uhc_somos_all_claims  where claim_type = 'PHARM' ) as Total_count,
        ( select min(received_month) from payor.uhc_somos_all_claims  where claim_type = 'PHARM' ) as Earliest_month,
        ( select max(received_month) from payor.uhc_somos_all_claims  where claim_type = 'PHARM' ) as Latest_month,
        ( select count(distinct claim_number) from payor.uhc_somos_all_claims
        where received_month in (select max(received_month) from payor.uhc_somos_all_claims
        where claim_type = 'PHARM' ) AND claim_type = 'PHARM' ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.uhc_somos_all_claims where claim_type = 'PHARM' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Corinthian' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'CMI' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'CMI' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'CMI') as Latest_month,
        ( select count(distinct prescription_number || date_filled ) from payor.wellcare_all_rx where master_ipa = 'CMI'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'CMI' )
        ) as Latest_month_rx_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'CMI' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'Excelsior' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'EX1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EX1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EX1') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_all_rx where master_ipa = 'EX1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EX1' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'EX1' ) as last_received
 	union all
        SELECT 'Wellcare' As MCO, 'BalanceMed' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'VR1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'VR1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'VR1') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_all_rx where master_ipa = 'VR1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'VR1' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'VR1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'ECAP' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_all_rx where master_ipa = 'EC1' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EC1' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EC1') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_all_rx where master_ipa = 'EC1'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_all_rx where master_ipa = 'EC1' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_all_rx where master_ipa = 'EC1' ) as last_received
        union all
        SELECT 'Wellcare' As MCO, 'SOMOS' as IPA, 'Pharmacy Claims' as FeedType,
        ( select count(*) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' ) as Total_count,
        ( select min(receivedmonth) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' ) as Earliest_month,
        ( select max(receivedmonth) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS') as Latest_month,
        ( select count(distinct prescription_number || date_filled) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS'
        and receivedmonth in (select max(receivedmonth) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' )
        ) as Latest_month_claim_count,
        (select cast(trunc(max(added_tz)) as varchar(20)) from payor.wellcare_somos_all_rx where master_ipa = 'SOMOS' ) as last_received
        union all
        SELECT 'NYDOH' AS SOURCE,'NYDOH' AS IPA, 'Pharmacy Claims' AS FEED_TYPE,(SELECT COUNT(*) FROM nydoh.all_rx_claims ) as total_count,
        (select substring(replace(cast(min(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_rx_claims) as earliest_month,
        (select substring(replace(cast(max(srv_dt) as varchar(20)),'-',''),1,6) from nydoh.all_rx_claims) as latest_month,
        (select count(*) from nydoh.all_rx_claims where received_month = ( select max(received_month) from nydoh.all_rx_claims) ) as latest_month,
        ( select cast(cast(max(received_month) || '01' as date) as varchar(20)) from nydoh.all_rx_claims ) as Last_received
        ) a
        order by 1
        """
    data=pd.read_sql(query,conn)
    return data

def main():
    conn=pyodbc.connect(dsn="somos_redshift_1")
    data=get_roster_details(conn)
    data1=get_claim_details(conn)
    data2=get_pharmacy_details(conn)
    webcreator(data,data1,data2)

if __name__ == '__main__':
    main()
