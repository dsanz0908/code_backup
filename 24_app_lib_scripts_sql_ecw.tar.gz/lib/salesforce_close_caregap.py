import requests
from simple_salesforce import Salesforce
from fuzzywuzzy import fuzz
from collections import defaultdict
import pyodbc


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': "ssundararaman@optimusha.com",
        'password': "OptimusSomos1yDsjYPT1d9QJYnq9n6UKdkG97"
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


if __name__ == '__main__':
    sf, instance_url = getSession()
    FILE_ROWS = [[
        i.split('|')[0], i.split('|')[1].rstrip()
    ] for i in open('to_complete_gaps_cin_measure.txt', 'r').readlines()]
    MEASURES_DICT = defaultdict(list)
    for file_row in FILE_ROWS:
        MEASURES_DICT[file_row[0]].append(file_row[1])
    REDSHIFT_CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
    QUERY = """select distinct cin__c, measure__c, salesforce_tasks.id  from salesforce_patients join salesforce_tasks on salesforce_patients.accountid = salesforce_tasks.accountid"""
    REDSHIFT_ROWS = REDSHIFT_CONNECTION.execute(QUERY).fetchall()
    REDSHIFT_DICT = defaultdict(dict)
    for redshift_rows in REDSHIFT_ROWS:
        REDSHIFT_DICT[redshift_rows[0]] = {redshift_rows[1]: redshift_rows[2]}
    REDSHIFT_CONNECTION.close()
    for file_cin in MEASURES_DICT:
        if file_cin in REDSHIFT_DICT:
            for file_cin_measure in MEASURES_DICT[file_cin]:
                for redshift_cin_measure in REDSHIFT_DICT[file_cin]:
                    if fuzz.WRatio(file_cin_measure,
                                   redshift_cin_measure) > 86:
                        task_id = REDSHIFT_DICT[file_cin][redshift_cin_measure]
		        sf.Task.update(task_id, {'status':'Closed', 'closed_by_source__c':'20190918 automated from scorecard - completed to closed'})
