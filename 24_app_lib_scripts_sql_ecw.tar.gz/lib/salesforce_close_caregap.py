# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding("utf-8")

import requests
from simple_salesforce import Salesforce
from fuzzywuzzy import fuzz
from collections import defaultdict
import pyodbc


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': "ssundararaman@optimusha.com",
        'password': "OptimusSomos1yDsjYPT1d9QJYnq9n6UKdkG97"
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


if __name__ == '__main__':
    sf, instance_url = getSession()
    REDSHIFT_CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
    QUERY1 = """
    create temp table if not exists gaps_to_close_20191003 (
    measure varchar(255),
    cin varchar(255),
    source varchar(255)
    );

    copy gaps_to_close_20191003
    from 's3://sftp_test/gaps_to_close_20191003.csv'
    iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
    TRIMBLANKS
    MAXERROR 10
    region 'us-east-1'
    dateformat 'auto'
    delimiter ','
    ignoreheader 1
    removequotes;

    create temp table if not exists scorecard_salesforce_measures_mapping (
    scorecard varchar(255),
    salesforce varchar(255)
    );

    copy scorecard_salesforce_measures_mapping
    from 's3://sftp_test/scorecard_salesforce_measures_mapping.csv'
    iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
    TRIMBLANKS
    MAXERROR 10
    ignoreheader 1
    region 'us-east-1'
    dateformat 'auto'
    delimiter ',';
    """

    QUERY2 = """
    SELECT distinct salesforce_tasks.id 
    FROM   gaps_to_close_20191003 
	   JOIN scorecard_salesforce_measures_mapping 
	     ON measure = scorecard 
	   JOIN (SELECT * 
		 FROM   (SELECT *, 
				Row_number() 
				  OVER ( 
				    partition BY id 
				    ORDER BY added_tz DESC) AS rn 
			 FROM   salesforce_tasks) 
		 WHERE  rn = 1) AS salesforce_tasks 
	     ON Regexp_replace(salesforce, '[[?±]]') = Regexp_replace(measure__c, '[[?±]]') 
	   JOIN salesforce_patients 
	     ON salesforce_tasks.whoid = salesforce_patients.id 
		AND cin = cin__c 
    """


    QUERY1 = """
    CREATE TEMPORARY TABLE temp_gaps_to_close 
      ( 
	 measure    VARCHAR(255), 
	 member_cin VARCHAR(20), 
	 source     VARCHAR(100) 
      ); 

    copy temp_gaps_to_close
    from 's3://sftp_test/gaps_to_close_20191003.csv'
    iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
    TRIMBLANKS
    MAXERROR 30
    region 'us-east-1'
    dateformat 'auto'
    ignoreheader 1
    csv;
    """

    QUERY2 = """
    SELECT DISTINCT t1.id 
    FROM   salesforce_tasks t1 
	   INNER JOIN salesforce_patients t3 
		   ON t3.contact_id_18_characters__c = t1.whoid 
	   INNER JOIN temp_gaps_to_close t4 
		   ON t3.cin__c = t4.member_cin 
		      AND CASE 
			    WHEN measure__c IN ( 'Children''s Access to Primary Care - 12 to 24 months',
						 'Children''s Access to Primary Care - 25 months to 6 years',
								      'Children''s Access to Primary Care - 7 to 11 years',
								      'Adolescent Access to Primary Care - 12 to 19 years',
						 'Adult Access to Preventive or Ambulatory Care ? 20 to 44',
						 'Adult Access to Preventive or Ambulatory Care ? 45 to 64 years',
						 'Adult Access to Preventive or Ambulatory Care ? 65 and older',
						 'Adult Access to Preventive or Ambulatory Care - 20 to 44 years',
						 'Adult Access to Preventive or Ambulatory Care - 45 to 64 years',
						 'Adult Access to Preventive or Ambulatory Care - 65 and older' ) THEN
			    'Access to care' 
			  END = CASE 
				  WHEN measure IN ( 'Child Access (12-24 mo)', 'Child Access (25 mo-6 yr)', 
						    'Child Access (7-11 yr)', 
						    'Adolescent Access (12-19 yr)', 
						    'Adult Access (20-44)', 'Adult Access (45-64)', 'Adult Access (65+)' ) 
				THEN 
				  'Access to care' 
				END 
    WHERE  status != 'Closed' 
	   AND t1.project_end_date__c LIKE '2019-12-31%'
    """

    QUERY3 = """
    with a as (select distinct id from (SELECT *,
		   Row_number()
		     OVER (
		       partition BY salesforce_tasks.id
		       ORDER BY added_tz DESC) AS rn
	    FROM   salesforce_tasks) as salesforce_tasks where rn > 1 and status = 'Closed')
    select distinct salesforce_tasks.id from (SELECT *,
		   Row_number()
		     OVER (
		       partition BY salesforce_tasks.id
		       ORDER BY added_tz DESC) AS rn
	    FROM   salesforce_tasks) as salesforce_tasks join a on salesforce_tasks.id = a.id where rn = 1 and status <> 'Closed'
    """

    REDSHIFT_ROWS = REDSHIFT_CONNECTION.execute(QUERY1)
    REDSHIFT_ROWS = REDSHIFT_CONNECTION.execute(QUERY2).fetchall()
    REDSHIFT_ROWS = REDSHIFT_CONNECTION.execute(QUERY3).fetchall()
    print len(REDSHIFT_ROWS)
    """
    for row in REDSHIFT_ROWS:
        try:
            sf.Task.update(
                row[0], {
                    'status':
                    'Closed',
                    #'closed_by_source__c':
                    #'20191010 automated from scorecard - completed to closed'
                })
        except Exception as e:
            print row[0], str(e)
    """
