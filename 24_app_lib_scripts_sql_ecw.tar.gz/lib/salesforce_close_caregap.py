import requests
from simple_salesforce import Salesforce
from fuzzywuzzy import fuzz

def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': "ssundararaman@optimusha.com",
        'password': "SomosOpt2019$z6gz9mRNzD38ZYJM6scMmoziU"
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


if __name__ == '__main__':
    sf, instance_url = getSession()
    rows = [[i.split('|')[0], i.split('|')[1].rstrip()] for i in open('abc2.txt', 'r').readlines()]
    count = 0
    for row in rows:
        try:
            accountid = sf.Contact.get_by_custom_id('CIN__c', row[0])['AccountId']
            task_id = sf.query("select id, status, measure__c from task where accountid = '{}' and status != 'Closed' and status != 'Completed'".format(accountid))
            for j in task_id['records']:
                if fuzz.WRatio(j['Measure__c'], row[1]) > 86:
                    count += 1
                    print j['Measure__c'], '|', row[1], fuzz.WRatio(j['Measure__c'], row[1])
        except:
            pass #print row, 'did not work'
    """
    task_id = sf.query(
        "select id from task where status != 'Completed' and accountid = '{}' and measure__c = '{}'"
        .format(accountid,
                'Lipid Management for patients with Cardiovascular disease'
                ))['records'][0]['Id']
    """
    #sf.Task.update(task_id, {'status':'Completed'})
print count
