from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce

def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)



CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)

FUZZ_TEST = """
CREATE TEMPORARY TABLE fuzz_test 
  ( 
     arcadia_name   VARCHAR(255), 
     arcadia_dob    DATE, 
     arcadia_pat_id VARCHAR(100), 
     mco_name       VARCHAR(255), 
     mco_dob        DATE, 
     mco_cin        VARCHAR(50), 
     mco_source     VARCHAR(50), 
     mco_npi        VARCHAR(20), 
     mco_address    VARCHAR(255), 
     mco_phone      VARCHAR(20), 
     mco_month      VARCHAR(20) 
  ); 

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';
"""

SCORECARD_MAPPING = """
CREATE TEMPORARY TABLE scorecard_to_sf_measure_map 
  ( 
     scorecard_measure VARCHAR(255), 
     sf_measure        VARCHAR(255) 
  ); 

copy scorecard_to_sf_measure_map 
from 's3://sftp_test/scorecard_measure_to_sf_measure_mapping.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
trimblanks
maxerror 1
region 'us-east-1'
dateformat 'auto'
ignoreheader 1
csv;
"""

DIRECT_MATCH = """
create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 100
IGNOREBLANKLINES
region 'us-east-1'
dateformat 'auto'
csv ;
"""

REDSHIFT_QUERY = """
SELECT DISTINCT salesforce_tasks.id, 
                pat_id, 
                scorecard_measure AS measure 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY salesforce_tasks.id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) AS salesforce_tasks 
       INNER JOIN salesforce_patients 
               ON contact_id_18_characters__c = whoid 
       INNER JOIN (SELECT pat_id, 
                          policy_nbr 
                   FROM   direct_match 
                   UNION 
                   SELECT arcadia_pat_id, 
                          mco_cin 
                   FROM   fuzz_test) 
               ON policy_nbr = cin__c 
       INNER JOIN scorecard_to_sf_measure_map 
               ON sf_measure = measure__c 
WHERE  rn = 1 
       AND status NOT IN ( 'Closed', 'Completed', 'Completed - Awaiting Claim Submission', 
                           'Completed - Awaiting Coding Correction') 
       AND salesforce_tasks.project_end_date__c LIKE '2019-12-31%'  and isdeleted = 'FALSE'
"""

query_arcadia = """
if OBJECT_ID('tempdb..#scorecard') is not null
	drop table #scorecard;
CREATE TABLE #SCORECARD (
        prov_first_name        VARCHAR(100) null,
		prov_last_name        VARCHAR(100) null,
		prov_npi		VARCHAR(20),
        measure         VARCHAR(100) null,
		pat_first_name	varchar(100) null,
		pat_last_name   varchar(100) null,
		pat_date_of_birth datetime,
		pat_id			varchar(100));


-- Access to Care
WITH cte_1
     AS (SELECT prov_first_name,
                prov_last_name,
                prov_npi,
                CASE
                  WHEN Datediff(mm, pat_date_of_birth, Getdate()) BETWEEN 12 AND 24 THEN 'Child Access - Primary Care (12 to 24 Months)'
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 2 AND 6 THEN 'Child Access - Primary Care (25 Months to 6)'
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 7 AND 11 THEN 'Child Access - Primary Care (7 to 11)'
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 12 AND 19 THEN 'Child Access - Primary Care (12 to 19)'
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 20 AND 44 THEN 'Adult Access Preventive (20 - 44)'
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 45 AND 64 THEN 'Adult Access Preventive (45 - 64)'
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) > 64 THEN 'Adult Access Preventive (65 and Older)'
                  WHEN Datediff(mm, pat_date_of_birth, Getdate()) <= 15
                       AND Count(DISTINCT cc_date_of_service) >= 5 THEN 'Well-Child (15 mo, 5+ Visits)'
                END AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
         FROM   t_chargecapture t1
                INNER JOIN t_patient t2
                        ON t1.cc_patient_id = t2.pat_id
                           AND t2.pat_delete_ind = 'N'
                           AND t2.pat_status = 'Active'
                INNER JOIN provider_master t3
                        ON t1.cc_rendering_provider_id = t3.prov_id
                           AND t3.prov_delete_ind = 'N'
         WHERE  t1.cc_cpt_code IN ( '99381', '99382', '99383', '99384',
                                    '99485', '99386', '99387', '99391',
                                    '99392', '99393', '99394', '99395',
                                    '99396', '99397' )
                AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231'
                AND t1.cc_delete_ind = 'N'
         GROUP  BY prov_first_name,
                   prov_last_name,
                   prov_npi,
                   pat_first_name,
                   pat_last_name,
                   pat_date_of_birth,
                   pat_id)
INSERT #scorecard
SELECT *
FROM   cte_1
WHERE  measure IS NOT NULL;

-- Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ( '3048F', '3049F', '3050F','80061','83700','83701','83704','83721' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

-- Use of Spirometry Testing in the Assessment and Diagnosis of COPD
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Use of Spirometry Testing in the Assessment and Diagnosis of COPD' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ( '94010', '94014', '94015', '94016',
                           '94060', '94070', '94375', '94620' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20180101' AND '20191231';

-- Diabetes - Dialated Eye Exam

INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes - Dialated Eye Exam' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ( '2022F','3072F', '3073F', '2024F', '2026F',
                           'S0620', 'S0621', 'S3000','67028','67030','67031','67036','67039','67040','67041','67042','67043','67101','67105','67107','67108','67110','67113',
			   '67121','67141','67145','67208','67210','67218','67220','67221','67227','67228','92002','92004','92012','92014','92018','92019','92134','92225',
			   '92226','92227','92228','92230','92235','92240','92250','92260','99203','99204','99205','99213','99214','99215','99242','99243','99244','99245' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';
       
-- Diabetes HbA1c Test
insert #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes HbA1c Test' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ('3044F','3046F','3051F','3052F','83036','83037','17856-6','4548-4','4549-2')
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' ;       

-- 'Comprehensive Diabetes Care'

with cte_a1c as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Hemoglobin A1C' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ('3044F','3046F','3051F','3052F','83036','83037','17856-6','4548-4','4549-2')
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' ),

cte_nep as ( --Diabetes - Nephropathy screening Coding
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes - Nephropathy screening Coding' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN (	'81000','81001','81002','81003','81005','82042','82043','82044','84156','3060F','3061F','3062F','11218-5','12842-1','13705-9','13801-6','13986-5','13992-3',
			'14956-7','14957-5','14958-3','14959-1','1753-3','1754-1','1755-8','1757-4','17819-4','18373-1','20454-5','20621-9','21059-1','21482-5',
			'26801-1','27298-9','2887-8','2888-6','2889-4','2890-2','29946-1','30000-4','30001-2','30003-8','32209-9','32294-1','32551-4','34366-5','35663-4','40486-3',
			'40662-9','40663-7','43605-5','43606-3','43607-1','44292-1','47558-2','49002-9','49023-5','50209-6','50561-0','50949-7','51190-7','53121-0','53525-2','53530-2',
			'53531-0','53532-8','56553-1','57369-1','57735-3','5804-0','58448-2','58992-9','59159-4','60678-0','63474-1','6941-9','6942-7','76401-9','77253-3','77254-1','77940-5','9318-7')
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' ) ,

cte_tdap as (SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Immunizations for Adolescents: Tdap' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90715' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' )

insert #scorecard
SELECT DISTINCT a.prov_first_name,
                a.prov_last_name,
                a.prov_npi,
                'Comprehensive Diabetes Care' AS measure,
                a.pat_first_name,
                a.pat_last_name,
                a.pat_date_of_birth,
                a.pat_id
from cte_a1c a
inner join cte_nep b
on a.pat_id = b.pat_id
inner join cte_tdap c
on a.pat_id = c.pat_id ;




-- Chlamydia Screening in women
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Chlamydia Screening in women' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ( '87110', '87270', '87320', '87490',
                           '87491', '87492', '87810', 'G9820', 'G9821' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Cervical Cancer Screening
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Cervical Cancer Screening' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ( '3015F', '88141', '88142', '88143',
                           '88147', '88148', '88150', '88152',
                           '88153', '88154', '88164', '88165',
                           '88166', '88167', '88174', '88175',
                           'G0123', 'G0124', 'G0141', 'G0143',
                           'G0144', 'G0145', 'G0147', 'G0148',
                           'P3000', 'P3001', 'Q0091' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20170101' AND '20191231';



--Breast Cancer Screening
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Breast Cancer Screening' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ( '3014F', '77055', '77056', '77057',
                           '77061', '77062', '77063', '77065',
                           '77066', '77067', 'G0202', 'G0204', 'G0206' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Adolescent Immunizations Combo 1

with cte_1 as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Adolescent Immunizations Combo 1' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code = '90734'
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' ),

 cte_2 as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Adolescent Immunizations Combo 1' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code = '90715'
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' )

INSERT #scorecard
select DISTINCT a.prov_first_name,
                a.prov_last_name,
                a.prov_npi,
                'Adolescent Immunizations Combo 1' AS measure,
                a.pat_first_name,
                a.pat_last_name,
                a.pat_date_of_birth,
                a.pat_id
from cte_1 a
inner join cte_2 b
on a.pat_id = b.pat_id;


--Control Blood Pressure Coding
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Control Blood Pressure Coding' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  t1.cc_cpt_code IN ( '3074F', '3075F', '3078F', '3079F','G8752', 'G8754' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Asthma Diagnosis
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Asthma Diagnosis' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_assessment t1
       INNER JOIN t_patient t2
               ON t1.patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  icd10_code IN ( 'J45.20', 'J45.21', 'J45.22', 'J45.30',
                       'J45.31', 'J45.32', 'J45.40', 'J45.41',
                       'J45.42', 'J45.50', 'J45.51', 'J45.52',
                       'J45.901', 'J45.902', 'J45.909', 'J45.990',
                       'J45.991', 'J45.998', 'J45.2', 'J45.3',
                       'J45.4', 'J45.5', 'J45.9', 'J45.90', 'J45.99' )
       AND t1.assessment_date BETWEEN '20190101' AND '20191231';


--Asthma Action Plan
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Asthma Action Plan' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( 'AST01' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';


--Cardiovascular  Diagnosis
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Cardiovascular  Diagnosis' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_assessment t1
       INNER JOIN t_patient t2
               ON t1.patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  icd10_code IN ( 'I13.10', 'I12.9', 'I11.9', 'I10',
                       'I50.20', 'I50.21', 'I50.22', 'I50.23',
                       'I50.30', 'I50.31', 'I50.32', 'I50.33',
                       'I50.40', 'I50.41', 'I50.42', 'I50.43',
                       'I50.9', 'I50.1', 'I50.20', 'I50.21',
                       'I50.22', 'I50.23', 'I50.30', 'I50.31',
                       'I50.32', 'I50.33', 'I50.40', 'I50.41',
                       'I50.42', 'I50.43', 'I50.9', 'E78.4',
                       'E78.5', 'I09.2', 'I05.0', 'I06.0',
                       'I08.0', 'I07.0', 'I07.1', 'I07.2',
                       'I07.8', 'I07.9', 'I09.0', 'I21.09',
                       'I25.2', 'I20.8', 'I25.10', 'I20.9',
                       'I21.09', 'I21.3', 'I25.10', 'I25.2',
                       'I25.84', 'I25.9', 'I10', 'I11.0',
                       'I11.9', 'I25.10', 'I48.91', 'I50.9',
                       'I63.9', 'I65.23', 'I65.29', 'I67.2',
                       'I67.9', 'I73.9' )
       AND t1.assessment_date BETWEEN '20190101' AND '20191231';


--COPD Diagnosis
WITH cte_access_to_care
     AS (SELECT DISTINCT enc_patient_id
         FROM   t_encounter T1
                INNER JOIN t_chargecapture T3
                        ON T1.enc_id = T3.cc_enc_id
         WHERE  enc_timestamp >= Dateadd(year, -3, Getdate())
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384',
                                     '99385', '99386', '99387', '99391',
                                     '99392', '99393', '99394', '99395',
                                     '99396', '99397', 'G0438', 'G0439',
                                     '90791', '90792', '90832', '90833',
                                     '90834', '90835', '90836', '90837',
                                     '90838', '90839', '90840', '90845',
                                     '90846', '90847', '90849', '90853',
                                     '90875', '90876', '98966', '98967',
                                     '98968', '99221', '99222', '99223',
                                     '99231', '99232', '99233', '99238',
                                     '99239', '99251', '99252', '99253',
                                     '99254', '99255', '99381', '99382',
                                     '99383', '99384', '99385', '99386',
                                     '99387', '99391', '99392', '99393',
                                     '99394', '99395', '99396', '99397',
                                     '99441', '99442', '99443' ))
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'COPD Diagnosis' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_assessment t1
       INNER JOIN t_patient t2
               ON t1.patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  icd10_code IN ( 'J41.0', 'J41.1', 'J41.8', 'J42',
                       'J43.0', 'J43.1', 'J43.2', 'J43.8',
                       'J43.9', 'J44.0', 'J44.1', 'J44.9' )
       AND t1.assessment_date BETWEEN '20190101' AND '20191231'
       AND EXISTS (SELECT 1
                   FROM   cte_access_to_care
                   WHERE  enc_patient_id = pat_id);

--Diabetes diagnosis
WITH cte_access_to_care
     AS (SELECT DISTINCT enc_patient_id
         FROM   t_encounter T1
                INNER JOIN t_chargecapture T3
                        ON T1.enc_id = T3.cc_enc_id
         WHERE  enc_timestamp >= Dateadd(year, -3, Getdate())
                AND t3.cc_delete_ind = 'N'
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384',
                                     '99385', '99386', '99387', '99391',
                                     '99392', '99393', '99394', '99395',
                                     '99396', '99397', 'G0438', 'G0439',
                                     '90791', '90792', '90832', '90833',
                                     '90834', '90835', '90836', '90837',
                                     '90838', '90839', '90840', '90845',
                                     '90846', '90847', '90849', '90853',
                                     '90875', '90876', '98966', '98967',
                                     '98968', '99221', '99222', '99223',
                                     '99231', '99232', '99233', '99238',
                                     '99239', '99251', '99252', '99253',
                                     '99254', '99255', '99381', '99382',
                                     '99383', '99384', '99385', '99386',
                                     '99387', '99391', '99392', '99393',
                                     '99394', '99395', '99396', '99397',
                                     '99441', '99442', '99443' ))
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes diagnosis' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_assessment t1
       INNER JOIN t_patient t2
               ON t1.patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  icd10_code IN ( 'E08.9', 'E09.9', 'E13.9', 'E08.65',
                       'E09.65', 'E08.10', 'E09.10', 'E13.10',
                       'E08.00', 'E08.01', 'E09.00', 'E09.01',
                       'E13.00', 'E13.01', 'E08.11', 'E08.641',
                       'E09.11', 'E09.641', 'E13.11', 'E13.641',
                       'E08.21', 'E08.22', 'E08.29', 'E09.21',
                       'E09.22', 'E09.29', 'E13.21', 'E13.22',
                       'E13.29', 'E08.311', 'E08.319', 'E08.321',
                       'E08.329', 'E08.331', 'E08.339', 'E08.341',
                       'E08.349', 'E08.351', 'E08.359', 'E08.36',
                       'E08.39', 'E09.311', 'E09.319', 'E09.321',
                       'E09.329', 'E09.331', 'E09.339', 'E09.341',
                       'E09.349', 'E09.351', 'E09.359', 'E09.36',
                       'E09.39', 'E13.311', 'E13.319', 'E13.321',
                       'E13.329', 'E13.331', 'E13.339', 'E13.341',
                       'E13.349', 'E13.351', 'E13.359', 'E13.36',
                       'E13.39', 'E08.40', 'E08.41', 'E08.42',
                       'E08.43', 'E08.44', 'E08.49', 'E08.610',
                       'E09.40', 'E09.41', 'E09.42', 'E09.43',
                       'E09.44', 'E09.49', 'E09.610', 'E13.40',
                       'E13.41', 'E13.42', 'E13.43', 'E13.44',
                       'E13.49', 'E13.610', 'E08.51', 'E08.52',
                       'E08.59', 'E09.51', 'E09.52', 'E09.59',
                       'E13.51', 'E13.52', 'E13.59', 'E08.618',
                       'E08.620', 'E08.621', 'E08.622', 'E08.628',
                       'E08.630', 'E08.638', '08.649', 'E08.69',
                       'E09.618', 'E09.620', 'E09.621', 'E09.622',
                       'E09.628', 'E09.630', 'E09.638', 'E09.649',
                       'E09.69', 'E13.618', 'E13.620', 'E13.621',
                       'E13.622', 'E13.628', 'E13.630', 'E13.638',
                       'E13.649', 'E13.65', 'E13.69', 'E08.8',
                       'E09.8', 'E13.8', 'E11.9', 'E10.9',
                       'E11.65', 'E10.65', 'E11.69', 'E10.10',
                       'E11.00', 'E11.01', 'E10.69', 'E11.641',
                       'E10.11', 'E10.641', 'E11.21', 'E11.22',
                       'E11.29', 'E11.311', 'E11.319', 'E11.321',
                       'E11.329', 'E11.331', 'E11.339', 'E11.341',
                       'E11.349', 'E11.351', 'E11.359', 'E11.36',
                       'E11.39', 'E10.311', 'E10.319', 'E10.321',
                       'E10.329', 'E10.331', 'E10.339', 'E10.341',
                       'E10.349', 'E10.351', 'E10.359', 'E10.36',
                       'E10.39', 'E11.40', 'E11.41', 'E11.42',
                       'E11.43', 'E11.44', 'E11.49', 'E11.610',
                       'E10.40', 'E10.41', 'E10.42', 'E10.43',
                       'E10.44', 'E10.49', 'E10.610', 'E11.51',
                       'E11.52', 'E11.59', 'E10.51', 'E10.52',
                       'E10.59', 'E11.618', 'E11.620', 'E11.621',
                       'E11.622', 'E11.628', 'E11.630', 'E11.638',
                       'E11.649', 'E10.618', 'E10.620', 'E10.621',
                       'E10.622', 'E10.628', 'E10.630', 'E10.638',
                       'E10.649', 'E11.8', 'E10.8' )
       AND t1.assessment_date BETWEEN '20190101' AND '20191231'
       AND EXISTS (SELECT 1
                   FROM   cte_access_to_care
                   WHERE  enc_patient_id = pat_id);
--Diabetes foot exam
WITH cte_access_to_care
     AS (SELECT DISTINCT enc_patient_id
         FROM   t_encounter T1
                INNER JOIN t_chargecapture T3
                        ON T1.enc_id = T3.cc_enc_id
                           AND t3.cc_delete_ind = 'N'
         WHERE  enc_timestamp >= Dateadd(year, -3, Getdate())
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384',
                                     '99385', '99386', '99387', '99391',
                                     '99392', '99393', '99394', '99395',
                                     '99396', '99397', 'G0438', 'G0439',
                                     '90791', '90792', '90832', '90833',
                                     '90834', '90835', '90836', '90837',
                                     '90838', '90839', '90840', '90845',
                                     '90846', '90847', '90849', '90853',
                                     '90875', '90876', '98966', '98967',
                                     '98968', '99221', '99222', '99223',
                                     '99231', '99232', '99233', '99238',
                                     '99239', '99251', '99252', '99253',
                                     '99254', '99255', '99381', '99382',
                                     '99383', '99384', '99385', '99386',
                                     '99387', '99391', '99392', '99393',
                                     '99394', '99395', '99396', '99397',
                                     '99441', '99442', '99443' ))
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes - Foot Exam' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '2028F', 'G8404', 'G8405', 'G8406' )
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231'
       AND t1.cc_delete_ind = 'N'
       AND EXISTS (SELECT 1
                   FROM   cte_access_to_care
                   WHERE  enc_patient_id = pat_id);
--Tobacco use assessment
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Tobacco use assessment' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '1000F' )
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--tobacco use assessment result
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'tobacco use assessment result' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '1000F', '1031F', '1032F', '1033F',
                        '1034F', '1035F', '1036F' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--tobacco Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'tobacco Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '99406', '99407', '4000F', '4001F',
                        '4004F', 'S9075', 'S9453', 'G0436', 'G0437' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--BMI Assessment
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'BMI Assessment' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '3008F' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';
--BMI ICD
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'BMI Assessment' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_assessment t1
       INNER JOIN t_patient t2
               ON t1.patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  icd10_code IN ( 'Z68.1', 'Z68.20', 'Z68.21', 'Z68.22',
                       'Z68.23', 'Z68.24', 'Z68.25', 'Z68.26',
                       'Z68.27', 'Z68.28', 'Z68.29', 'Z68.30',
                       'Z68.31', 'Z68.32', 'Z68.33', 'Z68.34',
                       'Z68.35', 'Z68.36', 'Z68.37', 'Z68.38',
                       'Z68.39', 'Z68.41', 'Z68.42', 'Z68.43',
                       'Z68.44', 'Z68.45', 'Z68.51', 'Z68.52',
                       'Z68.53', 'Z68.54' )
       AND t1.assessment_date BETWEEN '20190101' AND '20191231';


--BMI CPT
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'BMI CPT' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( 'G8417', 'G8418', 'G8420' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Alcohol Screening
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Alcohol Screening' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '3016F','G0396','G0397','G0443','H0005','H0007','H0015','H0016','H0022','H0050','H2036','T1006','T1012' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Alcohol Screening Results
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Alcohol Screening Results' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( 'G9621', 'G9622' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Drug Assessment
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Drug Assessment' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( 'H0001' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Clinical Depression Screening
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Clinical Depression Screening' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '3725F' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Clinical Depression Screening Results
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Clinical Depression Screening Results' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( 'G8510', 'G8431', 'G8511' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Immunizations for Adolescents: Meningococcal
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Immunizations for Adolescents: Meningococcal' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90734' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';
--Immunizations for Adolescents: Tdap
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Immunizations for Adolescents: Tdap' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90715' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--HPV Vaccination
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'HPV Vaccination' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90649', '90650', '90651' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Flu shots for Adults Ages 18-64
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Flu shots for Adults Ages 18-64' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90655', '90657', '90661', '90662',
                        '90673', '90685', '90686', '90687',
                        '90688', 'G0008' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';
--Lipid Management for patients with Cardiovascular disease
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Lipid Management for patients with Cardiovascular disease' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '3048F', '3049F', '3050F','80061','83700','83701','83704','83721' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';

--Diabetes - Nephropathy screening Coding
INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes - Nephropathy screening Coding' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN (	'81000','81001','81002','81003','81005','82042','82043','82044','84156','3060F','3061F','3062F')
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';



--Lipid Management for patients with Diabetes

with cte_lab as ( 
	select distinct pat_id 
	from t_result
	where collection_date between '20190101' and '20191231'
	and  lab_type in ('LDL','lipid panel')
	and delete_ind = 'N' )

INSERT #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Lipid Management for patients with Diabetes' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                t2.pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
       inner join cte_lab t4
       on t2.pat_id = t4.pat_id
WHERE  cc_cpt_code IN ('80061','83700','83701','83704','83721','3048F','3049F','3050F')
AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231';


--Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan
with cte_bmi as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'BMI Assessment' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_assessment t1
       INNER JOIN t_patient t2
               ON t1.patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  icd10_code IN ( 'Z68.1', 'Z68.20', 'Z68.21', 'Z68.22',
                       'Z68.23', 'Z68.24', 'Z68.25', 'Z68.26',
                       'Z68.27', 'Z68.28', 'Z68.29', 'Z68.30',
                       'Z68.31', 'Z68.32', 'Z68.33', 'Z68.34',
                       'Z68.35', 'Z68.36', 'Z68.37', 'Z68.38',
                       'Z68.39', 'Z68.41', 'Z68.42', 'Z68.43',
                       'Z68.44', 'Z68.45', 'Z68.51', 'Z68.52',
                       'Z68.53', 'Z68.54' )
       AND t1.assessment_date BETWEEN '20190101' AND '20191231' ),

cte_nutrition as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Nutritional Counseling' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('97802','97803','97804','G0270', 'G0271', 'G0447', 'S9449', 'S9451', 'S9452', 'S9470')
and   cc_date_of_service between '20190101' and '20191231'
AND pat_id IN ( 
select distinct patient_id 
	from t_assessment
	where assessment_date between '20190101' and '20191231'
	and  icd10_code = 'Z71.3'
	and  delete_ind = 'N' ) ),

cte_phy_act as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Physical activity Counseling' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('G0447','S9451')
and   cc_date_of_service between '20190101' and '20191231'
AND pat_id IN ( 
select distinct patient_id 
	from t_assessment
	where assessment_date between '20190101' and '20191231'
	and  icd10_code in ('Z71.82','Z02.5')
	and  delete_ind = 'N' ) )

INSERT #scorecard
select a.prov_first_name,a.prov_last_name,a.prov_npi,'Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow- Up Plan' AS measure,
                a.pat_first_name,a.pat_last_name,a.pat_date_of_birth,a.pat_id
	from cte_bmi a
	inner join cte_nutrition b
	on a.pat_id = b.pat_id
	inner join cte_phy_act c
	on a.pat_id = c.pat_id;


--Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents

with cte_bmi as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'BMI Assessment' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_assessment t1
       INNER JOIN t_patient t2
               ON t1.patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  icd10_code IN (  'Z68.51', 'Z68.52','Z68.53', 'Z68.54' )
       AND t1.assessment_date BETWEEN '20190101' AND '20191231' ),

cte_nutrition as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Nutritional Counseling' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('97802','97803','97804','G0270', 'G0271', 'G0447', 'S9449', 'S9451', 'S9452', 'S9470')
and   cc_date_of_service between '20190101' and '20191231'
AND pat_id IN ( 
select distinct patient_id 
	from t_assessment
	where assessment_date between '20190101' and '20191231'
	and  icd10_code = 'Z71.3'
	and  delete_ind = 'N' ) ),


cte_phy_act as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Physical activity Counseling' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('G0447','S9451')
and   cc_date_of_service between '20190101' and '20191231'
AND pat_id IN ( 
select distinct patient_id 
	from t_assessment
	where assessment_date between '20190101' and '20191231'
	and  icd10_code in ('Z71.82','Z02.5')
	and  delete_ind = 'N' ) )

INSERT #scorecard
select a.prov_first_name,a.prov_last_name,a.prov_npi,'Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents' AS measure,
                a.pat_first_name,a.pat_last_name,a.pat_date_of_birth,a.pat_id
	from cte_bmi a
	inner join cte_nutrition b
	on a.pat_id = b.pat_id
	inner join cte_phy_act c
	on a.pat_id = c.pat_id;

-- Colorectal Cancer Screening

with cte_fobt as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'fobt' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('3017F','82270','82274','G0328')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_FIT_DNA as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'fit-dna' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('81528','G0464')
and   cc_date_of_service between '20190101' and '20191231' ) ,

cte_Sigmoidoscopy as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Sigmoidoscopy' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('3017F','G0104')
and   cc_date_of_service between '20150101' and '20191231' ),
cte_colonoscopy as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'colonoscopy' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('3017F','G0105','G0121')
and   cc_date_of_service between '20090101' and '20191231' )

insert #scorecard
select DISTINCT prov_first_name,prov_last_name,prov_npi,'Colorectal Cancer Screening' AS measure,
                pat_first_name,pat_last_name,pat_date_of_birth,pat_id
from cte_fobt 
union 
select DISTINCT prov_first_name,prov_last_name,prov_npi,'Colorectal Cancer Screening' AS measure,
                pat_first_name,pat_last_name,pat_date_of_birth,pat_id
from cte_fit_dna
union 
select DISTINCT prov_first_name,prov_last_name,prov_npi,'Colorectal Cancer Screening' AS measure,
                pat_first_name,pat_last_name,pat_date_of_birth,pat_id
from cte_sigmoidoscopy
union
select DISTINCT prov_first_name,prov_last_name,prov_npi,'Colorectal Cancer Screening' AS measure,
                pat_first_name,pat_last_name,pat_date_of_birth,pat_id
from cte_colonoscopy;


--Child ADHD Medications Initiation 
insert #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Child ADHD Medications Initiation' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90791','90792','90832','90833','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847','90849','90853',
					  '90875','90876','98966','98967','98968','99221','99222','99223','99231','99232','99233','99238','99239','99251','99252','99253','99254', 
					  '99255','99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','99441','99442',
					  '99443','G0438','G0439')
and   cc_date_of_service between '20190101' and '20191231';

--Child ADHD Medications Continuation
with cte_1 as ( SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Child ADHD Medications Continuation' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
                ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as rid
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90791','90792','90832','90833','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847','90849','90853',
					  '90875','90876','98966','98967','98968','99221','99222','99223','99231','99232','99233','99238','99239','99251','99252','99253','99254', 
					  '99255','99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','99441','99442',
					  '99443','G0438','G0439')
and   cc_date_of_service between '20190101' and '20191231' )

insert #scorecard
select prov_first_name, prov_last_name, prov_npi, 'Child ADHD Medications Continuation' AS measure,
                pat_first_name,pat_last_name,pat_date_of_birth,pat_id
	from cte_1
	where rid = 2;


--Blood Lead Test
insert #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Blood Lead Test' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('83655')
and   cc_date_of_service between '20190101' and '20191231';

--Childhood Immunization Status Combo 3
with cte_dtap as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 3' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as dtap_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90698','90700','90721','90723')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_ipv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 3' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as ipv_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90698','90713','90723')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_mmr as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 3' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as mmr_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90707','90710')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_hib as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 3' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as hib_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90644','90645','90646','90647','90')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_hepb as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 3' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as hepb_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90723','90740','90744','90747','90748')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_vzv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 3' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as vzv_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90710','90716')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_pcv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 3' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as pcv_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90670')
and   cc_date_of_service between '20190101' and '20191231' )

insert #scorecard
SELECT DISTINCT a.prov_first_name,a.prov_last_name,a.prov_npi,'Childhood Immunization Status Combo 3' AS measure,
                a.pat_first_name,a.pat_last_name,a.pat_date_of_birth,a.pat_id
from cte_dtap a
inner join cte_ipv b
on a.pat_id = b.pat_id
and b.ipv_rid >= 3
inner join cte_mmr c
on a.pat_id = c.pat_id
inner join cte_hib d 
on a.pat_id = d.pat_id
and hib_rid >= 3
inner join cte_hepb e
on a.pat_id = e.pat_id
and e.hepb_rid >= 3
inner join cte_vzv f
on a.pat_id = f.pat_id
inner join cte_pcv g
on a.pat_id = g.pat_id
and pcv_rid >= 4
where a.dtap_rid >= 4;



--Childhood Immunization Status Combo 10
with cte_dtap as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as dtap_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90698','90700','90721','90723')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_ipv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as ipv_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90698','90713','90723')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_mmr as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as mmr_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90707','90710')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_hib as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as hib_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90644','90645','90646','90647','90')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_hepb as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as hepb_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90723','90740','90744','90747','90748')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_vzv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as vzv_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90710','90716')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_pcv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as pcv_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90670')
and   cc_date_of_service between '20190101' and '20191231' ) 


SELECT DISTINCT a.prov_first_name,a.prov_last_name,a.prov_npi,'Childhood Immunization Status Combo 10' AS measure,
                a.pat_first_name,a.pat_last_name,a.pat_date_of_birth,a.pat_id
into #t1
from cte_dtap a
inner join cte_ipv b
on a.pat_id = b.pat_id
and b.ipv_rid >= 3
inner join cte_mmr c
on a.pat_id = c.pat_id
inner join cte_hib d 
on a.pat_id = d.pat_id
and hib_rid >= 3
inner join cte_hepb e
on a.pat_id = e.pat_id
and e.hepb_rid >= 3
inner join cte_vzv f
on a.pat_id = f.pat_id
inner join cte_pcv g
on a.pat_id = g.pat_id
and pcv_rid >= 4
where a.dtap_rid >= 4;


with cte_hepa as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as hepa_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90633')
and   cc_date_of_service between '20190101' and '20191231' ),


cte_rv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as rv_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90681', '90680')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_flu as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Childhood Immunization Status Combo 10' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id,
				ROW_NUMBER() over ( partition by pat_id order by cc_date_of_service ) as flu_rid
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('90655','90657','90661','90662','90673','90685','90686','90687','90688')
and   cc_date_of_service between '20190101' and '20191231' )

insert #scorecard
select distinct a1.*
from #t1 a1
inner join cte_hepa h
on a1.pat_id = h.pat_id
inner join cte_rv i
on a1.pat_id = i.pat_id
and i.rv_rid >= 2
inner join cte_flu j
on a1.pat_id = j.pat_id
and flu_rid >= 2;

--Strep Test For Pharyngitis
insert #scorecard
 
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'LBP-Imaging for Low Back Pain' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('87070', '87071','87081','87430','87650','87651','87652','87880')
and   cc_date_of_service between '20190101' and '20191231' ;
 
--LBP-Imaging for Low Back Pain
insert #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'LBP-Imaging for Low Back Pain' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
and   cc_date_of_service between '20190101' and '20191231' ;
-- Non utilizer
insert #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Non-Utilizer' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_encounter t1
INNER JOIN t_patient t2
ON t1.enc_patient_id = t2.pat_id
AND t2.pat_delete_ind = 'N'
AND t2.pat_status = 'Active'
INNER JOIN provider_master t3
ON t1.enc_rendering_provider_id = t3.prov_id
AND t3.prov_delete_ind = 'N'
WHERE  t1.enc_delete_ind = 'N'
AND t1.enc_timestamp BETWEEN '20190101' AND '20191231' ;

-- Diabetes Monitoring for People with Diabetes and Schizophrenia
with cte_a1c AS (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes Monitoring (DM & Schizophrenia)' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('3044F','3046F','3051F','3052F','83036','83037')
and   cc_date_of_service between '20190101' and '20191231' ),

cte_ldlc AS (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes Monitoring for People with Diabetes and Schizophrenia' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
				
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
where cc_cpt_Code in ('80061','83700','83701','83704','83721','3048F','3049F','3050F')
and   cc_date_of_service between '20190101' and '20191231' )

insert #scorecard
select a.*
from cte_a1c a
inner join cte_ldlc b
on a.pat_id = b.pat_id;

--Adolescent Immunizations Combo 2
with cte_meningococcal as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Immunizations for Adolescents: Meningococcal' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90734' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' ),

cte_tdap as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Immunizations for Adolescents: Tdap' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90715' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' ),
cte_hpv as (
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'HPV Vaccination' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '90649', '90650', '90651' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' )

insert #scorecard

SELECT a.*
FROM   cte_meningococcal a
inner join cte_tdap b
on a.pat_id = b.pat_id
inner join cte_hpv c
on a.pat_id = c.pat_id;

--Diabetes Screening for People with Schizophrenia or Bipolar Disease who are Using Antipsychotic Medication
insert #scorecard
SELECT DISTINCT prov_first_name,
                prov_last_name,
                prov_npi,
                'Diabetes Screening (Antipsychotic Medication)' AS measure,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                pat_id
FROM   t_chargecapture t1
       INNER JOIN t_patient t2
               ON t1.cc_patient_id = t2.pat_id
                  AND t2.pat_delete_ind = 'N'
                  AND t2.pat_status = 'Active'
       INNER JOIN provider_master t3
               ON t1.cc_rendering_provider_id = t3.prov_id
                  AND t3.prov_delete_ind = 'N'
WHERE  cc_cpt_code IN ( '3044F','3046F','3051F','3052F','83036','83037','80047','80048','80050','80053','80069','82947','82950','82951' )
       AND t1.cc_delete_ind = 'N'
       AND t1.cc_date_of_service BETWEEN '20190101' AND '20191231' ;

"""

sf, INSTANCE_URL = getSession()
CONNECTION.execute(FUZZ_TEST)
CONNECTION.execute(DIRECT_MATCH)
CONNECTION.execute(SCORECARD_MAPPING)
DF_REDSHIFT = pd.read_sql(REDSHIFT_QUERY, CONNECTION)
CONNECTION_ARCADIA.execute(query_arcadia)
DF_SCORECARD = pd.read_sql("select distinct pat_id, measure from #scorecard",
                           CONNECTION_ARCADIA)
MATCHING_IDS_DF = pd.merge(DF_REDSHIFT, DF_SCORECARD, on='pat_id')
ACCESS_MATCH = MATCHING_IDS_DF[
    (MATCHING_IDS_DF['measure_x'].str.contains('Access '))
    & (MATCHING_IDS_DF['measure_y'].str.contains('Access '))].id.tolist()
MATCH = pd.merge(
    DF_REDSHIFT, DF_SCORECARD, on=['pat_id', 'measure']).id.tolist()

o=pd.merge( DF_REDSHIFT, DF_SCORECARD, on=['pat_id', 'measure'])
print(len(o))
o.to_csv("/tmp/sf_out.txt",header=True,index=False,sep=",")
#print(DF_REDSHIFT)
#print(DF_SCORECARD)
TASK_IDS = list(set().union(ACCESS_MATCH, MATCH))
TODAY = datetime.now().strftime("%Y%m%d")
for row in TASK_IDS:
    print(row)
    try:
        sf.Task.update(
            row, {
                'status':
                'Completed',
                'Care_Gap_Comments_Part_2__c':
                '{} automated from scorecard - to completed'.format(TODAY)
            })
    except Exception as e:
        print(row, str(e))
