from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce

def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)



CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
CONNECTION_ARCADIA = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)

FUZZ_TEST = """
CREATE TEMPORARY TABLE fuzz_test 
  ( 
     arcadia_name   VARCHAR(255), 
     arcadia_dob    DATE, 
     arcadia_pat_id VARCHAR(100), 
     mco_name       VARCHAR(255), 
     mco_dob        DATE, 
     mco_cin        VARCHAR(50), 
     mco_source     VARCHAR(50), 
     mco_npi        VARCHAR(20), 
     mco_address    VARCHAR(255), 
     mco_phone      VARCHAR(20), 
     mco_month      VARCHAR(20) 
  ); 

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';
"""

SCORECARD_MAPPING = """
CREATE TEMPORARY TABLE scorecard_to_sf_measure_map 
  ( 
     scorecard_measure VARCHAR(255), 
     sf_measure        VARCHAR(255) 
  ); 

copy scorecard_to_sf_measure_map 
from 's3://sftp_test/scorecard_measure_to_sf_measure_mapping.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
trimblanks
maxerror 1
region 'us-east-1'
dateformat 'auto'
ignoreheader 1
csv;
"""

DIRECT_MATCH = """
create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 100
IGNOREBLANKLINES
region 'us-east-1'
dateformat 'auto'
delimiter  '|';
"""

REDSHIFT_QUERY = """
SELECT DISTINCT salesforce_tasks.id, 
                pat_id, 
                scorecard_measure AS measure 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY salesforce_tasks.id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) AS salesforce_tasks 
       INNER JOIN salesforce_patients 
               ON contact_id_18_characters__c = whoid 
       INNER JOIN (SELECT pat_id, 
                          policy_nbr 
                   FROM   direct_match 
                   UNION 
                   SELECT arcadia_pat_id, 
                          mco_cin 
                   FROM   fuzz_test) 
               ON policy_nbr = cin__c 
       INNER JOIN scorecard_to_sf_measure_map 
               ON sf_measure = measure__c 
WHERE  rn = 1 
       AND status NOT IN ( 'Closed', 'Completed', 'Completed - Awaiting Claim Submission', 
                           'Completed - Awaiting Coding Correction') 
       AND salesforce_tasks.project_end_date__c LIKE '2019-12-31%' 
"""

query_arcadia = """
IF Object_id('tempdb..#scorecard') IS NOT NULL 
  DROP TABLE #scorecard; 

CREATE TABLE #scorecard 
  ( 
     prov_first_name   VARCHAR(100) NULL, 
     prov_last_name    VARCHAR(100) NULL, 
     prov_npi          VARCHAR(20), 
     measure           VARCHAR(100) NULL, 
     pat_first_name    VARCHAR(100) NULL, 
     pat_last_name     VARCHAR(100) NULL, 
     pat_date_of_birth DATETIME, 
     pat_id            VARCHAR(100) 
  ); 

-- Access to Care 
WITH cte_1 
     AS (SELECT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                CASE 
                  WHEN Datediff(mm, pat_date_of_birth, Getdate()) BETWEEN 12 AND 24 THEN 'Child Access (12-24 mo)' 
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 2 AND 6 THEN 'Child Access (25 mo-6 yr)' 
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 7 AND 11 THEN 'Child Access (7-11 yr)' 
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 12 AND 19 THEN 'Adolescent Access (12-19 yr)' 
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 20 AND 44 THEN 'Adult Access (20-44)' 
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) BETWEEN 45 AND 64 THEN 'Adult Access (45-64)' 
                  WHEN Datediff(yy, pat_date_of_birth, Getdate()) > 64 THEN 'Adult Access Preventive (65 and Older)'
                  WHEN Datediff(mm, pat_date_of_birth, Getdate()) <= 15 
                       AND Count(DISTINCT cc_date_of_service) >= 5 THEN 'Well-Child (15 mo, 5+ Visits)' 
                END AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
         FROM   t_chargecapture t1 
                INNER JOIN t_patient t2 
                        ON t1.cc_patient_id = t2.pat_id 
                           AND t2.pat_delete_ind = 'N' 
                           AND t2.pat_status = 'Active' 
                INNER JOIN provider_master t3 
                        ON t1.cc_rendering_provider_id = t3.prov_id 
                           AND t3.prov_delete_ind = 'N' 
         WHERE  t1.cc_cpt_code IN ( '99381', '99382', '99383', '99384', 
                                    '99485', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397' ) 
                AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate() 
                AND t1.cc_delete_ind = 'N' 
         GROUP  BY prov_first_name, 
                   prov_last_name, 
                   prov_npi, 
                   pat_first_name, 
                   pat_last_name, 
                   pat_date_of_birth, 
                   pat_id) 
INSERT #scorecard 
SELECT * 
FROM   cte_1 
WHERE  measure IS NOT NULL; 

-- Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia' AS measure,
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '3048F', '3049F', '3050F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

-- Use of Spirometry Testing in the Assessment and Diagnosis of COPD 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Use of Spirometry Testing in the Assessment and Diagnosis of COPD' AS measure,
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '94010', '94014', '94015', '94016', 
                           '94060', '94070', '94375', '94620' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

-- Diabeted - Dialated Eye Exam 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Diabeted - Dialated Eye Exam' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '2022F', '3073F', '2024F', '2026F', 
                           'S0620', 'S0621', 'S3000' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

-- Hemoglobin A1C 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Hemoglobin A1C' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '3044F', '3045F', '3046F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

-- Chlamydia Screening in women 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Chlamydia Screening in women' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '87110', '87270', '87320', '87490', 
                           '87491', '87492', '87810', 'G9820', 'G9821' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Cervical Cancer Screening 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Cervical Cancer Screening' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '3015F', '88141', '88142', '88143', 
                           '88147', '88148', '88150', '88152', 
                           '88153', '88154', '88164', '88165', 
                           '88166', '88167', '88174', '88175', 
                           'G0123', 'G0124', 'G0141', 'G0143', 
                           'G0144', 'G0145', 'G0147', 'G0148', 
                           'P3000', 'P3001', 'Q0091' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Breast Cancer Screening 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Breast Cancer Screening' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '3014F', '77055', '77056', '77057', 
                           '77061', '77062', '77063', '77065', 
                           '77066', '77067', 'G0202', 'G0204', 'G0206' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Adolescent Immunizations Combo 1 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Adolescent Immunizations Combo 1' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '90734', '90715' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Control Blood Pressure Coding 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Control Blood Pressure Coding' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  t1.cc_cpt_code IN ( '3074F', '3075F', '3078F', '3079F', 
                           'G8752', 'G8754' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Asthma Diagnosis 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Asthma Diagnosis' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_assessment t1 
       INNER JOIN t_patient t2 
               ON t1.patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  icd10_code IN ( 'J45.20', 'J45.21', 'J45.22', 'J45.30', 
                       'J45.31', 'J45.32', 'J45.40', 'J45.41', 
                       'J45.42', 'J45.50', 'J45.51', 'J45.52', 
                       'J45.901', 'J45.902', 'J45.909', 'J45.990', 
                       'J45.991', 'J45.998', 'J45.2', 'J45.3', 
                       'J45.4', 'J45.5', 'J45.9', 'J45.90', 'J45.99' ) 
       AND t1.assessment_date BETWEEN '20190101' AND Getdate(); 

--Asthma Action Plan 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Asthma Action Plan' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( 'AST01' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Cardiovascular  Diagnosis 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Cardiovascular  Diagnosis' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_assessment t1 
       INNER JOIN t_patient t2 
               ON t1.patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  icd10_code IN ( 'I13.10', 'I12.9', 'I11.9', 'I10', 
                       'I50.20', 'I50.21', 'I50.22', 'I50.23', 
                       'I50.30', 'I50.31', 'I50.32', 'I50.33', 
                       'I50.40', 'I50.41', 'I50.42', 'I50.43', 
                       'I50.9', 'I50.1', 'I50.20', 'I50.21', 
                       'I50.22', 'I50.23', 'I50.30', 'I50.31', 
                       'I50.32', 'I50.33', 'I50.40', 'I50.41', 
                       'I50.42', 'I50.43', 'I50.9', 'E78.4', 
                       'E78.5', 'I09.2', 'I05.0', 'I06.0', 
                       'I08.0', 'I07.0', 'I07.1', 'I07.2', 
                       'I07.8', 'I07.9', 'I09.0', 'I21.09', 
                       'I25.2', 'I20.8', 'I25.10', 'I20.9', 
                       'I21.09', 'I21.3', 'I25.10', 'I25.2', 
                       'I25.84', 'I25.9', 'I10', 'I11.0', 
                       'I11.9', 'I25.10', 'I48.91', 'I50.9', 
                       'I63.9', 'I65.23', 'I65.29', 'I67.2', 
                       'I67.9', 'I73.9' ) 
       AND t1.assessment_date BETWEEN '20190101' AND Getdate(); 

--COPD Diagnosis 
WITH cte_access_to_care 
     AS (SELECT DISTINCT enc_patient_id 
         FROM   t_encounter T1 
                INNER JOIN t_chargecapture T3 
                        ON T1.enc_id = T3.cc_enc_id 
         WHERE  enc_timestamp >= Dateadd(year, -3, Getdate()) 
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384', 
                                     '99385', '99386', '99387', '99391', 
                                     '99392', '99393', '99394', '99395', 
                                     '99396', '99397', 'G0438', 'G0439', 
                                     '90791', '90792', '90832', '90833', 
                                     '90834', '90835', '90836', '90837', 
                                     '90838', '90839', '90840', '90845', 
                                     '90846', '90847', '90849', '90853', 
                                     '90875', '90876', '98966', '98967', 
                                     '98968', '99221', '99222', '99223', 
                                     '99231', '99232', '99233', '99238', 
                                     '99239', '99251', '99252', '99253', 
                                     '99254', '99255', '99381', '99382', 
                                     '99383', '99384', '99385', '99386', 
                                     '99387', '99391', '99392', '99393', 
                                     '99394', '99395', '99396', '99397', 
                                     '99441', '99442', '99443' )) 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'COPD Diagnosis' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_assessment t1 
       INNER JOIN t_patient t2 
               ON t1.patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  icd10_code IN ( 'J41.0', 'J41.1', 'J41.8', 'J42', 
                       'J43.0', 'J43.1', 'J43.2', 'J43.8', 
                       'J43.9', 'J44.0', 'J44.1', 'J44.9' ) 
       AND t1.assessment_date BETWEEN '20190101' AND Getdate() 
       AND EXISTS (SELECT 1 
                   FROM   cte_access_to_care 
                   WHERE  enc_patient_id = pat_id); 

--Diabetes diagnosis 
WITH cte_access_to_care 
     AS (SELECT DISTINCT enc_patient_id 
         FROM   t_encounter T1 
                INNER JOIN t_chargecapture T3 
                        ON T1.enc_id = T3.cc_enc_id 
         WHERE  enc_timestamp >= Dateadd(year, -3, Getdate()) 
                AND t3.cc_delete_ind = 'N' 
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384', 
                                     '99385', '99386', '99387', '99391', 
                                     '99392', '99393', '99394', '99395', 
                                     '99396', '99397', 'G0438', 'G0439', 
                                     '90791', '90792', '90832', '90833', 
                                     '90834', '90835', '90836', '90837', 
                                     '90838', '90839', '90840', '90845', 
                                     '90846', '90847', '90849', '90853', 
                                     '90875', '90876', '98966', '98967', 
                                     '98968', '99221', '99222', '99223', 
                                     '99231', '99232', '99233', '99238', 
                                     '99239', '99251', '99252', '99253', 
                                     '99254', '99255', '99381', '99382', 
                                     '99383', '99384', '99385', '99386', 
                                     '99387', '99391', '99392', '99393', 
                                     '99394', '99395', '99396', '99397', 
                                     '99441', '99442', '99443' )) 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Diabetes diagnosis' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_assessment t1 
       INNER JOIN t_patient t2 
               ON t1.patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  icd10_code IN ( 'E08.9', 'E09.9', 'E13.9', 'E08.65', 
                       'E09.65', 'E08.10', 'E09.10', 'E13.10', 
                       'E08.00', 'E08.01', 'E09.00', 'E09.01', 
                       'E13.00', 'E13.01', 'E08.11', 'E08.641', 
                       'E09.11', 'E09.641', 'E13.11', 'E13.641', 
                       'E08.21', 'E08.22', 'E08.29', 'E09.21', 
                       'E09.22', 'E09.29', 'E13.21', 'E13.22', 
                       'E13.29', 'E08.311', 'E08.319', 'E08.321', 
                       'E08.329', 'E08.331', 'E08.339', 'E08.341', 
                       'E08.349', 'E08.351', 'E08.359', 'E08.36', 
                       'E08.39', 'E09.311', 'E09.319', 'E09.321', 
                       'E09.329', 'E09.331', 'E09.339', 'E09.341', 
                       'E09.349', 'E09.351', 'E09.359', 'E09.36', 
                       'E09.39', 'E13.311', 'E13.319', 'E13.321', 
                       'E13.329', 'E13.331', 'E13.339', 'E13.341', 
                       'E13.349', 'E13.351', 'E13.359', 'E13.36', 
                       'E13.39', 'E08.40', 'E08.41', 'E08.42', 
                       'E08.43', 'E08.44', 'E08.49', 'E08.610', 
                       'E09.40', 'E09.41', 'E09.42', 'E09.43', 
                       'E09.44', 'E09.49', 'E09.610', 'E13.40', 
                       'E13.41', 'E13.42', 'E13.43', 'E13.44', 
                       'E13.49', 'E13.610', 'E08.51', 'E08.52', 
                       'E08.59', 'E09.51', 'E09.52', 'E09.59', 
                       'E13.51', 'E13.52', 'E13.59', 'E08.618', 
                       'E08.620', 'E08.621', 'E08.622', 'E08.628', 
                       'E08.630', 'E08.638', '08.649', 'E08.69', 
                       'E09.618', 'E09.620', 'E09.621', 'E09.622', 
                       'E09.628', 'E09.630', 'E09.638', 'E09.649', 
                       'E09.69', 'E13.618', 'E13.620', 'E13.621', 
                       'E13.622', 'E13.628', 'E13.630', 'E13.638', 
                       'E13.649', 'E13.65', 'E13.69', 'E08.8', 
                       'E09.8', 'E13.8', 'E11.9', 'E10.9', 
                       'E11.65', 'E10.65', 'E11.69', 'E10.10', 
                       'E11.00', 'E11.01', 'E10.69', 'E11.641', 
                       'E10.11', 'E10.641', 'E11.21', 'E11.22', 
                       'E11.29', 'E11.311', 'E11.319', 'E11.321', 
                       'E11.329', 'E11.331', 'E11.339', 'E11.341', 
                       'E11.349', 'E11.351', 'E11.359', 'E11.36', 
                       'E11.39', 'E10.311', 'E10.319', 'E10.321', 
                       'E10.329', 'E10.331', 'E10.339', 'E10.341', 
                       'E10.349', 'E10.351', 'E10.359', 'E10.36', 
                       'E10.39', 'E11.40', 'E11.41', 'E11.42', 
                       'E11.43', 'E11.44', 'E11.49', 'E11.610', 
                       'E10.40', 'E10.41', 'E10.42', 'E10.43', 
                       'E10.44', 'E10.49', 'E10.610', 'E11.51', 
                       'E11.52', 'E11.59', 'E10.51', 'E10.52', 
                       'E10.59', 'E11.618', 'E11.620', 'E11.621', 
                       'E11.622', 'E11.628', 'E11.630', 'E11.638', 
                       'E11.649', 'E10.618', 'E10.620', 'E10.621', 
                       'E10.622', 'E10.628', 'E10.630', 'E10.638', 
                       'E10.649', 'E11.8', 'E10.8' ) 
       AND t1.assessment_date BETWEEN '20190101' AND Getdate() 
       AND EXISTS (SELECT 1 
                   FROM   cte_access_to_care 
                   WHERE  enc_patient_id = pat_id); 

--Diabetes foot exam 
WITH cte_access_to_care 
     AS (SELECT DISTINCT enc_patient_id 
         FROM   t_encounter T1 
                INNER JOIN t_chargecapture T3 
                        ON T1.enc_id = T3.cc_enc_id 
                           AND t3.cc_delete_ind = 'N' 
         WHERE  enc_timestamp >= Dateadd(year, -3, Getdate()) 
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384', 
                                     '99385', '99386', '99387', '99391', 
                                     '99392', '99393', '99394', '99395', 
                                     '99396', '99397', 'G0438', 'G0439', 
                                     '90791', '90792', '90832', '90833', 
                                     '90834', '90835', '90836', '90837', 
                                     '90838', '90839', '90840', '90845', 
                                     '90846', '90847', '90849', '90853', 
                                     '90875', '90876', '98966', '98967', 
                                     '98968', '99221', '99222', '99223', 
                                     '99231', '99232', '99233', '99238', 
                                     '99239', '99251', '99252', '99253', 
                                     '99254', '99255', '99381', '99382', 
                                     '99383', '99384', '99385', '99386', 
                                     '99387', '99391', '99392', '99393', 
                                     '99394', '99395', '99396', '99397', 
                                     '99441', '99442', '99443' )) 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Diabetes foot exam' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '2028F', 'G8404', 'G8405', 'G8406' ) 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate() 
       AND t1.cc_delete_ind = 'N' 
       AND EXISTS (SELECT 1 
                   FROM   cte_access_to_care 
                   WHERE  enc_patient_id = pat_id); 

--Tobacco use assessment 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Tobacco use assessment' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '1000F' ) 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--tobacco use assessment result 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'tobacco use assessment result' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '1000F', '1031F', '1032F', '1033F', 
                        '1034F', '1035F', '1036F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--tobacco Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'tobacco Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention' AS measure,
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '99406', '99407', '4000F', '4001F', 
                        '4004F', 'S9075', 'S9453', 'G0436', 'G0437' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--BMI Assessment 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'BMI Assessment' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '3008F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--BMI ICD 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'BMI Assessment' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_assessment t1 
       INNER JOIN t_patient t2 
               ON t1.patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  icd10_code IN ( 'Z68.1', 'Z68.20', 'Z68.21', 'Z68.22', 
                       'Z68.23', 'Z68.24', 'Z68.25', 'Z68.26', 
                       'Z68.27', 'Z68.28', 'Z68.29', 'Z68.30', 
                       'Z68.31', 'Z68.32', 'Z68.33', 'Z68.34', 
                       'Z68.35', 'Z68.36', 'Z68.37', 'Z68.38', 
                       'Z68.39', 'Z68.41', 'Z68.42', 'Z68.43', 
                       'Z68.44', 'Z68.45', 'Z68.51', 'Z68.52', 
                       'Z68.53', 'Z68.54', 'V85.1', 'V85.21', 
                       'V85.22', 'V85.23', 'V85.24', 'V85.25', 
                       'V85.30', 'V85.31', 'V85.32', 'V85.33', 
                       'V85.34', 'V85.35', 'V85.36', 'V85.37', 
                       'V85.38', 'V85.39', 'V85.41', 'V85.42', 
                       'V85.43', 'V85.44', 'V85.45', 'V85.51', 
                       'V85.52', 'V85.53', 'V85.54' ) 
       AND t1.assessment_date BETWEEN '20190101' AND Getdate(); 

--BMI CPT 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'BMI CPT' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( 'G8417', 'G8418', 'G8420' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Alcohol Screening 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Alcohol Screening' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '3016F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Alcohol Screening Results 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Alcohol Screening Results' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( 'G9621', 'G9622' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Drug Assessment 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Drug Assessment' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( 'H0001' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Clinical Depression Screening 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Clinical Depression Screening' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '3725F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Clinical Depression Screening Results 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Clinical Depression Screening Results' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( 'G8510', 'G8431', 'G8511' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Immunizations for Adolescents: Meningococcal 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Immunizations for Adolescents: Meningococcal' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '90734' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Immunizations for Adolescents: Tdap 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Immunizations for Adolescents: Tdap' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '90715' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--HPV Vaccination 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'HPV Vaccination' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '90649', '90650', '90651' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Flu shots for Adults Ages 18-64 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Flu shots for Adults Ages 18-64' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '90655', '90657', '90661', '90662', 
                        '90673', '90685', '90686', '90687', 
                        '90688', 'G0008' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Lipid Management for patients with Cardiovascular disease 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Lipid Management for patients with Cardiovascular disease' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '3048F', '3049F', '3050F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 

--Diabetes - Nephropathy screening Coding 
INSERT #scorecard 
SELECT DISTINCT prov_first_name, 
                prov_last_name, 
                prov_npi, 
                'Diabetes - Nephropathy screening Coding' AS measure, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                pat_id 
FROM   t_chargecapture t1 
       INNER JOIN t_patient t2 
               ON t1.cc_patient_id = t2.pat_id 
                  AND t2.pat_delete_ind = 'N' 
                  AND t2.pat_status = 'Active' 
       INNER JOIN provider_master t3 
               ON t1.cc_rendering_provider_id = t3.prov_id 
                  AND t3.prov_delete_ind = 'N' 
WHERE  cc_cpt_code IN ( '3060F', '3061F', '3062F', '3066F' ) 
       AND t1.cc_delete_ind = 'N' 
       AND t1.cc_date_of_service BETWEEN '20190101' AND Getdate(); 
"""

sf, INSTANCE_URL = getSession()
CONNECTION.execute(FUZZ_TEST)
CONNECTION.execute(DIRECT_MATCH)
CONNECTION.execute(SCORECARD_MAPPING)
DF_REDSHIFT = pd.read_sql(REDSHIFT_QUERY, CONNECTION)
CONNECTION_ARCADIA.execute(query_arcadia)
DF_SCORECARD = pd.read_sql("select distinct pat_id, measure from #scorecard",
                           CONNECTION_ARCADIA)
MATCHING_IDS_DF = pd.merge(DF_REDSHIFT, DF_SCORECARD, on='pat_id')
ACCESS_MATCH = MATCHING_IDS_DF[
    (MATCHING_IDS_DF['measure_x'].str.contains('Access '))
    & (MATCHING_IDS_DF['measure_y'].str.contains('Access '))].id.tolist()
MATCH = pd.merge(
    DF_REDSHIFT, DF_SCORECARD, on=['pat_id', 'measure']).id.tolist()
TASK_IDS = list(set().union(ACCESS_MATCH, MATCH))
TODAY = datetime.now().strftime("%Y%m%d")
for row in TASK_IDS:
    print(row)
    try:
        sf.Task.update(
            row, {
                'status':
                'Completed',
                'Care_Gap_Comments_Part_2__c':
                '{} automated from scorecard - to completed'.format(TODAY)
            })
    except Exception as e:
        print(row, str(e))
