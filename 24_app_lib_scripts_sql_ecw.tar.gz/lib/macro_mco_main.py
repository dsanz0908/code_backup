import pyodbc
import pandas as pd
from datetime import datetime
from bokeh.io import output_file, save
from bokeh.models import ColumnDataSource
from bokeh.models.widgets import DataTable, DateFormatter, TableColumn, HTMLTemplateFormatter, StringFormatter

conn = pyodbc.connect(dsn="somos_redshift_1")
query = """
SELECT DISTINCT 'Affinity'   AS MCO, 
                'Corinthian' AS IPA, 
                period       AS received_month 
FROM   payor.affinity_corinthian_all_rosters 
UNION ALL 
SELECT DISTINCT 'Affinity' AS MCO, 
                'Somos'    AS IPA, 
                period     AS received_month 
FROM   payor.affinity_somos_roster_all 
UNION ALL 
SELECT DISTINCT 'Empire/Anthem' AS MCO, 
                'Somos'         AS IPA, 
                received_month 
FROM   payor.empire_somos_member 
UNION ALL 
SELECT DISTINCT 'Empire/Anthem' AS MCO, 
                'Corinthian'    AS IPA, 
                received_month 
FROM   payor.empire_bcbs_healthplus_legacy_all_roster_oldformat 
UNION ALL 
SELECT DISTINCT 'Fidelis'   AS mco, 
                'Innovator' AS IPA, 
                received_month 
FROM   payor.fideliscare_prod_membership_full_somos_all 
UNION ALL 
SELECT DISTINCT 'Healthfirst' AS MCO, 
                'Corinthian'   AS IPA, 
                received_month 
FROM   payor.healthfirst_all_eligibility
WHERE  provider_parent_code = 'COR2' 
UNION ALL 
SELECT DISTINCT 'Healthfirst' AS MCO, 
                'Excelsior'    AS IPA, 
                received_month 
FROM   payor.healthfirst_all_eligibility
WHERE  provider_parent_code = 'EXC1' 
UNION ALL 
SELECT 'Healthfirst' as MCO, 'Somos' as IPA, to_char(to_date('2017-01-01', 'YYYY-MM-DD') + (n || ' months')::interval, 'YYYYMM')
from generate_series (0, 15) n
UNION ALL
SELECT DISTINCT 'Healthfirst' AS MCO, 
                'Somos'        AS IPA, 
                received_month 
FROM   payor.healthfirst_somos_all_eligibility 
WHERE  provider_parent_code LIKE 'SOM%' 
       AND received_month != '20172018' 
UNION ALL 
SELECT DISTINCT 'NYDOH' 
                AS SOURCE, 
                'NYDOH' 
                AS IPA, 
                received_month 
FROM   nydoh.all_rosters_all_columns
UNION ALL 
SELECT DISTINCT 'United' AS MCO, 
                'Somos'  AS IPA, 
                received_month 
FROM   payor.uhc_somos_all_membership
WHERE  received_month != '2017_2018' 
UNION ALL 
SELECT DISTINCT 'Wellcare'    AS MCO, 
                'Corinthian'  AS IPA, 
                receivedmonth AS received_month 
FROM   payor.wellcare_all_demographics 
WHERE  master_ipa = 'CMI' 
UNION ALL 
SELECT DISTINCT 'Wellcare'    AS MCO, 
                'Excelsior'   AS IPA, 
                receivedmonth AS received_month 
FROM   payor.wellcare_all_demographics 
WHERE  master_ipa = 'EX1' 
UNION ALL 
SELECT DISTINCT 'Wellcare'    AS MCO, 
                'BalanceMed'  AS IPA, 
                receivedmonth AS received_month 
FROM   payor.wellcare_all_demographics 
WHERE  master_ipa = 'VR1' 
UNION ALL 
SELECT DISTINCT 'Wellcare'    AS MCO, 
                'ECAP'        AS IPA, 
                receivedmonth AS received_month 
FROM   payor.wellcare_all_demographics 
WHERE  master_ipa = 'EC1' 
UNION ALL 
SELECT DISTINCT 'Wellcare'    AS MCO, 
                'SOMOS'       AS IPA, 
                receivedmonth AS received_month 
FROM   payor.wellcare_somos_all_demographics 
WHERE  master_ipa = 'SOMOS' 
ORDER  BY 1,2,3; 
"""
df = pd.read_sql(query, conn)
df.set_index(keys=['mco'], drop=False, inplace=False)
df.set_index(keys=['ipa'], drop=False, inplace=False)

mco = df['mco'].unique().tolist()
ipa = df['ipa'].unique().tolist()

date_range = [
    'MCO', 'IPA', 201701, 201702, 201703, 201704, 201705, 201706, 201707,
    201708, 201709, 201710, 201711, 201712, 201801, 201802, 201803, 201804,
    201805, 201806, 201807, 201808, 201809, 201810, 201811, 201812, 201901,
    201902, 201903, 201904, 201905, 201906, 201907, 201908, 201909, 201910,
    201911, 201912, 202001, 202002, 202003, 202004, 202005, 202006
]

date_range_temp = []
for item in date_range:
    date_range_temp.append(str(item))
date_range_temp
date_range = date_range_temp

final_df = pd.DataFrame(columns=date_range)
mco_list = [
    'Affinity', 'Affinity', 'Empire/Anthem', 'Empire/Anthem', 'Fidelis',
    'Healthfirst', 'Healthfirst', 'Healthfirst', 'NYDOH', 'United',
    'Wellcare', 'Wellcare', 'Wellcare', 'Wellcare', 'Wellcare'
]
ipa_list = [
    'Corinthian', 'Somos', 'Corinthian', 'Somos', 'Innovator', 'Corinthian',
    'Excelsior', 'SOMOS', 'NYDOH', 'Somos', 'BalanceMed', 'Corinthian', 'ECAP',
    'Excelsior', 'SOMOS'
]
mco_iteration = 0
for word in mco_list:
    x = 0
    templist = []
    templist.append(mco_list[mco_iteration])
    templist.append(ipa_list[mco_iteration])
    for i in range(len(date_range) - 2):
        if str(date_range[x + 2]) in df.loc[
            (df.mco == mco_list[mco_iteration])
                & (df.ipa == ipa_list[mco_iteration])].received_month.values:
            templist.append(' ')
            x += 1
        else:
            templist.append('No Data')
            x += 1
    mco_iteration += 1
    temp_df = pd.DataFrame([templist], columns=date_range)
    final_df = final_df.append(temp_df)
final_df = final_df.reset_index()
final_df = final_df.drop('index', axis=1)

output_file("/home/etl/etl_home/Reports/mco_macro.html")
source = ColumnDataSource(final_df)

formatter = StringFormatter(text_color='red')
columns = [
    TableColumn(field="MCO", title="MCO"),
    TableColumn(field="IPA", title="IPA"),
    TableColumn(field="201701", title="201701", formatter=formatter),
    TableColumn(field="201702", title="201702", formatter=formatter),
    TableColumn(field="201703", title="201703", formatter=formatter),
    TableColumn(field="201704", title="201704", formatter=formatter),
    TableColumn(field="201705", title="201705", formatter=formatter),
    TableColumn(field="201706", title="201706", formatter=formatter),
    TableColumn(field="201707", title="201707", formatter=formatter),
    TableColumn(field="201708", title="201708", formatter=formatter),
    TableColumn(field="201709", title="201709", formatter=formatter),
    TableColumn(field="201710", title="201710", formatter=formatter),
    TableColumn(field="201711", title="201711", formatter=formatter),
    TableColumn(field="201712", title="201712", formatter=formatter),
    TableColumn(field="201801", title="201801", formatter=formatter),
    TableColumn(field="201802", title="201802", formatter=formatter),
    TableColumn(field="201803", title="201803", formatter=formatter),
    TableColumn(field="201804", title="201804", formatter=formatter),
    TableColumn(field="201805", title="201805", formatter=formatter),
    TableColumn(field="201806", title="201806", formatter=formatter),
    TableColumn(field="201807", title="201807", formatter=formatter),
    TableColumn(field="201808", title="201808", formatter=formatter),
    TableColumn(field="201809", title="201809", formatter=formatter),
    TableColumn(field="201810", title="201810", formatter=formatter),
    TableColumn(field="201811", title="201811", formatter=formatter),
    TableColumn(field="201812", title="201812", formatter=formatter),
    TableColumn(field="201901", title="201901", formatter=formatter),
    TableColumn(field="201902", title="201902", formatter=formatter),
    TableColumn(field="201903", title="201903", formatter=formatter),
    TableColumn(field="201904", title="201904", formatter=formatter),
    TableColumn(field="201905", title="201905", formatter=formatter),
    TableColumn(field="201906", title="201906", formatter=formatter),
    TableColumn(field="201907", title="201907", formatter=formatter),
    TableColumn(field="201908", title="201908", formatter=formatter),
    TableColumn(field="201909", title="201909", formatter=formatter),
    TableColumn(field="201910", title="201910", formatter=formatter),
    TableColumn(field="201911", title="201911", formatter=formatter),
    TableColumn(field="201912", title="201912", formatter=formatter),
    TableColumn(field="202001", title="202001", formatter=formatter),
    TableColumn(field="202002", title="202002", formatter=formatter),
    TableColumn(field="202003", title="202003", formatter=formatter),
    TableColumn(field="202004", title="202004", formatter=formatter),
    TableColumn(field="202005", title="202005", formatter=formatter),
    TableColumn(field="202006", title="202006", formatter=formatter),
]
data_table = DataTable(source=source, columns=columns, width=3000, height=500)
save(data_table)

#This generates the table column list
#mco_list=['Affinity', 'Affinity', 'Empire/Anthem', 'Empire/Anthem', 'Fidelis', 'Healthfirst', 'Healthfirst', 'Healthfirst', 'NYDOH', 'United', 'Wellcare', 'Wellcare', 'Wellcare', 'Wellcare', 'Wellcare']
#ipa_list=['Corinthian', 'Somos', 'Corinthian', 'Somos', 'Innovator', 'Corinthian', 'Excelsior', 'SOMOS', 'NYDOH', 'Somos', 'BalanceMed', 'Corinthian', 'ECAP', 'Excelsior', 'SOMOS' ]
#x=0
#for item in date_range:
#print('TableColumn(field="'+date_range[x]+'", title="'+date_range[x]+'"),')
#x+=1
