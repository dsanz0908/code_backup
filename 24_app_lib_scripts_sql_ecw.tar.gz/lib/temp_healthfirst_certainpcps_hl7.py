# -*- coding: utf-8 -*-

from datetime import datetime
import pyodbc
import re
from hl7apy.core import Message, Segment, Field
import pandas as pd
from collections import defaultdict


def xstr(s):
    return '' if s is None or s == 'Needs Update' else str(s)


STOPWORDS = '({})'.format('|'.join([
    i.rstrip().lower() for i in open('substance_strings.txt', 'r').readlines()
]))
sud_codes = [i.rstrip() for i in open('substance_icd10_codes.txt', 'r').readlines()]
a = [
    i.rstrip().split('\t')
    for i in open('pcmh_hl7_codes.txt', 'r').readlines() if i.split('\t')[1] not in sud_codes
]


d = defaultdict(list)
for i in a:
    try:
        d[i[0]].append([i[1], i[2]])
    except:
        d[i[0]].append([i[1], ''])

df = pd.read_csv('pcmh_hl7_data.txt', sep='\t')
df = df.fillna('')
for i, j in enumerate(list(df.columns)):
    print i, j

rows = df.values.tolist()

for row_id, row in enumerate(rows):
    final_string = ''
    message = Message()
    message.msh.msh_1 = '|'
    message.msh.msh_2 = '^~\&'
    message.msh.msh_3 = 'SOMOS'
    message.msh.msh_4 = 'SOMOS'
    message.msh.msh_5 = 'HealthShare'
    message.msh.msh_6 = 'Healthfirst'
    message.msh.msh_7 = datetime.now().strftime('%Y%m%d%H%M%S')
    message.msh.msh_9 = 'ADT^A08'
    message.msh.msh_10 = "{}{}".format(datetime.now().strftime('%Y%m%d%H%M%S'),
                                       row_id + 1)
    message.msh.msh_11 = 'T'
    message.msh.msh_12 = '2.5'

    event = Segment("EVN")
    event.evn_1 = 'A08'
    event.evn_2 = datetime.strptime(row[1],
                                    '%Y-%m-%d').strftime("%Y%m%d%H%M%S")

    patient_id = Segment("PID")
    patient_id.pid_1 = '1'
    mpi = Field("PID_3")
    mpi.pid_3_1 = "{}-{}".format(xstr(row[3]), xstr(int(row[46])))
    mpi.pid_3_4 = 'SOMOS'
    mpi.pid_3_5 = 'MPI'
    patient_id.add(mpi)
    mrn = Field("PID_3")
    mrn.pid_3_1 = xstr(row[2])
    mrn.pid_3_4 = row[9] if row[9] else 'eClinicalWorks'
    mrn.pid_3_5 = 'MRN'
    patient_id.add(mrn)
    pid_5 = Field("PID_5")
    pid_5.pid_5_1 = row[30]
    pid_5.pid_5_2 = row[31]
    patient_id.add(pid_5)
    patient_id.pid_7 = datetime.strptime(
        row[32], '%Y-%m-%d').strftime("%Y%m%d") if row[32] else ''
    patient_id.pid_8 = row[33]
    patient_id.pid_10 = xstr(row[5])
    pid_11 = Field("PID_11")
    pid_11.pid_11_1 = xstr(row[34])
    pid_11.pid_11_3 = row[35]
    pid_11.pid_11_4 = row[36]
    pid_11.pid_11_5 = xstr(int(row[37]))
    patient_id.add(pid_11)
    patient_id.pid_13 = xstr(row[38])
    patient_id.pid_15 = xstr(row[6])
    patient_id.pid_19 = xstr(row[7])
    pid_21 = Field("PID_21")
    pid_21.pid_21_1 = row[30]
    pid_21.pid_21_2 = row[31]
    patient_id.add(pid_21)
    patient_id.pid_22 = xstr(row[8])

    patient_visit_1 = Segment("PV1")
    patient_visit_1.pv1_1 = '1'
    patient_visit_1.pv1_2 = 'O'
    pv1_3 = Field("PV1_3")
    pv1_3.pv1_3_1 = 'OP'
    pv1_3.pv1_3_4 = row[9]
    patient_visit_1.add(pv1_3)
    patient_visit_1.pv1_4 = 'ROUTINE'
    pv1_7 = Field("PV1_7")
    pv1_7.pv1_7_2 = xstr(row[40])
    pv1_7.pv1_7_3 = xstr(row[41])
    patient_visit_1.add(pv1_7)
    patient_visit_1.pv1_10 = xstr(row[41])
    patient_visit_1.pv1_14 = 'ROUTINE'
    pv1_17 = Field("PV1_17")
    pv1_17.pv1_17_2 = xstr(row[40])
    pv1_17.pv1_17_3 = xstr(row[41])
    patient_visit_1.add(pv1_17)
    patient_visit_1.pv1_18 = 'O'
    patient_visit_1.pv1_19 = str(int(
        row[10]))  #"{}-{}".format(str(int(row[11])), row[12])
    patient_visit_1.pv1_44 = datetime.strptime(
        row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    if row[44]:
        patient_visit_1.pv1_45 = xstr(row[44].strftime("%Y%m%d%H%M%S"))
        patient_visit_1.pv1_36 = 'Unknown'
        patient_visit_1.pv1_37 = 'Unknown'
    else:
        patient_visit_1.pv1_45 = ''

    print message.to_er7()
    print event.to_er7()
    print patient_id.to_er7()
    print patient_visit_1.to_er7()

    if row[12] or row[13]:
        patient_visit_2 = Segment("PV2")
        patient_visit_2.pv2_3 = xstr(row[12])[:250]
        row_reason = xstr(row[13])[:250]
        patient_visit_2.pv2_12 = re.sub(STOPWORDS, '', row_reason.lower())
        print patient_visit_2.to_er7()
    else:
        pass

    obx = Segment("OBX")
    obx.obx_1 = '1'
    obx.obx_3 = 'HEIGHT'
    obx.obx_5 = str(row[14])
    obx.obx_6 = row[15]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()
    obx = Segment("OBX")
    obx.obx_1 = '2'
    obx.obx_3 = 'WEIGHT'
    obx.obx_5 = str(row[16])
    obx.obx_6 = row[17]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()
    obx = Segment("OBX")
    obx.obx_1 = '3'
    obx.obx_3 = 'BMI'
    obx.obx_5 = str(row[18])
    obx.obx_6 = row[19]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()
    obx = Segment("OBX")
    obx.obx_1 = '4'
    obx.obx_3 = 'SYSTOLIC'
    obx.obx_5 = str(row[20])
    obx.obx_6 = row[21]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()
    obx = Segment("OBX")
    obx.obx_1 = '5'
    obx.obx_3 = 'DIASTOLIC'
    obx.obx_5 = str(row[22])
    obx.obx_6 = row[23]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()
    obx = Segment("OBX")
    obx.obx_1 = '6'
    obx.obx_3 = 'TEMPERATURE'
    obx.obx_5 = str(row[24])
    obx.obx_6 = row[25]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()
    obx = Segment("OBX")
    obx.obx_1 = '7'
    obx.obx_3 = 'HEART RATE'
    obx.obx_5 = str(row[26])
    obx.obx_6 = row[27]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()
    obx = Segment("OBX")
    obx.obx_1 = '8'
    obx.obx_3 = 'SP02'
    obx.obx_5 = str(row[28])
    obx.obx_6 = row[29]
    obx.obx_11 = 'F'
    obx.obx_14 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
    print obx.to_er7()

    for diagnosis_id, diagnosis in enumerate(d[row[0]]):
        diagnosis_1 = Segment("DG1")
        diagnosis_1.dg1_1 = str(diagnosis_id+1)
        diagnosis_1.dg1_2 = 'I10'
        dg1_3 = Field("DG1_3")
        dg1_3.dg1_3_1 = xstr(diagnosis[0])
        dg1_3.dg1_3_2 = diagnosis[1].rstrip()
        diagnosis_1.add(dg1_3)
        diagnosis_1.dg1_4 = diagnosis[1].rstrip()
        diagnosis_1.dg1_5 = datetime.strptime(row[1], '%Y-%m-%d').strftime("%Y%m%d%H%M%S")
        diagnosis_1.dg1_6 = 'Primary' if diagnosis_id == 0 else 'Other'
        print diagnosis_1.to_er7()

    insurance_1 = Segment("IN1")
    insurance_1.in1_1 = '1'
    insurance_1.in1_2 = 'Healthfirst'
    insurance_1.in1_3 = 'Healthfirst'
    insurance_1.in1_4 = 'Healthfirst'
    in1_16 = Field("IN1_16")
    in1_16.in1_16_1 = row[30]
    in1_16.in1_16_2 = row[31]
    insurance_1.add(in1_16)
    insurance_1.in1_18 = datetime.strptime(
        row[32], '%Y-%m-%d').strftime("%Y%m%d") if row[32] else ''   
    insurance_1.in1_36 = xstr(row[0])
    print insurance_1.to_er7()
 
