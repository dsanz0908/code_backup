import datetime
import pytz
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
def main():
	conn_24=pyodbc.connect(dsn="postgres_24")
	conn_67=pyodbc.connect(dsn="postgres_67")
	res_24=getDBDetails(conn_24)
	res_67=getDBDetails(conn_67)
	processResults(res_24,'10-0-10-24','w')
	processResults(res_67,'10-0-10-67','a')
	#email_report(success,fail,new_cnt,for_dt,table)

def getDBDetails(conn):
	query= """
	with cte_failed_dag_run as (
	select dag_id,execution_date,start_date,state from dag_run where dag_id like 'ecw%' and start_date >= current_date),
 	cte_max_start_date_state as ( select dag_id,max(start_date) as mx_date from dag_run where dag_id like 'ecw%' group by dag_id  ) ,
  	cte_max_success_state as ( select dag_id,max(start_date) as last_success_date from dag_run where dag_id like 'ecw%' and state = 'success' group by dag_id  )


	select distinct t1.dag_id,t1.state as last_state, mx.mx_date last_run_date, last_success_date 
	from dag_run t1, cte_failed_dag_run cte , cte_max_start_date_state mx,cte_max_success_state scs

	where t1.dag_id = cte.dag_id
  	and   t1.dag_id = mx.dag_id
  	and   t1.start_date = mx.mx_date
  	and   t1.dag_id = scs.dag_id
	"""

	cur=conn.execute(query)
	res=cur.fetchall()
	cur.close()
	return res
def  processResults(dbdetails,instancename,writemode):
	if len(dbdetails) == 0:
		return None
	f=open("/home/etl/etl_home/Reports/ecw_status.html",writemode)
	h=HTML()
	tbl=h.table(style='font-family:Arial;font-size:70%')
	r=tbl.tr(style="background-color:#AEB6BF")
	r.td("Instance")
	r.td("Dag Identifier")
        r.td("Last State")
        r.td("Last Run Time")
        r.td("Last Success Time")
	for row in dbdetails:
		bgcolor= "background-color:#117864" if row[1] == "success" else "background-color:#F7DC6F"
		r=tbl.tr(style=bgcolor)
		r.td(instancename)
		r.td(row[0])
		r.td(row[1])
		r.td(datetime.datetime.strftime(row[2],'%Y%m%d %H:%M'))
		r.td(datetime.datetime.strftime(row[3],'%Y%m%d %H:%M'))
	f.write(str(tbl))
	f.close()
	return tbl
def email_report(success,fail,new,for_dt,table):
	to_addr="ssundararaman@somoscommunitycare.org"
	smtp_user="acpscanner@optimusha.com"
	smtp_pwd="Optimum@2018"
	smtp_server=smtplib.SMTP("west.exch031.serverdata.net",587)
	smtp_server.ehlo()
	smtp_server.starttls()
	smtp_server.ehlo
	smtp_server.login(smtp_user,smtp_pwd)
	#header = "To:" + to_addr + "\n" + "From: " + "etluser@optimusha.net \n" + "Subject: Engagement Satus Report for : " + for_dt + "\n"
	#msg=header + "\n Success Count : " + str(success) +  "\n Failure Count: " + str(fail) + "\n New Count: " + str(new) 
	msg=email.message.Message()
	msg["Subject"]= "Subject: Engagement Satus Report for : " + for_dt + " Total Success Count: " + str(success) + " Total Fail Count: " + str(fail) + " Total Count: " + str(new)
	msg["From"]="etluser@optimusha.net"
	msg["To"]=to_addr
	msg.add_header("Content-Type","text/html")
	#msg.set_payload(str(table))
	msg=MIMEText(str(table))
	#smtp_server.sendmail("etluser@optimusha.com",to_addr,msg)
	smtp_server.sendmail("etluser@optimusha.com",to_addr,msg.as_string())
	smtp_server.close()
if __name__ == '__main__':
 main()
