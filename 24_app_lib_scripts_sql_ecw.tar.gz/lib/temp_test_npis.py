import json
import pyodbc
import requests

conn = pyodbc.connect(
    "dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL"
)

query = """
SELECT * 
FROM   (SELECT prov_fullname, 
               aa.*, 
               Row_number() 
                 OVER ( 
                   partition BY aa.prov_npi, year 
                   ORDER BY prov_fullname) AS rn 
        FROM   (SELECT prov_npi, 
                       Year(day)                                       AS year, 
                       Sum(minutes)                                    AS total_minutes, 
                       Sum(minutes) / 60                               AS total_hours, 
                       Min(day)                                        AS first_workday, 
                       Max(day)                                        AS last_workday, 
                       Count(DISTINCT day)                             AS days_worked, 
                       ( Sum(minutes) / 60 ) / Count(DISTINCT day)     AS average_hours_worked_per_day_worked,
                       ( Sum(minutes) / 60 ) / Count(DISTINCT day) * 7 AS average_hours_worked_per_7_days_worked,
                       CASE 
                         WHEN Datediff(week, Min(day), Max(day)) = 0 THEN NULL 
                         ELSE ( Sum(minutes) / 60 ) / Datediff(week, Min(day), Max(day)) 
                       END                                             AS average_hours_worked_per_week
                FROM   (SELECT prov_npi, 
                               CONVERT(DATE, appt_date)                         AS day, 
                               Datediff(minute, Min(appt_date), Max(appt_date)) AS minutes 
                        FROM   t_appointment AS a 
                               JOIN provider_master AS b 
                                 ON prov_id = appt_provider_id 
                               JOIN location_site AS c 
                                 ON appt_location_id = c.location_id 
                               JOIN site_master AS d 
                                 ON c.site_id = d.site_id 
                        WHERE  appt_date < Getdate() 
                               AND appt_date >= '2019-01-22' 
                               AND appt_kept_ind = 'Y' 
                               AND site_emr_name = 'eClinicalWorks' 
                        GROUP  BY prov_npi, 
                                  CONVERT(DATE, appt_date)) AS t1 
                GROUP  BY prov_npi, 
                          Year(day) 
                HAVING Datediff(week, Min(day), Max(day)) > 0) AS aa 
               JOIN (SELECT DISTINCT Upper(prov_fullname) AS prov_fullname, 
                                     prov_npi 
                     FROM   provider_master) AS bb 
                 ON aa.prov_npi = bb.prov_npi) AS cc 
WHERE  rn = 1 
       AND average_hours_worked_per_week >= 30 
       AND prov_npi IS NOT NULL 
ORDER  BY year, 
          prov_fullname 
"""

cur = conn.execute(query)
db_result = cur.fetchall()
cur.close()

npis = set()
types = set()
for row in db_result:
    seq_id = row[1]
    resp = requests.get(
        "https://npiregistry.cms.hhs.gov/api/resultsDemo2/?number={}".format(
            str(seq_id)))
    res = json.loads(resp.content.decode("UTF-8"))
    try:
        for i in range(res["result_count"]):
            npi = res["results"][i]["number"]
            state = res["results"][i]["addresses"][0]["state"]
            taxonomy = res["results"][i]["taxonomies"][0]["desc"]
            if state == 'NY' and taxonomy not in [
                    'Anesthesiology', 'Dermatology', 'Physical Therapist',
                    'Physician Assistant', 'Registered Nurse'
            ] and 'nurse' not in taxonomy.lower(
            ) and 'student' not in taxonomy.lower():
                print npi, taxonomy
                npis.add(npi)
        #print(seq_id, first_name, last_name, npi, state,
        #      res["result_count"])
    except:
        pass
conn.commit()
print npis
