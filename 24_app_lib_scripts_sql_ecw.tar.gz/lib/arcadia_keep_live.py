import pyodbc

def main():
	conn=pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")
	query="select @@servername"
	cur=conn.execute(query)
	res=cur.fetchall()
	conn.close()
	print(res[0][0])

if __name__ == '__main__':
	main()
