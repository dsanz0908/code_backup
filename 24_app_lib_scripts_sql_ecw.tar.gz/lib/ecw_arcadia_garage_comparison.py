import pandas as pd
import pyodbc
import time

ecw_query = "select distinct encounterid from db_nyafmp..enc where year(date) = 2019 and deleteFlag = 0"
arcadia_query = "select distinct cast(enc_original_id as int) as enc_original_id from t_encounter where enc_site_id = 'AF5338BD-4CC6-4E9B-897C-F355132E3BE1' and year(enc_timestamp) = 2019 and enc_delete_ind = 'N'"
gdw_query = "SELECT distinct sourceencounterid::int as sourceencounterid FROM   gdw.emr_encounters AS a JOIN gdw.practice_details AS b ON a.practiceid = b.id JOIN gdw.patients ON patientid = patients.id WHERE  b.id = '35CB72B8-74CD-4202-A7DE-A9F323AF3340' AND date_part(year, encounterdate) = 2019 and sourceencounterid <> ''"

ecw_connection = pyodbc.connect("dsn=arcadia_sql_02_2017;uid=dev-etl;pwd=2aUK*BSy&z295sD")
ecw_df = pd.read_sql(ecw_query, ecw_connection)
ecw_connection.close()

arcadia_connection = pyodbc.connect("dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL")
arcadia_df = pd.read_sql(arcadia_query, arcadia_connection)
arcadia_connection.close()


gdw_connection = pyodbc.connect("dsn=somos_redshift_1")
gdw_df = pd.read_sql(gdw_query, gdw_connection)
gdw_connection.close()

a = pd.merge(ecw_df, arcadia_df, left_on='encounterid', right_on='enc_original_id', how='left')
b = pd.merge(a, gdw_df, left_on='encounterid', right_on='sourceencounterid', how='left')
b.to_csv('20200305_abbydek_2019_ecw_arcadia_garage_encounterid.csv', index=False)
