import pyodbc
import pandas as pd
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
from multiprocessing import Pool
import json
import boto3
conn=pyodbc.connect(dsn="somos_redshift_1")
conn_arcadia = pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")

pat_with_policy="""
select pat_id,pat_first_name,pat_last_name,pat_date_of_birth,policy_nbr,max(enc_timestamp) as last_encounter
	from t_patient t1
	inner join t_payer t2
	on t1.pat_id = t2.patient_id
	--and policy_nbr like '[A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][A-Z]'
    and ( LEN(policy_nbr) = 15 or policy_nbr like '[A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][A-Z]' )
	and t2.payer_delete_ind = 'N'
	inner join t_encounter t3
	on t1.pat_id = t3.enc_patient_id
	and t3.enc_delete_ind = 'N'
	where t1.pat_delete_ind = 'N'
	group by pat_id,policy_nbr,pat_first_name,pat_last_name,pat_date_of_birth
"""

mco_data="""
select 'fidelis' as plan, mco_cin as member_id, '2019-12-01', mco_first_name, mco_last_name, mco_dob from scratch_misa.fidelis_non_compliant
"""

df_pat_with_policy=pd.read_sql(pat_with_policy,conn_arcadia)
df_mco=pd.read_sql(mco_data,conn)
mdf=df_mco.merge(df_pat_with_policy,how="inner",left_on="member_id",right_on="policy_nbr")
mdf["matching_source"]="arcadia_policy_nbr"
mdf.to_csv('20200108_fidelis_misa_direct.csv', header=True, index=False)

fuzzy_arc_query="""
with cte_pat_with_cin as (
select pat_id,pat_first_name,pat_last_name,pat_date_of_birth,policy_nbr,max(enc_timestamp) as last_encounter
	from t_patient t1
	inner join t_payer t2
	on t1.pat_id = t2.patient_id
	and policy_nbr like '[A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][A-Z]'
	and t2.payer_delete_ind = 'N'
	inner join t_encounter t3
	on t1.pat_id = t3.enc_patient_id
	and t3.enc_delete_ind = 'N'
	where t1.pat_delete_ind = 'N'
	group by pat_id,policy_nbr,pat_first_name,pat_last_name,pat_date_of_birth )

select pat_id,pat_first_name,pat_last_name,pat_first_name + ' ' +  pat_last_name as pat_full_name,
isnull(pat_date_of_birth,'19000101') as dob,Null as policy_nbr,isnull(MAX(enc_timestamp),'19000101') as last_encounter
from t_patient t1
inner join t_encounter t2
on t1.pat_id = t2.enc_patient_id
and t2.enc_delete_ind = 'N'
where t1.pat_delete_ind = 'N'
and not exists ( select 1 from cte_pat_with_cin where t1.pat_id = cte_pat_with_cin.pat_id )
group by pat_id,pat_first_name,pat_last_name,pat_date_of_birth
"""
mco_query="""
select 'fidelis' as plan, mco_cin as member_id, '2019-12-01', mco_first_name, mco_last_name, mco_first_name || ' ' || mco_last_name as mco_full_name, mco_dob from scratch_misa.fidelis_non_compliant
"""

print 1
cur1=conn.execute(mco_query)
res1=cur1.fetchall()
cur1.close()
print 2
cur2=conn_arcadia.execute(fuzzy_arc_query)
res2=cur2.fetchall()
cur2.close()
print 3
def target_extract(data):
    res_dict={}
    for row in data:
        if row[4].strftime("%Y%m%d") in res_dict.keys():
            res_dict[row[4].strftime("%Y%m%d")].append((row[0],row[1],row[2],row[3],row[5],row[6]))
        else:
            res_dict[row[4].strftime("%Y%m%d")]=[(row[0],row[1],row[2],row[3],row[5],row[6])]
    return res_dict
res_dict = target_extract(res2)
def check_data(mco_data):
    ret_data=[]
    mco_name=mco_data[5]
    mco_dob=mco_data[6]
    mco_cin=mco_data[1]
    mco_plan=mco_data[0]
    mco_effective_period=mco_data[2]#.strftime("%Y%m%d")
    mco_first_name = mco_data[3]
    mco_last_name = mco_data[4]
    
    if mco_dob in res_dict.keys():
        print mco_dob
        res=res_dict[mco_dob]
        for arcadia_data in res:
            arcadia_pat_id = arcadia_data[0]
            arcadia_pat_first_name = arcadia_data[1]
            arcadia_pat_last_name = arcadia_data[2]
            arcadia_pat_full_name = arcadia_data[3]
            arcadia_dob = mco_dob
            arcadia_mco_matched_cin = mco_cin
            arcadia_last_encounter = arcadia_data[5]#.strftime("%Y%m%d")
            #score=fuzz.token_set_ratio(arcadia_name,mco_name)
            score=fuzz.WRatio(arcadia_pat_full_name,mco_name)
            if score > 90 :
                ret_data.append(mco_plan + "|" + mco_cin + "|" + mco_effective_period + "|" + mco_first_name + "|" + mco_last_name  + \
                "|" +  mco_dob + '|' + arcadia_pat_id + '|' + arcadia_pat_first_name + '|' + arcadia_pat_last_name + '|' + \
                arcadia_dob + '|' + arcadia_last_encounter + '~!' )
    print ret_data
    return ret_data

Data=map(check_data,res1)
f=open("20200108_fidelis_misa_fuzzy.csv","w")
for row in Data:
    if len(row) > 0:
        f.write(json.dumps(row).replace('"','').replace("[","").replace("~!]","\n ").replace("~!, ","\n"))
f.close()

