# -*- coding: utf-8 -*-
import sys
import os
reload(sys)
sys.setdefaultencoding("utf-8")
from datetime import datetime
import requests
from simple_salesforce import Salesforce
from fuzzywuzzy import fuzz
from collections import defaultdict
import pyodbc


def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)

if __name__ == '__main__':
    sf, instance_url = getSession()
    query1 = """
    create temp table a (
    Plan varchar(255),
    Member_ID varchar(255),
    Member_First_Name varchar(255),
    Member_Last_Name varchar(255),
    Member_DOB varchar(255),
    Provider_ID varchar(255),
    Measure varchar(255),
    SF_Measure varchar(255),
    CHW varchar(255),
    Team_Lead varchar(255),
    Segment_Lead varchar(255),
    In_Salesforce varchar(255),
    Provider_First_Name varchar(255),
    Provider_Last_Name varchar(255),
    Provider_Full_Name varchar(255),
    Organization__SF varchar(255),
    NPI varchar(255),
    Current_Status varchar(255),
    Comment varchar(255),
    DOS varchar(255),
    Date_of_Claim_Submission varchar(255));

    copy a
    from 's3://sftp_test/20191206_jimmy_file.csv'
    iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
    MAXERROR 10
    ignoreheader 1
    region 'us-east-1'
    delimiter ','
    ACCEPTINVCHARS 
    dateformat 'auto' 
    removequotes;
    """

    query2 = """
select * from (select c.id, status as status_in_salesforce,
case when current_status ilike '%wai%subm%' then 'Completed - Awaiting Claim Submission'
when current_status ilike '%wait%cod%corr%' then 'Completed - Awaiting Coding Correction'
when current_status ilike '%exclus%mov%cov%' then 'Exclusion - Moved out of coverage area/Switched to commercial insurance'
when current_status ilike '%exclus%not%manag%' then 'Exclusion - Does not meet criteria - Verified by Management'
when current_status ilike '%exclus%patie%oon%' or lower(current_status) = 'change pcp oon ' then 'Exclusion - Patient switched to OON PCP'
when current_status ilike '%pra%t%sch%' then 'Pending - Practice will schedule'
when current_status ilike '%unable%reach%' or lower(current_status) = 'unreach' or lower(current_status) = 'no answer' then 'Outreach - Unable to reach'
when lower(current_status) = 'completed' then 'Completed'
when lower(current_status) = 'pending - patient will call' then 'Pending - Practice will schedule'
when lower(current_status) ilike '%app%sched%' then 'Pending - Appointment Scheduled'
when lower(current_status) = 'closed' then 'Closed'
when lower(current_status) ilike '%spanish%' or lower(current_status) = 'open' or lower(current_status) = 'issue' then 'Open'
when current_status ilike '%refus%' then 'Issue - Patient refused'
when lower(current_status) ilike '%phone%wrong%' then 'Issue - Phone wrong/disconnected/out of service'
when lower(current_status) = 'issue - ineligible for measure - need review' then 'Issue - Ineligible for measure - Needs Review'
when lower(current_status) = 'issue -eligibility - needs review' then 'Issue - Eligibility - Needs review'
when lower(current_status) = 'pending- patient will call' then 'Pending - Patient will call'


else lower(current_status) end as change_to_status, comment--,
                    --dos, to_char(to_date(replace(dos, 'PE ', ''), 'MM/DD/YYYY'), 'YYYY-MM-DD')

FROM   a
           JOIN salesforce_patients AS b
             ON member_id = cin__c
           JOIN (SELECT *,
                        Row_number()
                          OVER (
                            partition BY salesforce_tasks.id
                            ORDER BY added_tz DESC) AS rn
                 FROM   salesforce_tasks) AS c
             ON b.id = c.whoid
    WHERE  current_status <> ''
           AND sf_measure = measure__c  and status not in ('Closed', 'Completed') and c.isdeleted = 'FALSE'
           AND rn = 1 and status <> case when current_status ilike '%wai%subm%' then 'Completed - Awaiting Claim Submission'
when current_status ilike '%wait%cod%corr%' then 'Completed - Awaiting Coding Correction'
when current_status ilike '%exclus%mov%cov%' then 'Exclusion - Moved out of coverage area/Switched to commercial insurance'
when current_status ilike '%exclus%not%manag%' then 'Exclusion - Does not meet criteria - Verified by Management'
when current_status ilike '%exclus%patie%oon%' or lower(current_status) = 'change pcp oon ' then 'Exclusion - Patient switched to OON PCP'
when current_status ilike '%pra%t%sch%' then 'Pending - Practice will schedule'
when current_status ilike '%unable%reach%' or lower(current_status) = 'unreach' or lower(current_status) = 'no answer' then 'Outreach - Unable to reach'
when lower(current_status) = 'completed' then 'Completed'
when lower(current_status) = 'pending - patient will call' then 'Pending - Practice will schedule'
when lower(current_status) ilike '%app%sched%' then 'Pending - Appointment Scheduled'
when lower(current_status) = 'closed' then 'Closed'
when lower(current_status) ilike '%spanish%' or lower(current_status) = 'open' or lower(current_status) = 'issue' then 'Open'
when current_status ilike '%refus%' then 'Issue - Patient refused'
when lower(current_status) ilike '%phone%wrong%' then 'Issue - Phone wrong/disconnected/out of service'
when lower(current_status) = 'issue - ineligible for measure - need review' then 'Issue - Ineligible for measure - Needs Review'
when lower(current_status) = 'issue -eligibility - needs review' then 'Issue - Eligibility - Needs review'
when lower(current_status) = 'pending- patient will call' then 'Pending - Patient will call'
else lower(current_status) end)


where change_to_status not in ('Closed', 'Completed', 'Open')
and status_in_salesforce not ilike '%completed%'
and status_in_salesforce not in ('Open', 'Open - No Show', 'Outreach - Unable to reach')
and change_to_status in ('Completed - Awaiting Claim Submission', 'Completed - Awaiting Coding Correction')
    """
    conn = pyodbc.connect('dsn=somos_redshift_1')
    conn.execute(query1)
    a = conn.execute(query2).fetchall()
    TODAY = datetime.now().strftime("%Y%m%d")
    for i in a:
        print i
	try:
	    sf.Task.update(
		i[0], {
		    'status':i[2],
		    'care_gap_comments__c':i[3],
                    'Care_Gap_Comments_Part_2__c':'{} automated from aggregated jimmy file'.format(TODAY)
                    #'date_of_service__c':i[4],
		})
	except Exception as e:
	    print(i, str(e))

    conn.close()
