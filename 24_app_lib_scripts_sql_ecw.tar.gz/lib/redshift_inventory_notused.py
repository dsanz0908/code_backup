import datetime
import pytz
import sys
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
final_res=[]
def main():
	conn=pyodbc.connect(dsn="somos_redshift_1")
	tables=list_tables(conn,'payor')
	for table in tables:
		get_table_details(conn,'payor',table[0])
	processResults(final_res)

def list_tables(conn,schema):
	query = " select tablename from pg_tables where tablename like '%all%' and schemaname = '{0}'  order by 1"
	cur=conn.execute(query.format(schema))
	res=cur.fetchall()
	return res

def get_table_details(conn,schema,tablename):
	if tablename.startswith("affinity"):
		gcolumn = "period"
	elif tablename.startswith("wellcare"):
		gcolumn = "receivedmonth"
	else:
		gcolumn = "received_month"

	query = """ select '{0}' as schemaname, '{1}' as table_name,count(*) as total_count, min({2}) as earliest_month, 
		max({2}) as latest_month , ( select count(*) from {0}.{1} 
		where {2} = ( select max({2}) from {0}.{1} ) ) as lastest_count 
		from {0}.{1} """
	cur = conn.execute(query.format(schema,tablename,gcolumn))
	res = cur.fetchall()
	final_res.append(res[0])

def getDBDetails(process_date,conn):
	query="""
	select s3_key,1 as success, 0 as fail from etl_new.success_new where for_dt = '{0}'
	union
	select s3_key,0 as success, 1 as fail from etl_new.fail_new where for_dt = '{0}'
	"""
	cur=conn.execute(query.format(process_date))
	res=cur.fetchall()
	cur.close()
	return res
def  processResults(dbdetails):
	if len(dbdetails) == 0:
		return None
	f=open("/home/etl/etl_home/Reports/inventory.html","w")
	h=HTML()
	tbl=h.table(style='font-family:Arial;font-size:70%')
	r=tbl.tr(style="background-color:#AEB6BF")
	r.td("Schema Name")
        r.td("Table Name")
        r.td("Total Count")
        r.td("Earliest Month")
	r.td("Latest Month")
	r.td("Latest Month Count")
	rnum=0
	for row in dbdetails:
		rnum = rnum + 1
		bgcolor= "background-color:#EDF8D8" if rnum %2 == 0 else "background-color:#D6FF94"
		r=tbl.tr(style=bgcolor)
		r.td(row[0])
		r.td(row[1])
		r.td(str(row[2]))
		r.td(row[3])
		r.td(row[4])
		r.td(str(row[5]))
	f.write(str(tbl))
	f.close()
	return tbl
if __name__ == '__main__':
 main()
