import csv
import datetime
import time
import argparse
from pyvirtualdisplay import Display
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def automation(ipa, month):
    wellcare_download_page = "https://wellcare.accureports.com/downloads.cfm"
    wellcare_logout = "https://wellcare.accureports.com/downloads.cfm?MM_logout=1&compid=64"
    display = Display(visible=0, size=(800, 600))
    display.start()
    browser, wait = get_browser()
    login(browser, wait)
    browser.get(wellcare_download_page)
    if ipa == "CORINTHIAN":
        get_corinthian(browser, wait, month)
    elif ipa == 'EXCELSIOR':
        get_excelsior(browser, wait, month)
    elif ipa == 'BALANCE':
        get_balance(browser, wait, month)
    elif ipa == 'SOMOS':
        get_somos(browser, wait, month)
    browser.get(wellcare_logout)
    browser.quit()
    display.stop()


def get_browser():
    options = Options()
    options.headless = True
    options.add_argument('--disable-infobars')
    options.add_argument('--disable-extensions')
    options.add_argument('--profile-directory=Default')
    options.add_argument("--incognito")
    options.add_argument("--disable-plugins-discovery")
    options.add_argument("--start-maximized")
    options.add_argument("--headless")
    browser = webdriver.Chrome(options=options)
    browser.command_executor._commands["send_command"] = (
        "POST", '/session/$sessionId/chromium/send_command')
    params = {
        'cmd': 'Page.setDownloadBehavior',
        'params': {
            'behavior': 'allow',
            'downloadPath': "/home/etl/etl_home/temp/"
        }
    }
    command_result = browser.execute("send_command", params)
    browser.delete_all_cookies()
    wait = WebDriverWait(browser, 10)
    return browser, wait


def login(browser, wait):
    wellcare_homepage = "https://wellcare.accureports.com"
    browser.get(wellcare_homepage)
    username_element = wait.until(
        EC.presence_of_element_located((By.ID, "username")))
    password_element = wait.until(
        EC.presence_of_element_located((By.ID, "password")))
    submit_element = wait.until(
        EC.presence_of_element_located((By.ID, "login")))
    username_element.send_keys("jdionisio")
    password_element.send_keys("Umisays35!")
    submit_element.submit()
    return


def get_corinthian(browser, wait, month):
    corinthian_date_xpath = "//*[@id='spryregion1']/form/table/tbody/tr[5]/td[4]"
    corinthian_date_element = wait.until(
        EC.presence_of_element_located((By.XPATH, corinthian_date_xpath)))
    if month in corinthian_date_element.text:
        browser.get(
            "https://wellcare.accureports.com/downloads/64/CMI%5FCORINTHIAN%5Fallfiles%2Ezip"
        )
        time.sleep(10)
    return


def get_excelsior(browser, wait, month):
    excelsior_date_xpath = "//*[@id='spryregion1']/form/table/tbody/tr[8]/td[4]"
    excelsior_date_element = wait.until(
        EC.presence_of_element_located((By.XPATH, excelsior_date_xpath)))
    if month in excelsior_date_element.text:
        browser.get(
            "https://wellcare.accureports.com/downloads/64/EX1%5FEXCELSIORM%5Fallfiles%2Ezip"
        )
        time.sleep(10)
    return


def get_somos(browser, wait, month):
    somos_date_xpath = "//*[@id='spryregion1']/form/table/tbody/tr[11]/td[4]"
    somos_date_element = wait.until(
        EC.presence_of_element_located((By.XPATH, somos_date_xpath)))
    if month in somos_date_element.text:
        browser.get(
            "https://wellcare.accureports.com/downloads/64/SOMOS%5FSOMOSYOURH%5Fallfiles%2Ezip"
        )
        time.sleep(10)
    return


def get_balance(browser, wait, month):
    balance_date_xpath = "//*[@id='spryregion1']/form/table/tbody/tr[14]/td[4]"
    balance_date_element = wait.until(
        EC.presence_of_element_located((By.XPATH, balance_date_xpath)))
    if month in balance_date_element.text:
        browser.get(
            "https://wellcare.accureports.com/downloads/64/VR1%5FBALANCEMED%5Fallfiles%2Ezip"
        )
        time.sleep(10)
    return


if __name__ == "__main__":
    PARSER = argparse.ArgumentParser(description='grab wellcare from portal')
    PARSER.add_argument(
        'ipa',
        action='store',
        help='Missing Wellcare IPA')
    PARSER.add_argument(
        'month_to_grab',
        action='store',
        help='Missing Wellcare date')
    ARGS = PARSER.parse_args()
    IPA = ARGS.ipa
    MONTH_TO_GRAB = ARGS.month_to_grab
    automation(IPA, MONTH_TO_GRAB)
