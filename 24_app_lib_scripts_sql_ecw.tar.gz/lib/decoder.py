import sys
import base64
from Crypto.Cipher import AES

encrypted_value = sys.argv[1]
secret_key = sys.argv[2]

cipher = AES.new(secret_key,AES.MODE_ECB)
decoded = cipher.decrypt(base64.b64decode(encrypted_value))
print decoded.split()[0]
