import sys
import subprocess
import pandas as pd
import pyodbc

CONNECTION_ARCADIA = pyodbc.connect(
    "DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01"
)

ALLERGY_QUERY = """
SELECT DISTINCT  allergy_original_id, 
                allergy_ndcid, 
                allergy_description, 
                allergy_type, 
                allergy_start_date, 
                allergy_stopped_date, 
                allergy_orig_site_id, 
                allergy_severity, 
                allergy_reaction, 
                tallergyid, 
                allergy_rxnorm, 
                pat_original_id 
FROM   t_allergy 
       JOIN site_master 
         ON t_allergy.allergy_orig_site_id = site_master.site_orig_site_id 
       JOIN t_patient 
         ON t_allergy.allergy_patient_id = t_patient.pat_id 
WHERE  site_emr_name = 'Mdland iClinic' 
       AND allergy_delete_ind = 'N' 
"""

APPOINTMENT_QUERY = """
SELECT DISTINCT  appt_original_id, 
                appt_date, 
                appt_begintime, 
                appt_endtime, 
                appt_reason, 
                appt_kept_ind, 
                appt_delete_ind, 
                appt_orig_site_id, 
                appt_rescheduled_ind, 
                appt_cancel_ind, 
                appt_billed_ind, 
                appt_location_unscrubbed, 
                pat_original_id, 
                prov_original_id 
FROM   t_appointment 
       JOIN site_master 
         ON t_appointment.appt_orig_site_id = site_master.site_orig_site_id 
       JOIN t_patient 
         ON t_appointment.appt_patient_id = t_patient.pat_id 
       JOIN provider_master 
         ON t_appointment.appt_provider_id = provider_master.prov_id 
WHERE  site_emr_name = 'Mdland iClinic' 
       AND appt_delete_ind = 'N'
"""

APPOINTMENT_QUERY = """
SELECT DISTINCT appt_original_id, appt_date, appt_begintime, appt_endtime, appt_reason, appt_kept_ind, appt_delete_ind, appt_orig_site_id, appt_rescheduled_ind, appt_cancel_ind, appt_billed_ind, appt_location_unscrubbed, pat_original_id, prov_original_id FROM t_appointment JOIN site_master ON t_appointment.appt_orig_site_id = site_master.site_orig_site_id JOIN t_patient ON t_appointment.appt_patient_id = t_patient.pat_id JOIN provider_master ON t_appointment.appt_provider_id = provider_master.prov_id WHERE site_emr_name = 'Mdland iClinic' AND appt_delete_ind = 'N'"""

ASSESSMENT_QUERY = """
SELECT DISTINCT  original_id, 
                original_problem_id, 
                assessment_severity, 
                assessment_description, 
                assessment_notes, 
                icd9_code, 
                assessment_date, 
                primary_diagnosis_ind, 
                orig_site_id, 
                tassessmentid, 
                icd10_code, 
                pat_original_id, 
                prov_original_id 
FROM   t_assessment 
       JOIN site_master 
         ON t_assessment.orig_site_id = site_master.site_orig_site_id 
       JOIN t_patient 
         ON t_assessment.patient_id = t_patient.pat_id 
       JOIN provider_master 
         ON t_assessment.provider_id = provider_master.prov_id 
WHERE  site_emr_name = 'Mdland iClinic' 
       AND delete_ind = 'N'
"""

ASSESSMENT_QUERY = """
SELECT DISTINCT original_id, original_problem_id, assessment_severity, assessment_description, assessment_notes, icd9_code, assessment_date, primary_diagnosis_ind, orig_site_id, tassessmentid, icd10_code, pat_original_id, prov_original_id FROM t_assessment JOIN site_master ON t_assessment.orig_site_id = site_master.site_orig_site_id JOIN t_patient ON t_assessment.patient_id = t_patient.pat_id JOIN provider_master ON t_assessment.provider_id = provider_master.prov_id WHERE site_emr_name = 'Mdland iClinic' AND delete_ind = 'N'"""

CHARGECAPTURE_QUERY = """
SELECT DISTINCT cc_original_id, 
                cc_cpt_code, 
                cc_currency, 
                cc_amount, 
                cc_reimbursed, 
                cc_quantity, 
                cc_j_code, 
                cc_dx_id_1, 
                cc_dx_id_2, 
                cc_dx_id_3, 
                cc_dx_id_4, 
                cc_date_of_service, 
                cc_reason_code, 
                cc_orig_site_id, 
                cc_rendering_name, 
                cc_prioritization_of_procedure, 
                cc_submitted_date, 
                cc_emp_id, 
                tchargecaptureid, 
                cc_mod_1, 
                cc_mod_2, 
                cc_mod_3, 
                cc_mod_4, 
                orig_midlevel_provider_id, 
                orig_referral_provider_id, 
                orig_patient_id, 
                orig_encounter_id, 
                orig_provider_id 
FROM   t_chargecapture 
       JOIN site_master 
         ON t_chargecapture.cc_orig_site_id = site_master.site_orig_site_id 
WHERE  cc_delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic' 
"""

CHARGECAPTURE_QUERY = """
SELECT DISTINCT cc_original_id, cc_cpt_code, cc_currency, cc_amount, cc_reimbursed, cc_quantity, cc_j_code, cc_dx_id_1, cc_dx_id_2, cc_dx_id_3, cc_dx_id_4, cc_date_of_service, cc_reason_code, cc_orig_site_id, cc_rendering_name, cc_prioritization_of_procedure, cc_submitted_date, cc_emp_id, tchargecaptureid, cc_mod_1, cc_mod_2, cc_mod_3, cc_mod_4, orig_midlevel_provider_id, orig_referral_provider_id, orig_patient_id, orig_encounter_id, orig_provider_id FROM t_chargecapture  JOIN site_master ON t_chargecapture.cc_orig_site_id = site_master.site_orig_site_id WHERE cc_delete_ind = 'N' AND site_emr_name = 'Mdland iClinic'"""

ENCOUNTER_QUERY = """
SELECT DISTINCT  enc_original_id, 
                enc_timestamp, 
                enc_type, 
                enc_type_description, 
                enc_dept_desc, 
                enc_orig_dept_id, 
                enc_billable_ind, 
                enc_clinical_ind, 
                enc_optical_ind, 
                enc_status, 
                enc_eligibility_check_ind, 
                enc_reason, 
                enc_discharge_timestamp, 
                enc_notes, 
                enc_room, 
                enc_orig_site_id, 
                enc_age_months, 
                enc_age_years, 
                enc_provider1_name, 
                enc_provider2_name, 
                enc_provider3_name, 
                enc_medical_ind, 
                enc_location_unscrubbed, 
                enc_locked_ind, 
                enc_no_known_allergy_ind, 
                enc_no_known_medication_ind, 
                enc_no_known_problem_ind, 
                enc_appt_original_id, 
                enc_dental_ind, 
                enc_optometry_ind, 
                enc_behavioral_ind, 
                enc_enabling_ind, 
                enc_locked_timestamp, 
                enc_signed_ind, 
                enc_signed_timestamp, 
                enc_progress_note_ind, 
                tencounterid, 
                enc_opt_out_ind, 
                enc_orig_patient_id, 
                enc_orig_rendering_provider_id, 
                enc_orig_scrubbed_ind 
FROM   t_encounter 
       JOIN site_master 
         ON t_encounter.enc_orig_site_id = site_master.site_orig_site_id 
WHERE  enc_delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic'
"""

ENCOUNTER_QUERY = "SELECT DISTINCT enc_original_id, enc_timestamp, enc_type, enc_type_description, enc_dept_desc, enc_orig_dept_id, enc_billable_ind, enc_clinical_ind, enc_optical_ind, enc_status, enc_eligibility_check_ind, enc_reason, enc_discharge_timestamp, enc_notes, enc_room, enc_orig_site_id, enc_age_months, enc_age_years, enc_provider1_name, enc_provider2_name, enc_provider3_name, enc_medical_ind, enc_location_unscrubbed, enc_locked_ind, enc_no_known_allergy_ind, enc_no_known_medication_ind, enc_no_known_problem_ind, enc_appt_original_id, enc_dental_ind, enc_optometry_ind, enc_behavioral_ind, enc_enabling_ind, enc_locked_timestamp, enc_signed_ind, enc_signed_timestamp, enc_progress_note_ind, tencounterid, enc_opt_out_ind, enc_orig_patient_id, enc_orig_rendering_provider_id, enc_orig_scrubbed_ind FROM t_encounter JOIN site_master ON t_encounter.enc_orig_site_id = site_master.site_orig_site_id WHERE enc_delete_ind = 'N' AND site_emr_name = 'Mdland iClinic'"

IMMUNIZATION_QUERY = """
SELECT DISTINCT  original_id, 
                imm_type, 
                completed_date, 
                cpt_code, 
                cvx_code, 
                dose, 
                units, 
                lot_number, 
                manufacturer, 
                route, 
                imm_site, 
                orig_site_id, 
                imm_type_unscrubbed, 
                hx_data_ind, 
                enc_orig_patient_id, 
                enc_orig_rendering_provider_id 
FROM   t_immunization 
       JOIN site_master 
         ON t_immunization.orig_site_id = site_master.site_orig_site_id 
       JOIN t_encounter 
         ON t_immunization.enc_id = t_encounter.enc_id 
WHERE  delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic'
"""

MAINTENANCE_QUERY = """
SELECT DISTINCT  maint_original_id, 
                maint_observation, 
                maint_observation_type, 
                maint_status, 
                maint_completed_date, 
                maint_ordered_date, 
                maint_ordered_by, 
                maint_completed_by, 
                maint_class, 
                maint_sequence_number, 
                maint_cpt_code, 
                maint_icd9_code, 
                maint_icd10_code, 
                maint_orig_site_id, 
                maint_numeric_obsvalue, 
                maint_type_unscrubbed, 
                maint_result_unscrubbed, 
                maint_orig_completed_by_prov_id, 
                tmaintenanceid, 
                maint_loinc_code, 
                maint_category, 
                maint_orig_patient_id, 
                maint_orig_encounter_id 
FROM   t_maintenance 
       JOIN site_master 
         ON t_maintenance.maint_orig_site_id = site_master.site_orig_site_id 
WHERE  maint_delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic'
"""

MAINTENANCE_QUERY = """
SELECT DISTINCT maint_original_id, maint_observation, maint_observation_type, maint_status, maint_completed_date, maint_ordered_date, maint_ordered_by, maint_completed_by, maint_class, maint_sequence_number, maint_cpt_code, maint_icd9_code, maint_icd10_code, maint_orig_site_id, maint_numeric_obsvalue, maint_type_unscrubbed, maint_result_unscrubbed, maint_orig_completed_by_prov_id, tmaintenanceid, maint_loinc_code, maint_category, maint_orig_patient_id, maint_orig_encounter_id FROM t_maintenance  JOIN site_master ON t_maintenance.maint_orig_site_id = site_master.site_orig_site_id WHERE maint_delete_ind = 'N' AND site_emr_name = 'Mdland iClinic'
"""

MEDICATIONLIST_QUERY = """
SELECT DISTINCT original_id, 
               ndc_code, 
               prescribed_elsewhere_ind, 
               start_date, 
               stop_date, 
               date_last_refilled, 
               medication_dictionary, 
               cpoe_ind, 
               orig_site_id, 
               medication_name, 
               medication_generic_name, 
               order_ind, 
               order_date, 
               tmedicationlistid, 
               location_unscrubbed, 
               provider_id_unscrubbed, 
               dose, 
               route, 
               instructions, 
               status, 
               rxnorm, 
               orig_patient_id, 
               orig_originating_enc_id, 
               orig_updated_enc_id 
FROM   t_medicationlist 
       JOIN site_master 
         ON t_medicationlist.orig_site_id = site_master.site_orig_site_id 
            AND site_emr_name = 'Mdland iClinic' 
       AND delete_ind = 'N'
"""

MEDICATIONLIST_QUERY = """
SELECT DISTINCT original_id, ndc_code, prescribed_elsewhere_ind, start_date, stop_date, date_last_refilled, medication_dictionary, cpoe_ind, orig_site_id, medication_name, medication_generic_name, order_ind, order_date, tmedicationlistid, location_unscrubbed, provider_id_unscrubbed, dose, route, instructions, status, rxnorm, orig_patient_id, orig_originating_enc_id, orig_updated_enc_id FROM t_medicationlist JOIN site_master ON t_medicationlist.orig_site_id = site_master.site_orig_site_id AND site_emr_name = 'Mdland iClinic' AND delete_ind = 'N'"""

ORDER_QUERY = """
SELECT DISTINCT  ordered_date, 
                original_id, 
                to_location_name, 
                order_name, 
                order_type, 
                order_specialty, 
                order_category, 
                order_notes, 
                order_priority, 
                order_status, 
                cpt_code, 
                icd9_code, 
                icd10_code, 
                sequence_number, 
                result_received_date, 
                orig_site_id, 
                ordering_provider_id_unscrubbed, 
                reviewing_provider_id_unscrubbed, 
                cpoe_ind, 
                torderid, 
                linked_image_ind, 
                loinc_code, 
                orig_patient_id, 
                orig_encounter_id 
FROM   t_order 
       JOIN site_master 
         ON t_order.orig_site_id = site_master.site_orig_site_id 
WHERE  delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic'
"""

ORDER_QUERY = """
SELECT DISTINCT ordered_date, original_id, to_location_name, order_name, order_type, order_specialty, order_category, order_notes, order_priority, order_status, cpt_code, icd9_code, icd10_code, sequence_number, result_received_date, orig_site_id, ordering_provider_id_unscrubbed, reviewing_provider_id_unscrubbed, cpoe_ind, torderid, linked_image_ind, loinc_code, orig_patient_id, orig_encounter_id FROM t_order JOIN site_master ON t_order.orig_site_id = site_master.site_orig_site_id WHERE delete_ind = 'N' AND site_emr_name = 'Mdland iClinic'"""

PAYER_QUERY = """
SELECT DISTINCT  payer_original_id, 
                policy_nbr, 
                policy_start_dt, 
                policy_end_dt, 
                payer_orig_site_id, 
                payer_name_unscrubbed, 
                payer_order, 
                subscriber_nbr, 
                family_relationship, 
                pat_original_id, 
                pat_provider_id_unscrubbed 
FROM   t_payer 
       JOIN site_master 
         ON t_payer.payer_orig_site_id = site_master.site_orig_site_id 
       JOIN t_patient 
         ON t_payer.patient_id = t_patient.pat_id 
WHERE  site_emr_name = 'Mdland iClinic' 
       AND payer_delete_ind = 'N' 
"""

PRESCRIPTION_QUERY = """
SELECT DISTINCT  ndc_code, 
                prescription_date, 
                prescription_method, 
                quantity, 
                refills, 
                days_supply, 
                daw_ind, 
                sig_codes, 
                sig_description, 
                medication_dictionary, 
                cpoe_ind, 
                orig_site_id, 
                medication_name, 
                medication_generic_name, 
                order_ind, 
                formulary_check_ind, 
                location_unscrubbed, 
                tprescriptionid, 
                rxnorm, 
                orig_enc_id, 
                orig_provider_id, 
                orig_patient_id, 
                end_date 
FROM   t_prescription 
       JOIN site_master 
         ON t_prescription.orig_site_id = site_master.site_orig_site_id 
WHERE  delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic'
"""

PROBLEM_QUERY = """
SELECT DISTINCT  original_id, 
                problem_status, 
                problem_severity, 
                problem_description, 
                problem_notes, 
                icd9_code, 
                onset_date, 
                resolved_date, 
                orig_site_id, 
                tproblemid, 
                icd10_code, 
                enc_orig_patient_id, 
                enc_orig_rendering_provider_id 
FROM   t_problem 
       JOIN site_master 
         ON t_problem.orig_site_id = site_master.site_orig_site_id 
       JOIN t_encounter 
         ON t_problem.originating_encounter_id = t_encounter.enc_id 
WHERE  delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic' 
"""

RESULT_QUERY = """
SELECT DISTINCT  original_id, 
                original_parent_result_id, 
                original_name, 
                lab_facility_name, 
                lab_type, 
                collection_date, 
                received_date, 
                sign_off_date, 
                result_type, 
                result_value, 
                result_units, 
                result_value_numeric, 
                result_min, 
                result_max, 
                result_out_of_range, 
                result_status, 
                result_notes, 
                orig_site_id, 
                provider_id_unscrubbed, 
                sign_off_provider_id_unscrubbed, 
                result_from_interface_ind, 
                tresultid, 
                location_unscrubbed, 
                loinc_code, 
                orig_patient_id, 
                orig_encounter_id, 
                orig_order_id 
FROM   t_result 
       JOIN site_master 
         ON t_result.orig_site_id = site_master.site_orig_site_id 
WHERE  delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic' 
"""

RESULT_QUERY = """
SELECT DISTINCT original_id, original_parent_result_id, original_name, lab_facility_name, lab_type, collection_date, received_date, sign_off_date, result_type, result_value, result_units, result_value_numeric, result_min, result_max, result_out_of_range, result_status, result_notes, orig_site_id, provider_id_unscrubbed, sign_off_provider_id_unscrubbed, result_from_interface_ind, tresultid, location_unscrubbed, loinc_code, orig_patient_id, orig_encounter_id, orig_order_id FROM t_result JOIN site_master ON t_result.orig_site_id = site_master.site_orig_site_id WHERE delete_ind = 'N' AND site_emr_name = 'Mdland iClinic'"""

VITALS_QUERY = """
SELECT DISTINCT  vitals_original_id, 
                vitals_height, 
                vitals_height_unit, 
                vitals_weight, 
                vitals_weight_unit, 
                vitals_bmi, 
                vitals_systolic, 
                vitals_diastolic, 
                vitals_date, 
                vitals_taken_by, 
                vitals_orig_site_id, 
                vitals_temperature, 
                vitals_temperature_units, 
                vitals_heart_rate, 
                vitals_spo2, 
                vitals_bp_position, 
                vitals_bmi_percentile, 
                tvitalsid, 
                enc_orig_patient_id, 
                enc_orig_rendering_provider_id 
FROM   t_vitals 
       JOIN site_master 
         ON t_vitals.vitals_orig_site_id = site_master.site_orig_site_id 
       JOIN t_encounter 
         ON t_vitals.vitals_enc_id = t_encounter.enc_id 
WHERE  vitals_delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic' 
"""

VITALS_QUERY = """
SELECT DISTINCT vitals_original_id, vitals_height, vitals_height_unit, vitals_weight, vitals_weight_unit, vitals_bmi, vitals_systolic, vitals_diastolic, vitals_date, vitals_taken_by, vitals_orig_site_id, vitals_temperature, vitals_temperature_units, vitals_heart_rate, vitals_spo2, vitals_bp_position, vitals_bmi_percentile, tvitalsid, enc_orig_patient_id, enc_orig_rendering_provider_id, enc_orig_patient_id, enc_orig_rendering_provider_id FROM t_vitals JOIN site_master ON t_vitals.vitals_orig_site_id = site_master.site_orig_site_id JOIN t_encounter ON t_vitals.vitals_enc_id = t_encounter.enc_id WHERE vitals_delete_ind = 'N' AND site_emr_name = 'Mdland iClinic'"""

PATIENTS_QUERY = """
SELECT DISTINCT pat_original_id, 
                pat_first_name, 
                pat_last_name, 
                pat_middle_name, 
                pat_race, 
                pat_ethnicity, 
                pat_occupation, 
                pat_status, 
                pat_language, 
                pat_city, 
                pat_county, 
                pat_state, 
                pat_zip, 
                pat_phone_1, 
                pat_phone_2, 
                pat_date_of_birth, 
                pat_sex, 
                pat_ssn, 
                pat_email_address, 
                pat_orig_site_id, 
                pat_expired_ind, 
                pat_medical_record_number, 
                pat_address_1, 
                pat_address_2, 
                pat_orig_guarantor_id, 
                pat_provider_id_unscrubbed, 
                pat_advance_directive_ind, 
                pat_opt_in_ind, 
                tpatientid, 
                pat_mail_address1, 
                pat_mail_address2, 
                pat_mail_city, 
                pat_mail_state, 
                pat_mail_zip 
FROM   t_patient 
       JOIN site_master 
         ON t_patient.pat_orig_site_id = site_master.site_orig_site_id 
WHERE  pat_delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic' 
"""

PATIENTS_QUERY = """
SELECT DISTINCT pat_original_id, pat_first_name, pat_last_name, pat_middle_name, pat_race, pat_ethnicity, pat_occupation, pat_status, pat_language, pat_city, pat_county, pat_state, pat_zip, pat_phone_1, pat_phone_2, pat_date_of_birth, pat_sex, pat_ssn, pat_email_address, pat_orig_site_id, pat_expired_ind, pat_medical_record_number, pat_address_1, pat_address_2, pat_orig_guarantor_id, pat_provider_id_unscrubbed, pat_advance_directive_ind, pat_opt_in_ind, tpatientid, pat_mail_address1, pat_mail_address2, pat_mail_city, pat_mail_state, pat_mail_zip FROM t_patient JOIN site_master ON t_patient.pat_orig_site_id = site_master.site_orig_site_id WHERE pat_delete_ind = 'N' AND site_emr_name = 'Mdland iClinic'"""

SITE_MASTER_QUERY = """
SELECT DISTINCT site_center_name, 
                site_emr_name, 
                site_emr_version, 
                site_orig_site_id, 
                med_ind_calc, 
                site_display_name 
FROM   site_master 
WHERE  site_emr_name = 'Mdland iClinic' and site_delete_ind = 'N'
"""

PROVIDER_MASTER_QUERY = """
SELECT DISTINCT prov_original_id, 
                prov_first_name, 
                prov_last_name, 
                prov_middle_name, 
                prov_fullname, 
                prov_specialty_1, 
                prov_npi, 
                prov_address_1, 
                prov_address_2, 
                prov_city, 
                prov_state, 
                prov_zip, 
                prov_orig_site_id, 
                prov_type, 
                prov_active, 
                prov_usual_location_unscrubbed 
FROM   provider_master 
       JOIN site_master 
         ON provider_master.prov_orig_site_id = site_master.site_orig_site_id 
WHERE  prov_delete_ind = 'N' 
       AND site_emr_name = 'Mdland iClinic' 
"""

arcadia_bash_cmd_template = "sqlcmd -D -S arcadia_replica -U ACPPS_ClientAccess -P 490qXXAAt6zsSvFL -d ACPPS_WAREHOUSE_PRD01 -Q \"{}\" -o {}  -W -w 999 -s'|'"


def get_mdland_table(full,
                     dtd,
                     query,
                     name,
                     updated_timestamp='updated_timestamp'):
    if full == 'F':
        final_query = 'set nocount on; ' + query
        arcadia_bash_cmd = arcadia_bash_cmd_template.format(
            final_query,
            "/home/etl/etl_home/downloads/garage_mdland/garage_mdland_FULL_{}.txt"
            .format(name))
        subprocess.check_output(arcadia_bash_cmd, shell=True)
    elif full == 'D':
        final_query = query + ' and cast({} as date) = \'{}\';'.format(
            updated_timestamp, dtd)
        pd.read_sql(final_query, CONNECTION_ARCADIA).to_csv(
            "/home/etl/etl_home/downloads/garage_mdland/garage_mdland_DIFF_{}_{}.txt"
            .format(dtd, name),
            sep='|',
            index=False, encoding = 'utf-8')
    return


if __name__ == '__main__':
    FULL = sys.argv[1]
    #DATE_TO_DIFF = sys.argv[2]
    DATE_TO_DIFF = ''
    get_mdland_table(FULL, DATE_TO_DIFF, ALLERGY_QUERY, 'allergy',
                     'allergy_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, APPOINTMENT_QUERY, 'appointment',
                     'appt_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, ASSESSMENT_QUERY, 'assessment')
    get_mdland_table(FULL, DATE_TO_DIFF, CHARGECAPTURE_QUERY, 'chargecapture',
                     'cc_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, ENCOUNTER_QUERY, 'encounter',
                     'enc_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, IMMUNIZATION_QUERY, 'immunization')
    get_mdland_table(FULL, DATE_TO_DIFF, MAINTENANCE_QUERY, 'maintenance',
                     'maint_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, MEDICATIONLIST_QUERY,
                     'medicationlist')
    get_mdland_table(FULL, DATE_TO_DIFF, ORDER_QUERY, 'order')
    get_mdland_table(FULL, DATE_TO_DIFF, PAYER_QUERY, 'payer')
    get_mdland_table(FULL, DATE_TO_DIFF, PRESCRIPTION_QUERY, 'prescription')
    get_mdland_table(FULL, DATE_TO_DIFF, RESULT_QUERY, 'result')
    get_mdland_table(FULL, DATE_TO_DIFF, VITALS_QUERY, 'vitals',
                     'vitals_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, PATIENTS_QUERY, 'patients',
                     'pat_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, SITE_MASTER_QUERY, 'site_master',
                     'site_updated_timestamp')
    get_mdland_table(FULL, DATE_TO_DIFF, PROVIDER_MASTER_QUERY,
                     'provider_master', 'prov_updated_timestamp')
