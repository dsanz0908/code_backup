from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce

def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)


PATIENT_QUERY = """
SELECT DISTINCT to_char( dob, 'YYYY-MM-DD') AS birthdate,
                cin_plan_id,
                '005f4000000nXJTAA2'                              AS contact_assigned_chw__c,
                member_first_name,
                member_last_name,
                mco,
                gender,
                member_address_1,
                member_city,
                member_zip,
                member_phone,
                'NY'                                              AS state,
                provider_contact_id,
                '012f4000000MBgDAAW'                              AS recordtypeid,
                PCP_NPI
FROM   sf_hhc_measures 
inner join ( select  min(id) as  provider_contact_id,individual_npi__c from salesforce_providers group by individual_npi__c ) sp
on pcp_npi = individual_npi__c
WHERE NOT EXISTS (SELECT 1
                       FROM   salesforce_patients
                       WHERE  cin_plan_id = cin__c) 
and cin_plan_id != '131838651'
"""

sf, INSTANCE_URL = getSession()
CONNECTION = pyodbc.connect(dsn="somos_redshift_1")
PATIENTS = CONNECTION.execute(PATIENT_QUERY).fetchall()
for patient in PATIENTS:
    print patient
    sf.Contact.create({
        'birthdate': patient[0],
        'cin__c': patient[1],
        'contact_assigned_chw__c': patient[2],
        'firstname': patient[3],
        'lastname': patient[4],
        'health_plan_carriers__c': patient[5],
        'gender__c': patient[6],
        'mailingstreet': patient[7],
        'mailingcity': patient[8],
        'mailingpostalcode': patient[9],
        'phone': patient[10],
        'mailingstate': patient[11],
        'pcp__c': patient[12],
        'recordtypeid': patient[13]
    })
CONNECTION.close()
