import pyodbc
import pandas as pd
from fuzzywuzzy import fuzz

q = """
WITH a 
     AS (SELECT DISTINCT member_number 
         FROM   payor.healthfirst_all_claims 
         UNION 
         SELECT DISTINCT member_number 
         FROM   payor.healthfirst_somos_all_claims) 
SELECT NAME, 
               member_dob, 
               member_id 
FROM   (SELECT Lower(member_name)                AS NAME, 
               member_dob, 
               member_id, 
               Row_number() 
                 OVER ( 
                   partition BY member_id 
                   ORDER BY received_month DESC) AS rn 
        FROM   payor.healthfirst_all_eligibility 
        WHERE  effective_period = (select max(effective_period) from payor.healthfirst_all_eligibility)
               AND NOT EXISTS (SELECT 1 
                               FROM   a 
                               WHERE  member_id = member_number)) 
WHERE  rn = 1 
union
SELECT NAME, 
               member_dob, 
               member_id 
FROM   (SELECT Lower(member_name)                AS NAME, 
               member_dob, 
               member_id, 
               Row_number() 
                 OVER ( 
                   partition BY member_id 
                   ORDER BY received_month DESC) AS rn 
        FROM   payor.healthfirst_somos_all_eligibility 
        WHERE  effective_period = (select max(effective_period) from payor.healthfirst_somos_all_eligibility)
               AND NOT EXISTS (SELECT 1 
                               FROM   a 
                               WHERE  member_id = member_number)) 
WHERE  rn = 1 
"""

conn = pyodbc.connect(dsn="somos_redshift_1")
a = pd.read_sql(q, conn)
a['member_dob'] = pd.to_datetime(a['member_dob'], errors='coerce')
a['dob'] = a['member_dob'].dt.date.astype(str)

print a
arcadia_members = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_members_with_encounters.txt',
    sep='|',
    error_bad_lines=False,
    names=['pat_id', 'fname', 'lname', 'dob', 'dos'])

#arcadia_members = arcadia_members[arcadia_members['dos'] >= '2018-01-01']


merged_df = pd.merge(arcadia_members, a, on='dob')
values = merged_df.values.tolist()
found = set()
for i in values:
    score = fuzz.WRatio('{} {}'.format(i[1], i[2]), i[5])
    if score > 90:
        found.add(i[7])
b = list(found)
pd.DataFrame(b).to_csv('abc.csv')
