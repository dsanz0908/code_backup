import pyodbc
import pandas as pd
from fuzzywuzzy import fuzz

q = """
select name, member_dob, member_id from (SELECT Lower(member_name) as name,
                member_dob,
                member_id, row_number() over (partition by member_id order by received_month desc) as rn
FROM   payor.healthfirst_all_eligibility
WHERE  date_part(year, effective_period) = 2019) where rn = 1
/*
UNION
SELECT DISTINCT Lower(member_name),
                member_dob,
                member_id
FROM   payor.healthfirst_somos_all_eligibility
WHERE  date_part(year, effective_period) = 2019
*/
"""

conn = pyodbc.connect(dsn="somos_redshift_1")
a = pd.read_sql(q, conn)
a['member_dob'] = pd.to_datetime(a['member_dob'], errors='coerce')
a['dob'] = a['member_dob'].dt.date.astype(str)

arcadia_members = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_members_with_encounters.txt',
    sep='|',
    error_bad_lines=False,
    names=['pat_id', 'fname', 'lname', 'dob', 'dos'])

arcadia_members = arcadia_members[arcadia_members['dos'] >= '2019-01-01']


merged_df = pd.merge(arcadia_members, a, on='dob')
values = merged_df.values.tolist()
for i in values[:1000]:
    score = fuzz.WRatio('{} {}'.format(i[1], i[2]), i[5])
    if score > 90:
        print i
