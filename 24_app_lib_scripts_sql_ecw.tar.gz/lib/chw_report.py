import datetime
import pytz
import sys
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
from fuzzywuzzy import fuzz

final_res = []


def main():
    conn = pyodbc.connect(dsn="somos_redshift_1")
    results = get_db_details(conn)
    processResults(results)

def get_db_details(conn):
    query = open('/home/etl/etl_home/sql/chw_report_pull.sql', 'r').read()
    cur=conn.execute(query)
    res=cur.fetchall()
    cur.close()
    return res

def processResults(dbdetails):
    if len(dbdetails) == 0:
        return None
    f = open("/home/etl/etl_home/Reports/chw.html", "w")
    h = HTML()
    tbl = h.table(style='font-family:Calibri;font-size:80%;width:150%;display:block;overflow:auto;-webkit-print-color-adjust:exact;')
    r = tbl.tr(style="background-color:#e3e0cc;font-size:80%;text-align: center;")
    r.td("Name")
    r.td("Closed")
    r.td("Completed")
    r.td("Completed - Awaiting Claim Submission")
    r.td("Completed - Awaiting Coding Correction")
    r.td("Exclusion - Does not meet criteria - Verified by Management")
    r.td(
        "Exclusion - Moved out of coverage area/Switched to commercial Insurance"
    )
    r.td("Exclusion - Patient deceased")
    r.td("Exclusion - Patient switched to OON PCP")
    r.td("Issue - Eligibility - Needs review")
    r.td("Issue - Ineligible for measure - Needs Review")
    r.td("Issue - Patient refused")
    r.td("Issue - PCP refused to collaborate")
    r.td("Issue - Phone wrong/disconnected/out of service")
    r.td("Issue - Unable to reach (3) attempts - Needs Management Review")
    r.td("Open")
    r.td("Outreach - Unable to reach")
    r.td("Pending - Appointment Scheduled")
    r.td("Pending - Patient will call")
    r.td("Pending - Practice will schedule")
    r.td("Pending")
    r.td("Rx - Pending")
    r.td("Grand Total")
    rnum = 0
    for row in dbdetails:
        rnum = rnum + 1
        rowStyle = "background-color:#f0f0f0"
        r = tbl.tr(style=rowStyle)
        for i, abc in enumerate(row):
            if i == 0 or i == 22:
                r.td(str(abc), style='width:300;text-align:center;')
            elif i == 15:
                if row[i] < row[i+23]:
                    r.td(str(abc)+'%', style='width:300;text-align:center;background-color:#228B22;')
                elif row[i] > row[i+23]:
                    r.td(str(abc)+'%', style='width:300;text-align:center;background-color:#B22222;')
                else:
                    r.td(str(abc)+'%', style='width:300;text-align:center;')
            elif i < 22:
                if row[i] > row[i+23]:
                    r.td(str(abc)+'%', style='width:300;text-align:center;background-color:#228B22;')
                elif row[i] < row[i+23]:
                    r.td(str(abc)+'%', style='width:300;text-align:center;background-color:#B22222;')
                else:
                    r.td(str(abc)+'%', style='width:300;text-align:center;')
    header = '''<head><link href="check.css" rel="stylesheet"></head><body>	<h3>CHW Report</h3>
        <div class="content">
	<div class="sidebar">
	  <ul>
	    <li><a href="ecw_status.html">ECW Status</a></li>
	    <li><a href="engagement.html">Engagement Files Status</a></li>
	    <li><a href="inventory.html">Redshift Inventory Status</a></li>
	    <li><a href="chw.html">CHW Report</a></li>
	  </ul>
	  
	  <div class="logo">
	    <img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
	  </div>
	</div>'''
    footer = '''<br><center><p style="font-family:'Calibri';font-size:125%">Total: ''' + str(
        rnum
    ) + '''<br><p style="font-family:'Calibri';font-size:125%">Time of latest report: ''' + datetime.datetime.now(
    ).strftime("%Y-%m-%d %H:%M:%S") + '''</p></center><br><br>'''
    f.write(header + str(tbl) + footer)
    f.close()
    return tbl


if __name__ == '__main__':
    main()
