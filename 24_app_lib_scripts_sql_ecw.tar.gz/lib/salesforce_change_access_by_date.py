from datetime import datetime
import requests
import pandas as pd
import pyodbc
import os
from simple_salesforce import Salesforce

def getSession():
    consumer_key = "3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
    consumer_sec = "2390566482488021811"
    params = {
        'grant_type': "password",
        'client_id': consumer_key,
        'client_secret': consumer_sec,
        'username': os.environ['SALESFORCE_USERNAME'],
        'password': os.environ['SALESFORCE_PASSWORD']
    }
    access_token_url = 'https://login.salesforce.com/services/oauth2/token'
    r = requests.post(access_token_url, params=params)
    access_token = r.json().get("access_token")
    instance_url = r.json().get("instance_url")
    response = r.json()
    sf = Salesforce(
        instance_url=response['instance_url'],
        session_id=response['access_token'])
    return (sf, instance_url)



CONNECTION = pyodbc.connect(dsn="somos_redshift_1")

QUERY1 = """
drop table if exists shariff_pilot_20191113;
create temp table shariff_pilot_20191113 (
Member_ID varchar(255),
Member_First_Name varchar(255),
Member_Last_Name varchar(255),
Member_DOB varchar(255),
Salesforce_Measure varchar(255),
Status varchar(255),
Comments varchar(255),
Date_of_Service date,
Claim_submission_date date,
Date_worked_on varchar(255));


copy shariff_pilot_20191113
from 's3://sftp_test/shariff_pilot_gaps_11132019.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
ignoreheader 1
removequotes
ACCEPTINVCHARS 
region 'us-east-1'
dateformat 'auto'
delimiter  ',';
"""

QUERY2 = """
SELECT DISTINCT salesforce_tasks.id, 
                CASE 
                  WHEN Datediff(month, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 0 AND 24 THEN
                  'Children''s Access to Primary Care - 12 to 24 months' 
                  WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 2 AND 6 THEN
                  'Children''s Access to Primary Care - 25 months to 6 years' 
                  WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 7 AND 11 THEN
                  'Children''s Access to Primary Care - 7 to 11 years' 
                  WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 12 AND 19 THEN
                  'Adolescent Access to Primary Care - 12 to 19 years' 
                  WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 20 AND 44 THEN
                  'Adult Access to Preventive or Ambulatory Care - 20 to 44 years' 
                  WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 45 AND 64 THEN
                  'Adult Access to Preventive or Ambulatory Care - 45 to 64 years' 
                  WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) > 64 THEN 
                  'Adult Access to Preventive or Ambulatory Care - 65 and older' 
                END AS measure, 
                shariff_pilot_20191113.status, 
                comments, 
                to_char(date_of_service, 'YYYY-MM-DD'),
                to_char(claim_submission_date, 'YYYY-MM-DD'),
                date_worked_on 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY salesforce_tasks.id 
                   ORDER BY added_tz DESC) AS rn 
        FROM   salesforce_tasks) AS salesforce_tasks 
       INNER JOIN salesforce_patients 
               ON contact_id_18_characters__c = whoid 
       JOIN shariff_pilot_20191113 
         ON member_id = cin__c 
WHERE  salesforce_measure ILIKE '%access%' 
       AND measure__c ILIKE '%access%' 
       AND rn = 1 
       AND salesforce_tasks.project_end_date__c LIKE '2019-12-31%' 
       AND measure__c <> CASE 
                           WHEN Datediff(month, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 0 AND 24 THEN
                           'Children''s Access to Primary Care - 12 to 24 months' 
                           WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 2 AND 6 THEN
                           'Children''s Access to Primary Care - 25 months to 6 years' 
                           WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 7 AND 11 THEN
                           'Children''s Access to Primary Care - 7 to 11 years' 
                           WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 12 AND 19 THEN
                           'Adolescent Access to Primary Care - 12 to 19 years' 
                           WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 20 AND 44 THEN
                           'Adult Access to Preventive or Ambulatory Care - 20 to 44 years' 
                           WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) BETWEEN 45 AND 64 THEN
                           'Adult Access to Preventive or Ambulatory Care - 45 to 64 years' 
                           WHEN Datediff(year, To_date(member_dob, 'MM/DD/YYYY'), Getdate()) > 64 THEN
                           'Adult Access to Preventive or Ambulatory Care - 65 and older' 
                         END 
"""

CONNECTION.execute(QUERY1)
rows = CONNECTION.execute(QUERY2).fetchall()
TODAY = datetime.now().strftime("%Y%m%d")
sf, INSTANCE_URL = getSession()
for row in rows:
    try:
	sf.Task.update(
	    row[0], {
		'measure__c':
		row[1],
                'status':row[2],
		'Care_Gap_Comments__c':row[3],
                'date_of_service__c':row[4],
                'claim_submitted__c':row[5],
		'Care_Gap_Comments_Part_2__c':'{} automated change - access care'.format(TODAY),
	    })
    except Exception as e:
	print(row, str(e))
