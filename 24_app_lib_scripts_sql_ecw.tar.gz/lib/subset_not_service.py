import pyodbc
import pandas as pd
conn_arcadia=pyodbc.connect("dsn=arcadia_replica;Database=acpps_warehouse_prd01;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL")
import datetime

subsetnots_sql="""

CREATE TABLE #TEMP_SUBSET_NOTS (
CIN					VARCHAR(20),
PAT_FIRST_NAME		VARCHAR(100),
PAT_LAST_NAME		VARCHAR(100),
PAT_DATE_OF_BIRTH	DATETIME,
PHONE_NO			VARCHAR(20),
PAT_ADDR_1			VARCHAR(100),
PAT_ADDR_2			VARCHAR(100),
PAT_CITY			VARCHAR(50),
PAT_STATE			VARCHAR(20),
PAT_ZIP				VARCHAR(20),
PROV_FIRST_NAME		VARCHAR(100),
PROV_LAST_NAME		VARCHAR(100),
PROV_NPI			VARCHAR(20),
MEASURE				VARCHAR(100));

with cte_plan_member as ( select member_id,MAX(medicaid_id) as individual_no from plan_member
where source_id in ( 1000,1002,1003,1004)
and member_id in ( select member_id from plan_member_elig where delete_ind = 'N' and source_id in ( 1000,1002,1003,1004) and end_date > = '20190101' group by member_id )
and medicaid_id is not null
group by member_id ) ,

cte_mx_person_member as (select person_id,individual_no,MAX(entry_timestamp) as max_entrytime 
								from mpi.person_member r1
								inner join cte_plan_member r2 
								on r1.member_id = r2.member_id 
								group by person_id,individual_no ) ,

cte_person_pat as ( select MAX(pat_id) as pat_id,individual_no 
				from mpi.person_patient rr1 
				inner join cte_mx_person_member rr2
				on rr1.person_id = rr2.person_id
				group by rr1.person_id ,individual_no),

cte_mx_patient as ( select pat_first_name,pat_last_name,pat_date_of_birth,MAX(pat_entry_timestamp) mx_entrytime,MAX(pat_updated_timestamp) as mx_update_time 
					from t_patient t1
					inner join Provider_Master t2
					on t1.pat_responsible_provider_id = t2.prov_id
					inner join Site_Master t3
					on t2.prov_orig_site_id = t3.site_orig_site_id
					where t1.pat_delete_ind = 'N'
					and   t1.pat_expired_ind = 'N'
					and   t1.pat_status != 'inActive'
					and   t2.prov_delete_ind = 'N'
					group by pat_first_name,pat_last_name,pat_date_of_birth ) 

 select tp.pat_id,max(pat_first_name) as pat_first_name,max(pat_last_name) as pat_last_name,max(pat_date_of_birth) as pat_date_of_birth,
				max(pat_phone_1) as pat_phone_1,max(pat_address_1) as pat_address_1,max(pat_address_2) as pat_address_2,max(pat_city) as pat_city,max(pat_state) as pat_state,
				max(pat_zip) as pat_zip,max(pat_responsible_provider_id) pat_responsible_provider_id,MAX(individual_no) as individual_no 
				into #temp_patient_member
				from t_patient tp 
				inner join cte_person_pat cte
				on tp.pat_id = cte.pat_id
				where exists ( select 1 from cte_mx_patient ctp 
									where ctp.pat_first_name = tp.pat_first_name
									and   ctp.pat_last_name = tp.pat_last_name 
									and   ctp.mx_entrytime = tp.pat_entry_timestamp 
									and   pat_updated_timestamp = mx_update_time) 

				group by tp.pat_id;
   
    
--Child Access - Primary Care (12 to 24 Months)
with cte_pat  as ( select pat_id from t_patient where datediff(mm,pat_date_of_birth,GETDATE()) between 12 and 24 and pat_delete_ind = 'N' and pat_expired_ind = 'N' and   pat_status != 'inActive'
					and pat_id in ( select distinct pat_id from #temp_patient_member ) ),

cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 2 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (12 to 24 Months)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 2,3 desc;


-- Child Access - Primary Care (25 Months to 6)

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(mm,pat_date_of_birth,GETDATE()) > 24 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 5 and pat_delete_ind = 'N' and pat_expired_ind = 'N' 
					and   pat_status != 'inActive'
					and pat_id in ( select distinct pat_id from #temp_patient_member )  ),

cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 3 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (25 Months to 6)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;

-- Child Access - Primary Care (7 to 11)
with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 6 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 11 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
					and   pat_status != 'inActive' 
					and pat_id in ( select distinct pat_id from #temp_patient_member )  ),

cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 3 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS

select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (7 to 11)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;	
-- Child Access - Primary Care (12 to 19)

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 11 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 19 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
		and   pat_status != 'inActive'
		and pat_id in ( select distinct pat_id from #temp_patient_member )  ),
cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 3 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child Access - Primary Care (12 to 19)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;	

-- Well Care Visits - 5+ visits In first 15 months

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(mm,pat_date_of_birth,GETDATE()) <= 15 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
					and   pat_status != 'inActive'
					and pat_id in ( select distinct pat_id from #temp_patient_member ) 
					),
cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 2 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Well Care Visits - 5+ visits In first 15 months'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;	

--Adult Access Preventive (20 - 44)
with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 19 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 44 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
			and   pat_status != 'inActive' AND pat_id IN ( select pat_id from #temp_patient_member )
		 ),
cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 3 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Adult Access Preventive (20 - 44)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;

--Adult Access Preventive (45 - 64)

with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) > 44 and DATEDIFF(yy,pat_date_of_birth,getdate()) <= 64 and pat_delete_ind = 'N' and pat_expired_ind = 'N'
					and   pat_status != 'inActive' AND pat_id IN ( select pat_id from #temp_patient_member )
				),
cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 3 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Adult Access Preventive (45 - 64)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;

--Adult Access Preventive (65 and Older)
with cte_pat  as ( select pat_id,pat_date_of_birth from t_patient where datediff(yy,pat_date_of_birth,GETDATE()) >= 65 and pat_delete_ind = 'N' and pat_expired_ind = 'N' 
					and   pat_status != 'inActive' AND pat_id IN ( select pat_id from #temp_patient_member )),
cte_denominator as ( select distinct enc_patient_id from t_encounter where DATEDIFF(yy,enc_timestamp,getdate()) <= 3 and enc_patient_id 	in ( select pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from cte_pat ) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Adult Access Preventive (65 and Older)'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;

-- Control Blood Pressure 
with cte_assesment as (
select distinct patient_id from t_assessment where icd10_code in (
  'I13.10','I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40','I50.41','I50.42','I50.43','I50.9','I50.1','I50.20','I50.21','I50.22', 
 'I50.23','I50.30','I50.31','I50.32','I50.33','I50.40','I50.41','I50.42','I50.43','I50.9','E78.4','E78.5','I09.2','I05.0','I06.0','I08.0','I07.0','I07.1','I07.2','I07.8','I07.9','I09.0',
 'I21.09','I25.2','I20.8','I25.10','I20.9','I21.09','I21.3','I25.10','I25.2','I25.84','I25.9','I10','I11.0','I11.9','I25.10','I48.91','I50.9','I63.9','I65.23','I65.29','I67.2','I67.9','I73.9') 
 and assessment_date between '20190101' and GETDATE()
 AND patient_id IN ( select pat_id from #temp_patient_member )),

cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()),

cte_denominator as ( select cta.patient_id 	
						from cte_assesment cta 
						inner join cte_chargecapture ctc
						on cta.patient_id = ctc.cc_patient_id ) ,


cte_numerator as ( select distinct vitals_patient_id --,vitals_systolic,vitals_diastolic,vitals_date 
	from t_vitals
	where vitals_date between '20190101' and GETDATE()
	and   vitals_patient_id in ( select patient_id from cte_denominator )
	and vitals_systolic <= 140
	and vitals_diastolic <= 90 )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Control Blood Pressure'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.vitals_patient_id )
	order by 1 desc;

--Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia

with cte_assessment_1  as ( select distinct patient_id from t_assessment  
	where icd10_code in ('I13.10','I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40',
	'I50.41','I50.42','I50.43','I50.9','I50.1','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33',
	'I50.40','I50.41','I50.42','I50.43','I50.9',' E78.4',' E78.5','I09.2','I05.0','I06.0','I08.0','I07.0','I07.1','I07.2',
	'I07.8','I07.9','I09.0','I21.09','I25.2','I20.8','I25.10','I20.9','I21.09','I21.3','I25.10','I25.2','I25.84','I25.9',
	'I10','I11.0','I11.9','I25.10','I48.91','I50.9','I63.9','I65.23','I65.29','I67.2','I67.9','I73.9')
	AND assessment_date	>= DATEADD(yy,-3,getdate()) ) ,
cte_assessment_2 as ( select distinct patient_id from t_assessment where icd10_code in ( 'F20.0','F20.1','F20.2','F20.3','F20.4','F20.5','F20.81', 'F20.89', 'F20.9', 'F25.0', 'F25.1', 'F25.8', 'F25.9' )
	and assessment_date >= DATEADD(yy,-3,getdate())),

cte_denominator as ( 
						select distinct cta1.patient_id 
						from cte_assessment_1 cta1
						inner join cte_assessment_2 cta2
						on cta1.patient_id = cta2.patient_id
						) ,

 cte_numerator as ( select distinct pat_id from t_result where lab_type in ('LDL','LIPID PANEL')
	AND pat_id IN ( SELECT patient_id from cte_denominator )
	AND collection_date  between '20190101' and GETDATE() )
 
 INSERT #TEMP_SUBSET_NOTS
 select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Cardiovascular Monitoring for People with Cardiovascular Disease and Schizophrenia'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.pat_id )
	order by 1 desc;

--Lipid Management for patients with Cardiovascular disease
with cte_denominator as (
select distinct patient_id from t_assessment where icd10_code in (
	'I13.10','I12.9','I11.9','I10','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40','I50.41','I50.42','I50.43','I50.9','I50.1','I50.20',
	'I50.21', 'I50.22', 'I50.23','I50.30','I50.31','I50.32', 'I50.33', 'I50.40','I50.41','I50.42','I50.43','I50.9', 'E78.4','E78.5','I09.2','I05.0', 'I06.0', 'I08.0', 
	'I07.0','I07.1', 'I07.2', 'I07.8', 'I07.9', 'I09.0', 'I21.09', 'I25.2', 'I20.8', 'I25.10', 'I20.9', 'I21.09', 'I21.3', 'I25.10', 'I25.2', 'I25.84', 'I25.9', 'I10', 
	'I11.0', 'I11.9', 'I25.10', 'I48.91', 'I50.9', 'I63.9', 'I65.23', 'I65.29', 'I67.2', 'I67.9', 'I73.9' )
 and assessment_date between '20190101' and GETDATE()
 AND patient_id IN ( select pat_id from #temp_patient_member )),

 cte_numerator as ( select distinct pat_id from t_result where lab_type in ('LDL','LIPID PANEL')
	AND pat_id IN ( SELECT patient_id from cte_denominator )
	AND collection_date  between '20190101' and GETDATE()  )
 
 INSERT #TEMP_SUBSET_NOTS
 select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Lipid Management for patients with Cardiovascular disease'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.pat_id )
	order by 1 desc;


--Diabetes - Nephropathy screening
with cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()
	AND cc_patient_id IN ( select pat_id from #temp_patient_member )) ,
 cte_ass as (
select distinct patient_id from t_assessment where icd10_code in (
	'E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01',
	'E08.11','E08.641','E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22',
	'E13.29','E08.311','E08.319','E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311',
	'E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321',
	'E13.329','E13.331','E13.339','E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49',
	'E08.610','E09.40','E09.41','E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51',
	'E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638',
	'E08.649','E08.69','E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622',
	'E13.628','E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349','E11.351',
	'E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36','E10.39','E11.40',
	'E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51',
	'E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620','E10.621','E10.622','E10.628',
	'E10.630','E10.638','E10.649','E11.8','E10.8' 	 )
 and assessment_date between '20190101' and GETDATE()
 AND patient_id IN ( select pat_id from #temp_patient_member )) ,

 cte_denominator as ( select  patient_id from cte_ass cta inner join cte_chargecapture ctc on ctc.cc_patient_id = cta.patient_id ),
 cte_numerator as ( 
 select distinct pat_id from t_order 
					where  order_name LIKE '%nephro%'
					AND pat_id IN ( SELECT patient_id from cte_denominator )
					AND ordered_date  between '20190101' and GETDATE() )
 
 INSERT #TEMP_SUBSET_NOTS
 select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Diabetes - Nephropathy screening'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.pat_id )
	order by 1 desc;

-- Hemoglobin A1C

with cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()
	AND cc_patient_id IN ( select pat_id from #temp_patient_member )) ,
 cte_ass as (
select distinct patient_id from t_assessment where icd10_code in (
	'E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01',
	'E08.11','E08.641','E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22',
	'E13.29','E08.311','E08.319','E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311',
	'E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321',
	'E13.329','E13.331','E13.339','E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49',
	'E08.610','E09.40','E09.41','E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51',
	'E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638',
	'E08.649','E08.69','E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622',
	'E13.628','E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349','E11.351',
	'E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36','E10.39','E11.40',
	'E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51',
	'E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620','E10.621','E10.622','E10.628',
	'E10.630','E10.638','E10.649','E11.8','E10.8' 	 )
 and assessment_date between '20190101' and GETDATE()
 AND patient_id IN ( select pat_id from #temp_patient_member )) ,

 cte_denominator as ( select  patient_id from cte_ass cta inner join cte_chargecapture ctc on ctc.cc_patient_id = cta.patient_id ),
 cte_numerator as ( 
 select distinct pat_id from t_result
					where  lab_type = 'A1C'
					AND pat_id IN ( SELECT patient_id from cte_denominator )
					AND collection_date  between '20190101' and GETDATE() )
 
 INSERT #TEMP_SUBSET_NOTS
 select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Hemoglobin A1C'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.pat_id )
	order by 1 desc;


-- Lipid Management for patients with Diabetes

with cte_chargecapture as ( select distinct cc_patient_id from t_chargecapture where cc_cpt_code in (
	'90791','90792','90832','90833','90834','90835','90836','90837','90838','90839','90840','90845','90846','90847', '90849','90853', '90875', '90876','98966','98967','98968',
	'99221','99222','99223', '99231','99232','99233', '99238','99239','99251','99252','99253','99254','99255','99381','99382','99383','99384','99385','99386','99387',
	'99391','99392','99393','99394','99395','99396','99397','99441','99442','99443','G0438','G0439' ) 
	and cc_date_of_service between '20190101' and GETDATE()
	AND cc_patient_id IN ( select pat_id from #temp_patient_member )) ,
 cte_ass as (
select distinct patient_id from t_assessment where icd10_code in (
	'E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01',
	'E08.11','E08.641','E09.11','E09.641','E13.11','E13.641','E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22',
	'E13.29','E08.311','E08.319','E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359','E08.36','E08.39','E09.311',
	'E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321',
	'E13.329','E13.331','E13.339','E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49',
	'E08.610','E09.40','E09.41','E09.42','E09.43','E09.44','E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51',
	'E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618','E08.620','E08.621','E08.622','E08.628','E08.630','E08.638',
	'E08.649','E08.69','E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618','E13.620','E13.621','E13.622',
	'E13.628','E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01',
	'E10.69','E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349','E11.351',
	'E11.359','E11.36','E11.39','E10.311','E10.319','E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36','E10.39','E11.40',
	'E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42','E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51',
	'E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620','E10.621','E10.622','E10.628',
	'E10.630','E10.638','E10.649','E11.8','E10.8' 	 )
 and assessment_date between '20190101' and GETDATE()
 AND patient_id IN ( select pat_id from #temp_patient_member )) ,

 cte_denominator as ( select  patient_id from cte_ass cta inner join cte_chargecapture ctc on ctc.cc_patient_id = cta.patient_id ),
 cte_numerator as ( 
 select distinct pat_id from t_result
					where   lab_type in ('LDL','LIPID PANEL' )
					AND pat_id IN ( SELECT patient_id from cte_denominator )
					AND collection_date  between '20190101' and GETDATE() )
 
 INSERT #TEMP_SUBSET_NOTS
 select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Lipid Management for patients with Diabetes'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.pat_id )
	order by 1 desc;
    
--BMI Assessment

with cte_denominator as ( select distinct pat_id from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) >= 2  and pat_status != 'Inactive' and pat_delete_ind = 'N'
						 AND pat_id IN ( select pat_id from #temp_patient_member ) )	,

cte_numerator as ( 
select distinct vitals_patient_id as enc_patient_id from t_vitals where vitals_date between '20190101' and GETDATE() and vitals_patient_id in ( select pat_id from cte_denominator ) and vitals_BMI is not null)

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'BMI Assessment'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;

--Chlamydia Screening in women

with cte_denominator as ( select distinct pat_id from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) between 16 and 24 and pat_sex = 'F'  and pat_status != 'Inactive' and pat_delete_ind = 'N' 
							AND pat_id IN ( select pat_id from #temp_patient_member ))	,

cte_numerator as ( 
select distinct pat_id as enc_patient_id from t_result where collection_date between '20190101' and GETDATE() and pat_id in ( select pat_id from cte_denominator ) and lab_type in ('CHLAMYDIA','CHLAMYDIA TEST'))

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Chlamydia Screening in women'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;

--Child ADHD Medications Initiation 

with cte_pat as ( select distinct pat_id from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) between 6 and 12  and pat_status != 'Inactive' and pat_delete_ind = 'N'
					AND pat_id IN ( select pat_id from #temp_patient_member ) )	,

cte_denominator as (select distinct patient_id from t_assessment where icd10_code in ( 'F90.0','F90.1','F90.2','F90.8','F90.9') AND patient_id IN ( SELECT pat_id from cte_pat ) ),

cte_numerator as ( 
select distinct num1.enc_patient_id from t_encounter num1
 inner join 
 (select enc_patient_id,MIN(enc_timestamp) min_enc_timestamp from t_encounter where enc_patient_id in ( select patient_id from cte_denominator ) group by enc_patient_id,YEAR(enc_timestamp) ) num2
 on num1.enc_patient_id = num2.enc_patient_id
 and num1.enc_timestamp > num2.min_enc_timestamp 
 and num1.enc_timestamp <= DATEADD(dd,30,min_enc_timestamp) )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child ADHD Medications Initiation'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.enc_patient_id )
	order by 1 desc;  
    
--Immunizations for Adolescents: Meningococcal
with cte_denominator as ( select distinct pat_id,pat_date_of_birth from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) between 11 and 13  and pat_status != 'Inactive' and pat_delete_ind = 'N' 
							AND pat_id IN ( select pat_id from #temp_patient_member ))	,

cte_numerator as ( select distinct patient_id from t_immunization where  imm_type = 'MCV' and patient_id in ( select pat_id from cte_denominator )  )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Immunizations for Adolescents: Meningococcal'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc;  

--Immunizations for Adolescents: Tdap
with cte_denominator as ( select distinct pat_id,pat_date_of_birth from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) between 10 and 13  and pat_status != 'Inactive' and pat_delete_ind = 'N' 
							AND pat_id IN ( select pat_id from #temp_patient_member ))	,

cte_numerator as ( select distinct patient_id from t_immunization where  imm_type = 'TDAP' and patient_id in ( select pat_id from cte_denominator )  )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Immunizations for Adolescents: Tdap'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc;  

--HPV Vaccination
with cte_denominator as ( select distinct pat_id,pat_date_of_birth from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) between 9 and 13  and pat_status != 'Inactive' and pat_delete_ind = 'N' 
							AND pat_id IN ( select pat_id from #temp_patient_member ))	,

cte_numerator as ( select distinct patient_id from t_immunization where  imm_type = 'HPV VACCINE' and patient_id in ( select pat_id from cte_denominator )  )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'HPV Vaccination'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc;  

--Adolescent Immunizations Combo 1
with cte_denominator as ( select distinct pat_id,pat_date_of_birth from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) between 10 and 13  and pat_status != 'Inactive' and pat_delete_ind = 'N' 
							AND pat_id IN ( select pat_id from #temp_patient_member ))	,

cte_numerator as ( select distinct patient_id from t_immunization where  imm_type in ( 'MCV', 'TDAP') and patient_id in ( select pat_id from cte_denominator )  )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Adolescent Immunizations Combo 1'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc; 
	
--Flu Shots for Adults Ages 18 – 64	 
with cte_denominator as ( select distinct pat_id,pat_date_of_birth from t_patient where DATEDIFF(yy,pat_date_of_birth,getdate()) between 18 and 64  and pat_status != 'Inactive' and pat_delete_ind = 'N' 
							AND pat_id IN ( select pat_id from #temp_patient_member ))	,

cte_numerator as ( select distinct patient_id from t_immunization where  imm_type = 'FLU' and patient_id in ( select pat_id from cte_denominator )  )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Flu Shots for Adults Ages 18 – 64'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.pat_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.patient_id )
	order by 1 desc; 

--Claims/Encounter Submissions
with cte_denominator as  ( select distinct enc_patient_id from t_encounter where enc_timestamp between '20190101' and GETDATE() and enc_patient_id in ( select pat_id from #temp_patient_member ) ),
cte_numerator as  ( select distinct cc_patient_id from t_chargecapture where cc_date_of_service between '20190101' and GETDATE() and cc_patient_id in ( select enc_patient_id from cte_denominator) 
					and cc_patient_id in ( select pat_id from #temp_patient_member ) )
INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Claims/Encounter Submissions'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.enc_patient_id )
	and not exists ( select 1 from cte_numerator ctn where t2.pat_id = ctn.cc_patient_id )
	order by 1 desc;
--Child ADHD Medications Continuation

with cte_patient as ( select distinct pat_id from t_patient where datediff(yy,pat_date_of_birth,getdate()) between 6 and 12 ),

cte_denominator as ( select patient_id from t_assessment where icd10_code in ('F90.0','F90.1','F90.2','F90.8','F90.9') 
						and patient_id in ( select pat_id from cte_patient) ),

cte_minencounter as ( select enc_patient_id,MIN(enc_timestamp) as min_enctimestamp 
						from t_encounter where enc_timestamp between '20190101' and GETDATE() 
						and enc_patient_id in ( select patient_id from cte_denominator )
						group by enc_patient_id )  ,

cte_numerator_rank as ( 
	select distinct t1.enc_patient_id,min_enctimestamp,convert(varchar(10),enc_timestamp,101) as enc_timestamp, rank() 
		over( partition by t1.enc_patient_id order by convert(varchar(10),enc_timestamp,101) ) as rnk  
		from t_encounter t1
		inner join cte_minencounter t2
		on t1.enc_patient_id = t2.enc_patient_id
		and t1.enc_timestamp > min_enctimestamp
		and DATEDIFF(mm,min_enctimestamp,convert(varchar(10),enc_timestamp,101)) between 2 and 9
	) ,
cte_numerator as ( select distinct enc_patient_id from cte_numerator_rank where rnk > 1 )

INSERT #TEMP_SUBSET_NOTS
select distinct individual_no, t2.pat_first_name,t2.pat_last_name,t2.pat_date_of_birth,pat_phone_1,pat_address_1,pat_address_2,pat_city,pat_state,pat_zip,
			prov_first_name,prov_last_name,prov_npi,'Child ADHD Medications Continuation'  as measure
	from #temp_patient_member t2
	inner join provider_master prov
	on pat_responsible_provider_id = prov_id
	where exists ( select 1 from cte_denominator ctd where t2.pat_id = ctd.patient_id )
	and  not exists ( select 1 from cte_numerator where t2.pat_id = enc_patient_id )
	order by 1 desc;
    
"""

cur=conn_arcadia.execute(subsetnots_sql)
print(len(cur))
cur.close()
df=pd.read_sql("select distinct measure from #temp_subset_nots",conn_arcadia)
measures=list(df["measure"])
for measure in measures:
    mdf=pd.read_sql("select * from #temp_subset_nots where measure = '{0}'".format(measure),conn_arcadia)
    output_file_name = 'subsetnots_service_' + measure.replace("(","_").replace(")","_").replace(":","_").replace(" ","_").replace("-","_") .replace("+","_").replace("/","_")+"_" +datetime.datetime.now().strftime("%Y%m%d") + '.xlsx'
    writer = pd.ExcelWriter('/home/etl/etl_home/Reports/'+ output_file_name)
    mdf.to_excel(writer,'sheet1',index=False)
    writer.save()
    print(measure)

