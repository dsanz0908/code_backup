import pyodbc
import datetime
conn=pyodbc.connect(dsn="arcadia_sql_02;uid=dev-etl;pwd=2aUK*BSy&z295sD")
def get_dbnames():
   db_query="select name from master..sysdatabases where name like 'db_%'"
   cur=conn.execute(db_query)
   res=cur.fetchall()
   cur.close()
   return res
   
def query_db(db_name):
   query = """
   DECLARE @db_name VARCHAR(100)
   SELECT @db_name = '{0}'
   -- Get Backup History
   SELECT @db_name,max(backup_start_date)
   FROM msdb.dbo.backupset s
   INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
   WHERE s.database_name = @db_name """
   cur=conn.execute(query.format(db_name[0]))
   res=cur.fetchall()
   cur.close()
   return res

def main():
   dbs=get_dbnames()
   data=[(res[0][0],res[0][1]) for res in map(query_db,dbs) ]
   print(data)

if __name__ == '__main__':
   main()
