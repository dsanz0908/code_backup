import pandas as pd
from bokeh.io import output_file, show, save
from bokeh.models import ColumnDataSource
from bokeh.models.widgets import DataTable, DateFormatter, TableColumn, HTMLTemplateFormatter,StringFormatter
import pyodbc
conn_src=pyodbc.connect(dsn="somos_redshift_1")
conn_tgt=pyodbc.connect(dsn="claims_dw")

#source = pd.read_csv(r'C:\Users\smueller-intern\Documents\Test Data\source.csv')
#target = pd.read_csv(r'C:\Users\smueller-intern\Documents\Test Data\target.csv')
query_src="""select 'wellcare_all_demographics' as table_name,receivedmonth,count(*) as cnt from payor.wellcare_all_demographics group by receivedmonth
union all
select 'wellcare_somos_all_demographics' as table_name,receivedmonth,count(*) as cnt from payor.wellcare_somos_all_demographics group by receivedmonth 
union all
select 'wellcare_all_claims' as table_name,receivedmonth,count(*) as cnt from payor.wellcare_all_claims group by receivedmonth
union all
select 'wellcare_somos_all_claims' as table_name,receivedmonth,count(*) as cnt from payor.wellcare_somos_all_claims group by receivedmonth
union all
select 'wellcare_all_rx' as table_name,receivedmonth,count(*) as cnt from payor.wellcare_all_rx group by receivedmonth
union all
select 'wellcare_somos_all_rx' as table_name,receivedmonth,count(*) as cnt from payor.wellcare_somos_all_rx group by receivedmonth 
union all
select 'healthfirst_all_demographics' as table_name,received_month,count(*) as cnt from payor.healthfirst_all_eligibility group by received_month
union all
select 'healthfirst_somos_all_demographics' as table_name,received_month,count(*) as cnt from payor.healthfirst_somos_all_eligibility group by received_month 
union all
select 'healthfirst_all_claims' as table_name,received_month,count(*) as cnt from payor.healthfirst_all_claims group by received_month
union all
select 'healthfirst_somos_all_claims' as table_name,received_month,count(*) as cnt from payor.healthfirst_somos_all_claims group by received_month
union all
select 'healthfirst_all_rx' as table_name,received_month,count(*) as cnt from payor.healthfirst_all_rx_claims group by received_month
union all
select 'healthfirst_somos_all_rx' as table_name,received_month,count(*) as cnt from payor.healthfirst_somos_all_rx_claims group by received_month order by 1,2 desc"""

query_tgt="""
select 'wellcare_all_demographics' as table_name,receivedmonth,count(*) as cnt from temp_wellcare_all_demographics group by receivedmonth
union all
select 'wellcare_somos_all_demographics' as table_name,receivedmonth,count(*) as cnt from temp_wellcare_somos_all_demographics group by receivedmonth 
union all
select 'wellcare_all_claims' as table_name,receivedmonth,count(*) as cnt from temp_wellcare_all_claims group by receivedmonth
union all
select 'wellcare_somos_all_claims' as table_name,receivedmonth,count(*) as cnt from temp_wellcare_somos_all_claims group by receivedmonth
union all
select 'wellcare_all_rx' as table_name,receivedmonth,count(*) as cnt from temp_wellcare_all_rx group by receivedmonth
union all
select 'wellcare_somos_all_rx' as table_name,receivedmonth,count(*) as cnt from temp_wellcare_somos_all_rx group by receivedmonth
union all
select 'healthfirst_all_demographics' as table_name,received_month,count(*) as cnt from temp_healthfirst_all_eligibility group by received_month
union all
select 'healthfirst_somos_all_demographics' as table_name,received_month,count(*) as cnt from temp_healthfirst_somos_all_eligibility group by received_month 
union all
select 'healthfirst_all_claims' as table_name,received_month,count(*) as cnt from temp_healthfirst_all_claims group by received_month
union all
select 'healthfirst_somos_all_claims' as table_name,received_month,count(*) as cnt from temp_healthfirst_somos_all_claims group by received_month
union all
select 'healthfirst_all_rx' as table_name,received_month,count(*) as cnt from temp_healthfirst_all_rx_claims group by received_month
union all
select 'healthfirst_somos_all_rx' as table_name,received_month,count(*) as cnt from temp_healthfirst_somos_all_rx_claims group by received_month order by 1,2 desc
"""
source=pd.read_sql(query_src,conn_src)
target=pd.read_sql(query_tgt,conn_tgt)
mdf=source.merge(target,how="outer",left_on=["table_name","receivedmonth"],right_on=["table_name", "receivedmonth"])
mdf["Difference"]=mdf["cnt_x"] - mdf["cnt_y"]
mdf = mdf.rename(columns={"cnt_x":"Count Source", "cnt_y":"Count Target"})
output_file("/home/etl/etl_home/Reports/mco_raw_data_status.html")
source = ColumnDataSource(mdf)
template="""
            <div style="background:<%= 
                (function colorfromint(){
                    if(Difference!=0){
                        return("red")}
                    }()) %>; 
                color: black; text-align:right;"> 
            <%= value %>
            </div>
            """
formatter =  HTMLTemplateFormatter(template=template)
alignformatter = StringFormatter(text_align="right")

columns = [
        TableColumn(field="table_name", title="table_name"),
        TableColumn(field="receivedmonth", title="Month Received", formatter=alignformatter),
        TableColumn(field="Count Source", title="Count Source", formatter=alignformatter),
        TableColumn(field="Count Target", title="Count Target", formatter=alignformatter),
        TableColumn(field="Difference", title="Difference", formatter=formatter),
    ]
data_table = DataTable(source=source, columns=columns, width=1200, height=500)
save(data_table)
