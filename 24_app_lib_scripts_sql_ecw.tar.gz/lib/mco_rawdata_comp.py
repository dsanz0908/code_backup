import pandas as pd
from bokeh.io import output_file,save
from bokeh.models import ColumnDataSource
from bokeh.models.widgets import DataTable, DateFormatter, TableColumn, HTMLTemplateFormatter,StringFormatter
import pyodbc
conn_src=pyodbc.connect(dsn="somos_redshift_1")
conn_tgt=pyodbc.connect(dsn="claims_dw")

query_src="""
SELECT  'wellcare_all_demographics' as table_name,
case when master_ipa = 'EX1'  then 'Excelsior'
     when master_ipa = 'CMI' then 'Corinthian'
     when master_ipa = 'EC1' then 'Ecap'
     when master_ipa = 'VR1' then 'Balance Med' END AS IPA,
 receivedmonth, count(*) as cnt from payor.wellcare_all_demographics group by receivedmonth, ipa

union all
select 'wellcare_somos_all_demographics' as table_name,'SOMOS' as ipa,receivedmonth,count(*) as cnt from payor.wellcare_somos_all_demographics group by receivedmonth, ipa
union all
select 'wellcare_all_claims' as table_name,
case when master_ipa = 'EX1'  then 'Excelsior'
     when master_ipa = 'CMI' then 'Corinthian'
     when master_ipa = 'EC1' then 'Ecap'
     when master_ipa = 'VR1' then 'Balance Med' END AS IPA,
receivedmonth, count(*) as cnt from payor.wellcare_all_claims group by receivedmonth, ipa
union all
select 'wellcare_somos_all_claims' as table_name,'SOMOS' as ipa, receivedmonth,count(*) as cnt from payor.wellcare_somos_all_claims group by receivedmonth, ipa
union all
select 'wellcare_all_rx' as table_name,
case when master_ipa = 'EX1'  then 'Excelsior'
     when master_ipa = 'CMI' then 'Corinthian'
     when master_ipa = 'EC1' then 'Ecap'
     when master_ipa = 'VR1' then 'Balance Med' END AS IPA,
receivedmonth,count(*) as cnt from payor.wellcare_all_rx group by receivedmonth, ipa
union all
select 'wellcare_somos_all_rx' as table_name,'SOMOS' as ipa, receivedmonth,count(*) as cnt from payor.wellcare_somos_all_rx group by receivedmonth, ipa
union all
select 'healthfirst_all_demographics' as table_name,
case when provider_parent_code = 'EXC1'  then 'Excelsior'
     when provider_parent_code = 'COR2' then 'Corinthian'
     when provider_parent_code = 'EC1' then 'Ecap'
     when provider_parent_code = 'VR1' then 'Balance Med' END AS IPA,
received_month,count(*) as cnt from payor.healthfirst_all_eligibility group by received_month, ipa
union all
select 'healthfirst_somos_all_demographics' as table_name, 'SOMOS' as ipa, received_month,count(*) as cnt from payor.healthfirst_somos_all_eligibility group by received_month, ipa
union all
select 'healthfirst_all_claims' as table_name,
case when pcp_parent_code = 'EXC1'  then 'Excelsior'
     when pcp_parent_code = 'COR2' then 'Corinthian'
     when pcp_parent_code like 'SOM%' then 'SOMOS_ALL' END AS IPA,
received_month,count(*) as cnt from payor.healthfirst_all_claims group by received_month, ipa
union all
select 'healthfirst_somos_all_claims' as table_name, 'SOMOS' as IPA, received_month,count(*) as cnt from payor.healthfirst_somos_all_claims group by received_month, ipa
union all
select 'healthfirst_all_rx' as table_name,
case when provider_parent_code = 'EXC1'  then 'Excelsior'
     when provider_parent_code = 'COR2' then 'Corinthian'
     when provider_parent_code = 'EC1' then 'Ecap'
     when provider_parent_code = 'VR1' then 'Balance Med' END AS IPA,
received_month,count(*) as cnt from payor.healthfirst_all_rx_claims group by received_month, ipa
union all
select 'healthfirst_somos_all_rx' as table_name, 'SOMOS' as ipa, received_month,count(*) as cnt from payor.healthfirst_somos_all_rx_claims group by received_month, ipa order by 1,2,3 desc

"""

query_tgt="""
SELECT  'wellcare_all_demographics' as table_name,
case when master_ipa = 'EX1'  then 'Excelsior'
     when master_ipa = 'CMI' then 'Corinthian'
     when master_ipa = 'EC1' then 'Ecap'
     when master_ipa = 'VR1' then 'Balance Med' END AS IPA,
 receivedmonth, count(*) as cnt from temp_wellcare_all_demographics group by receivedmonth, ipa

union all
select 'wellcare_somos_all_demographics' as table_name,'SOMOS' as ipa,receivedmonth,count(*) as cnt from temp_wellcare_somos_all_demographics group by receivedmonth, ipa
union all
select 'wellcare_all_claims' as table_name,
case when master_ipa = 'EX1'  then 'Excelsior'
     when master_ipa = 'CMI' then 'Corinthian'
     when master_ipa = 'EC1' then 'Ecap'
     when master_ipa = 'VR1' then 'Balance Med' END AS IPA,
receivedmonth, count(*) as cnt from temp_wellcare_all_claims group by receivedmonth, ipa
union all
select 'wellcare_somos_all_claims' as table_name,'SOMOS' as ipa, receivedmonth,count(*) as cnt from temp_wellcare_somos_all_claims group by receivedmonth, ipa
union all
select 'wellcare_all_rx' as table_name,
case when master_ipa = 'EX1'  then 'Excelsior'
     when master_ipa = 'CMI' then 'Corinthian'
     when master_ipa = 'EC1' then 'Ecap'
     when master_ipa = 'VR1' then 'Balance Med' END AS IPA,
receivedmonth,count(*) as cnt from temp_wellcare_all_rx group by receivedmonth, ipa
union all
select 'wellcare_somos_all_rx' as table_name,'SOMOS' as ipa, receivedmonth,count(*) as cnt from temp_wellcare_somos_all_rx group by receivedmonth, ipa
union all
select 'healthfirst_all_demographics' as table_name,
case when provider_parent_code = 'EXC1'  then 'Excelsior'
     when provider_parent_code = 'COR2' then 'Corinthian'
     when provider_parent_code = 'EC1' then 'Ecap'
     when provider_parent_code = 'VR1' then 'Balance Med' END AS IPA,
received_month,count(*) as cnt from temp_healthfirst_all_eligibility group by received_month, ipa
union all
select 'healthfirst_somos_all_demographics' as table_name, 'SOMOS' as ipa, received_month,count(*) as cnt from temp_healthfirst_somos_all_eligibility group by received_month, ipa
union all
select 'healthfirst_all_claims' as table_name,
case when pcp_parent_code = 'EXC1'  then 'Excelsior'
     when pcp_parent_code = 'COR2' then 'Corinthian'
     when pcp_parent_code like 'SOM%' then 'SOMOS_ALL' END AS IPA,
received_month,count(*) as cnt from temp_healthfirst_all_claims group by received_month, ipa
union all
select 'healthfirst_somos_all_claims' as table_name, 'SOMOS' as IPA, received_month,count(*) as cnt from temp_healthfirst_somos_all_claims group by received_month, ipa
union all
select 'healthfirst_all_rx' as table_name,
case when provider_parent_code = 'EXC1'  then 'Excelsior'
     when provider_parent_code = 'COR2' then 'Corinthian'
     when provider_parent_code = 'EC1' then 'Ecap'
     when provider_parent_code = 'VR1' then 'Balance Med' END AS IPA,
received_month,count(*) as cnt from temp_healthfirst_all_rx_claims group by received_month, ipa
union all
select 'healthfirst_somos_all_rx' as table_name, 'SOMOS' as ipa, received_month,count(*) as cnt from temp_healthfirst_somos_all_rx_claims group by received_month, ipa order by 1,2,3 desc
"""


source=pd.read_sql(query_src,conn_src)
target=pd.read_sql(query_tgt,conn_tgt)
mdf=source.merge(target,how="outer",left_on=["table_name","ipa","receivedmonth"],right_on=["table_name", "ipa", "receivedmonth"])
mdf["Difference"]=mdf["cnt_x"] - mdf["cnt_y"]
mdf = mdf.rename(columns={"cnt_x":"Count Source", "cnt_y":"Count Target"})
output_file("/home/etl/etl_home/Reports/mco_raw_data_status.html")
page_source = ColumnDataSource(mdf)
template="""
            <div style="background:<%=
                (function colorfromint(){
                    if(Difference!=0){
                        return("red")}
                    }()) %>;
                color: black">
            <%= value %>
            </div>
            """
formatter =  HTMLTemplateFormatter(template=template)


columns = [
        TableColumn(field="table_name", title="table_name"),
        TableColumn(field="ipa", title="IPA"),
        TableColumn(field="receivedmonth", title="Month Received"),
        TableColumn(field="Count Source", title="Count Source"),
        TableColumn(field="Count Target", title="Count Target"),
        TableColumn(field="Difference", title="Difference", formatter=formatter),
    ]
data_table = DataTable(source=page_source, columns=columns, width=1200, height=550,)


conn_src.close()
conn_tgt.close()
save(data_table)
