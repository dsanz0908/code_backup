import datetime
import pytz
import sys
import pyodbc
import smtplib
from html import HTML
import email.message
from email.mime.text import MIMEText
from fuzzywuzzy import fuzz

final_res=[]

def main():
	conn=pyodbc.connect(dsn="somos_redshift_1")
	tables=list_tables(conn,'payor')
	for table in tables:
		get_table_details(conn,'payor',table[0])
	processResults(final_res)

def list_tables(conn,schema):
	query = "select tablename from pg_tables where tablename like '%all%' and tablename not like '%dentalline%' and tablename not like '%notused%' and schemaname = '{0}' and tablename not like '%caregap%' order by 1"
	cur=conn.execute(query.format(schema))
	res=cur.fetchall()
	return res

def get_arcadia_dates():
    conn_arcadia = pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")
    date_query = """
    SELECT DISTINCT Format(create_timestamp, 'yyyyMM') AS processed_date, 
		    loaded_from_file 
    FROM   (SELECT create_timestamp, 
		   loaded_from_file 
	    FROM   plan_member 
	    UNION 
	    SELECT create_timestamp, 
		   loaded_from_file 
	    FROM   plan_claim_header 
	    UNION 
	    SELECT create_timestamp, 
		   loaded_from_file 
	    FROM   plan_claim_rx) AS full_table where create_timestamp >= '2018-09-01'
    """
    cursor = conn_arcadia.execute(date_query)
    result = cursor.fetchall()
    cursor.close()
    return result


arcadia_dates = get_arcadia_dates()
def get_table_details(conn,schema,tablename):
        arcadia_list = []
        for arcadia_data in arcadia_dates:
            score = fuzz.WRatio(tablename, arcadia_data[1])
            if score > 80:
                arcadia_set = arcadia_list.append(arcadia_data[0])
            elif score > 70:
                arcadia_set = arcadia_list.append(arcadia_data[0]+'*')

        if arcadia_list:
            max_arcadia_date = max(arcadia_list)
        else:
            max_arcadia_date = ''

        if tablename.startswith("affinity"):
                gcolumn = "period"
                if tablename in ["affinity_corinthian_all_members", "affinity_somos_all_caregaps", "affinity_somos_all_members"]:
                        lcolumn = "member_id"
                else:
                        lcolumn = "affinity_subscriber_number"                       
        elif tablename.startswith("wellcare"):
                gcolumn = "receivedmonth"
                if tablename in ["wellcare_all_claims", "wellcare_all_claims_with_npi_xwalk", "wellcare_all_claims_with_somos_npi_xwalk",
                                "wellcare_somos_all_claims", "wellcare_somos_all_claims_with_npi_xwalk"]:
                    lcolumn = "seq_member_id"
                else:

                    lcolumn = "seq_memb_id"
        elif tablename.startswith("healthfirst"):
                gcolumn = "received_month"
                if tablename.endswith(("caregaps", "claims")):
                    lcolumn = "member_number"
                elif tablename.endswith("cntl"):
                    lcolumn = "effective_period"
                else:
                    lcolumn = "member_id"
        elif tablename.startswith("anthem") or tablename.startswith("empire"):
                gcolumn = "received_month"
                if tablename.endswith("claims"):
                        lcolumn = "empire_member_id"
                elif tablename.endswith("rx"):
                        lcolumn = "src_subs_id"
                else:
                        lcolumn = "empire_subscriber_id"
        elif tablename.startswith("uhc"):
                gcolumn = "received_month"
                if tablename.endswith("claims"):
                        lcolumn = "medicaid_no"
                elif tablename.endswith("membership"):
                        lcolumn = "medicaid_no"
                else: 
                        lcolumn = "subscriber_id"
        else: 
                gcolumn = "received_month"
                lcolumn = "received_month"
                        
        query = """ select * from (select '{0}' as schemaname, '{1}' as table_name,count(*) as total_count, min({2}) as earliest_month,
                        max({2}) as latest_month , ( select count(*) from {0}.{1}
                        where {2} = ( select max({2}) from {0}.{1} ) ) as lastest_count,
                        (select count(distinct {3}) as cnt from {0}.{1} 
                        where {2} = ( select max({2}) from {0}.{1} ))  as lastest_member_count,
                        case when table_name = 'wellcare_all_demographics'
                        then (select count(distinct seq_memb_id) from payor.wellcare_all_demographics  
                        where receivedmonth = (select max(receivedmonth) from payor.wellcare_all_demographics) and master_ipa = 'EX1')
                        else '0'
                        end as excelsior_count, 
                        case when table_name  = 'wellcare_all_demographics'
                        then (select count(distinct seq_memb_id) from payor.wellcare_all_demographics  
                        where receivedmonth = (select max(receivedmonth) from payor.wellcare_all_demographics) and master_ipa = 'VR1')
                        else '0'
                        end as balancemed_count,
                        case when table_name  = 'wellcare_all_demographics'
                        then (select count(distinct seq_memb_id) from payor.wellcare_all_demographics  
                        where receivedmonth = (select max(receivedmonth) from payor.wellcare_all_demographics) and master_ipa = 'CMI')
                        else '0'
                        end as corinthian_count,
                        case when table_name  = 'wellcare_all_demographics'
                        then (select count(distinct seq_memb_id) from payor.wellcare_all_demographics  
                        where receivedmonth = (select max(receivedmonth) from payor.wellcare_all_demographics) and master_ipa = 'EC1')
                        else '0'
                        end as ECAP_count, '{4}' as latest_arcadia_date
                        from {0}.{1}) as temp_table where latest_month > '201809'"""
        
        cur = conn.execute(query.format(schema,tablename,gcolumn,lcolumn,max_arcadia_date))
        res = cur.fetchall()
        if res:
            final_res.append(res[0])

def getDBDetails(process_date,conn):
	query="""
	select s3_key,1 as success, 0 as fail from etl_new.success_new where for_dt = '{0}'
	union
	select s3_key,0 as success, 1 as fail from etl_new.fail_new where for_dt = '{0}'
	"""
	cur=conn.execute(query.format(process_date))
	res=cur.fetchall()
	cur.close()
	return res
def  processResults(dbdetails):
	if len(dbdetails) == 0:
		return None
	f=open("/home/etl/etl_home/Reports/inventory.html","w")
	h=HTML()
	tbl=h.table(style='font-family:Calibri;font-size:125%;width:100%')
	#r=tbl.tr(style="background-color:darksalmon;font-size:200%")
	r=tbl.tr(style="background-color:#e3e0cc;font-size:200%")
	r.td("Schema Name")
        r.td("Table Name")
        r.td("Total Count")
        r.td("Earliest Month")
	r.td("Latest Month")
	r.td("Latest Month Count")
	r.td("Latest Member Count")
        r.td("Excelsior Count")
        r.td("BalanceMed Count")
        r.td("Corinthian Count")
        r.td("ECAP Count")
        r.td("Latest Arcadia Date")
	rnum=0
	for row in dbdetails:
		rnum = rnum + 1
		#rowStyle= "background-color:lightgreen" if rnum %2 == 0 else "background-color:seagreen;color:ivory"
		rowStyle="background-color:#c5d5c5" if rnum %2 == 0 else "background-color:#f0f0f0"
		r=tbl.tr(style=rowStyle)
		r.td(row[0])
		r.td(row[1])
		r.td(str(row[2]))
		r.td(row[3])
		r.td(row[4])
		r.td(str(row[5]))
		r.td(str(row[6]))
                r.td(str(row[7]))
                r.td(str(row[8]))
                r.td(str(row[9]))
                r.td(str(row[10]))
                r.td(str(row[11]))
        #header='''<center><b><p style="font-family:'Calibri';font-size:333%;">Inventory Report</p></b></center><br>'''
	header='''<head><link href="check.css" rel="stylesheet"></head><body>	<h3>Engagement Files</h3>
        <div class="content">
	<div class="sidebar">
	  <ul>
	    <li><a href="ecw_status.html">ECW Status</a></li>
	    <li><a href="engagement.html">Engagement Files Status</a></li>
	    <li><a href="inventory.html">Redshift Inventory Status</a></li>
	  </ul>
	  
	  <div class="logo">
	    <img id="somosLogo" src="SOMOS_logo.png" alt="SOMOS Community Care">
	  </div>
	</div>'''
        footer='''<br><center><p style="font-family:'Calibri';font-size:125%">Total: ''' + str(rnum) + '''<br><p style="font-family:'Calibri';font-size:125%">Time of last inventory taken: ''' + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + '''</p></center><br><br>'''
	f.write(header + str(tbl) + footer)
	f.close()
	return tbl
if __name__ == '__main__':
 main()
