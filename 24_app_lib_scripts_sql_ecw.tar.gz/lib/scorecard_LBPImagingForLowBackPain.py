import pandas as pd
import pyodbc
import boto3
conn=pyodbc.connect(dsn="somos_redshift_1")
conn_arcadia = pyodbc.connect("DSN=arcadia_replica;uid=ACPPS_ClientAccess;pwd=490qXXAAt6zsSvFL;database=acpps_warehouse_prd01")

arc_query="""
select distinct site_center_name,t1.site_id,t1.patient_id,1 as denominator,t2.pat_responsible_provider_id,policy_nbr,assessment_date 
from t_assessment  t1
inner join t_patient t2
on t1.patient_id = t2.pat_id
and  DATEDIFF(yy,pat_date_of_birth,getdate()) between 18 and 50
and  t2.pat_delete_ind = 'N'
left outer join t_payer t3
on t2.pat_id = t3.patient_id
and t3.payer_delete_ind = 'N'
and ( LEN(policy_nbr) = 15 or policy_nbr like '[A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][A-Z]' )
inner join site_master t4
on t1.site_id = t4.site_id
where icd10_code in (
'M47.26','M47.27','M47.28','M47.816','M47.817','M47.818','M47.896','M47.897','M47.98','M48.06','M48.061','M48.062','M48.067','M48.08','M51.16','M51.17','M51.26','M51.27','M51.36','M51.37',
'M51.86','M51.87','M53.2X6','M53.2X7','M53.2X8','M53.3','M53.86','M53.87','M53.88','M54.16','M54.17','M54.18','M54.30','M54.31','M54.32','M54.40','M54.41','M54.42','M54.5','M54.89','M54.9',
'M99.03','M99.04','M99.23','M99.33','M99.43','M99.53','M99.63','M99.73','M99.83','M99.84','S33.100A','S33.100D','S33.100S','S33.110A','S33.110D','S33.110S','S33.120A','S33.120D','S33.120S',
'S33.130A','S33.130D','S33.130S','S33.140A','S33.140D','S33.140S','S33.5XXA','S33.6XXA','S33.8XXA','S33.9XXA','S39.002A','S33.002D','S39.002S','S39.012A','S39.012D','S39.012S','S39.092A',
'S39.092D','S39.092S','S39.82XA','S39.82XD','S39.82XS','S39.92XA','S39.92XD','S39.92XS' )
and t1.delete_ind = 'N'
and datepart(year,assessment_date) = 2019
"""
fuzzy_query="""
create temporary table fuzz_test (
arcadia_name		varchar(255),
arcadia_dob			date,
arcadia_pat_id		varchar(100),
mco_name			varchar(255),
mco_dob       date,
mco_cin				varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));


copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

"""
conn.execute(fuzzy_query)
df_arc=pd.read_sql(arc_query,conn_arcadia)
df_arc.to_csv("/home/etl/etl_home/temp/LBP_1.csv",header=True,index=False,encoding="UTF-8")
#df_fuzzy=pd.read_sql("select * from fuzz_test",conn)
#mdf=df_arc.merge(df_fuzzy,how="inner",left_on="patient_id",right_on="arcadia_pat_id")
#mdf.to_csv("/home/etl/etl_home/temp/pat_cin_scorecard.txt",header=True,index=False)
s3=boto3.resource("s3")
with open("/home/etl/etl_home/temp/LBP_1.csv","rb") as f:
   obj=s3.Object("sftp_test","LBP_1.csv") 
   obj.put(Body=f)
    
ctbl="""
create temporary table LBP_1 (
site_center_name    VARCHAR(255),
site_id   VARCHAR(100),
patient_id  VARCHAR(100),
denominator INT,
pat_responsible_provider_id VARCHAR(100),
policy_nbr  VARCHAR(100),
assessment_date DATE);

create temporary table scorecard_cin (
site_center_name varchar(255),
site_id   varchar(100), 
patient_id varchar(100), 
denominator int, 
pat_responsible_provider_id varchar(100), 
policy_nbr varchar(20), 
assessment_date date,
arcadia_name varchar(100),  
arcadia_dob date, 
arcadia_pat_id varchar(100), 
mco_name varchar(100), 
mco_dob date, 
mco_cin varchar(20),  
mco_source varchar(100),  
mco_npi varchar(20), 
mco_address varchar(100), 
mco_phone varchar(20),
mco_month varchar(20) );

delete LBP_1;
copy LBP_1
from 's3://sftp_test/LBP_1.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
ignoreheader 1
csv;
insert into scorecard_cin
select * from LBP_1
INNER JOIN fuzz_test
on patient_id = arcadia_pat_id;

/* delete scorecard_cin;
copy scorecard_cin
from 's3://sftp_test/pat_cin_scorecard.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
ignoreheader 1
csv;
*/
"""
conn.execute(ctbl)

final_query="""
insert into scorecard_report (for_date,sitename,measure,universe,denominator,numerator,added_tz)
with cte_denominator as ( select site_center_name,count(distinct patient_id) as denominator from scorecard_cin group by site_center_name),

cte_max as ( select patient_id,max(mco_month) as max_month from scorecard_cin where mco_source != 'nydoh' group by patient_id ),

cte_numerator as ( select site_center_name,count(distinct patient_id) as numerator
  from ( select t1.*
  from scorecard_cin t1
  inner join cte_max t2
  on t1.patient_id = t2.patient_id
  and t1.mco_month = t2.max_month
  inner join payor.anthem_somos_all_claims t3
  on policy_nbr = member_medicaid_id
  and mco_source = 'Empire Somos'
  and t3.procedure_code in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
  and datediff(day,t1.assessment_date,claim_line_end_date) between 1 and 28
where t1.mco_source != 'nydoh' 
union all
select t1.*
  from scorecard_cin t1
  inner join cte_max t2
  on t1.patient_id = t2.patient_id
  and t1.mco_month = t2.max_month
  inner join payor.empire_bcbs_healthplus_legacy_all_claims_oldformat t3
  on policy_nbr = member_medicaid_id
  and mco_source = 'Anthem Corinthian'
  and t3.procedure_code in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
  and datediff(day,t1.assessment_date,claim_line_end_date) between 1 and 28
where t1.mco_source != 'nydoh' 
union all
select t1.*
  from scorecard_cin t1
  inner join cte_max t2
  on t1.patient_id = t2.patient_id
  and t1.mco_month = t2.max_month
  inner join payor.healthfirst_all_claims t3
  on policy_nbr = member_number
  and mco_source = 'Healthfirst Corinthian'
  and t3.service_code in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
  and datediff(day,assessment_date,end_date) between 1 and 28
where t1.mco_source != 'nydoh' 
union all
select t1.*
  from scorecard_cin t1
  inner join cte_max t2
  on t1.patient_id = t2.patient_id
  and t1.mco_month = t2.max_month
  inner join payor.healthfirst_somos_all_claims t3
  on policy_nbr = member_number
  and mco_source = 'Healthfirst Somos'
  and t3.service_code in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
  and datediff(day,assessment_date,end_date) between 1 and 28
where t1.mco_source != 'nydoh' 
union all
select t1.*
  from scorecard_cin t1
  inner join cte_max t2
  on t1.patient_id = t2.patient_id
  and t1.mco_month = t2.max_month
  inner join payor.uhc_somos_all_claims t3
  on policy_nbr = medicaid_no
  and mco_source = 'United Somos'
  and t3.procedure_code in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
  and datediff(day,assessment_date,post_date) between 1 and 28
where t1.mco_source != 'nydoh' 
union all
select t1.*
  from scorecard_cin t1
  inner join cte_max t2
  on t1.patient_id = t2.patient_id
  and t1.mco_month = t2.max_month
  inner join payor.wellcare_all_claims t3
  on policy_nbr = subscriber_id
  and mco_source = 'WellCare Non Somos'
  and t3.procedure_code_1 in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
  and datediff(day,assessment_date,activity_date) between 1 and 28
where t1.mco_source != 'nydoh'  
union all
select t1.*
  from scorecard_cin t1
  inner join cte_max t2
  on t1.patient_id = t2.patient_id
  and t1.mco_month = t2.max_month
  inner join payor.wellcare_somos_all_claims t3
  on policy_nbr = subscriber_id
  and mco_source = 'WellCare Somos'
  and t3.procedure_code_1 in ('72020','72052','72100','72110','72114','72120','72131','72132','72133','72141','72142','72146','72147','72148','72149','72156','72158','72200','72202','72220')
  and datediff(day,assessment_date,activity_date) between 1 and 28
where t1.mco_source != 'nydoh'  ) a
group by site_center_name )


select trunc(getdate()),site_center_name,'LBP-Imaging for Low Back Pain' as measure,0,
    sum(denominator) as denominator,sum(numerator) as numerator,getdate()
    from ( select site_center_name,denominator, 0 as numerator from cte_denominator
           union all
           select site_center_name,0 as denominator, numerator from cte_numerator) a
group by site_center_name           
"""
conn.execute(final_query)
conn.commit()
#final_df=pd.read_sql(final_query,conn)
#final_df.head(100)
