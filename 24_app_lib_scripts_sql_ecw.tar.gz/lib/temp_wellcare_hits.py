import pandas as pd
from fuzzywuzzy import fuzz

a = pd.read_csv(
    '../temp/20200306_wellcare_noncompliant.txt',
    sep='|',
    names=['subscriber', 'Member DOB', 'name', 'measure'])
a['Member DOB'] = pd.to_datetime(a['Member DOB'], errors='coerce')
a['dob'] = a['Member DOB'].dt.date.astype(str)

AWC = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_awc.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'icd'
    ])
AWC['dob'] = AWC['pat_date_of_birth'].astype(str)
AWC_MERGED = pd.merge(
    a[a['measure'].str.contains("Well")], AWC,
    on='dob').values.tolist()

a_AWC_FINAL_LIST = []
for awc_item in AWC_MERGED:
    awc_score = fuzz.WRatio(awc_item[2], '{}, {}'.format(
        awc_item[5], awc_item[6]))
    if awc_score > 90:
        a_AWC_FINAL_LIST.append([awc_item[0].split('-')[0]] + [awc_item[3]] +
                                awc_item[5:11])

awc_df = pd.DataFrame(
    a_AWC_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'CPT', 'ICD'
    ])

ABA = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_aba.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'icd'
    ])
ABA['dob'] = ABA['pat_date_of_birth'].astype(str)
ABA_MERGED = pd.merge(
    a[a['measure'].str.contains("BMI")], ABA,
    on='dob').values.tolist()

a_ABA_FINAL_LIST = []
for aba_item in ABA_MERGED:
    aba_score = fuzz.WRatio(aba_item[2], '{}, {}'.format(
        aba_item[5], aba_item[6]))
    if aba_score > 90:
        a_ABA_FINAL_LIST.append([aba_item[0].split('-')[0]] + [aba_item[3]] +
                                aba_item[5:10])

aba_df = pd.DataFrame(
    a_ABA_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'ICD'
    ])

ANNUALVISIT = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_members_with_encounters.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_id', 'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos'
    ])
ANNUALVISIT['dob'] = ANNUALVISIT['pat_date_of_birth'].astype(str)
ANNUALVISIT_MERGED = pd.merge(
    a[a['measure'].str.contains("Annual Visit")], ANNUALVISIT,
    on='dob').values.tolist()

a_ANNUALVISIT_FINAL_LIST = []
for annualvisit_item in ANNUALVISIT_MERGED:
    annualvisit_score = fuzz.WRatio(annualvisit_item[2], '{}, {}'.format(
        annualvisit_item[6], annualvisit_item[7]))
    if annualvisit_score > 90:
        a_ANNUALVISIT_FINAL_LIST.append([annualvisit_item[0].split('-')[0]] + [annualvisit_item[3]] +
                                annualvisit_item[6:10])

annualvisit_df = pd.DataFrame(
    a_ANNUALVISIT_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS'
    ])
annualvisit_df = annualvisit_df[annualvisit_df['DOS'] >= '2019-01-01']
annualvisit_df = annualvisit_df[annualvisit_df['DOS'] < '2020-01-01']

CCS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_ccs.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'icd'
    ])
CCS['dob'] = CCS['pat_date_of_birth'].astype(str)
CCS_MERGED = pd.merge(
    a[a['measure'].str.contains("Cervical")], CCS,
    on='dob').values.tolist()

a_CCS_FINAL_LIST = []
for ccs_item in CCS_MERGED:
    ccs_score = fuzz.WRatio(ccs_item[2], '{}, {}'.format(
        ccs_item[5], ccs_item[6]))
    if ccs_score > 90:
        a_CCS_FINAL_LIST.append([ccs_item[0].split('-')[0]] + [ccs_item[3]] +
                                ccs_item[5:11])

ccs_df = pd.DataFrame(
    a_CCS_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'CPT', 'ICD'
    ])


COL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_col.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'icd'
    ])
COL['dob'] = COL['pat_date_of_birth'].astype(str)
COL_MERGED = pd.merge(
    a[a['measure'].str.contains("Colorectal")], COL,
    on='dob').values.tolist()

a_COL_FINAL_LIST = []
for col_item in COL_MERGED:
    col_score = fuzz.WRatio(col_item[2], '{}, {}'.format(
        col_item[5], col_item[6]))
    if col_score > 90:
        a_COL_FINAL_LIST.append([col_item[0].split('-')[0]] + [col_item[3]] +
                                col_item[5:11])

col_df = pd.DataFrame(
    a_COL_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'CPT', 'ICD'
    ])

CHL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_chl.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
CHL['dob'] = CHL['pat_date_of_birth'].astype(str)
CHL_MERGED = pd.merge(
    a[a['measure'].str.contains("Chlamydia")], CHL,
    on='dob').values.tolist()

a_CHL_FINAL_LIST = []
for chl_item in CHL_MERGED:
    chl_score = fuzz.WRatio(chl_item[2], '{}, {}'.format(
        chl_item[5], chl_item[6]))
    if chl_score > 90:
        a_CHL_FINAL_LIST.append([chl_item[0].split('-')[0]] + [chl_item[3]] +
                                chl_item[5:10])

chl_df = pd.DataFrame(
    a_CHL_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'CPT'
    ])

CBP = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_cbp.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'systolic', 'diastolic', 'cpt1', 'cpt2', 'rn'
    ])
CBP['dob'] = CBP['pat_date_of_birth'].astype(str)
CBP_MERGED = pd.merge(
    a[a['measure'].str.contains("Diabetes BP")], CBP,
    on='dob').values.tolist()

a_CBP_FINAL_LIST = []
for cbp_item in CBP_MERGED:
    cbp_score = fuzz.WRatio(cbp_item[2], '{}, {}'.format(
        cbp_item[5], cbp_item[6]))
    if cbp_score > 90:
        a_CBP_FINAL_LIST.append([cbp_item[0].split('-')[0]] + [cbp_item[3]] +
                                cbp_item[5:11])

cbp_df = pd.DataFrame(
    a_CBP_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'Systolic', 'Diastolic'
    ])
cbp_df = cbp_df[cbp_df['Systolic'] < 140]
cbp_df = cbp_df[cbp_df['Diastolic'] < 90]


A1C = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_a1c.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'result'
    ])
A1C['dob'] = A1C['pat_date_of_birth'].astype(str)
A1C_MERGED = pd.merge(
    a[a['measure'].str.contains("A1c")], A1C,
    on='dob').values.tolist()

a_A1C_FINAL_LIST = []
for a1c_item in A1C_MERGED:
    a1c_score = fuzz.WRatio(a1c_item[2], '{}, {}'.format(
        a1c_item[5], a1c_item[6]))
    if a1c_score > 90:
        a_A1C_FINAL_LIST.append([a1c_item[0].split('-')[0]] + [a1c_item[3]] +
                                a1c_item[5:10])

a1c_df = pd.DataFrame(
    a_A1C_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'result'
    ])
a1c_df = a1c_df[a1c_df['result'].convert_objects(
    convert_numeric=True) <= 9]

NEPHROPATHY = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_nephropathy.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
NEPHROPATHY['dob'] = NEPHROPATHY['pat_date_of_birth'].astype(str)
NEPHROPATHY_MERGED = pd.merge(
    a[a['measure'].str.contains("Nephropathy")], NEPHROPATHY,
    on='dob').values.tolist()

a_NEPHROPATHY_FINAL_LIST = []
for nephropathy_item in NEPHROPATHY_MERGED:
    nephropathy_score = fuzz.WRatio(nephropathy_item[2], '{}, {}'.format(
        nephropathy_item[5], nephropathy_item[6]))
    if nephropathy_score > 90:
        a_NEPHROPATHY_FINAL_LIST.append([nephropathy_item[0].split('-')[0]] + [nephropathy_item[3]] +
                                nephropathy_item[5:10])

nephropathy_df = pd.DataFrame(
    a_NEPHROPATHY_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'CPT'
    ])


BCS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_bcs.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
BCS['dob'] = BCS['pat_date_of_birth'].astype(str)
BCS_MERGED = pd.merge(
    a[a['measure'].str.contains("Mammogram")], BCS,
    on='dob').values.tolist()

a_BCS_FINAL_LIST = []
for bcs_item in BCS_MERGED:
    bcs_score = fuzz.WRatio(bcs_item[2], '{}, {}'.format(
        bcs_item[5], bcs_item[6]))
    if bcs_score > 90:
        a_BCS_FINAL_LIST.append([bcs_item[0].split('-')[0]] + [bcs_item[3]] +
                                bcs_item[5:10])

bcs_df = pd.DataFrame(
    a_BCS_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'CPT'
    ])


WCC = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_wcc.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'icd', 'rn'
    ])
WCC['dob'] = WCC['pat_date_of_birth'].astype(str)
WCC_MERGED = pd.merge(
    a[a['measure'].str.contains("WCC")], WCC,
    on='dob').values.tolist()

a_WCC_FINAL_LIST = []
for wcc_item in WCC_MERGED:
    wcc_score = fuzz.WRatio(wcc_item[2], '{}, {}'.format(
        wcc_item[5], wcc_item[6]))
    if wcc_score > 90:
        a_WCC_FINAL_LIST.append([wcc_item[0].split('-')[0]] + [wcc_item[3]] +
                                wcc_item[5:11])

wcc_df = pd.DataFrame(
    a_WCC_FINAL_LIST,
    columns=[
        'Subscriber ID', 'Measure', 'Member First Name', 'Member Last Name',
        'DOB', 'DOS', 'CPT', 'ICD'
    ])


DF = pd.concat([cbp_df, awc_df, aba_df, annualvisit_df, ccs_df, chl_df, col_df, a1c_df, nephropathy_df, bcs_df, wcc_df], ignore_index=True)
DF.to_csv('20200306_wellcare_hits.txt', sep='|', index=False)
