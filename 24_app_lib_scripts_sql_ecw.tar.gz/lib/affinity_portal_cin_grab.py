import csv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def automation(adn):
    affinity_eligibility = "https://providerportal.affinityplan.org/Eligibility"
    browser, wait = get_browser()
    login(browser, wait)
    if "ChallengeSecurityQuestion" in browser.current_url:
        validate_user(wait)
    browser.get(affinity_eligibility)
    enter_member_id(browser, wait, adn)
    cin = get_cin(wait)
    browser.quit()
    return cin


def get_browser():
    options = Options()
    options.headless = True
    options.add_argument('--disable-infobars')
    options.add_argument('--disable-extensions')
    options.add_argument('--profile-directory=Default')
    options.add_argument("--incognito")
    options.add_argument("--disable-plugins-discovery")
    options.add_argument("--start-maximized")
    browser = webdriver.Chrome(options=options)
    browser.delete_all_cookies()
    wait = WebDriverWait(browser, 1)
    return browser, wait


def login(browser, wait):
    affinity_portal = "https://identity.affinityplan.org/Account/Login?returnUrl=%2F&portalMode=Provider"
    browser.get(affinity_portal)
    username_element = wait.until(
        EC.presence_of_element_located((By.ID, "Username")))
    password_element = wait.until(
        EC.presence_of_element_located((By.ID, "Password")))
    submit_button_xpath = "/html/body/div[5]/div/form/div/div/div[2]/div[3]/button"
    submit_button_element = wait.until(
        EC.presence_of_element_located((By.XPATH, submit_button_xpath)))
    username_element.send_keys("kemar")
    password_element.send_keys("Mysticalxk01!")
    submit_button_element.submit()
    return


def validate_user(wait):
    question_element_xpath = "/html/body/div[5]/form/div[1]/div[2]/div[1]/div/label"
    question_element = wait.until(
        EC.presence_of_element_located((By.XPATH, question_element_xpath)))
    answer_element = wait.until(
        EC.presence_of_element_located((By.ID, "Answer")))
    submit_button_xpath = "/html/body/div[5]/form/div[2]/input[1]"
    submit_button_element = wait.until(
        EC.presence_of_element_located((By.XPATH, submit_button_xpath)))
    if "mother" in question_element.text:
        answer_element.send_keys("ellis")
    elif "pet" in question_element.text:
        answer_element.send_keys("mittens")
    submit_button_element.submit()
    return


def enter_member_id(browser, wait, asn):
    asn_text_box_xpath = '//*[@id="Items_0__AffinityId"]'
    asn_text_box_element = wait.until(
        EC.presence_of_element_located((By.XPATH, asn_text_box_xpath)))
    submit_button_xpath = '//*[@id="divSearch"]/form[1]/div/input[2]'
    submit_button_element = wait.until(
        EC.presence_of_element_located((By.XPATH, submit_button_xpath)))
    asn_text_box_element.send_keys(asn)
    submit_button_element.submit()
    return browser


def get_cin(wait):
    cin_xpath = '//*[@id="grid"]/table/tbody/tr/td[2]'
    cin_element = wait.until(
        EC.presence_of_element_located((By.XPATH, cin_xpath)))
    cin = cin_element.text
    return cin


if __name__ == "__main__":
    FILE_PATH = "/home/etl/etl_home/temp/20181228_missing_affinity_cins.txt"
    CSV_PATH = FILE_PATH.replace('.txt', '.csv')
    with open(FILE_PATH, 'r') as opened_file:
        ADNS = [adn.rstrip() for adn in opened_file.readlines()]
    ADN_CIN_LIST = []
    for adn in ADNS:
        try:
            CIN = automation(adn)
            ADN_CIN_LIST.append([adn, CIN])
        except Exception, e:
            print(str(e))
            CIN = ''
            ADN_CIN_LIST.append([adn, ''])

    with open(CSV_PATH, 'wb') as opened_csv:
        WRITER = csv.writer(opened_csv)
        WRITER.writerow(['ADN', 'CIN'])
        WRITER.writerows(ADN_CIN_LIST)
