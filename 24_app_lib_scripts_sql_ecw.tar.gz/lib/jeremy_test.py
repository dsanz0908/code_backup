import socket
 
IP = '40.143.139.138'  # Standard loopback interface address (localhost)
PORT = 4014        # Port to listen on (non-privileged ports are > 1023)
message = chr(11)
message += "MSH|^~\&|SOMOS|SOMOS|HealthShare|Healthfirst|20190624111429||ADT^A08|1|T|2.5\r"
message +="EVN|A08|20190610084500\r"
message +="PID|1||00000-00000000000^^^SOMOS^MPI~00000^^^eClinicalWorks^MRN||NEWYORK^NAME^J||00000000|F||Other|000 EAST 000TH STREET^^NEW YORK^NY^10033||000-000-0000||Spanish||||000-00-0000||NEWYORK^NAME^J|Hispanic or Latino\r"
message +="PV1|1|O|OP^^^CCN General Medicine,PLLC|ROUTINE|||^NEW^YORK^D|||Family Practice||||ROUTINE|||^NEW^YORK^|O|00000-00|||||||||||||||||||||||||20190610084500|\r"
message +="PV2|||Walk-In Visit|||||||||\r"
message +="OBX|1||BMI||29.57|kg/m2|||||F|||20190610000000\r"
message +="OBX|2||DIASTOLIC||83.0|mmHg|||||F|||20190610000000\r"
message +="OBX|3||HEART RATE||98.0|bmp|||||F|||20190610000000\r"
message +="OBX|5||SP02||98.0|%|||||F|||20190610000000\r"
message +="OBX|6||SYSTOLIC||135.0|mmHg|||||F|||20190610000000\r"
message +="OBX|7||TEMPERATURE||98.0|F|||||F|||20190610000000\r"
message +="OBX|8||WEIGHT||175.0|lb|||||F|||20190610000000\r"
message +="DG1|1|I10|J01.90^Acute sinusitis, unspecified|Acute sinusitis, unspecified|20190610084500|Primary\r"
message +="DG1|2|I10|Z68.29^Body mass index (BMI) 29.0-29.9, adult|Body mass index (BMI) 29.0-29.9, adult|20190610084500|Other\r"
message +="DG1|3|I10|Z76.0^Encounter for issue of repeat prescription|Encounter for issue of repeat prescription|20190610084500|Other\r"
message +="DG1|4|I10|Z00.00^Encntr for general adult medical exam w/o abnormal findings|Encntr for general adult medical exam w/o abnormal findings|20190610084500|Other\r"
message +="IN1|1|Healthfirst|Healthfirst|Healthfirst||||||||||||NEWYORK^NAME^J||19640418||||||||||||||||||000000000|||||||F\r"
message +=chr(28)
#message +=chr(13)
 
message +=chr(11)
message +="MSH|^~\&|SOMOS|SOMOS|HealthShare|Healthfirst|20190624111428||ADT^A08|2|T|2.5\r"
message +="EVN|A08|20190610084500\r"
message +="PID|1||00000-00000000000^^^SOMOS^MPI~00000^^^eClinicalWorks^MRN||NEWYORK^NAME^J||00000000|F||Other|000 EAST 000TH STREET^^NEW YORK^NY^10033||000-000-0000||Spanish||||000-00-0000||NEWYORK^NAME^J|Hispanic or Latino\r"
message +="PV1|1|O|OP^^^CCN General Medicine,PLLC|ROUTINE|||^NEW^YORK^D|||Family Practice||||ROUTINE|||^NEW^YORK^|O|00000-00|||||||||||||||||||||||||20190610084500|\r"
message +="PV2|||Walk-In Visit|||||||||\r"
message +="OBX|1||BMI||29.57|kg/m2|||||F|||20190610000000\r"
message +="OBX|2||DIASTOLIC||83.0|mmHg|||||F|||20190610000000\r"
message +="OBX|3||HEART RATE||98.0|bmp|||||F|||20190610000000\r"
message +="OBX|5||SP02||98.0|%|||||F|||20190610000000\r"
message +="OBX|6||SYSTOLIC||135.0|mmHg|||||F|||20190610000000\r"
message +="OBX|7||TEMPERATURE||98.0|F|||||F|||20190610000000\r"
message +="OBX|8||WEIGHT||175.0|lb|||||F|||20190610000000\r"
message +="DG1|1|I10|J01.90^Acute sinusitis, unspecified|Acute sinusitis, unspecified|20190610084500|Primary\r"
message +="DG1|2|I10|Z68.29^Body mass index (BMI) 29.0-29.9, adult|Body mass index (BMI) 29.0-29.9, adult|20190610084500|Other\r"
message +="DG1|3|I10|Z76.0^Encounter for issue of repeat prescription|Encounter for issue of repeat prescription|20190610084500|Other\r"
message +="DG1|4|I10|Z00.00^Encntr for general adult medical exam w/o abnormal findings|Encntr for general adult medical exam w/o abnormal findings|20190610084500|Other\r"
message +="IN1|1|Healthfirst|Healthfirst|Healthfirst||||||||||||NEWYORK^NAME^J||19640418||||||||||||||||||000000000|||||||F\r"
message +=chr(28)
message +=chr(13)
 
message +=chr(11)
message +="MSH|^~\&|SOMOS|SOMOS|HealthShare|Healthfirst|20190624111427||ADT^A08|2|T|2.5\r"
message +="EVN|A08|20190610084500\r"
message +="PID|1||00000-00000000000^^^SOMOS^MPI~00000^^^eClinicalWorks^MRN||NEWYORK^NAME^J||00000000|F||Other|000 EAST 000TH STREET^^NEW YORK^NY^10033||000-000-0000||Spanish||||000-00-0000||NEWYORK^NAME^J|Hispanic or Latino\r"
message +="PV1|1|O|OP^^^CCN General Medicine,PLLC|ROUTINE|||^NEW^YORK^D|||Family Practice||||ROUTINE|||^NEW^YORK^|O|00000-00|||||||||||||||||||||||||20190610084500|\r"
message +="PV2|||Walk-In Visit|||||||||\r"
message +="OBX|1||BMI||29.57|kg/m2|||||F|||20190610000000\r"
message +="OBX|2||DIASTOLIC||83.0|mmHg|||||F|||20190610000000\r"
message +="OBX|3||HEART RATE||98.0|bmp|||||F|||20190610000000\r"
message +="OBX|5||SP02||98.0|%|||||F|||20190610000000\r"
message +="OBX|6||SYSTOLIC||135.0|mmHg|||||F|||20190610000000\r"
message +="OBX|7||TEMPERATURE||98.0|F|||||F|||20190610000000\r"
message +="OBX|8||WEIGHT||175.0|lb|||||F|||20190610000000\r"
message +="DG1|1|I10|J01.90^Acute sinusitis, unspecified|Acute sinusitis, unspecified|20190610084500|Primary\r"
message +="DG1|2|I10|Z68.29^Body mass index (BMI) 29.0-29.9, adult|Body mass index (BMI) 29.0-29.9, adult|20190610084500|Other\r"
message +="DG1|3|I10|Z76.0^Encounter for issue of repeat prescription|Encounter for issue of repeat prescription|20190610084500|Other\r"
message +="DG1|4|I10|Z00.00^Encntr for general adult medical exam w/o abnormal findings|Encntr for general adult medical exam w/o abnormal findings|20190610084500|Other\r"
message +="IN1|1|Healthfirst|Healthfirst|Healthfirst||||||||||||NEWYORK^NAME^J||19640418||||||||||||||||||000000000|||||||F\r"
message +=chr(28)
message +=chr(13)
 
 
 
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((IP,PORT))
    s.send(bytes(message, 'latin-1'))

s.close()
