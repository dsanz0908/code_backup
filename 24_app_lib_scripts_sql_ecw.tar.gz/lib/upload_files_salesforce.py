import requests
import base64
import json
from simple_salesforce import Salesforce
import sys
def main():
	filename=sys.argv[1]
	sf,instance_url=getSession()
        npi = 'abc12345'
        npi = filename.split('_')[3]
        print(npi)
	parent_id=getParentID(npi,sf)
	version=getVersion(instance_url)
	print(version)
	#resp=uploadFile(filename,sf,instance_url,version,parent_id)
	#resp=uploadContentVersion(filename,sf,instance_url,version,parent_id)
	resp=uploadFeed(filename,sf,instance_url,version,parent_id)
	print(resp)

def getVersion(instance_url):
	instance_url=instance_url + "/services/data/"
	resp=requests.get(instance_url)
	return(resp.json()[0]["version"])

def getParentID(npi,sf):
	parent_id=sf.query("select Id from contact where cin__c = '{0}'".format(npi))
	return parent_id["records"][0]["Id"]

def uploadFile(filename,sf,instance_url,version,parent_id):
	body=""
	instance_url = instance_url + "/services/data/v" + str(version) + "/sobjects/Attachment/"
	with open(filename,"r") as f:
		body=base64.b64encode(f.read())
	print(parent_id)
	resp=requests.post(instance_url,
	headers= { 'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % sf.session_id },
	data = json.dumps({
		'ParentId' : parent_id,
		'Name' : filename,
		'body' : body,
		'IsPrivate' : False
		})
	)
	return resp.json()

def uploadContentVersion(filename,sf,instance_url,version,parent_id):
	body=""
	instance_url = instance_url + "/services/data/v" + str(version) + "/sobjects/ContentVersion/"
	with open(filename,"r") as f:
		body=base64.b64encode(f.read())
	print(parent_id)
	resp=requests.post(instance_url,
	headers= { 'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % sf.session_id },
	data = json.dumps({
		'Origin' : 'H',
		'PathOnClient' : filename,
		'VersionData' : body
		})
	)
	return resp.json()

def uploadFeed(filename,sf,instance_url,version,parent_id):
	body=""
	with open(filename,"r") as f:
                body=base64.b64encode(f.read())
	instance_url = instance_url + "/services/data/v" + str(version) + "/sobjects/FeedPost/"
	resp=requests.post(instance_url,
	headers= { 'Content-Type': 'application/json', 'Authorization': 'Bearer %s' % sf.session_id },
	data = json.dumps({
		'ParentId' : parent_id,
		'Type' : "ContentPost",
		'Title' : filename,
		'ContentFileName' : filename,
		'ContentData' : body
		})
	)
	return resp.json()

def getSession():
	consumer_key="3MVG9zlTNB8o8BA2tboYIbV95eaqf3A1_GESOvtVE6E59IsjfGYuAp4UAHvRZtYcJ4m.Hqz5lroJu3Jy43eDI"
	consumer_sec="2390566482488021811"
	params = {
        'grant_type': "password",
        'client_id' : consumer_key,
        'client_secret' : consumer_sec,
        'username' : "ssundararaman@optimusha.com",
        'password': "SomosOpt2019$z6gz9mRNzD38ZYJM6scMmoziU"
    	}
	access_token_url = 'https://login.salesforce.com/services/oauth2/token'
	r = requests.post(access_token_url,params=params)
	access_token = r.json().get("access_token")
	instance_url = r.json().get("instance_url")
	response = r.json()
	sf = Salesforce(instance_url=response['instance_url'], session_id=response['access_token'])
	return (sf,instance_url)
if __name__ == '__main__':
	main()


