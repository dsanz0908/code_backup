from os import listdir, path
from datetime import datetime
import re
import csv
import imaplib
import email
import xlrd

EXCEL_DIRECTORY = "/home/etl/etl_home/downloads/hie_mrp_discharge_excel/"
CSV_DIRECTORY = "/home/etl/etl_home/downloads/hie_mrp_discharge_csv/"


def get_hie_mrp_discharges():
    conn = imaplib.IMAP4_SSL("outlook.office365.com")
    conn.login('dsanz@optimusha.com', 'Bacalao2')
    conn.select('Inbox')
    return_code, msgs = conn.search(None, '(SUBJECT "HIE MRP DAILY DISCHARGE")')
    return conn, msgs[0].split()


def get_processed_message(conn, msg):
    result, data = conn.fetch(msg, "(RFC822)")
    email_body = data[0][1]
    pmail = email.message_from_string(email_body)
    return pmail


def save_excel_attachment(msg):
    if msg.get_content_maintype() != 'multipart':
        return
    for part in msg.walk():
        if part.get_content_maintype() == 'multipart':
            continue
        if part.get('Content-Disposition') is None:
            continue
        filename = part.get_filename()
        original_date_regex = re.compile(ur'\d\d\s...\s20\d\d')
        if 'xlsx' in filename.lower():
            original_date_regex_list = re.findall(
                original_date_regex, part.get('Content-Disposition'))
            if original_date_regex_list:
                original_email_date = str(original_date_regex_list[0]).replace(
                    ' ', '')
                excel_save_path = path.join(
                    EXCEL_DIRECTORY, "{}_{}".format(original_email_date,
                                                    filename))
                with open(excel_save_path, 'wb') as opened_file:
                    opened_file.write(part.get_payload(decode=True))
    return

if __name__ == '__main__':
    CONNECTION, MESSAGES = get_hie_mrp_discharges()
    for message in MESSAGES:
        processed_email = get_processed_message(CONNECTION, message)
        save_excel_attachment(processed_email)

    CONNECTION.close()
    CONNECTION.logout()
    del CONNECTION

