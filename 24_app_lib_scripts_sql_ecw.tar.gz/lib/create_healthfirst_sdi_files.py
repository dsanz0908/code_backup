# -*- coding: utf-8 -*-

import sys
from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

EXCEL = sys.argv[1]
MMS = pd.read_excel(EXCEL)
MMS['Member DOB'] = pd.to_datetime(MMS['Member DOB'], errors='coerce')
MMS['dob'] = MMS['Member DOB'].dt.date.astype(str)
MMS.fillna('', inplace=True)

CBP = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_cbp.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'systolic', 'diastolic', 'cpt1', 'cpt2', 'rn'
    ])
CBP['dob'] = CBP['pat_date_of_birth'].astype(str)
CBP_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Controlling High Blood Pressure")],
    CBP,
    on='dob').values.tolist()
MMS_CBP_FINAL_LIST = []
for cbp_item in CBP_MERGED:
    cbp_score = fuzz.WRatio('{} {}'.format(cbp_item[1], cbp_item[2]),
                            '{}, {}'.format(cbp_item[43], cbp_item[44]))
    if cbp_score > 90:
        MMS_CBP_FINAL_LIST.append([
            cbp_item[0], cbp_item[1], cbp_item[2], cbp_item[3], cbp_item[46],
            cbp_item[47], cbp_item[48],cbp_item[49],cbp_item[50],
        ])
pd.DataFrame(
    MMS_CBP_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS', 'Systolic', 'Diastolic',
        'CPT1', 'CPT2'
    ]).to_csv(
        '20200212_healthfirst_corinthian_cbp.csv', sep=',', index=False)

AWC = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_awc.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt', 'icd'
    ])
AWC['dob'] = AWC['pat_date_of_birth'].astype(str)
AWC_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Adolescent Well Care Visit")],
    AWC,
    on='dob').values.tolist()
MMS_AWC_FINAL_LIST = []
for awc_item in AWC_MERGED:
    awc_score = fuzz.WRatio('{} {}'.format(awc_item[1], awc_item[2]),
                            '{}, {}'.format(awc_item[43], awc_item[44]))
    if awc_score > 90:
        MMS_AWC_FINAL_LIST.append([
            awc_item[0], awc_item[1], awc_item[2], awc_item[3], awc_item[46],
            awc_item[47], awc_item[48]
        ])
pd.DataFrame(
    MMS_AWC_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT', 'ICD'
    ]).to_csv(
        '20200212_healthfirst_corinthian_awc.csv', sep=',', index=False)

BCS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_bcs.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
BCS['dob'] = BCS['pat_date_of_birth'].astype(str)
BCS_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Breast Cancer Screening")],
    BCS,
    on='dob').values.tolist()
MMS_BCS_FINAL_LIST = []
for bcs_item in BCS_MERGED:
    bcs_score = fuzz.WRatio('{} {}'.format(bcs_item[1], bcs_item[2]),
                            '{}, {}'.format(bcs_item[43], bcs_item[44]))
    if bcs_score > 90:
        MMS_BCS_FINAL_LIST.append([
            bcs_item[0], bcs_item[1], bcs_item[2], bcs_item[3], bcs_item[46],
            bcs_item[47]
        ])
pd.DataFrame(
    MMS_BCS_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT'
    ]).to_csv(
        '20200212_healthfirst_corinthian_bcs.csv', sep=',', index=False)

CCS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_ccs.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
CCS['dob'] = CCS['pat_date_of_birth'].astype(str)
CCS_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Cervical Cancer Screening")],
    CCS,
    on='dob').values.tolist()
MMS_CCS_FINAL_LIST = []
for ccs_item in CCS_MERGED:
    ccs_score = fuzz.WRatio('{} {}'.format(ccs_item[1], ccs_item[2]),
                            '{}, {}'.format(ccs_item[43], ccs_item[44]))
    if ccs_score > 90:
        MMS_CCS_FINAL_LIST.append([
            ccs_item[0], ccs_item[1], ccs_item[2], ccs_item[3], ccs_item[46],
            ccs_item[47]
        ])
pd.DataFrame(
    MMS_CCS_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT'
    ]).to_csv(
        '20200212_healthfirst_corinthian_ccs.csv', sep=',', index=False)


CIS = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_cis.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
CIS['dob'] = CIS['pat_date_of_birth'].astype(str)
CIS_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Childhood Immunizations")],
    CIS,
    on='dob').values.tolist()
MMS_CIS_FINAL_LIST = []
for cis_item in CIS_MERGED:
    cis_score = fuzz.WRatio('{} {}'.format(cis_item[1], cis_item[2]),
                            '{}, {}'.format(cis_item[43], cis_item[44]))
    if cis_score > 90:
        MMS_CIS_FINAL_LIST.append([
            cis_item[0], cis_item[1], cis_item[2], cis_item[3], cis_item[46],
            cis_item[47]
        ])
pd.DataFrame(
    MMS_CIS_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT'
    ]).to_csv(
        '20200212_healthfirst_corinthian_cis.csv', sep=',', index=False)



CHL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_chl.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
CHL['dob'] = CHL['pat_date_of_birth'].astype(str)
CHL_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Chlamydia Screening")],
    CHL,
    on='dob').values.tolist()
MMS_CHL_FINAL_LIST = []
for chl_item in CHL_MERGED:
    chl_score = fuzz.WRatio('{} {}'.format(chl_item[1], chl_item[2]),
                            '{}, {}'.format(chl_item[43], chl_item[44]))
    if chl_score > 90:
        MMS_CHL_FINAL_LIST.append([
            chl_item[0], chl_item[1], chl_item[2], chl_item[3], chl_item[46],
            chl_item[47]
        ])
pd.DataFrame(
    MMS_CHL_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT'
    ]).to_csv(
        '20200212_healthfirst_corinthian_chl.csv', sep=',', index=False)

COL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_col.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
COL['dob'] = COL['pat_date_of_birth'].astype(str)
COL_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Colorectal Cancer Screening")],
    COL,
    on='dob').values.tolist()
MMS_COL_FINAL_LIST = []
for col_item in COL_MERGED:
    col_score = fuzz.WRatio('{} {}'.format(col_item[1], col_item[2]),
                            '{}, {}'.format(col_item[43], col_item[44]))
    if col_score > 90:
        MMS_COL_FINAL_LIST.append([
            col_item[0], col_item[1], col_item[2], col_item[3], col_item[46],
            col_item[47]
        ])
pd.DataFrame(
    MMS_COL_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT'
    ]).to_csv(
        '20200212_healthfirst_corinthian_col.csv', sep=',', index=False)

EYE = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_eye.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
EYE['dob'] = EYE['pat_date_of_birth'].astype(str)
EYE_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Eye Exam")],
    EYE,
    on='dob').values.tolist()
MMS_EYE_FINAL_LIST = []
for eye_item in EYE_MERGED:
    eye_score = fuzz.WRatio('{} {}'.format(eye_item[1], eye_item[2]),
                            '{}, {}'.format(eye_item[43], eye_item[44]))
    if eye_score > 90:
        MMS_EYE_FINAL_LIST.append([
            eye_item[0], eye_item[1], eye_item[2], eye_item[3], eye_item[46],
            eye_item[47]
        ])
pd.DataFrame(
    MMS_EYE_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT'
    ]).to_csv(
        '20200212_healthfirst_corinthian_eye.csv', sep=',', index=False)

A1C = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_a1c.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
A1C['dob'] = A1C['pat_date_of_birth'].astype(str)
A1C_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("HbA1c")],
    A1C,
    on='dob').values.tolist()
MMS_A1C_FINAL_LIST = []
for a1c_item in A1C_MERGED:
    a1c_score = fuzz.WRatio('{} {}'.format(a1c_item[1], a1c_item[2]),
                            '{}, {}'.format(a1c_item[43], a1c_item[44]))
    if a1c_score > 90:
        MMS_A1C_FINAL_LIST.append([
            a1c_item[0], a1c_item[1], a1c_item[2], a1c_item[3], a1c_item[46],
            a1c_item[47]
        ])
pd.DataFrame(
    MMS_A1C_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_a1c.csv', sep=',', index=False)

SPR = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_spr.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
SPR['dob'] = SPR['pat_date_of_birth'].astype(str)
SPR_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Spirometry")],
    SPR,
    on='dob').values.tolist()
MMS_SPR_FINAL_LIST = []
for spr_item in SPR_MERGED:
    spr_score = fuzz.WRatio('{} {}'.format(spr_item[1], spr_item[2]),
                            '{}, {}'.format(spr_item[43], spr_item[44]))
    if spr_score > 90:
        MMS_SPR_FINAL_LIST.append([
            spr_item[0], spr_item[1], spr_item[2], spr_item[3], spr_item[46],
            spr_item[47]
        ])
pd.DataFrame(
    MMS_SPR_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_spr.csv', sep=',', index=False)


FUNCTIONAL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_functional.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
FUNCTIONAL['dob'] = FUNCTIONAL['pat_date_of_birth'].astype(str)
FUNCTIONAL_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Functional")],
    FUNCTIONAL,
    on='dob').values.tolist()
MMS_FUNCTIONAL_FINAL_LIST = []
for functional_item in FUNCTIONAL_MERGED:
    functional_score = fuzz.WRatio('{} {}'.format(functional_item[1], functional_item[2]),
                            '{}, {}'.format(functional_item[43], functional_item[44]))
    if functional_score > 90:
        MMS_FUNCTIONAL_FINAL_LIST.append([
            functional_item[0], functional_item[1], functional_item[2], functional_item[3], functional_item[46],
            functional_item[47]
        ])
pd.DataFrame(
    MMS_FUNCTIONAL_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_functional.csv', sep=',', index=False)


PAIN = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_pain.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
PAIN['dob'] = PAIN['pat_date_of_birth'].astype(str)
PAIN_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Pain")],
    PAIN,
    on='dob').values.tolist()
MMS_PAIN_FINAL_LIST = []
for pain_item in PAIN_MERGED:
    pain_score = fuzz.WRatio('{} {}'.format(pain_item[1], pain_item[2]),
                            '{}, {}'.format(pain_item[43], pain_item[44]))
    if pain_score > 90:
        MMS_PAIN_FINAL_LIST.append([
            pain_item[0], pain_item[1], pain_item[2], pain_item[3], pain_item[46],
            pain_item[47]
        ])
pd.DataFrame(
    MMS_PAIN_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_pain.csv', sep=',', index=False)

MEDICATIONREVIEW = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_medicationreview.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt1', 'cpt2'
    ])
MEDICATIONREVIEW['dob'] = MEDICATIONREVIEW['pat_date_of_birth'].astype(str)
MEDICATIONREVIEW_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Medication Review")],
    MEDICATIONREVIEW,
    on='dob').values.tolist()
MMS_MEDICATIONREVIEW_FINAL_LIST = []
for medicationreview_item in MEDICATIONREVIEW_MERGED:
    medicationreview_score = fuzz.WRatio('{} {}'.format(medicationreview_item[1], medicationreview_item[2]),
                            '{}, {}'.format(medicationreview_item[43], medicationreview_item[44]))
    if medicationreview_score > 90:
        MMS_MEDICATIONREVIEW_FINAL_LIST.append([
            medicationreview_item[0], medicationreview_item[1], medicationreview_item[2], medicationreview_item[3], medicationreview_item[46],
            medicationreview_item[47]
        ])
pd.DataFrame(
    MMS_MEDICATIONREVIEW_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_medicationreview.csv', sep=',', index=False)



NEPHROPATHY = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_nephropathy.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
NEPHROPATHY['dob'] = NEPHROPATHY['pat_date_of_birth'].astype(str)
NEPHROPATHY_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Nephropathy")],
    NEPHROPATHY,
    on='dob').values.tolist()
MMS_NEPHROPATHY_FINAL_LIST = []
for nephropathy_item in NEPHROPATHY_MERGED:
    nephropathy_score = fuzz.WRatio('{} {}'.format(nephropathy_item[1], nephropathy_item[2]),
                            '{}, {}'.format(nephropathy_item[43], nephropathy_item[44]))
    if nephropathy_score > 90:
        MMS_NEPHROPATHY_FINAL_LIST.append([
            nephropathy_item[0], nephropathy_item[1], nephropathy_item[2], nephropathy_item[3], nephropathy_item[46],
            nephropathy_item[47]
        ])
pd.DataFrame(
    MMS_NEPHROPATHY_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_nephropathy.csv', sep=',', index=False)

NONUSER = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_nonuser.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
NONUSER['dob'] = NONUSER['pat_date_of_birth'].astype(str)
NONUSER_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("New Member")],
    NONUSER,
    on='dob').values.tolist()
MMS_NONUSER_FINAL_LIST = []
for nonuser_item in NONUSER_MERGED:
    nonuser_score = fuzz.WRatio('{} {}'.format(nonuser_item[1], nonuser_item[2]),
                            '{}, {}'.format(nonuser_item[43], nonuser_item[44]))
    if nonuser_score > 90:
        MMS_NONUSER_FINAL_LIST.append([
            nonuser_item[0], nonuser_item[1], nonuser_item[2], nonuser_item[3], nonuser_item[46],
            nonuser_item[47]
        ])
pd.DataFrame(
    MMS_NONUSER_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_nonuser.csv', sep=',', index=False)

ART = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_art.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
ART['dob'] = ART['pat_date_of_birth'].astype(str)
ART_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Arthritis")],
    ART,
    on='dob').values.tolist()
MMS_ART_FINAL_LIST = []
for art_item in ART_MERGED:
    art_score = fuzz.WRatio('{} {}'.format(art_item[1], art_item[2]),
                            '{}, {}'.format(art_item[43], art_item[44]))
    if art_score > 90:
        MMS_ART_FINAL_LIST.append([
            art_item[0], art_item[1], art_item[2], art_item[3], art_item[46],
            art_item[47]
        ])
pd.DataFrame(
    MMS_ART_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_art.csv', sep=',', index=False)


WCC = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_wcc.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt'
    ])
WCC['dob'] = WCC['pat_date_of_birth'].astype(str)
WCC_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("Wgt")],
    WCC,
    on='dob').values.tolist()
MMS_WCC_FINAL_LIST = []
for wcc_item in WCC_MERGED:
    wcc_score = fuzz.WRatio('{} {}'.format(wcc_item[1], wcc_item[2]),
                            '{}, {}'.format(wcc_item[43], wcc_item[44]))
    if wcc_score > 90:
        MMS_WCC_FINAL_LIST.append([
            wcc_item[0], wcc_item[1], wcc_item[2], wcc_item[3], wcc_item[46],
            wcc_item[47]
        ])
pd.DataFrame(
    MMS_WCC_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'Value'
    ]).to_csv(
        '20200212_healthfirst_corinthian_wcc.csv', sep=',', index=False)

W34 = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_w34.txt',
    sep='|',
    index_col=False,
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt', 'icd'
    ])
W34['dob'] = W34['pat_date_of_birth'].astype(str)
W34_MERGED = pd.merge(
    MMS[MMS['Measure'].str.contains("3 to 6 yrs")],
    W34,
    on='dob').values.tolist()
MMS_W34_FINAL_LIST = []
for w34_item in W34_MERGED:
    w34_score = fuzz.WRatio('{} {}'.format(w34_item[1], w34_item[2]),
                            '{}, {}'.format(w34_item[43], w34_item[44]))
    if w34_score > 90:
        MMS_W34_FINAL_LIST.append([
            w34_item[0], w34_item[1], w34_item[2], w34_item[3], w34_item[46],
            w34_item[47], w34_item[48]
        ])
pd.DataFrame(
    MMS_W34_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB', 'DOS',
        'CPT', 'ICD'
    ]).to_csv(
        '20200212_healthfirst_corinthian_w34.csv', sep=',', index=False)


