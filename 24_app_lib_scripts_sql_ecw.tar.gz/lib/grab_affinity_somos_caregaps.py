# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf8')

import os
import csv
import datetime
import time
import argparse
import glob
import pandas as pd
from pyvirtualdisplay import Display
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
from grab_affinity_somos_roster import get_browser, login, validate_user


def get_reports(browswer, wait):
    qip_report_element_xpath = "//*[@id='formparent']/form/div/input"
    qip_report_element = wait.until(
        EC.presence_of_element_located((By.XPATH, qip_report_element_xpath)))
    qip_report_element.click()
    received_month = browser.current_url[-6:]
    html = browser.page_source
    soup = BeautifulSoup(html)
    tins = [
        a.text for a in soup.find('div', {
            'class': 'k-grid-content'
        }).findAll('a')
    ]
    report_template = "https://providerportal.affinityplan.org/QipReportCard/DownloadMeasureDetailReport?yearAndMonth={}&taxId={}%20&lob=%24ALL"
    for tin in tins:
        try:
            report_link = report_template.format(received_month, tin)
            browser.get(report_link)
        except:
            pass
    return


def ingest_reports():
    reports = glob.glob("/home/etl/etl_home/temp/Summary Report*All*xlsx")
    for report in reports:
        filename = os.path.basename(report)
        report_xls = pd.ExcelFile(report)
        tin = report.split('-')[1].strip()
        for sheetname in report_xls.sheet_names:
            sheet_df = pd.read_excel(report, sheetname=sheetname, skiprows=2)
            sheet_df['tin'] = tin
            sheet_df['ipa'] = 'Somos'
            sheet_df['filename'] = filename
            sheet_df['sheetname'] = sheetname
            sheet_df.to_csv(
                '/data/downloads/Affinity_Somos/{}_{}.txt'.format(
                    filename.replace('.xlsx', ''), sheetname),
                sep='|',
                index=False)


if __name__ == "__main__":
    affinity_qip_page = "https://providerportal.affinityplan.org/Qip"
    affinity_logout = "https://providerportal.affinityplan.org/Authentication/Logout"
    display = Display(visible=0, size=(800, 600))
    display.start()
    browser, wait = get_browser()
    login(browser, wait)
    if "ChallengeSecurityQuestion" in browser.current_url:
        validate_user(browser, wait)
    browser.get(affinity_qip_page)
    time.sleep(10)
    get_reports(browser, wait)
    ingest_reports()
