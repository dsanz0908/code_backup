# -*- coding: utf-8 -*-

from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

CORINTHIAN = pd.read_excel('20200107_emblem_corinthian_caregaps.xlsx')
CORINTHIAN['dob'] = CORINTHIAN['Member DOB'].dt.date.astype(str)
BLOODSUGARCONTROL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_bloodsugarcontrol.txt',
    sep='|',
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'npi', 'provider', 'specialty'
    ])
BLOODSUGARCONTROL['dob'] = BLOODSUGARCONTROL['pat_date_of_birth'].astype(str)
BLOODSUGARCONTROL_MERGED = pd.merge(
    CORINTHIAN[CORINTHIAN['Measure'].str.contains("Blood Sugar")], BLOODSUGARCONTROL,
    on='dob').values.tolist()
CORINTHIAN_BLOODSUGARCONTROL_FINAL_LIST = []
for bloodsugarcontrol_item in BLOODSUGARCONTROL_MERGED:
    bloodsugarcontrol_score = fuzz.WRatio(bloodsugarcontrol_item[5], '{}, {}'.format(
        bloodsugarcontrol_item[19], bloodsugarcontrol_item[18]))
    print bloodsugarcontrol_score, bloodsugarcontrol_item[5], '{}, {}'.format(bloodsugarcontrol_item[19], bloodsugarcontrol_item[18])
    if bloodsugarcontrol_score > 90:
        CORINTHIAN_BLOODSUGARCONTROL_FINAL_LIST.append([
            bloodsugarcontrol_item[4], bloodsugarcontrol_item[18], bloodsugarcontrol_item[19], bloodsugarcontrol_item[17],
            int(bloodsugarcontrol_item[23]), bloodsugarcontrol_item[24], bloodsugarcontrol_item[25], bloodsugarcontrol_item[21],
            '', bloodsugarcontrol_item[22], '', '', 'HbA1c Blood Sugar Control'
        ])
pd.DataFrame(
    CORINTHIAN_BLOODSUGARCONTROL_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB',
        'Servicing Provider NPI', 'Servicing Provider Name',
        'Provider Specialty', 'DOS', 'Dx Codes', 'CPT Code', 'CPTII Code', 'LOINC Codes', 'Test Screening Name'
    ]).to_csv(
        '20200109_emblem_corinthian_bloodsugarcontrol.txt', sep='|', index=False)
