# -*- coding: utf-8 -*-

from datetime import datetime
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc

CORINTHIAN = pd.read_excel('20200107_emblem_balance_caregaps.xlsx')
CORINTHIAN['dob'] = CORINTHIAN['Member DOB'].dt.date.astype(str)
COL = pd.read_csv(
    '/home/etl/etl_home/temp/arcadia_col.txt',
    sep='|',
    names=[
        'pat_first_name', 'pat_last_name', 'pat_date_of_birth', 'dos', 'cpt',
        'npi', 'provider', 'specialty'
    ])
COL['dob'] = COL['pat_date_of_birth'].astype(str)
COL_MERGED = pd.merge(
    CORINTHIAN[CORINTHIAN['Measure'].str.contains("Chlamydia")], COL,
    on='dob').values.tolist()
CORINTHIAN_COL_FINAL_LIST = []
for col_item in COL_MERGED:
    col_score = fuzz.WRatio(col_item[5], '{}, {}'.format(
        col_item[19], col_item[18]))
    print col_score, col_item[5], '{}, {}'.format(col_item[19], col_item[18])
    if col_score > 90:
        CORINTHIAN_COL_FINAL_LIST.append([
            col_item[4], col_item[18], col_item[19], col_item[17],
            int(col_item[23]), col_item[24], col_item[25], col_item[21],
            '', col_item[22]
        ])
pd.DataFrame(
    CORINTHIAN_COL_FINAL_LIST,
    columns=[
        'Member ID', 'Member First Name', 'Member Last Name', 'DOB',
        'Servicing Provider NPI', 'Servicing Provider Name',
        'Provider Specialty', 'DOS', 'Dx Codes', 'CPT Code'
    ]).to_csv(
        '20200109_emblem_balance_col.txt', sep='|', index=False)
