import pandas as pd
import pyodbc
import base64
from Crypto.Cipher import AES

CONNECTION = pyodbc.connect('dsn=somos_redshift_1')

QUERY = """
SELECT DISTINCT * 
FROM   (SELECT 'hf.' || plan_member_id 
        FROM   reinsurance.hf_rx 
        UNION 
        SELECT 'hf.' || plan_member_id 
        FROM   reinsurance.hf_medical_verify 
        UNION 
        SELECT 'wc.' || seq_member_id 
        FROM   reinsurance.wc_ri_medical_2 
        UNION 
        SELECT 'wc.' || seq_memb_id 
        FROM   reinsurance.wc_ri_rx_2
        UNION
        SELECT 'em.' || member_id 
        FROM   reinsurance.emblem_medical
        UNION 
        SELECT 'em.' || member_number
        FROM   reinsurance.emblem_rx)
"""

QUERY = """
SELECT DISTINCT *
FROM   (SELECT 'hfa.' || plan_member_id
        FROM   reinsurance.hf_rx_all
        UNION
        SELECT 'hfa.' || plan_member_id
        FROM   reinsurance.hf_medical_verify_all)
"""

MAPPING = []
IDS = CONNECTION.execute(QUERY).fetchall()
for id in IDS:
    text = id[0].encode("utf8").rjust(32)
    secret_key = 'misamisamisamisa'
    cipher = AES.new(secret_key, AES.MODE_ECB)
    encoded = base64.b64encode(cipher.encrypt(text))
    MAPPING.append([id[0], encoded])

pd.DataFrame(
    MAPPING, columns=['id', 'encrypted']).to_csv(
        '../temp/20191209_encrypted_reins_hfall.txt',
        index=False,
        sep='|')
