DELETE STAGING_ROSTER;

COPY STAGING_ROSTER
from 's3://hedis-app/hc_wc_latest_roster_000'
iam_role 'arn:aws:iam::057748858673:role/myRedshiftrole'
dateformat 'auto'
delimiter '|';

UPDATE patients
SET    updated_at = '2020-01-13 12:10PM',
       active_ind = False
WHERE  NOT EXISTS (SELECT 1
                   FROM   staging_roster
                   WHERE  medicare_id = medicare_patient_id)
       AND active_ind = True;


INSERT INTO patients
            (effective_period,
             member_id,
             medicare_id,
             member_name,
             member_dob,
             pcp_npi,
             pcp_name,
             pcp_id,
             pcp_type,
             coder_type,
             insurance_id,
             first_name,
             last_name,
             created_at,
             updated_at,
             active_ind,
             pcp_tin)

SELECT DISTINCT Cast('2020-01-01' AS DATE),
                member_id,
                medicare_patient_id,
                member_name,
                dob,
                provider_npi,
                users.last_name || ',' || users.first_name as pcp_name,
                users.id,
                'User' as pcp_type,
                'User' as code_type,
                insurances.id,
                Split_part(member_name, ' ', 1) as member_first_name,
                Split_part(member_name, ' ', 2) as member_last_name,
                getdate() as created_at,
                getdate() as updated_at,
                True as active_ind,
                provider_tin
FROM   users
       JOIN staging_roster
         ON pcp_npi = provider_npi
       JOIN insurances
         ON CASE
              WHEN payor = 'hf' THEN 10524
              WHEN payor = 'wc' THEN 10527
              WHEN payor = 'ep' THEN 10528
            END = insurances.id
where            NOT EXISTS (SELECT 1
                            FROM   patients
                            WHERE  medicare_id = medicare_patient_id)
and provider_npi != '';
