with a as (select distinct pat_first_name, pat_last_name, dob, cast(enc_timestamp as date) as dos, cc_cpt_code, icd10_code from (SELECT pat_first_name, 
               pat_last_name, 
               cast(pat_date_of_birth as date) as dob, 
               enc_timestamp, 
               cc_cpt_code, 
               icd10_code, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by enc_timestamp desc) as rn
        FROM   t_patient 
               JOIN t_encounter 
                 ON pat_id = enc_patient_id 
               JOIN t_assessment 
                 ON enc_id = encounter_id 
	       JOIN t_chargecapture
                 ON enc_id = cc_enc_id
        WHERE  pat_delete_ind = 'N' 
               AND delete_ind = 'N' 
               AND cc_delete_ind = 'N'
               AND icd10_code IN ( 'Z68.51','Z68.52','Z68.53','Z68.54', 'Z71.3', 'Z02.5', 'Z71.82')
               AND cc_cpt_code IN ('99381','99391','99382','99392','99383','99393','99384','99394','99385','99395')
               AND Year(enc_timestamp) = 2019 
UNION ALL
SELECT pat_first_name, 
               pat_last_name, 
               cast(pat_date_of_birth as date) as dob, 
               enc_timestamp, 
               cc_cpt_code, 
               icd10_code, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by enc_timestamp desc) as rn
        FROM   t_patient 
               JOIN t_encounter 
                 ON pat_id = enc_patient_id 
               JOIN t_assessment 
                 ON enc_id = encounter_id 
	       JOIN t_chargecapture
                 ON enc_id = cc_enc_id
        WHERE  pat_delete_ind = 'N' 
               AND delete_ind = 'N' 
               AND cc_delete_ind = 'N'
               AND icd10_code IN ('Z71.3')
               AND cc_cpt_code in ('97802','97803','97804','G0270','G0270','G0447','S9449','S9452,S9470')
               AND Year(enc_timestamp) = 2019 
UNION ALL
SELECT pat_first_name, 
               pat_last_name, 
               cast(pat_date_of_birth as date) as dob, 
               enc_timestamp, 
               cc_cpt_code, 
               icd10_code, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by enc_timestamp desc) as rn
        FROM   t_patient 
               JOIN t_encounter 
                 ON pat_id = enc_patient_id 
               JOIN t_assessment 
                 ON enc_id = encounter_id 
	       JOIN t_chargecapture
                 ON enc_id = cc_enc_id
        WHERE  pat_delete_ind = 'N' 
               AND delete_ind = 'N' 
               AND cc_delete_ind = 'N'
               AND icd10_code IN ('Z02.5', 'Z71.82')
               AND cc_cpt_code in ('G0447', 'S9451')
               AND Year(enc_timestamp) = 2019) as t1 where rn = 1),
b as (select pat_first_name, pat_last_name, dob, count(*) as c from a group by pat_first_name, pat_last_name, dob having count(*) = 3)
select a.* from a where exists ( select 1 from b where a.pat_first_name = b.pat_first_name and a.pat_last_name = b.pat_last_name and a.dob = b.dob)

