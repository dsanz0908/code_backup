select pat_first_name, pat_last_name, dob, dos, cc_cpt_code from (SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob, 
                Cast(cc_date_of_service AS DATE) as dos, 
                cc_cpt_code, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by cc_date_of_service desc) as rn
FROM   t_chargecapture 
       JOIN t_patient 
         ON cc_patient_id = pat_id 
WHERE  cc_delete_ind = 'N' 
       AND cc_cpt_code IN ( '97802', '97803', '97804', 'G0270',
                            'G0271', 'G0447', 'S9449', 'S9452',
                            'S9470', 'G0447', 'S9451' ) 
       AND Year(cc_date_of_service) = 2019 ) as t1 where rn = 1
