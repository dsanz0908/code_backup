SELECT distinct pat_first_name, 
               pat_last_name, 
               pat_date_of_birth, 
               enc_timestamp, 
               cc_cpt_code, 
               icd10_code 
        FROM   t_patient 
               JOIN t_encounter 
                 ON pat_id = enc_patient_id 
               JOIN t_assessment 
                 ON enc_id = encounter_id 
               LEFT JOIN t_chargecapture 
                      ON enc_id = cc_enc_id 
        WHERE  pat_delete_ind = 'N' 
               AND delete_ind = 'N' 
               AND cc_delete_ind = 'N' 
               AND icd10_code IN ( 'Z68.51','Z68.52','Z68.53','Z68.54', 'Z71.3', 'Z02.5', 'Z71.82')
               AND cc_cpt_code IN ( '97802','97803','97804','G0270','G0270','G0447','S9449','S9452','S9470','G0447','S9451')
               AND Year(enc_timestamp) = 2019 
