SELECT DISTINCT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code,
                prov_npi,
                prov_fullname,
                prov_specialty_1
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       JOIN provider_master
         ON cc_rendering_provider_id = prov_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service >= '2019-01-01'
       AND cc_cpt_code IN ( '97802', '97803', '97804', 'G0270',
                            'G0271', 'G0447', 'S9449', 'S9452',
                            'S9470', 'G0447', 'S9451' )
       AND pat_date_of_birth BETWEEN '2002-01-01' AND '2016-12-31'
       AND pat_delete_ind = 'N'

