WITH cte_reliever 
     AS (SELECT patient_id, 
                Count(DISTINCT prescription_id) AS relievers 
         FROM   t_prescription 
         WHERE  delete_ind = 'N' 
                AND ( medication_generic_name LIKE '%Albuterol%' 
                       OR medication_generic_name LIKE '%Albuterol%' 
                       OR medication_name LIKE '%Albuterol%' 
                       OR medication_name LIKE '%Albuterol%' ) 
                AND Year(prescription_date) = 2019 
         GROUP  BY patient_id), 
     cte_controller 
     AS (SELECT patient_id, 
                Count(DISTINCT prescription_id) AS controller 
         FROM   t_prescription 
         WHERE  ( medication_name LIKE '%Dyphylline-guaifenesin%' 
                   OR medication_name LIKE '%Omalizumab%' 
                   OR medication_name LIKE '%Mepolizumab%' 
                   OR medication_name LIKE '%Reslizumab%' 
                   OR medication_name LIKE '%Budesonide-formoterol%' 
                   OR medication_name LIKE '%Fluticasone-salmeterol%' 
                   OR medication_name LIKE '%Fluticasone-vilanterol%' 
                   OR medication_name LIKE '%Mometasone-formoterol%' 
                   OR medication_name LIKE '%Beclomethasone%' 
                   OR medication_name LIKE '%Budesonide%' 
                   OR medication_name LIKE '%Ciclesonide%' 
                   OR medication_name LIKE '%Flunisolide%' 
                   OR medication_name LIKE '%Fluticasone%CFC%free%' 
                   OR medication_name LIKE '%Mometasone%' 
                   OR medication_name LIKE '%Montelukast%' 
                   OR medication_name LIKE '%Zafirlukast%' 
                   OR medication_name LIKE '%Zileuton%' 
                   OR medication_name LIKE '%Theophylline%' 
                   OR medication_generic_name LIKE '%Dyphylline-guaifenesin%' 
                   OR medication_generic_name LIKE '%Omalizumab%' 
                   OR medication_generic_name LIKE '%Mepolizumab%' 
                   OR medication_generic_name LIKE '%Reslizumab%' 
                   OR medication_generic_name LIKE '%Budesonide-formoterol%' 
                   OR medication_generic_name LIKE '%Fluticasone-salmeterol%' 
                   OR medication_generic_name LIKE '%Fluticasone-vilanterol%' 
                   OR medication_generic_name LIKE '%Mometasone-formoterol%' 
                   OR medication_generic_name LIKE '%Beclomethasone%' 
                   OR medication_generic_name LIKE '%Budesonide%' 
                   OR medication_generic_name LIKE '%Ciclesonide%' 
                   OR medication_generic_name LIKE '%Flunisolide%' 
                   OR medication_generic_name LIKE '%Fluticasone%CFC%free%' 
                   OR medication_generic_name LIKE '%Mometasone%' 
                   OR medication_generic_name LIKE '%Montelukast%' 
                   OR medication_generic_name LIKE '%Zafirlukast%' 
                   OR medication_generic_name LIKE '%Zileuton%' 
                   OR medication_generic_name LIKE '%Theophylline%' ) 
                AND Year(prescription_date) = 2019 
         GROUP  BY patient_id) 
SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                pat_date_of_birth 
FROM   cte_controller 
       LEFT JOIN cte_reliever 
              ON cte_controller.patient_id = cte_reliever.patient_id 
       JOIN t_patient 
         ON cte_controller.patient_id = pat_id 
WHERE  ( controller * 1.0 ) / ( controller + CASE WHEN relievers IS NULL THEN 0 ELSE relievers END ) >= .5 
