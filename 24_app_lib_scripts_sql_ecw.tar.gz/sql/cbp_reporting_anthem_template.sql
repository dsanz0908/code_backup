unload ($$
SELECT 'Medicaid'         AS Line_of_Business, 
       subscriber_id      AS MEMBER_ID, 
       NULL               AS medicare_hic, 
       orig_member_id     AS medicaid_id, 
       pat_last_name      AS member_last_name, 
       pat_first_name     AS member_first_name, 
       ' '                AS Address_1, 
       NULL               AS Address_2, 
       ''                 AS city, 
       ''                 AS state, 
       ''                 AS zipcode, 
       sex                AS gender, 
       to_char(dob, 'MM/DD/YYYY') as        dob, 
       provider_name, 
       provider_npi, 
       NULL               AS PROVIDER_TAX_ID, 
       NULL               AS PROVIDER_LICENSE_NUMBER, 
       provider_speciality, 
       NULL               AS PROVIDER_SPECIALITY_2, 
       to_char(vitals_date, 'MM/DD/YYYY')        AS DATE_OF_SERVICE, 
       icd10_code         AS ICD_PRIMARY, 
       icd10_code_1               AS ICD_SEC_1, 
       icd10_code_2               AS ICD_SEC_2, 
       icd10_code_3               AS ICD_SEC_3, 
       icd10_code_4               AS ICD_SEC_4, 
       icd10_code_5               AS ICD_SEC_5, 
       icd10_code_6               AS ICD_SEC_6, 
       icd10_code_7               AS ICD_SEC_7, 
       icd10_code_8               AS ICD_SEC_8, 
       cpt_code           AS PROCED_CODE, 
       ''                 AS CVX_CODE, 
       11                 AS PLACE_OF_SERVICE, 
       case when icd10_code like 'Z68%' then NULL else vitals_height  end    AS HEIGHT, 
       case when icd10_code like 'Z68%' then NULL else vitals_height_unit  end AS HEIGHT_MEASURING_UNIT, 
       case when icd10_code like 'Z68%' then NULL else vitals_weight  end      AS WEIGHT, 
       case when icd10_code like 'Z68%' then NULL else vitals_weight_unit  end AS WEIGHT_MEASURING_UNIT, 
       vitals_systolic    AS SYSTOLIC_CBP, 
       vitals_diastolic   AS DIASTOLIC_CBP, 
       NULL               AS MISC_1, 
       NULL               AS MISC_2 
FROM   cbp_reporting_new T1 
       INNER JOIN (SELECT member_medicaid_number, 
                          Max(empire_subscriber_id) AS subscriber_id 
                   FROM   payor.anthem_corinthian_all_rosters 
                   GROUP  BY member_medicaid_number 
                   UNION 
                   SELECT member_medicaid_number, 
                          Max(empire_subscriber_id) AS subscriber_id 
                   FROM   payor.empire_bcbs_healthplus_somos_all_roster 
                   GROUP  BY member_medicaid_number) t2 
               ON t1.orig_member_id = t2.member_medicaid_number 
WHERE  mco = 'NY State Claims' 
       AND vitals_systolic IS NOT NULL 
       AND vitals_diastolic IS NOT NULL 
       AND exists (select 1 from procedure_code_crosswalk where cpt_code = proc_code)
UNION 
SELECT 'Medicaid'         AS Line_of_Business, 
       subscriber_id      AS MEMBER_ID, 
       NULL               AS medicare_hic, 
       medicaid_number, 
       pat_last_name      AS member_last_name, 
       pat_first_name     AS member_first_name, 
       ' '                AS Address_1, 
       NULL               AS Address_2, 
       ''                 AS city, 
       ''                 AS state, 
       ''                 AS zipcode, 
       sex                AS gender, 
       to_char(dob, 'MM/DD/YYYY') as        dob, 
       provider_name, 
       provider_npi, 
       NULL               AS PROVIDER_TAX_ID, 
       NULL               AS PROVIDER_LICENSE_NUMBER, 
       provider_speciality, 
       NULL               AS PROVIDER_SPECIALITY_2, 
       to_char(vitals_date, 'MM/DD/YYYY')        AS DATE_OF_SERVICE, 
       icd10_code         AS ICD_PRIMARY, 
       icd10_code_1               AS ICD_SEC_1, 
       icd10_code_2               AS ICD_SEC_2, 
       icd10_code_3               AS ICD_SEC_3, 
       icd10_code_4               AS ICD_SEC_4, 
       icd10_code_5               AS ICD_SEC_5, 
       icd10_code_6               AS ICD_SEC_6, 
       icd10_code_7               AS ICD_SEC_7, 
       icd10_code_8               AS ICD_SEC_8, 
       cpt_code           AS PROCED_CODE, 
       ''                 AS CVX_CODE, 
       11                 AS PLACE_OF_SERVICE, 
       case when icd10_code like 'Z68%' then NULL else vitals_height  end      AS HEIGHT, 
       case when icd10_code like 'Z68%' then NULL else vitals_height_unit  end AS HEIGHT_MEASURING_UNIT, 
       case when icd10_code like 'Z68%' then NULL else vitals_weight  end      AS WEIGHT, 
       case when icd10_code like 'Z68%' then NULL else vitals_weight_unit  end AS WEIGHT_MEASURING_UNIT, 
       vitals_systolic    AS SYSTOLIC_CBP, 
       vitals_diastolic   AS DIASTOLIC_CBP, 
       NULL               AS MISC_1, 
       NULL               AS MISC_2 
FROM   cbp_reporting_new t1 
       INNER JOIN (SELECT Upper(Substring(member_first_name, 1, 3)) mem_f, 
                          Upper(Substring(member_last_name, 1, 3))  mem_l, 
                          member_dob                                mem_d, 
                          Max(empire_subscriber_id)                 AS 
                          subscriber_id, 
                          member_medicaid_number                    AS 
                          medicaid_number 
                   FROM   payor.anthem_corinthian_all_rosters 
                   GROUP  BY Upper(Substring(member_first_name, 1, 3)), 
                             Upper(Substring(member_last_name, 1, 3)), 
                             member_dob, 
                             member_medicaid_number 
                   UNION 
                   SELECT Upper(Substring(member_first_name, 1, 3)), 
                          Upper(Substring(member_last_name, 1, 3)), 
                          Cast(member_dob AS DATE), 
                          Max(empire_subscriber_id), 
                          member_medicaid_number AS medicaid_number 
                   FROM   payor.empire_bcbs_healthplus_somos_all_roster 
                   GROUP  BY Upper(Substring(member_first_name, 1, 3)), 
                             Upper(Substring(member_last_name, 1, 3)), 
                             Cast(member_dob AS DATE), 
                             member_medicaid_number) t2 
               ON Upper(Substring(pat_first_name, 1, 3)) = mem_f 
                  AND Upper(Substring(pat_last_name, 1, 3)) = mem_l 
                  AND Cast(dob AS DATE) = mem_d 
WHERE  mco IS NULL 
       AND vitals_systolic IS NOT NULL 
       AND vitals_diastolic IS NOT NULL 
       AND exists (select 1 from procedure_code_crosswalk where cpt_code = proc_code)$$)
TO 's3://acp-data/CBP/cbp_reporting_anthem_TODAY_' delimiter '|' gzip parallel OFF allowoverwrite iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
