set statement_timeout to 0;

-- Flag the provider which were moved to Somos.
/*
update temp_healthfirst_all_eligibility set moved_to_pilot_ind = 0
from ( select distinct provider_id,effective_period from temp_healthfirst_somos_all_eligibility ) t1,
  temp_healthfirst_all_eligibility t2
  where t1.provider_id = t2.provider_id
  and   t1.effective_period = t2.effective_period
  and   t2.COMPANY_NUMBER in ('30','34')
  and   t2.moved_to_pilot_ind = 1;

update temp_healthfirst_all_eligibility set moved_to_pilot_ind = 0
from ( select distinct provider_id,effective_period from temp_healthfirst_somos_all_eligibility ) t1,
  temp_healthfirst_all_eligibility t2
  where t1.provider_id = t2.provider_id
  and   t1.effective_period = t2.effective_period
  and   t2.COMPANY_NUMBER in ('42')
  and   t2.eligibility_category not in ('EP PLAN 1', 'EP PLAN 2','EP PLAN 3','EP PLAN 4' )
  and   t2.moved_to_pilot_ind = 1;

update temp_healthfirst_all_eligibility set moved_to_pilot_ind = 0
where moved_to_pilot_ind = 1 
and   not exists ( select 1 from temp_healthfirst_somos_all_eligibility t2 
	where temp_healthfirst_all_eligibility.provider_id = t2.provider_id 
	and temp_healthfirst_all_eligibility.effective_period = t2.effective_period );


update temp_healthfirst_all_claims set moved_to_pilot_ind = 0
from ( select distinct pcp_id,effective_period from temp_healthfirst_somos_all_claims ) t1,
  temp_healthfirst_all_claims t2
  where t1.pcp_id = t2.pcp_id
  and   t1.effective_period = t2.effective_period
  and   t2.COMPANY in ('30','34')
  and   t2.moved_to_pilot_ind = 1;

update temp_healthfirst_all_claims set moved_to_pilot_ind = 0
from ( select distinct pcp_id,effective_period from temp_healthfirst_somos_all_claims ) t1,
  temp_healthfirst_all_claims t2
  where t1.pcp_id = t2.pcp_id
  and   t1.effective_period = t2.effective_period
  and   t2.COMPANY in ('42')
  and   t2.eligibility_category not in ('EP PLAN 1', 'EP PLAN 2','EP PLAN 3','EP PLAN 4' )
  and   t2.moved_to_pilot_ind = 1;


update temp_healthfirst_all_claims set moved_to_pilot_ind = 0
where moved_to_pilot_ind = 1 
and   not exists ( select 1 from temp_healthfirst_somos_all_claims t2 
	where temp_healthfirst_all_claims.pcp_id = t2.pcp_id 
	and temp_healthfirst_all_claims.effective_period = t2.effective_period );


update temp_healthfirst_all_rx_claims set moved_to_pilot_ind = 0
from ( select distinct pcp_identifier,effective_period from temp_healthfirst_somos_all_rx_claims ) t1,
  temp_healthfirst_all_rx_claims t2
  where t1.pcp_identifier = t2.pcp_identifier
  and   t1.effective_period = t2.effective_period
  and   t2.COMPANY_number in ('30','34')
  and   t2.moved_to_pilot_ind = 1;

update temp_healthfirst_all_rx_claims set moved_to_pilot_ind = 0
from ( select distinct pcp_identifier,effective_period from temp_healthfirst_somos_all_rx_claims ) t1,
  temp_healthfirst_all_rx_claims t2
  where t1.pcp_identifier = t2.pcp_identifier
  and   t1.effective_period = t2.effective_period
  and   t2.COMPANY_number in ('42')
  and   t2.eligibility_category not in ('EP PLAN 1', 'EP PLAN 2','EP PLAN 3','EP PLAN 4' )
  and   t2.moved_to_pilot_ind = 1;

update temp_healthfirst_all_rx_claims set moved_to_pilot_ind = 0
where moved_to_pilot_ind = 1 
and   not exists ( select 1 from temp_healthfirst_somos_all_rx_claims t2 
	where temp_healthfirst_all_rx_claims.pcp_identifier = t2.pcp_identifier 
	and temp_healthfirst_all_rx_claims.effective_period = t2.effective_period );
*/
--DIM PROVIDER

INSERT INTO DIM_PROVIDER (PROVIDER_NPI,PROVIDER_FIRST_NAME,PROVIDER_LAST_NAME,PROVIDER_IPA,PROVIDER_TYPE,PROVIDER_FULL_NAME)
select provider_npi,max(upper(substring(split_part(t1.pcp_name,' ',1),1,1)) || lower(substring(split_part(t1.pcp_name,' ',1),2))) as firstname,
max(upper(substring(split_part(t1.pcp_name,' ',2),1,1)) || lower(substring(split_part(t1.pcp_name,' ',2),2)))  as lastname,max(provider_parent_code) as provider_ipa,
'PCP' as pcp_provider_type,
max(upper(substring(split_part(t1.pcp_name,' ',1),1,1)) || lower(substring(split_part(t1.pcp_name,' ',1),2))) || ' ' ||
max(upper(substring(split_part(t1.pcp_name,' ',2),1,1)) || lower(substring(split_part(t1.pcp_name,' ',2),2))) as pcp_full_name
from temp_healthfirst_all_eligibility t1
where not exists ( select 1 from dim_provider t2 where t1.provider_npi = t2.provider_npi )
and provider_parent_code = 'COR2'
and moved_to_pilot_ind = 0
group by provider_npi;


-- PCP AND SERVICE  PROVIDERS from claim
insert into dim_provider (provider_npi,provider_first_name,provider_last_name,provider_ipa,provider_full_name)
select '0000000000' as npi,'Unknown' as first_name,'Unknown' as last_name,'Unknown' as ipa, 'Unknown' as full_name
where not exists ( select 1 from dim_provider where npi = provider_npi);


INSERT INTO DIM_PROVIDER ( PROVIDER_NPI,PROVIDER_FIRST_NAME,PROVIDER_LAST_NAME,PROVIDER_IPA,PROVIDER_PCP_LICENSE_NO,PROVIDER_TYPE,PROVIDER_FULL_NAME)
select pcp_npi,max(pcp_first_name),max(pcp_last_name),min(pcp_ipa),max(pcp_license_number),min(provider_type),max(pcp_full_name)
  from (
select pcp_npi, max(upper(substring(split_part(pcp_name,' ',1),1,1)) || lower(substring(split_part(pcp_name,' ',1),2))) as pcp_first_name, 
                max(upper(substring(split_part(pcp_name,' ',2),1,1)) || lower(substring(split_part(pcp_name,' ',2),2)))  as pcp_last_name,
                max(pcp_parent_code) as pcp_ipa, 
                max(pcp_license_number) as pcp_license_number,
                'PCP' as provider_type,
                max(upper(substring(split_part(pcp_name,' ',1),1,1)) || lower(substring(split_part(pcp_name,' ',1),2)) || ' ' ||
                upper(substring(split_part(pcp_name,' ',2),1,1)) || lower(substring(split_part(pcp_name,' ',2),2))) as PCP_FULL_NAME
  from temp_healthfirst_all_claims
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER WHERE PROVIDER_NPI = PCP_NPI )
  and pcp_parent_code = 'COR2'
  group by pcp_npi
UNION  
select servicing_provider_npi_id, 
    max(upper(substring(split_part(servicing_provider_name,' ',1),1,1)) || lower(substring(split_part(servicing_provider_name,' ',1),2))) as service_provider_first_name,
    max(upper(substring(split_part(servicing_provider_name,' ',2),1,1)) || lower(substring(split_part(servicing_provider_name,' ',2),2))) as service_provider_last_name,
    'N/A' as provider_ipa,
    max(servicing_provider_license_number) as servicing_provider_license_no,
    'SERVICE' ,
    
    max( upper(substring(split_part(servicing_provider_name,' ',1),1,1)) || lower(substring(split_part(servicing_provider_name,' ',1),2)) || ' ' ||
    upper(substring(servicing_provider_name,charindex(' ',servicing_provider_name)+1,1)) || lower(substring(servicing_provider_name,charindex(' ',servicing_provider_name)+2))) as servicing_full_name
FROM temp_healthfirst_all_claims
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER WHERE PROVIDER_NPI = servicing_provider_npi_id )
AND SERVICING_PROVIDER_NPI_ID != ''
and pcp_parent_code = 'COR2'
GROUP BY SERVICING_PROVIDER_NPI_ID ) a
group by pcp_npi   ;


-- Attending & Referral Provider population
INSERT INTO DIM_PROVIDER(PROVIDER_NPI,PROVIDER_FIRST_NAME,PROVIDER_LAST_NAME,PROVIDER_IPA,PROVIDER_FULL_NAME,PROVIDER_TYPE)
SELECT  ATTENDING_PHYSICIAN_NPI_ID,
  MAX(UPPER(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',1),1,1)) ||  lower(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',1),2)) ) AS FIRST_NAME,
  MAX(UPPER(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',2),1,1)) ||  lower(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',2),2)) ) AS LAST_NAME,
  'N/A' as IPA,
  MAX(UPPER(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',1),1,1)) ||  lower(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',1),2)) || ' ' ||
  UPPER(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',2),1,1)) ||  lower(SUBSTRING(SPLIT_PART(ATTENDING_PROVIDER_NAME,' ',2),2)) ) AS FULL_NAME,
  'Attending' as provider_type
  FROM temp_healthfirst_ALL_CLAIMS 
  WHERE  NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER WHERE PROVIDER_NPI = ATTENDING_PHYSICIAN_NPI_ID )
  AND ATTENDING_PHYSICIAN_NPI_ID != ''
  and pcp_parent_code = 'COR2'
  GROUP BY ATTENDING_PHYSICIAN_NPI_ID;
  

INSERT INTO DIM_PROVIDER(PROVIDER_NPI,PROVIDER_FIRST_NAME,PROVIDER_LAST_NAME,PROVIDER_IPA,PROVIDER_FULL_NAME,PROVIDER_TYPE)
SELECT  REFERRING_PROVIDER_NPI,
  MAX(UPPER(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',1),1,1)) ||  lower(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',1),2)) ) AS FIRST_NAME,
  MAX(UPPER(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',2),1,1)) ||  lower(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',2),2)) ) AS LAST_NAME,
  'N/A' as IPA,
  MAX(UPPER(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',1),1,1)) ||  lower(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',1),2)) || ' ' ||
  UPPER(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',2),1,1)) ||  lower(SUBSTRING(SPLIT_PART(REFERRING_PROVIDER_NAME,' ',2),2)) ) AS FULL_NAME,
  'Referral' as provider_type
  FROM temp_healthfirst_ALL_CLAIMS 
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER WHERE PROVIDER_NPI = REFERRING_PROVIDER_NPI )
  AND REFERRING_PROVIDER_NPI != ''
  and pcp_parent_code = 'COR2'
  GROUP BY REFERRING_PROVIDER_NPI;

-- PRESCRIBER PROVIDER
INSERT INTO DIM_PROVIDER ( PROVIDER_NPI,PROVIDER_FIRST_NAME,PROVIDER_LAST_NAME,PROVIDER_IPA,PROVIDER_FULL_NAME,PROVIDER_TYPE)
SELECT PCP_NPI, MAX(UPPER(SUBSTRING(PRESCRIBER_NAME,1,1)) || LOWER(SUBSTRING(PRESCRIBER_NAME,2))) AS PRES_FIRST_NAME, 'Unknown' as PRES_LAST_NAME,
'N/A' AS IPA, 
MAX(UPPER(SUBSTRING(PRESCRIBER_NAME,1,1)) ||  LOWER(SUBSTRING(PRESCRIBER_NAME,2))) AS PRES_FULL_NAME,
'Prescriber' AS PROVIDER_TYPE
 FROM temp_healthfirst_ALL_RX_CLAIMS 
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER WHERE CASE WHEN PCP_NPI = '' THEN '0000000000' ELSE PCP_NPI END = PROVIDER_NPI )
and provider_parent_code = 'COR2'
GROUP BY PCP_NPI;


-- PCP AND SERVICE PROVIDER P_ORG DETAILS
insert into dim_provider_org_detail (provider_id,provider_org,provider_npi,hospital_name,practice_name,provider_address_1,provider_address_2,provider_city,provider_state,provider_zip,provider_tin)
SELECT T1.PROVIDER_ID,PORG,T1.PROVIDER_NPI,  
MAX(T1.hospital_name) AS HOSPITAL_NAME,
MAX(upper(pcp_address1)) as practice_name,
MAX(lower(pcp_address2)) as pcp_address1,
NULL as pcp_address2,
MAX(upper(substring(pcp_city,1,1))  || lower(substring(pcp_city,2))) as pcp_city,
MAX(upper(pcp_state)) as pcp_state,
MAX(SUBSTRING(pcp_zip,1,5)) AS ZIP,
MAX(CASE WHEN LEN(PROVIDER_TIN) < 9 THEN LPAD(PROVIDER_TIN,'0',9) ELSE PROVIDER_TIN END) AS TIN
FROM TEMP_HEALTHFIRST_ALL_ELIGIBILITY T1
INNER JOIN 
( SELECT DISTINCT PROVIDER_ID, SUBSTRING(SPLIT_PART(PROVIDER_ID,'-',2),2) AS PORG,PROVIDER_NPI FROM TEMP_HEALTHFIRST_ALL_ELIGIBILITY  WHERE provider_parent_code = 'COR2' and moved_to_pilot_ind = 0 ) T2
ON T1.PROVIDER_ID = T2.PROVIDER_ID
AND T1.PROVIDER_NPI = T2.PROVIDER_NPI
AND T1.PROVIDER_ORG = PORG
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER_ORG_DETAIL DP  WHERE T1.PROVIDER_ID = DP.PROVIDER_ID AND PORG = PROVIDER_ORG AND T1.PROVIDER_NPI = DP.PROVIDER_NPI )
and provider_parent_code = 'COR2'
and moved_to_pilot_ind = 0
GROUP BY PORG,T1.PROVIDER_ID,T1.PROVIDER_NPI;




insert into dim_provider_org_detail  ( provider_id,provider_org,provider_npi)
select '000000-000' as prov_id , '00' as prov_org, '0000000000' as prov_npi
where not exists ( select 1 from dim_provider_org_detail where prov_id = provider_id and prov_org = provider_org  and provider_npi = prov_npi);

-- pcp from claim
insert into dim_provider_org_detail (provider_id,provider_org,provider_npi,hospital_name,practice_name,provider_address_1,provider_address_2,provider_city,provider_state,provider_zip,provider_tin)
SELECT T1.PCP_ID,PORG,T1.PCP_NPI,  
MAX(T1.MEMBER_hospital_name) AS HOSPITAL_NAME,
NULL as practice_name,
MAX(lower(pcp_address)) as pcp_address1,
NULL as pcp_address2,
MAX(upper(substring(pcp_city,1,1))  || lower(substring(pcp_city,2))) as pcp_city,
MAX(upper(pcp_state)) as pcp_state,
MAX(SUBSTRING(pcp_zip,1,5)) AS ZIP,
MAX(CASE WHEN LEN(PCP_FED_NUMBER) < 9 THEN LPAD(PCP_FED_NUMBER,'0',9) ELSE PCP_FED_NUMBER END) AS TIN

FROM TEMP_HEALTHFIRST_ALL_CLAIMS T1
INNER JOIN 
( SELECT DISTINCT Pcp_ID, SUBSTRING(SPLIT_PART(Pcp_ID,'-',2),2) AS PORG,Pcp_NPI FROM TEMP_HEALTHFIRST_ALL_CLAIMS WHERE pcp_parent_code = 'COR2' and moved_to_pilot_ind = 0 ) T2
ON T1.PCP_ID = T2.PCP_ID
AND T1.PCP_NPI = T2.PCP_NPI
AND T1.MEMBER_PORG = PORG
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER_ORG_DETAIL DP WHERE T1.PCP_ID = DP.PROVIDER_ID AND T1.PCP_NPI = DP.PROVIDER_NPI )
and pcp_parent_code = 'COR2'
and moved_to_pilot_ind = 0
GROUP BY T1.PCP_ID,PORG,T1.PCP_NPI;

-- service provider from claim
insert into dim_provider_org_detail (provider_id,provider_org,provider_npi,hospital_name,practice_name,provider_address_1,provider_address_2,provider_city,provider_state,provider_zip,provider_tin)
SELECT T1.SERVICING_PROVIDER_ID,MAX(PORG),T1.SERVICING_PROVIDER_NPI_ID,  
MAX(T1.SERVICING_PROVIDER_hospital) AS HOSPITAL_NAME,
NULL as practice_name,
MAX(lower(SERVICING_PROVIDER_address)) as pcp_address1,
NULL as pcp_address2,
MAX(upper(substring(SERVICING_PROVIDER_city,1,1))  || lower(substring(SERVICING_PROVIDER_city,2))) as pcp_city,
MAX(upper(SERVICING_PROVIDER_state)) as pcp_state,
MAX(SUBSTRING(SERVICING_PROVIDER_zip,1,5)) AS ZIP,
MAX(CASE WHEN LEN(SERVICING_PROVIDER_FEDNUM) < 9 THEN LPAD(SERVICING_PROVIDER_FEDNUM,'0',9) ELSE SERVICING_PROVIDER_FEDNUM END) AS TIN

FROM TEMP_HEALTHFIRST_ALL_CLAIMS T1
INNER JOIN 
( SELECT DISTINCT SERVICING_PROVIDER_ID, 
 CASE WHEN SUBSTRING(ISNULL(SPLIT_PART(SERVICING_PROVIDER_ID,'-',2),''),1,1) ~ '[A-Z]' THEN  SUBSTRING(SPLIT_PART(SERVICING_PROVIDER_ID,'-',2),2) ELSE SPLIT_PART(SERVICING_PROVIDER_ID,'-',2) END AS PORG,
 SERVICING_PROVIDER_NPI_ID FROM TEMP_HEALTHFIRST_ALL_CLAIMS   WHERE pcp_parent_code = 'COR2' and moved_to_pilot_ind = 0 ) T2
ON T1.SERVICING_PROVIDER_ID = T2.SERVICING_PROVIDER_ID
AND T1.SERVICING_PROVIDER_NPI_ID = T2.SERVICING_PROVIDER_NPI_ID
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PROVIDER_ORG_DETAIL DP WHERE T1.SERVICING_PROVIDER_ID = DP.PROVIDER_ID AND T1.SERVICING_PROVIDER_NPI_ID = DP.PROVIDER_NPI )
and pcp_parent_code = 'COR2'
and moved_to_pilot_ind = 0
GROUP BY T1.SERVICING_PROVIDER_ID,T1.SERVICING_PROVIDER_NPI_ID ;





-- DIM_MEMBERSHIP
UPDATE DIM_MEMBERSHIP SET HEALTHFIRST_SRC_MEMBER_ID = T1.MEMBER_ID
	FROM TEMP_HEALTHFIRST_ALL_ELIGIBILITY T1, DIM_MEMBERSHIP T2
	WHERE CASE WHEN SUBSTRING(T1.MEMBER_ID,1,2) ~ ('[A-Z][A-Z]') AND SUBSTRING(T1.MEMBER_ID,LEN(T1.MEMBER_ID)-1) ~ ('[A-Z]') THEN T1.MEMBER_ID ELSE NULL END = T2.MEMBER_CIN
	AND HEALTHFIRST_SRC_MEMBER_ID IS NULL
	AND PROVIDER_PARENT_CODE = 'COR2';

INSERT INTO DIM_MEMBERSHIP ( HEALTHFIRST_SRC_MEMBER_ID,MEMBER_CIN,MEMBER_DOB,MEMBER_FIRST_NAME,MEMBER_LAST_NAME,MEMBER_ADDRESS_1,MEMBER_ADDRESS_2,MEMBER_CITY,MEMBER_STATE,MEMBER_ZIP,
            MEMBER_HOME_PHONE,MEMBER_OTHER_PHONE,MEMBER_EMAIL,MEMBER_SEX)
            
WITH CTE_RANK AS (
SELECT DISTINCT MEMBER_ID,MEMBER_DOB_NEW  AS DOB, RANK() OVER ( PARTITION BY MEMBER_ID ORDER BY RECEIVED_MONTH DESC ) AS RNK
FROM temp_healthfirst_ALL_ELIGIBILITY  where provider_parent_code = 'COR2' and moved_to_pilot_ind = 0)

select  T1.member_id as healthfirst_src_member_id,
        CASE WHEN SUBSTRING(T1.MEMBER_ID,1,2) ~ ('[A-Z][A-Z]') AND SUBSTRING(T1.MEMBER_ID,LEN(T1.MEMBER_ID)-1) ~ ('[A-Z]') THEN T1.MEMBER_ID ELSE NULL END AS CIN,
        DOB  ,
        max(upper(substring(member_first_name,1,1)) || lower(substring(member_first_name,2)) ) as first_name ,
        max(upper(substring(member_last_name,1,1)) || lower(substring(member_last_name,2)) ) as last_name ,
        max(lower(member_address_1)) as address_1,
        max(lower(member_address_2)) as  address_2,
        max(upper(substring(member_city,1,1)) || lower(substring(member_city,2))) as city, 
        max(upper(member_state)) as state , 
        max(substring(member_zip,1,5)) as zip, 
        max(member_home_phone) as home_phone , 
        max(member_other_phone) as other_phone,
        max(lower(member_email)) as email,
        max(upper(member_sex)) as sex 
from temp_healthfirst_all_eligibility  T1
INNER JOIN CTE_RANK CTE
ON T1.MEMBER_ID = CTE.MEMBER_ID
WHERE NOT EXISTS ( SELECT 1 FROM DIM_MEMBERSHIP T2 WHERE T1.MEMBER_ID = T2.HEALTHFIRST_SRC_MEMBER_ID  )
AND RNK = 1
and provider_parent_code = 'COR2'
and moved_to_pilot_ind = 0                    
group by T1.member_id,DOB;


-- members from the claim file

UPDATE DIM_MEMBERSHIP SET HEALTHFIRST_SRC_MEMBER_ID = T1.MEMBER_NUMBER
	FROM TEMP_HEALTHFIRST_SOMOS_ALL_CLAIMS T1, DIM_MEMBERSHIP T2
	WHERE CASE WHEN SUBSTRING(T1.MEMBER_NUMBER,1,2) ~ ('[A-Z][A-Z]') AND SUBSTRING(T1.MEMBER_NUMBER,LEN(T1.MEMBER_NUMBER)-1) ~ ('[A-Z]') THEN T1.MEMBER_NUMBER ELSE NULL END = T2.MEMBER_CIN
	AND HEALTHFIRST_SRC_MEMBER_ID IS NULL
	AND PCP_PARENT_CODE = 'COR2';

insert into dim_membership ( member_first_name,member_last_name,member_dob,member_cin,healthfirst_src_member_id,member_address_1)
WITH CTE_MEMBER AS (
select MAX(upper(substring(split_part(member_name,' ',1), 1,1)) || lower(substring(split_part(member_name,' ',1),2))) as member_first_name,
       MAX(upper(substring(split_part(member_name,' ',2), 1,1)) || lower(substring(split_part(member_name,' ',2),2))) as member_last_name,
       MAX(member_dob) as dob,
       MAX(CASE WHEN SUBSTRING(MEMBER_NUMBER,1,2) ~ ('[A-Z][A-Z]') AND SUBSTRING(MEMBER_NUMBER,LEN(MEMBER_NUMBER)-1) ~ ('[A-Z]') THEN MEMBER_NUMBER ELSE NULL END) AS CIN,
       MEMBER_NUMBER AS HEALTHFIRST_SRC_MEMBER_NUMBER
       FROM temp_healthfirst_all_claims
       where pcp_parent_code = 'COR2'
       GROUP BY MEMBER_NUMBER )
       
SELECT *,'' as member_address FROM CTE_MEMBER 
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_MEMBERSHIP WHERE MEMBER_CIN = CIN )
  AND   CIN IS NOT NULL
UNION
SELECT *,'' as member_address FROM CTE_MEMBER 
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_MEMBERSHIP WHERE HEALTHFIRST_SRC_MEMBER_ID = HEALTHFIRST_SRC_MEMBER_NUMBER )
  AND   CIN IS NULL;

-- dim membership from rx_claims file
UPDATE DIM_MEMBERSHIP SET HEALTHFIRST_SRC_MEMBER_ID = T1.MEMBER_NUMBER
	FROM TEMP_HEALTHFIRST_ALL_RX_CLAIMS T1, DIM_MEMBERSHIP T2
	WHERE CASE WHEN SUBSTRING(T1.MEMBER_NUMBER,1,2) ~ ('[A-Z][A-Z]') AND SUBSTRING(T1.MEMBER_NUMBER,LEN(T1.MEMBER_NUMBER)-1) ~ ('[A-Z]') THEN T1.MEMBER_NUMBER ELSE NULL END = T2.MEMBER_CIN
	AND HEALTHFIRST_SRC_MEMBER_ID IS NULL
	AND PROVIDER_PARENT_CODE = 'COR2';

insert into dim_membership ( member_first_name,member_last_name,member_dob,member_cin,healthfirst_src_member_id,member_home_phone,member_other_phone,member_sex,member_zip,member_address_1)
WITH CTE_MEMBER AS (
select MAX(upper(substring(split_part(member_name,' ',1), 1,1)) || lower(substring(split_part(member_name,' ',1),2))) as member_first_name,
       MAX(upper(substring(split_part(member_name,' ',2), 1,1)) || lower(substring(split_part(member_name,' ',2),2))) as member_last_name,
       MAX(member_dob) as dob,
       MAX(CASE WHEN SUBSTRING(MEMBER_NUMBER,1,2) ~ ('[A-Z][A-Z]') AND SUBSTRING(MEMBER_NUMBER,LEN(MEMBER_NUMBER)-1) ~ ('[A-Z]') THEN MEMBER_NUMBER ELSE NULL END) AS CIN,
       MEMBER_NUMBER AS HEALTHFIRST_SRC_MEMBER_NUMBER,
       MAX(MEMBER_HOME_PHONE) as member_home_phone,
       max(member_other_phone) as member_other_phone,
       max(member_sex) as member_sex,
       max(substring(member_zip_code,1,5)) as member_zip
       FROM temp_healthfirst_all_rx_claims
       where provider_parent_code = 'COR2'
       GROUP BY MEMBER_NUMBER )
       
SELECT *,'' as member_address FROM CTE_MEMBER 
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_MEMBERSHIP WHERE MEMBER_CIN = CIN )
  AND   CIN IS NOT NULL
UNION
SELECT *,'' as member_address FROM CTE_MEMBER 
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_MEMBERSHIP WHERE HEALTHFIRST_SRC_MEMBER_ID = HEALTHFIRST_SRC_MEMBER_NUMBER )
  AND   CIN IS NULL;

-- dim product from eligibility
INSERT INTO DIM_PRODUCT (LOB,PRODUCT_CD)
SELECT DISTINCT CASE WHEN ( ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                            'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                            'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN') OR PRODUCT = 'CHP') THEN 'MCD'
                     WHEN COMPANY_NUMBER IN ('30','34') THEN 'MCR'
                     ELSE 'N/A' END AS LOB,
CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
     WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4') THEN 'EP'
     WHEN ELIGIBILITY_CATEGORY IN ('GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                                  'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN' ) THEN PRODUCT
     WHEN PRODUCT = 'CHP' OR ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSI','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
     WHEN COMPANY_NUMBER = '30' THEN 'MCR Standard'
     WHEN COMPANY_NUMBER = '34' THEN 'MCR Dual'
     ELSE 'Unknown' END AS PRODUCT_CD
FROM TEMP_HEALTHFIRST_ALL_ELIGIBILITY
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PRODUCT 
                    WHERE LOB = CASE WHEN ( ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                                           'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                                           'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN') OR PRODUCT = 'CHP') THEN 'MCD'
                                     WHEN COMPANY_NUMBER IN ('30','34') THEN 'MCR'
                                     ELSE 'N/A' END
AND PRODUCT_CD = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
                                      WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4') THEN 'EP'
                                      WHEN ELIGIBILITY_CATEGORY IN ('GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                                      'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN' ) THEN PRODUCT
                                      WHEN PRODUCT = 'CHP' OR ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSI','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
                                      WHEN COMPANY_NUMBER = '30' THEN 'MCR Standard'
                                      WHEN COMPANY_NUMBER = '34' THEN 'MCR Dual'  ELSE 'Unknown' END )
and provider_parent_code = 'COR2'
and moved_to_pilot_ind = 0;

-- dim product from claim file

INSERT INTO DIM_PRODUCT (LOB,PRODUCT_CD)
SELECT DISTINCT CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                            'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                            'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN','PARTIAL SUBSIDY','FULL SUBSIDY','SELF-PAY') THEN 'MCD'
                     WHEN ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%'
                          THEN 'MCD'
                     WHEN COMPANY IN ('30','34') THEN 'MCR'
                     ELSE 'N/A' END AS LOB,
CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
     WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4') THEN 'EP'
     WHEN ELIGIBILITY_CATEGORY IN ('CHILDREN','NO CHILDREN' ) THEN 'FHP'
     WHEN ( ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%' OR ELIGIBILITY_CATEGORY LIKE 'GREEN%') THEN 'QHP'
     WHEN ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSIDY','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
     WHEN COMPANY = '30' THEN 'MCR Standard'
     WHEN COMPANY = '34' THEN 'MCR Dual'
     ELSE 'Unknown' END AS PRODUCT_CD
FROM TEMP_HEALTHFIRST_ALL_CLAIMS
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PRODUCT WHERE LOB = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                            'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                            'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN','PARTIAL SUBSIDY','FULL SUBSIDY','SELF-PAY') THEN 'MCD'
                     WHEN ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%'
                          THEN 'MCD'
                     WHEN COMPANY IN ('30','34') THEN 'MCR'
                     ELSE 'N/A' END
AND PRODUCT_CD = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
                     WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4') THEN 'EP'
                     WHEN ELIGIBILITY_CATEGORY IN ('CHILDREN','NO CHILDREN' ) THEN 'FHP'
                     WHEN ( ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%' OR ELIGIBILITY_CATEGORY LIKE 'GREEN%') THEN 'QHP'
                     WHEN ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSIDY','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
                     WHEN COMPANY = '30' THEN 'MCR Standard'
                     WHEN COMPANY = '34' THEN 'MCR Dual'
                     ELSE 'Unknown' END )
and pcp_parent_code = 'COR2'
and moved_to_pilot_ind = 0;
-- DIM_PRODUCT FROM RX_CLAIM
insert into dim_product(lob,product_cd)
select distinct CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                            'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                            'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN','PARTIAL SUBSIDY','FULL SUBSIDY','SELF-PAY','CHP') THEN 'MCD'
                     WHEN ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%'
                          THEN 'MCD'
                     WHEN COMPANY_NUMBER IN ('30','34') THEN 'MCR'
                     ELSE 'N/A' END AS LOB, 
CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
     WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4','CHP') THEN 'EP'
     WHEN ELIGIBILITY_CATEGORY IN ('CHILDREN','NO CHILDREN' ) THEN 'FHP'
     WHEN ( ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%' OR ELIGIBILITY_CATEGORY LIKE 'GREEN%') THEN 'QHP'
     WHEN ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSIDY','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
     WHEN COMPANY_NUMBER = '30' THEN 'MCR Standard'
     WHEN COMPANY_NUMBER = '34' THEN 'MCR Dual'
     ELSE 'Unknown' END AS PRODUCT_CD                     
from temp_healthfirst_all_rx_claims
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PRODUCT 
  WHERE LOB = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                            'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                            'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN','PARTIAL SUBSIDY','FULL SUBSIDY','SELF-PAY','CHP') THEN 'MCD'
                     WHEN ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%'
                          THEN 'MCD'
                     WHEN COMPANY_NUMBER IN ('30','34') THEN 'MCR'
                     ELSE 'N/A' END
   AND PRODUCT_CD = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
                         WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4','CHP') THEN 'EP'
                         WHEN ELIGIBILITY_CATEGORY IN ('CHILDREN','NO CHILDREN' ) THEN 'FHP'
                         WHEN ( ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%' OR ELIGIBILITY_CATEGORY LIKE 'GREEN%') THEN 'QHP'
                         WHEN ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSIDY','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
                         WHEN COMPANY_NUMBER = '30' THEN 'MCR Standard'
                         WHEN COMPANY_NUMBER = '34' THEN 'MCR Dual'
                         ELSE 'Unknown' END )
  and provider_parent_code = 'COR2'
  and moved_to_pilot_ind = 0 ;


-- Claims Fact Related queries
insert into dim_admission_source (admission_source_cd,admission_source_description )
select distinct case when admission_source = '' then 'N/A' else admission_source end as admission_source, case when admission_source = '' then 'UNKNOWN' else admission_source_description end as admission_source_description 
from temp_healthfirst_all_claims
where not exists ( select 1 from dim_admission_source where lower(admission_source_cd) = lower(case when admission_source = '' then 'N/A' else admission_source end) )
and pcp_parent_code = 'COR2';

INSERT INTO DIM_ADMIT_TYPE ( ADMIT_TYPE )
SELECT DISTINCT CASE WHEN ADMIT_TYPE = '' THEN 'N/A' ELSE ADMIT_TYPE END AS ADMITTYPE FROM temp_healthfirst_ALL_CLAIMS T1
WHERE NOT EXISTS ( SELECT 1 FROM DIM_ADMIT_TYPE T2 WHERE lower(T2.ADMIT_TYPE) = lower(CASE WHEN T1.ADMIT_TYPE = '' THEN 'N/A' ELSE T1.ADMIT_TYPE END) )
and pcp_parent_code = 'COR2';

INSERT INTO DIM_CLAIM_TYPE ( CLAIM_TYPE)
SELECT DISTINCT CASE WHEN CLAIM_TYPE = '' THEN 'N/A' ELSE CLAIM_TYPE END AS CLAIMTYPE 
FROM temp_healthfirst_ALL_CLAIMS T1
WHERE NOT EXISTS ( SELECT 1 FROM DIM_CLAIM_TYPE T2 WHERE lower(T2.CLAIM_TYPE) = lower(CASE WHEN T1.CLAIM_TYPE = '' THEN 'N/A' ELSE T1.CLAIM_TYPE END) )
and pcp_parent_code = 'COR2';


INSERT INTO DIM_PLACE_OF_SERVICE(PLACE_OF_SERVICE_CD,PLACE_OF_SERVICE_DESCRIPTION )
SELECT DISTINCT CASE WHEN PLACE_OF_SERVICE_CODE = '' THEN 'N/A' ELSE PLACE_OF_SERVICE_CODE END AS PLACE_OF_SERVICE_CODE, 
                CASE WHEN PLACE_OF_SERVICE_CODE = '' THEN 'UNKNOWN' ELSE PLACE_OF_SERVICE END AS PLACE_OF_SERVICE 
                FROM temp_healthfirst_ALL_CLAIMS 
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PLACE_OF_SERVICE WHERE lower(PLACE_OF_SERVICE_CD) = lower(CASE WHEN PLACE_OF_SERVICE_CODE = '' THEN 'N/A' ELSE PLACE_OF_SERVICE_CODE END))
and pcp_parent_code = 'COR2'
UNION
SELECT 'N/A' AS PLACE_OF_SERVICE_CODE,'UNKNOWN'  AS PLACE_OF_SERVICE
WHERE NOT EXISTS ( SELECT 1 FROM DIM_PLACE_OF_SERVICE WHERE PLACE_OF_SERVICE_CD = CASE WHEN PLACE_OF_SERVICE_CODE = '' THEN 'N/A' ELSE PLACE_OF_SERVICE_CODE END );


INSERT INTO DIM_SERVICE_TYPE ( SERVICE_CD,SERVICE_CD_DESCRIPTION,SERVICE_CD_TYPE )
SELECT DISTINCT SERVICE_CODE,max(SUBSTRING(SERVICE_CODE_DESCRIPTION,1,200)) as service_code_description,max(SERVICE_TYPE) as service_type
  FROM temp_healthfirst_ALL_CLAIMS
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_SERVICE_TYPE WHERE lower(SERVICE_CD) = lower(SERVICE_CODE) )
  and pcp_parent_code = 'COR2'
  group by service_code
UNION
SELECT 'N/A' AS SERVICE_CODE,'UNKNOWN' AS SERVICE_CODE_DESCRIPTION,'N/A' AS SERVICE_TYPE
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_SERVICE_TYPE WHERE SERVICE_CD = SERVICE_CODE );
  
INSERT INTO DIM_UMR_CATEGORY (UMR_CATEGORY_CD,UMR_CATEGORY_DESCRIPTION)
SELECT DISTINCT UMR_CATEGORY,UMR_CATEGORY_DESCRIPTION 
  FROM temp_healthfirst_ALL_CLAIMS
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_UMR_CATEGORY WHERE lower(UMR_CATEGORY_CD) = lower(UMR_CATEGORY) )
  and pcp_parent_code = 'COR2'
UNION  
SELECT 'N/A' AS UMR_CATEGORY, 'UNKNOWN' AS UMR_CATEGORY_DESCRIPTION
  WHERE NOT EXISTS ( SELECT 1 FROM DIM_UMR_CATEGORY WHERE UMR_CATEGORY_CD = UMR_CATEGORY );

-- Dim Codes
INSERT INTO DIM_CODES ( CODE,CODE_DESCRIPTION,CODE_TYPE )
WITH CTE_CODES AS (
select primary_diagnosis as diagnosis_cd,max(primary_diagnosis_description) as diagnosis_description from (
select distinct primary_diagnosis, primary_diagnosis_description  from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_2,diag_description_2 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_3,diag_description_3 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_4,diag_description_4 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_5,diag_description_5 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_6,diag_description_6 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_7,diag_description_7 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_8,diag_description_8 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_9,diag_description_9 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_10,diag_description_10 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_11,diag_description_11 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_12,diag_description_12 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_13,diag_description_13 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_14,diag_description_14 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_15,diag_description_15 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_16,diag_description_15 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_17,diag_description_17 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2'
union
select distinct diagnosis_code_18,diag_description_18 from temp_healthfirst_all_claims where pcp_parent_code = 'COR2' ) a
where primary_diagnosis != ''
group by primary_diagnosis )

SELECT diagnosis_cd,diagnosis_description,'ICD' as code_type from cte_codes
where not exists ( select 1 from dim_codes where code = diagnosis_cd );


INSERT INTO DIM_CODES ( CODE,CODE_DESCRIPTION,CODE_TYPE)
WITH CTE_PROC AS (
SELECT PROC_CODE,MAX(PROC_DESCRIPTION) AS PROC_DESCRIPTION FROM (
select DISTINCT PRINCIPLE_PROCEDURE_CODE AS PROC_CODE,PRIMARY_PROCEDURE_CODE_DESCRIPTION AS PROC_DESCRIPTION FROM temp_healthfirst_ALL_CLAIMS  where pcp_parent_code = 'COR2'
UNION 
SELECT DISTINCT SECONDARY_PROCEDURE_CODE,PROC_DESCRIPTION_2 FROM temp_healthfirst_ALL_CLAIMS where pcp_parent_code = 'COR2'
UNION
SELECT DISTINCT  TERTIARY_PROCEDURE_CODE,PROC_DESCRIPTION_3 FROM temp_healthfirst_ALL_CLAIMS where pcp_parent_code = 'COR2'
UNION
select DISTINCT QUATERNARY_PROCEDURE_CODE,PROC_DESCRIPTION_4 FROM temp_healthfirst_ALL_CLAIMS where pcp_parent_code = 'COR2'
UNION
select DISTINCT FIFTH_PROCEDURE_CODE,PROC_DESCRIPTION_5 FROM temp_healthfirst_ALL_CLAIMS where pcp_parent_code = 'COR2'
UNION
SELECT DISTINCT SIXTH_PROCEDURE_CODE,PROC_DESCRIPTION_6 FROM temp_healthfirst_ALL_CLAIMS  where pcp_parent_code = 'COR2'
UNION
SELECT 'OPT1ZZZ','Unknown') A
WHERE PROC_CODE != ''

GROUP BY PROC_CODE )

select PROC_CODE,PROC_DESCRIPTION,'PROC' 
FROM CTE_PROC
WHERE NOT EXISTS ( SELECT 1 FROM DIM_CODES WHERE CODE = PROC_CODE );


INSERT INTO DIM_CODES (CODE,CODE_DESCRIPTION,CODE_TYPE)
select distinct revenue_code,revenue_code_description,'REVENUE' AS CD_TYPE from temp_healthfirst_all_claims 
WHERE NOT EXISTS ( SELECT 1 FROM DIM_CODES WHERE CODE = revenue_code and code_type = 'REVENUE' )
AND REVENUE_CODE != ''
and pcp_parent_code = 'COR2'
UNION 
SELECT '000' AS rev_code, 'Unknown' as rev_code_description, 'REVENUE'
where not exists ( select 1 from dim_codes where code = rev_code and code_type = 'REVENUE' );


-- dim pharmacy_class from rx_file  
insert into dim_pharmacy_class (pharmacy_class_cd,pharmacy_class_description )
select distinct pharmacy_class,pharmacy_class_description from temp_healthfirst_all_rx_claims
where not exists ( select 1 from dim_pharmacy_class where pharmacy_class_cd = pharmacy_class )
and provider_parent_code = 'COR2';


-- dim_therapeutic_class from rx_file
insert into dim_therapeutic_class ( therapeutic_class_cd  )
select distinct case when specific_therapeutic_class_code = '' then 'N/A' else specific_therapeutic_class_code end 
from temp_healthfirst_all_rx_claims
where not exists ( select 1 from dim_therapeutic_class where therapeutic_class_cd = case when specific_therapeutic_class_code = '' then 'N/A' else specific_therapeutic_class_code end )
and provider_parent_code = 'COR2';

-- dim_pharmacy from rx_claim file
insert into dim_pharmacy ( pharmacy_cd,pharmacy_name,pharmacy_npi,pharmacy_phone_number )
select distinct MAX(pharmacy_id),MAX(pharmacy_name),pharmacy_npi,
MAX(substring(pharmacy_phone_number,1,3) || '-' || substring(pharmacy_phone_number,4,3) || '-' || substring(pharmacy_phone_number,7) )
from temp_healthfirst_all_rx_claims T1
where not exists ( select 1 from dim_pharmacy T2 where T1.pharmacy_npi = t2.pharmacy_npi )
and provider_parent_code = 'COR2'
group by pharmacy_npi;



-- dim drug from rx_claim file
insert into dim_drug_details ( ndc_number,drug_name,gpi0_value,gpi2_value,gpi4_value,gpi6_value,gpi8_value)
select distinct ndc_code_or_id_of_prod_or_svc_provided,max(drug_name),max(gpi0_category),max(gpi2_drug_group_desc),max(gpi4_drug_class_desc),max(gpi6_drug_subclass_desc),max(gpi8_drug_name_desc)
from temp_healthfirst_all_rx_claims t1
where not exists ( select 1 from dim_drug_details t2 where t1.ndc_code_or_id_of_prod_or_svc_provided = t2.ndc_number )
and provider_parent_code = 'COR2'
group by ndc_code_or_id_of_prod_or_svc_provided;

-- Fact Table related Queries
DELETE FACT_ELIGIBILITY WHERE SOURCE = 'Healthfirst Corinthian';                    
insert into fact_eligibility (date_id,local_member_id,local_product_id,local_provider_id,local_provider_org_id,membership_month_count,source,file_name,effective_date)

with cte_min_effective_dates
as (
select distinct effective_period as min_effective_dates 
  from temp_healthfirst_all_eligibility
  where  provider_parent_code = 'COR2'
  and moved_to_pilot_ind = 0
   --order by 1 
   ) ,
cte_correct_dates
as (
select max(received_month) as max_received_month, min_effective_dates as effective_date, trunc(dateadd(month,-1,effective_date)) as prev_effective_date,
  trunc(dateadd(month,1,effective_date)) as next_effective_date
  from temp_healthfirst_all_eligibility m1
  INNER JOIN cte_min_effective_dates  m2
  ON m1.effective_period = m2.min_effective_dates
  where  provider_parent_code = 'COR2'
  and moved_to_pilot_ind = 0
  group by min_effective_dates  )

    select t1.date_id,t2.local_member_id,t6.local_product_id,t4.local_provider_id,t5.local_provider_org_id,sum(member_month) as membership_month,'Healthfirst Corinthian' as source,filename,t1.the_date
    from temp_healthfirst_all_eligibility elg
    inner join  cte_correct_dates cte
    on elg.effective_period = cte.effective_date
    and elg.received_month = cte.max_received_month
    inner join dim_date t1
    on elg.effective_period = t1.the_date
    inner join dim_membership t2
    on elg.member_id = t2.healthfirst_src_member_id
    --and case when len(elg.member_dob) > 4 then cast(elg.member_dob as date) else cast('19000101' as date) end = t2.member_dob
    inner join  dim_provider t4
    on elg.provider_npi = t4.provider_npi  
    inner join dim_provider_org_detail t5
    on elg.provider_id = t5.provider_id
    and elg.provider_npi = t5.provider_npi
    inner join dim_product t6
    on  t6.lob = CASE WHEN ( ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                                           'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                                           'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN') OR PRODUCT = 'CHP') THEN 'MCD'
                                     WHEN COMPANY_NUMBER IN ('30','34') THEN 'MCR'
                                     ELSE 'N/A' END
    and t6.product_cd = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
                                      WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4') THEN 'EP'
                                      WHEN ELIGIBILITY_CATEGORY IN ('GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                                      'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN' ) THEN PRODUCT
                                      WHEN PRODUCT = 'CHP' OR ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSI','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
                                      WHEN COMPANY_NUMBER = '30' THEN 'MCR Standard'
                                      WHEN COMPANY_NUMBER = '34' THEN 'MCR Dual'  ELSE 'Unknown' END
    where provider_parent_code = 'COR2'
    and moved_to_pilot_ind = 0
    group by t1.date_id,t2.local_member_id,t6.local_product_id,t4.local_provider_id,t5.local_provider_org_id,elg.provider_id,elg.provider_org,filename,t1.the_date;


-- Populate fact_claims table
DELETE FACT_CLAIMS WHERE SOURCE = 'Healthfirst Corinthian';                    
INSERT INTO fact_claims ( CLAIM_ID,CLAIM_LINE_NO,LOCAL_MEMBER_ID,LOCAL_PCP_PROVIDER_ID,LOCAL_SERVICE_PROVIDER_ID,LOCAL_PCP_ORG_ID,LOCAL_SERVICE_ORG_ID,LOCAL_PRODUCT_ID,
            ACCT_PAYABLE_DATE_ID,SERVICE_START_DATE_ID,SERVICE_END_DATE_ID,LOCAL_PLACE_OF_SERVICE_ID,LOCAL_CLAIM_TYPE_ID,LOCAL_DISCHARGE_STATUS_ID,LOCAL_UMR_CATEGORY_ID,
            LOCAL_ATTEND_PROVIDER_ID,LOCAL_REF_PROVIDER_ID,ACCT_PAYABLE_AMOUNT,NET_ALLOWED_AMOUNT,ALLOWED_AMOUNT,TO_PAY_AMOUNT,BILLED_AMOUNT,COPAY_AMOUNT,COINSURANCE_AMOUNT,
            DEDUCTIBLE_AMOUNT,NON_COVERED_AMOUNT,SERVICE_HOLD_CD_1,SERVICE_HOLD_CD_2,SERVICE_HOLD_CD_3,SERVICE_HOLD_CD_4,SERVICE_HOLD_CD_5,IP_OP_IND,CPT_CODE,CPT_MODIFIER_1,
            CPT_MODIFIER_2,CPT_MODIFIER_3,CPT_MODIFIER_4,MODIFIER_CODE_1,MODIFIER_CODE_2,MODIFIER_CODE_3,MODIFIER_CODE_4,VENDOR_CODE,VENDOR_TAX_CODE,PROVIDER_RISK,PCP_PROV_TYPE_CODE,
            PREMIUM_GROUP,IP_ADVANCE_IND,CAPITATED_CLAIM_IND,UMR_GROUP,CARE_TYPE,SERVICE_WEIGHT,BILL_TYPE,FORM_CODE,SERVICE_LINE_STATUS,REVERSAL_IND,REVERSED_FROM,REVERSED_TO,
            ADMIT_DATE,ADMIT_SOURCE,PAT_ACCT_NUMBER,DISCHARGE_DATE,AVG_SERVICE_LEN,COORDINATION_BENEFITS,DRG,DRG_DESCRIPTION,SOURCE,effective_date_id,
	    ACCT_PAYABLE_DATE,SERVICE_START_DATE,SERVICE_END_DATE,EFFECTIVE_DATE,FILE_NAME)

with cte_correct_claim as (
  select max(received_month) as max_received_month,claim_id ct_claim_id,line_no ct_line_no
  from temp_healthfirst_all_claims
  where pcp_parent_code = 'COR2'
  and   moved_to_pilot_ind = 0
  group by claim_id,line_no ) 

select claim_id,coalesce(line_no,0) as line_no,t5.local_member_id,t3.local_provider_id,srv_prov.local_provider_id,t4.local_provider_org_id,srv_prov_org.local_provider_org_id,t12.local_product_id,
        acct_pay_dt.date_id,srv_start_dt.date_id,srv_end_dt.date_id,t8.local_place_of_service_id,t6.local_claim_type_id,
        COALESCE(t9.local_discharge_status_id, (SELECT LOCAL_DISCHARGE_STATUS_ID FROM DIM_DISCHARGE_STATUS WHERE DISCHARGE_CD = 'N/A')), t10.local_umr_category_id,
        att_prov.local_provider_id,ref_prov.local_provider_id,ap_transaction_amount,net_allowed_amount,allowed_amount,to_pay_amount,billed_amount,copay_amount,coinsurance_amount ,
        deductible_amount,non_covered_amount,service_hold_code_1,service_hold_code_2,service_hold_code_3,service_hold_code_4,service_hold_code_5,ip_op_indicator,cpt_code ,
        cpt_modifier_1,cpt_modifier_2,cpt_modifier_3,cpt_modifier_4,modifier_code_1,modifier_code_2,modifier_code_3,modifier_code_4,vendor,vendor_tax_id,provider_risk ,
        pcp_prov_type_code,premium_group,inpatient_advance_indicator,capitated_claim_indicator,umr_group,care_type,service_weight,bill_type,form_code,service_line_status  ,
        reversal_indicator,case when reversed_from = '' then NULL ELSE CAST(reversed_from as smallint) end as reversed_from , 
        case when reversed_to = '' then NULL else CAST(reversed_to as smallint) end as reversed_to,admission_date,admission_source,patient_account_number,discharge_date  ,
        average_length_service,case when coordination_benefits = '' then NULL else cast(coordination_benefits as decimal(10,2)) end,drg,drg_description , 'Healthfirst Corinthian' as source,eff_dt.date_id,
	acct_payable_transaction_date,start_date,end_date,effective_period,filename
        
from 
  temp_healthfirst_all_claims  t1
  inner join 
  cte_correct_claim t2
  on t1.claim_id = t2.ct_claim_id
  and ( t1.line_no = t2.ct_line_no or t1.line_no is null )
  and t1.received_month = t2.max_received_month
  inner join dim_provider t3
  on t1.pcp_npi = t3.provider_npi
  inner join dim_provider_org_detail t4
  on t1.pcp_id = t4.provider_id
  and t1.pcp_npi = t4.provider_npi
  inner join dim_membership t5
  on t1.member_number = t5.healthfirst_src_member_id
  inner join dim_claim_type t6
  on case when t1.claim_type = '' then 'N/A' ELSE t1.claim_type END = t6.claim_type
  inner join dim_admit_type t7
  on case when t1.admit_type = '' then 'N/A' else t1.admit_type END = t7.admit_type
  inner join dim_place_of_service t8
  on t1.place_of_service_code = t8.place_of_service_cd
  inner join dim_date acct_pay_dt
  on acct_payable_transaction_date = acct_pay_dt.the_date
  inner join dim_date srv_start_dt
  on t1.start_date = srv_start_dt.the_date
  inner join dim_date srv_end_dt
  on t1.end_date = srv_end_dt.the_date
  left outer join dim_discharge_status t9
  on case when t1.discharge_status = ''  then 'N/A' else t1.discharge_status end = discharge_cd
  inner join dim_umr_category t10
  on t1.umr_category = umr_category_cd
  inner join dim_service_type t11
  on case when t1.service_code = '' then 'N/A' else t1.service_code end = service_cd
  inner join dim_provider srv_prov
  on case when t1.servicing_provider_npi_id = '' then '0000000000' else t1.servicing_provider_npi_id end = srv_prov.provider_npi
  inner join dim_provider_org_detail srv_prov_org
  on t1.servicing_provider_npi_id  = srv_prov_org.provider_npi
  and t1.servicing_provider_id  = srv_prov_org.provider_id
  inner join dim_product t12
      ON t12.product_cd = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
     WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4') THEN 'EP'
     WHEN ELIGIBILITY_CATEGORY IN ('CHILDREN','NO CHILDREN' ) THEN 'FHP'
     WHEN ( ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%' OR ELIGIBILITY_CATEGORY LIKE 'GREEN%') THEN 'QHP'
     WHEN ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSIDY','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
     WHEN COMPANY = '30' THEN 'MCR Standard'
     WHEN COMPANY = '34' THEN 'MCR Dual'
     ELSE 'Unknown' END
      AND T12.LOB = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                            'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                            'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN','PARTIAL SUBSIDY','FULL SUBSIDY','SELF-PAY') THEN 'MCD'
                     WHEN ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%'
                          THEN 'MCD'
                     WHEN COMPANY IN ('30','34') THEN 'MCR'
                     ELSE 'N/A' END
  inner join dim_provider att_prov
  on case when t1.attending_physician_npi_id = '' then '0000000000' else t1.attending_physician_npi_id end = att_prov.provider_npi
 inner join dim_provider ref_prov
  on case when t1.referring_provider_npi = '' then '0000000000' else t1.referring_provider_npi end = ref_prov.provider_npi
 inner join dim_date eff_dt
 on t1.effective_period = eff_dt.the_date
 where pcp_parent_code = 'COR2'
 and moved_to_pilot_ind = 0;

update fact_claims set local_service_id = t1.local_service_id
  from dim_service_type t1, temp_healthfirst_all_claims t2, fact_claims t3,
  ( select max(received_month) as max_received_month,claim_id ct_claim_id,line_no ct_line_no
  from temp_healthfirst_all_claims
  group by claim_id,line_no  ) t4
  where t1.service_cd = t2.service_code
  and   t2.claim_id = t3.claim_id
  and   t2.line_no =  t3.claim_line_no
  and   t2.claim_id = t4.ct_claim_id
  and   t2.line_no = t4.ct_line_no
  and   t2.received_month = max_received_month
  and   t3.source = 'Healthfirst Corinthian';

UPDATE FACT_CLAIMS SET LOCAL_CATEGORY_OF_SERVICE_ID = T1.LOCAL_CATEGORY_OF_SERVICE_ID
  FROM DIM_CATEGORY_OF_SERVICE T1, FACT_CLAIMS T2, DIM_PLACE_OF_SERVICE T3
  WHERE T2.LOCAL_PLACE_OF_SERVICE_ID = T3.LOCAL_PLACE_OF_SERVICE_ID
  AND   CATEGORY_OF_SERVICE_DESCRIPTION = CASE WHEN FORM_CODE = 'U' AND PLACE_OF_SERVICE_CD = '21' THEN 'Inpatient Hospital'
                     WHEN FORM_CODE = 'U' AND PLACE_OF_SERVICE_CD IN ('22','24') THEN 'Outpatient Hospital'
                     WHEN FORM_CODE = 'U' AND PLACE_OF_SERVICE_CD = '23' THEN 'ER Visit'
                     WHEN FORM_CODE = 'H' THEN 'Physician' ELSE 'Other Charges' END
   AND SOURCE = 'Healthfirst Corinthian';



-- Pharmacy Fact table
CREATE TEMPORARY TABLE TEMP_RX AS 
with cte_correct_claim 
as ( select claim_id,max(received_month) as max_received_month from temp_healthfirst_all_rx_claims  group by claim_id )

select  LOCAL_PRODUCT_ID,PCP_IDENTIFIER,t1.CLAIM_ID,MEMBER_NUMBER,SERVICE_DATE,CYCLE_DATE,PHARMACY_CLASS,specific_therapeutic_class_code,PHARMACY_NPI,
PCP_NPI AS PRESCRIBER_NPI,DRUG_NAME,AVG_WHOLESALE_PRICE,DRUG_TYPE,CASE WHEN FORMULARY_FLAG = 'Formulary' THEN 1 ELSE 0 END AS FORMULARY_IND,
CAST(GENERIC_FILLED AS INT) as GENERIC_FILL_IND,CLAIMS_PAID_CODE as CLAIMS_PAID_CD,PRESCRIPTION_COST,REFILL_NUMBER,PRESCRIBED_DAILY_SUPPLY,PRESCRIPTION_FILLED,PRESCRIPTION_PROCESSED,topay_Amount as TO_PAY_AMOUNT,
PRESCRIBED_DAYS_SUPPLY,NDC_CODE_OR_ID_OF_PROD_OR_SVC_PROVIDED as NDC_CODE,PRESCRIPTION_NUMBER,
SPECIALTY_RX_CLAIM_INDICATOR as SPECIALTY_RX_CLAIM_IND,'Healthfirst Corinthian' as SOURCE ,EFFECTIVE_PERIOD,FILENAME

from temp_healthfirst_all_rx_claims  t1
INNER JOIN CTE_CORRECT_CLAIM T2
ON T1.CLAIM_ID = T2.CLAIM_ID
AND T1.RECEIVED_MONTH = T2.MAX_RECEIVED_MONTH
INNER JOIN dim_product t3
on t3.lob = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME','EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4',
                            'GOLD AD DENTV','BRONZE AD DEN','GOLD','PLATINUM','SILVER 100-15','BRONZE NA','CHILDREN','SILVER 200-25','PLATINUM AD D','SILVER',
                            'BRONZE','SILVER AD DEN','SILVER 150-20','GREEN','NO CHILDREN','PARTIAL SUBSIDY','FULL SUBSIDY','SELF-PAY','CHP') THEN 'MCD'
                     WHEN ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%'
                          THEN 'MCD'
                     WHEN COMPANY_NUMBER IN ('30','34') THEN 'MCR'
                     ELSE 'N/A' END
and  t3.product_cd = CASE WHEN ELIGIBILITY_CATEGORY IN ('TANF ADULTS','TANF CHILDREN','SSI','HARP','EP','NURSING HOME') THEN ELIGIBILITY_CATEGORY
     WHEN ELIGIBILITY_CATEGORY IN ('EP PLAN 1','EP PLAN 2','EP PLAN 3','EP PLAN 4','CHP') THEN 'EP'
     WHEN ELIGIBILITY_CATEGORY IN ('CHILDREN','NO CHILDREN' ) THEN 'FHP'
     WHEN ( ELIGIBILITY_CATEGORY LIKE 'SILVER%' OR ELIGIBILITY_CATEGORY LIKE 'GOLD%' OR ELIGIBILITY_CATEGORY LIKE 'BRONZE%' OR ELIGIBILITY_CATEGORY LIKE 'PLATINUM%' OR ELIGIBILITY_CATEGORY LIKE 'GREEN%') THEN 'QHP'
     WHEN ELIGIBILITY_CATEGORY IN ('PARTIAL SUBSIDY','SELF-PAY','FULL SUBSIDY' ) THEN 'CHP'
     WHEN COMPANY_NUMBER = '30' THEN 'MCR Standard'
     WHEN COMPANY_NUMBER = '34' THEN 'MCR Dual'
     ELSE 'Unknown' END
WHERE MOVED_TO_PILOT_IND = 0
AND PROVIDER_PARENT_CODE = 'COR2';


ALTER TABLE TEMP_RX ADD LOCAL_PCP_PROV_ID INT;
ALTER TABLE TEMP_RX ADD LOCAL_PROVIDER_ORG_ID INT;
ALTER TABLE TEMP_RX ADD LOCAL_MEMBER_ID INT;
ALTER TABLE TEMP_RX ADD SERVICE_DATE_ID INT;
ALTER TABLE TEMP_RX ADD ACCOUNTING_DATE_ID INT;
ALTER TABLE TEMP_RX ADD LOCAL_PHARMACY_CLASS_ID INT;
ALTER TABLE TEMP_RX ADD LOCAL_THERAPEUTIC_CLASS_ID INT;
ALTER TABLE TEMP_RX ADD LOCAL_PHARMACY_ID INT;
ALTER TABLE TEMP_RX ADD LOCAL_PRESCRIBER_ID INT;
ALTER TABLE TEMP_RX ADD LOCAL_DRUG_ID INT;
ALTER TABLE TEMP_RX ADD EFFECTIVE_DATE_ID INT;


UPDATE TEMP_RX SET LOCAL_PCP_PROV_ID = T1.LOCAL_PROVIDER_ID
FROM DIM_PROVIDER T1,
( SELECT DISTINCT PROVIDER_ID,PROVIDER_NPI FROM TEMP_HEALTHFIRST_ALL_ELIGIBILITY) T2,
TEMP_RX T3
WHERE T1.PROVIDER_NPI = T2.PROVIDER_NPI
AND   T2.PROVIDER_ID = T3.PCP_IDENTIFIER;


UPDATE TEMP_RX SET LOCAL_PROVIDER_ORG_ID = T1.LOCAL_PROVIDER_ORG_ID
FROM DIM_PROVIDER_ORG_DETAIL T1, TEMP_RX T2
WHERE T1.PROVIDER_ID = T2.PCP_IDENTIFIER;

UPDATE TEMP_RX SET LOCAL_PCP_PROV_ID = ( SELECT LOCAL_PROVIDER_ID FROM DIM_PROVIDER WHERE PROVIDER_NPI = '0000000000') 
WHERE LOCAL_PCP_PROV_ID IS NULL;

UPDATE TEMP_RX SET LOCAL_PROVIDER_ORG_ID = ( SELECT LOCAL_PROVIDER_ORG_ID FROM DIM_PROVIDER_ORG_DETAIL WHERE PROVIDER_ID = '000000-000' 
												       AND PROVIDER_NPI = '0000000000' )
WHERE LOCAL_PROVIDER_ORG_ID IS NULL;

UPDATE TEMP_RX SET LOCAL_MEMBER_ID = T1.LOCAL_MEMBER_ID
FROM DIM_MEMBERSHIP T1, TEMP_RX T2
WHERE T1.HEALTHFIRST_SRC_MEMBER_ID = T2.MEMBER_NUMBER;

UPDATE TEMP_RX SET SERVICE_DATE_ID = T1.DATE_ID
FROM DIM_DATE T1, TEMP_RX T2
WHERE T1.THE_DATE = T2.SERVICE_DATE;



UPDATE TEMP_RX SET ACCOUNTING_DATE_ID = T1.DATE_ID
FROM DIM_DATE T1, TEMP_RX T2
WHERE T1.THE_DATE = T2.CYCLE_DATE;

UPDATE TEMP_RX SET LOCAL_PHARMACY_CLASS_ID = T1.LOCAL_PHARMACY_CLASS_ID
FROM DIM_PHARMACY_CLASS T1, TEMP_RX T2
WHERE T1.PHARMACY_CLASS_CD = T2.PHARMACY_CLASS;

UPDATE TEMP_RX SET LOCAL_THERAPEUTIC_CLASS_ID = T1. LOCAL_THERAPEUTIC_CLASS_ID
FROM DIM_THERAPEUTIC_CLASS T1, TEMP_RX T2
WHERE CASE WHEN t2.specific_therapeutic_class_code = '' THEN 'N/A' ELSE t2.specific_therapeutic_class_code END = T1.therapeutic_class_cd;

UPDATE TEMP_RX SET LOCAL_PHARMACY_ID = T1.LOCAL_PHARMACY_ID
FROM DIM_PHARMACY T1, TEMP_RX T2
WHERE T1.PHARMACY_NPI = T2.PHARMACY_NPI;

UPDATE TEMP_RX SET LOCAL_PRESCRIBER_ID = T1.LOCAL_PROVIDER_ID
FROM DIM_PROVIDER T1, TEMP_RX T2
WHERE T1.PROVIDER_NPI = T2.PRESCRIBER_NPI;

update temp_rx set local_prescriber_id = ( select local_provider_id from dim_provider where provider_npi = '0000000000' )
where local_prescriber_id is null;

UPDATE TEMP_RX SET LOCAL_DRUG_ID = T1.LOCAL_DRUG_ID
FROM DIM_DRUG_DETAILS T1, TEMP_RX T2
WHERE T1.NDC_NUMBER = T2.NDC_CODE;

UPDATE TEMP_RX SET EFFECTIVE_DATE_ID = T1.DATE_ID
FROM DIM_DATE T1, TEMP_RX T2
WHERE T1.THE_DATE = T2.EFFECTIVE_PERIOD;
     

DELETE FACT_PHARMACY_CLAIMS WHERE SOURCE = 'Healthfirst Corinthian';                    
INSERT INTO FACT_PHARMACY_CLAIMS ( LOCAL_PRODUCT_ID,LOCAL_PROVIDER_ORG_ID,LOCAL_PCP_PROV_ID,CLAIM_ID,LOCAL_MEMBER_ID,SERVICE_DATE_ID,ACCOUNTING_DATE_ID,
LOCAL_PHARMACY_CLASS_ID,LOCAL_THERAPEUTIC_CLASS_ID,LOCAL_PHARMACY_ID,LOCAL_PRESCRIBER_ID,LOCAL_DRUG_ID,AVG_WHOLESALE_PRICE,DRUG_TYPE,FORMULARY_IND,
GENERIC_FILL_IND,CLAIMS_PAID_CD,PRESCRIPTION_COST,REFILL_NUMBER,PRESCRIBED_DAILY_SUPPLY,PRESCRIPTION_FILLED,PRESCRIPTION_PROCESSED,TO_PAY_AMOUNT,
PRESCRIBED_DAYS_SUPPLY,NDC_CODE,PRESCRIPTION_NUMBER,SPECIALTY_RX_CLAIM_IND,SOURCE,EFFECTIVE_DATE_ID,SERVICE_DATE,ACCOUNTING_DATE,EFFECTIVE_DATE,FILE_NAME )

select LOCAL_PRODUCT_ID,LOCAL_PROVIDER_ORG_ID,LOCAL_PCP_PROV_ID,CLAIM_ID,LOCAL_MEMBER_ID,SERVICE_DATE_ID,ACCOUNTING_DATE_ID,
LOCAL_PHARMACY_CLASS_ID,LOCAL_THERAPEUTIC_CLASS_ID,LOCAL_PHARMACY_ID,LOCAL_PRESCRIBER_ID,LOCAL_DRUG_ID,AVG_WHOLESALE_PRICE,DRUG_TYPE,FORMULARY_IND,
GENERIC_FILL_IND,CLAIMS_PAID_CD,PRESCRIPTION_COST,REFILL_NUMBER,PRESCRIBED_DAILY_SUPPLY,PRESCRIPTION_FILLED,PRESCRIPTION_PROCESSED,TO_PAY_AMOUNT,
PRESCRIBED_DAYS_SUPPLY,NDC_CODE,PRESCRIPTION_NUMBER,SPECIALTY_RX_CLAIM_IND,SOURCE,EFFECTIVE_DATE_ID,SERVICE_DATE,CYCLE_DATE,EFFECTIVE_PERIOD,FILENAME
from temp_rx;

UPDATE FACT_PHARMACY_CLAIMS 
  SET LOCAL_CATEGORY_OF_SERVICE_ID = ( SELECT LOCAL_CATEGORY_OF_SERVICE_ID FROM DIM_CATEGORY_OF_SERVICE WHERE CATEGORY_OF_SERVICE_DESCRIPTION = 'Pharmacy Charges')
  WHERE SOURCE = 'Healthfirst Corinthian';


--Make sure the values are set to 0.
UPDATE FACT_ELIGIBILITY SET CLAIM_AMOUNT = 0, RX_CLAIM_AMOUNT = 0 WHERE SOURCE = 'Healthfirst Corinthian';
/*
-- Create unique records to avoid assigning claims amount to multiple records

create temp table temp_uniq
as
select local_member_id,local_provider_id,date_id,max(membership_month_count) as mmonth,local_provider_org_id as lop
  from fact_eligibility
  where source = 'Healthfirst Corinthian'
  and drop_count =0 
  group by local_member_id,local_provider_id,local_provider_org_id,date_id;

-- Update the claim amount where there is perfect match

update fact_eligibility 
  set claim_amount =   claim.claim_amount
  from fact_eligibility elig ,
  ( select local_member_id, local_pcp_provider_id,local_pcp_org_id,the_date as claim_service_dt, 
  sum(to_pay_amount)as claim_amount from fact_claims t1
  inner join dim_date t2
  on t1.effective_date_id = date_id
  where t1.source = 'Healthfirst Corinthian'
  group by local_member_id,local_pcp_provider_id,local_pcp_org_id,the_date ) claim,
  dim_date dt , temp_uniq u
  where elig.local_member_id = claim.local_member_id
  and elig.local_provider_id = claim.local_pcp_provider_id
  and elig.local_provider_org_id = claim.local_pcp_org_id
  and the_date = claim.claim_service_dt
  and elig.date_id = dt.date_id 
  and elig.date_id = u.date_id
  and elig.local_member_id = u.local_member_id
  and elig.local_provider_id = u.local_provider_id
  and elig.membership_month_count = mmonth
  and elig.local_provider_org_id = lop
  and elig.source = 'Healthfirst Corinthian';


create temporary table temp_match
as
with cte_claim_only as (
 select local_member_id, local_pcp_provider_id,local_pcp_org_id,the_date as claim_service_dt, sum(to_pay_amount) as claim_amount 
  from fact_claims t1
  inner join dim_date t2
  on t1.effective_date_id = date_id
  
  where not exists ( select 1 from fact_eligibility elig , dim_date dt 
                    where elig.date_id = dt.date_id 
                    and t1.local_member_id = elig.local_member_id 
                    and t1.local_pcp_provider_id = elig.local_provider_id
		    and t1.local_pcp_org_id  = elig.local_provider_org_id
                    and t2.the_date = dt.the_date 
                    and source = 'Healthfirst Corinthian')
  and t1.source = 'Healthfirst Corinthian'
  group by local_member_id,local_pcp_provider_id,local_pcp_org_id,the_date )
  
  
select t1.date_id,t1.local_member_id,t1.local_provider_id,mmonth,lop,claim_amount FROM temp_uniq T1
INNER JOIN DIM_DATE T2
ON T1.DATE_ID = T2.DATE_ID
INNER JOIN CTE_CLAIM_ONLY cte
on t1.local_member_id = cte.local_member_id
and t2.the_date = cte.claim_service_dt
order by 1,2,3;

update fact_eligibility   
  set claim_amount =   elig.claim_amount + temp.claim_amount
  from fact_eligibility elig, temp_match temp
  where elig.date_id = temp.date_id
  and   elig.local_member_id = temp.local_member_id
  and   elig.local_provider_id = temp.local_provider_id
  and   elig.membership_month_count = mmonth
  and   elig.local_provider_org_id = lop
  and   elig.source = 'Healthfirst Corinthian';

-- Create records with dummy product and provider org where there are records in claim but not in eligibility
  
INSERT INTO FACT_ELIGIBILITY ( DATE_ID,LOCAL_MEMBER_ID,LOCAL_PRODUCT_ID,LOCAL_PROVIDER_ID,LOCAL_PROVIDER_ORG_ID,MEMBERSHIP_MONTH_COUNT,SOURCE,NEW_COUNT,CONTINUE_COUNT,DROP_COUNT,CLAIM_AMOUNT,ELIGIBILITY_IND)
with cte_claim_only as (
select local_member_id, local_pcp_provider_id,local_pcp_org_id,the_date as claim_service_dt, sum(to_pay_amount) as claim_amount 
from fact_claims t1
inner join dim_date t2
on t1.effective_date_id = date_id
where not exists ( select 1 from fact_eligibility elig , dim_date dt 
                    where elig.date_id = dt.date_id 
                    and t1.local_member_id = elig.local_member_id 
                    and t2.the_date = dt.the_date 
                    and source = 'Healthfirst Corinthian')
and t1.source = 'Healthfirst Corinthian'
group by local_member_id,local_pcp_provider_id,local_pcp_org_id,the_date)

select claim_dt.DATE_ID,LOCAL_MEMBER_ID, ( select local_product_id from dim_product where lob = 'N/A' ) AS LOCAL_PRODUCT_ID,
      LOCAL_PCP_PROVIDER_ID, local_provider_org_id AS LOCAL_PROVIDER_ORG_ID,
      1 AS MEMBERSHIP_MONTH,'Healthfirst Corinthian' AS SOURCE,0 AS NEW_COUNT,0 AS CONTINUE_COUNT,0 AS DROP_COUNT,claim_amount, 0 AS ELIGIBILITY_IND 
      from cte_claim_only  t1, dim_date claim_dt, dim_provider_org_detail t3
where not exists ( select 1 from temp_uniq tu, dim_date dt where t1.local_member_id = tu.local_member_id and tu.date_id = dt.date_id and t1.claim_service_dt = dt.the_date )
and t1.claim_service_dt = claim_dt.the_date
and t1.local_pcp_org_id = t3.local_provider_org_id;

-- Update pharmacy claim where there is a perfect match 
  update fact_eligibility 
  set rx_claim_amount =    pharm.pharmacy_amount
  from fact_eligibility elig ,
  (  select local_pcp_prov_id,local_provider_org_id,local_member_id,the_date as pharmacy_service_dt,
  sum(to_pay_amount) as pharmacy_amount 
  from fact_pharmacy_claims t1
  inner join dim_date t2
  on t1.effective_date_id = t2.date_id
  where t1.source = 'Healthfirst Corinthian'
  group by local_pcp_prov_id,local_provider_org_id,local_member_id,the_date ) pharm,
  dim_date dt, temp_uniq u
  where elig.local_member_id = pharm.local_member_id
  and elig.local_provider_id = pharm.local_pcp_prov_id
  and elig.local_provider_org_id = pharm.local_provider_org_id
  and the_date = pharm.pharmacy_service_dt
  and elig.date_id = dt.date_id
  and elig.local_member_id = u.local_member_id
  and elig.local_provider_id = u.local_provider_id
  and elig.membership_month_count = mmonth
  and elig.local_provider_org_id = lop
  and elig.source = 'Healthfirst Corinthian';

-- Update pharmacy claim amount there is not a perfect match only the member_id and the service date match
create temporary table temp_pharmacy_match
as
with cte_claim_only as (
 select local_member_id, local_pcp_prov_id,local_provider_org_id,the_date as claim_service_dt, sum(to_pay_amount) as pharmacy_claim_amount 
  from fact_pharmacy_claims t1
  inner join dim_date t2
  on t1.effective_date_id = date_id
  where not exists ( select 1 from fact_eligibility elig , dim_date dt 
                    where elig.date_id = dt.date_id 
                    and t1.local_member_id = elig.local_member_id 
                    and t1.local_pcp_prov_id = elig.local_provider_id
		    and t1.local_provider_org_id = elig.local_provider_org_id
                    and claim_service_dt = dt.the_date
                    and source = 'Healthfirst Corinthian' )
  and t1.source = 'Healthfirst Corinthian'
  group by local_member_id,local_pcp_prov_id,local_provider_org_id,the_date )
  
select t1.date_id,t1.local_member_id,t1.local_provider_id,mmonth,lop,pharmacy_claim_amount 
FROM temp_uniq T1
INNER JOIN DIM_DATE T2
ON T1.DATE_ID = T2.DATE_ID
INNER JOIN CTE_CLAIM_ONLY cte
on t1.local_member_id = cte.local_member_id
and t2.the_date = cte.claim_service_dt
order by 1,2,3;


update fact_eligibility   
  set rx_claim_amount =   elig.rx_claim_amount + temp.pharmacy_claim_amount
  from fact_eligibility elig, temp_pharmacy_match temp
  where elig.date_id = temp.date_id
  and   elig.local_member_id = temp.local_member_id
  and   elig.local_provider_id = temp.local_provider_id
  and   elig.membership_month_count = mmonth
  and   elig.local_provider_org_id = lop
  and   elig.source = 'Healthfirst Corinthian';

-- Insert the pharmacy amount where there is no match.

INSERT INTO FACT_ELIGIBILITY ( DATE_ID,LOCAL_MEMBER_ID,LOCAL_PRODUCT_ID,LOCAL_PROVIDER_ID,LOCAL_PROVIDER_ORG_ID,MEMBERSHIP_MONTH_COUNT,SOURCE,NEW_COUNT,CONTINUE_COUNT,DROP_COUNT,RX_CLAIM_AMOUNT,ELIGIBILITY_IND)
with cte_claim_only as (
 select local_member_id, local_pcp_prov_id,local_provider_org_id,the_date as claim_service_dt, sum(to_pay_amount) as pharmacy_claim_amount 
  from fact_pharmacy_claims t1
  inner join dim_date t2
  on t1.effective_date_id = date_id
  
  where not exists ( select 1 from fact_eligibility elig , dim_date dt 
                    where elig.date_id = dt.date_id 
                    and t1.local_member_id = elig.local_member_id 
                    and t1.local_pcp_prov_id = elig.local_provider_id
		    and t1.local_provider_org_id = elig.local_provider_org_id 
                    and claim_service_dt = dt.the_date
                    and source = 'Healthfirst Corinthian' )
  and t1.source = 'Healthfirst Corinthian'
  group by local_member_id,local_pcp_prov_id,local_provider_org_id,the_date )
  
select claim_dt.DATE_ID,LOCAL_MEMBER_ID, ( select local_product_id from dim_product where lob = 'N/A' ) AS LOCAL_PRODUCT_ID,
      LOCAL_PCP_PROV_ID, ( select local_provider_org_id from dim_provider_org_detail where provider_id = '000000-000' and provider_org = '00' ) AS LOCAL_PROVIDER_ORG_ID,
      1 AS MEMBERSHIP_MONTH,'Healthfirst Corinthian' AS SOURCE,0 AS NEW_COUNT,0 AS CONTINUE_COUNT,0 AS DROP_COUNT,pharmacy_claim_amount, 0 AS ELIGIBILITY_IND
      from cte_claim_only  t1, dim_date claim_dt
where not exists ( select 1 from temp_uniq tu, dim_date dt where t1.local_member_id = tu.local_member_id and tu.date_id = dt.date_id and t1.claim_service_dt = dt.the_date )
and t1.claim_service_dt = claim_dt.the_date;

*/
-- Populate FACT_CLAIMS_CODE_DETAILS

DELETE FACT_CLAIMS_CODE_DETAILS WHERE SOURCE = 'Healthfirst Corinthian';

INSERT INTO FACT_CLAIMS_CODE_DETAILS( CLAIM_ID,CLAIM_LINE_NO,LOCAL_CODE_ID,TYPE,IS_PRIMARY_IND,SOURCE)
with cte_correct_claims as ( select max(received_month) as max_received_month,claim_id ct_claim_id,line_no ct_line_no
  from temp_healthfirst_all_claims
  where pcp_parent_code = 'COR2'
  group by claim_id,line_no  )    ,
  
cte_codes as (
select * from (
select top 100 claim_id,line_no,primary_diagnosis,primary_diag_poa_description,'DIAG' AS TYPE, 1 AS is_primary_ind from temp_healthfirst_all_claims 
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_2,poa_description_2,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_3,poa_description_3,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_4,poa_description_4,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_5,poa_description_5,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_6,poa_description_6,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_7,poa_description_7,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_8,poa_description_8,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_9,poa_description_9,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_10,poa_description_10,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_11,poa_description_11,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_12,poa_description_12,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_13,poa_description_13,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_14,poa_description_14,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_15,poa_description_15,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_16,poa_description_16,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_17,poa_description_17,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
UNION ALL
select claim_id,line_no,diagnosis_code_18,poa_description_18,'DIAG' AS TYPE, 0 AS is_primary_ind from temp_healthfirst_all_claims 
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
union all
select claim_id,line_no,principle_procedure_code,NULL,'PROC' AS TYPE ,1 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
union all
select claim_id,line_no,secondary_procedure_code,NULL,'PROC' AS TYPE ,0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
union all
select claim_id,line_no,tertiary_procedure_code,NULL,'PROC' AS TYPE ,0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
union all
select claim_id,line_no,quaternary_procedure_code,NULL,'PROC' AS TYPE ,0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
union all
select claim_id,line_no,fifth_procedure_code,NULL,'PROC' AS TYPE ,0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2'
union all
select claim_id,line_no,sixth_procedure_code,NULL,'PROC' AS TYPE ,0 AS is_primary_ind from temp_healthfirst_all_claims
inner join cte_correct_claims 
on claim_id = ct_claim_id
and line_no = ct_line_no
and received_month = max_received_month
where pcp_parent_code = 'COR2') a
where  primary_diagnosis != '' and 
primary_diagnosis is not null 
 )

select claim_id,line_no,local_code_id,type,is_primary_ind,'Healthfirst Corinthian' as source from cte_codes cte
  inner join dim_codes t1
  on cte.primary_diagnosis = t1.code;
  


