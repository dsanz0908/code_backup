
DELETE STAGING_ROSTER;

COPY STAGING_ROSTER
from 's3://hedis-app/hc_wc_latest_roster_000'
iam_role 'arn:aws:iam::057748858673:role/myRedshiftrole'
dateformat 'auto'
delimiter '|';



UPDATE patients
SET    updated_at = '2020-01-13 12:10PM',
       active_ind = False
WHERE  NOT EXISTS (SELECT 1
                   FROM   staging_roster
                   WHERE  medicare_id = medicare_patient_id)
       AND active_ind = True;

insert into users ( first_name,last_name,pcp_npi,tax_id,created_at,updated_at)
select distinct split_part(pcp_name,' ',1) as first_name, split_part(pcp_name,' ',2) as last_name,provider_npi,provider_tin,getdate() as created_at, getdate() as updated_at
from staging_roster
where not exists ( select 1 from users where pcp_npi = provider_npi );


INSERT INTO patients
            (effective_period,
             member_id,
             medicare_id,
             member_name,
             member_dob,
             pcp_npi,
             pcp_name,
             pcp_id,
             pcp_type,
             coder_type,
             insurance_id,
             first_name,
             last_name,
             created_at,
             updated_at,
             active_ind,
             pcp_tin)

SELECT DISTINCT Cast('2020-01-01' AS DATE),
                member_id,
                medicare_patient_id,
                member_name,
                dob,
                provider_npi,
                users.last_name || ',' || users.first_name as pcp_name,
                users.id,
                'User' as pcp_type,
                'User' as code_type,
                insurances.id,
                Split_part(member_name, ' ', 1) as member_first_name,
                Split_part(member_name, ' ', 2) as member_last_name,
                getdate() as created_at,
                getdate() as updated_at,
                True as active_ind,
                provider_tin
FROM   users
       JOIN staging_roster
         ON pcp_npi = provider_npi
       JOIN insurances
         ON CASE
              WHEN payor = 'hf' THEN 10524
              WHEN payor = 'wc' THEN 10527
              WHEN payor = 'ep' THEN 10528
            END = insurances.id
where            NOT EXISTS (SELECT 1
                            FROM   patients
                            WHERE  medicare_id = medicare_patient_id)
and provider_npi != '';






create temporary table ltst_details
as
select medicare_patient_id,provider_npi,case WHEN payor = 'hf' THEN 10524
              WHEN payor = 'wc' THEN 10527
              WHEN payor = 'ep' THEN 10528 end as ins_id , t2.pcp_npi,insurance_id
 from staging_roster t1
 inner join patients t2
 on t1.medicare_patient_id = t2.medicare_id
 and t1.provider_npi != t2.pcp_npi
 and t2.active_ind = 1
 inner join  users t3
 on t1.provider_npi = t3.pcp_npi 
where provider_npi != '' ;

update patients set pcp_npi = provider_npi,
                    insurance_id = ins_id
from ltst_details t1
where t1.medicare_patient_id = medicare_id
and   active_ind = True;


update patients set coder_id = t1.coder_id
  from coder_pcps t1
  where patients.pcp_id = t1.pcp_id
  and   patients.insurance_id = t1.insurance_id
  and   patients.created_at >= '20200214';

update patients set coder_id = 1569 where coder_id is null and active_ind = True;

insert into coder_pcps ( coder_id,coder_type,pcp_id,pcp_type,insurance_id,insurance_type,created_at,updated_at)
select distinct 1569,'User',id,'User',CASE   WHEN payor = 'hf' THEN 10524
                                    WHEN payor = 'wc' THEN 10527
                                    WHEN payor = 'ep' THEN 10528 END,
      'Insurance',getdate(),getdate()
from users t1
inner join staging_roster t2
on t1.pcp_npi = t2.provider_npi
where created_at >= trunc(getdate())
and not exists ( select 1 from coder_pcps t3 where t3.pcp_id = t1.id and 
                   t3.insurance_id = CASE   WHEN payor = 'hf' THEN 10524
                                            WHEN payor = 'wc' THEN 10527
                                            WHEN payor = 'ep' THEN 10528 END  );
  
