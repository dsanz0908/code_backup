UPDATE patients 
SET    updated_at = '2019-12-27 12:10PM', 
       active_ind = 'false' 
WHERE  NOT EXISTS (SELECT 1 
                   FROM   latest_roster 
                   WHERE  medicare_id = medicare_patient_id) 
       AND active_ind = 'true' 


INSERT INTO patients 
            (effective_period, 
             member_id, 
             medicare_id, 
             member_name, 
             member_dob, 
             pcp_npi, 
             pcp_name, 
             pcp_id, 
             pcp_type, 
             coder_id, 
             coder_type, 
             insurance_id, 
             first_name, 
             last_name, 
             created_at, 
             updated_at, 
             active_ind, 
             pcp_tin) 
SELECT DISTINCT Cast('2019-11-01' AS DATE), 
                member_id, 
                medicare_patient_id, 
                member_name, 
                dob, 
                provider_npi, 
                pcp_name, 
                coder_pcps.pcp_id, 
                'User', 
                coder_pcps.coder_id, 
                'User', 
                insurances.id, 
                Split_part(member_name, ' ', 1), 
                Split_part(member_name, ' ', Array_length(Regexp_split_to_array(member_name, ' '), 1)),
                Cast('2019-12-27 12:20PM' AS TIMESTAMP), 
                Cast('2019-12-27 12:20PM' AS TIMESTAMP), 
                Cast('true' AS BOOL), 
                provider_tin 
FROM   users 
       JOIN coder_pcps 
         ON users.id = coder_pcps.pcp_id 
       JOIN latest_roster 
         ON pcp_npi = provider_npi 
       JOIN insurances 
         ON CASE 
              WHEN payor = 'hf' THEN 10524 
              WHEN payor = 'wc' THEN 10527 
              WHEN payor = 'ep' THEN 10528 
            END = insurances.id 
            AND NOT EXISTS (SELECT 1 
                            FROM   patients 
                            WHERE  medicare_id = medicare_patient_id) 
