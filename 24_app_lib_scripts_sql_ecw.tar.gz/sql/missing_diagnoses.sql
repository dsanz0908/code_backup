WITH cte_latest_healthfirst_members 
     AS (SELECT * 
         FROM   (SELECT *, 
                        Rank() 
                          OVER ( 
                            partition BY CASE WHEN loaded_from_file LIKE '%somos%' THEN 1 WHEN loaded_from_file LIKE
                          '%corinthian%' THEN 
                          2 END 
                            ORDER BY modify_timestamp DESC) AS plan_member_elig_rn 
                 FROM   plan_member_elig 
                 WHERE  source_id = 1002 
                        AND delete_ind = 'N') AS all_healthfirst_members 
         WHERE  plan_member_elig_rn = 1), 
     cte_latest_distinct_members 
     AS (SELECT DISTINCT cte_latest_healthfirst_members.orig_member_id, 
                         first_name, 
                         middle_name, 
                         last_name, 
                         dob, 
                         sex 
         FROM   cte_latest_healthfirst_members 
                JOIN plan_member 
                  ON cte_latest_healthfirst_members.orig_member_id = plan_member.orig_member_id
         WHERE  end_date = (SELECT Max(end_date) 
                            FROM   cte_latest_healthfirst_members)) 
SELECT distinct cte_latest_distinct_members.*, 
       icd10_code, 
       assessment_date, 
       provider_master.prov_last_name, 
       provider_master.prov_first_name, 
       provider_master.prov_middle_name, 
       responsible_provider_master.prov_last_name   AS responsible_prov_last_name, 
       responsible_provider_master.prov_first_name  AS responsible_prov_first_name, 
       responsible_provider_master.prov_middle_name AS responsible_prov_middle_name 
FROM   cte_latest_distinct_members 
       INNER JOIN t_payer 
               ON cte_latest_distinct_members.orig_member_id = t_payer.policy_nbr 
       INNER JOIN t_encounter 
               ON t_payer.patient_id = t_encounter.enc_patient_id 
       INNER JOIN t_patient 
               ON t_encounter.enc_patient_id = t_patient.pat_id 
       LEFT JOIN provider_master 
              ON t_encounter.enc_rendering_provider_id = provider_master.prov_id 
       LEFT JOIN provider_master AS responsible_provider_master 
              ON t_patient.pat_responsible_provider_id = responsible_provider_master.prov_id 
       JOIN t_assessment 
         ON t_assessment.encounter_id = t_encounter.enc_id 




drop table staging_arcadia_diagnoses;
create temp table if not exists staging_arcadia_diagnoses (
orig_member_id varchar(255),
first_name varchar(255),
middle_name varchar(255),
last_name varchar(255),
dob datetime,
sex varchar(255),
icd10_code varchar(255),
assessment_date datetime, 
prov_last_name varchar(255),
prov_first_name varchar(255),
prov_middle_name varchar(255),
responsible_prov_last_name varchar(255),
responsible_prov_first_name varchar(255),
responsible_prov_middle_name varchar(255));


copy staging_arcadia_diagnoses
from 's3://sftp_test/missing_diagnoses.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
region 'us-east-1'
dateformat 'auto'
delimiter '|'
NULL as 'NULL';


with cte_cdw_hf as (
SELECT distinct healthfirst_src_member_id, service_start_date, code
FROM   fact_claims AS a
       JOIN fact_claims_code_details AS b
         ON a.claim_id = b.claim_id
       JOIN dim_codes AS c
         ON b.local_code_id = c.local_code_id
       join dim_membership as d
         on a.local_member_id = d.local_member_id
WHERE  type = 'DIAG')
select count(*) from staging_arcadia_diagnoses where not exists (select 1 from cte_cdw_hf where orig_member_id = healthfirst_src_member_id and trunc(assessment_date) = service_start_date and icd10_code = code) and icd10_code is not null 
and assessment_date > '2019-01-01';


SELECT distinct  healthfirst_src_member_id, service_start_date, code
FROM   fact_claims AS a
       JOIN fact_claims_code_details AS b
         ON a.claim_id = b.claim_id
       JOIN dim_codes AS c
         ON b.local_code_id = c.local_code_id
       join dim_membership as d
         on a.local_member_id = d.local_member_id
WHERE  type = 'DIAG' and healthfirst_src_member_id = 110093915 and service_start_date >= '2019-01-01' order by service_start_date;
