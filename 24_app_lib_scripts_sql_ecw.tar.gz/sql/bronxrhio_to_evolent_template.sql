unload ($$
SELECT * 
FROM   bronx_rhio_enriched_cen 
WHERE  filename = 'FILENAME.csv'
$$)
to 's3://acp-evolent/ToEvolent/RHIO/FILENAME_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

