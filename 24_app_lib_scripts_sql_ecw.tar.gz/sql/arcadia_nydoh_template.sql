unload ('select * from nydoh.all_claims where received_month = YYYYMM ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/YYYYMM/nydoh_claims_YYYYMM_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_cpa where received_month = YYYYMM ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/YYYYMM/nydoh_cpa_YYYYMM_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_rosters_all_columns where received_month = YYYYMM ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/YYYYMM/nydoh_all_rosters_all_columns_YYYYMM_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_shred where received_month = YYYYMM ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/YYYYMM/nydoh_shred_YYYYMM_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_patient_alerts where received_month = YYYYMM ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/YYYYMM/nydoh_patient_alerts_YYYYMM_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;

unload ('select * from nydoh.all_rx_claims where received_month = YYYYMM ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/YYYYMM/nydoh_rx_claims_YYYYMM_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;
