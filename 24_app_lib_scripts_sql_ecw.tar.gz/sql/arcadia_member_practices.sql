SELECT DISTINCT pat_id, 
                site_center_name 
FROM   t_patient 
       JOIN site_master 
         ON pat_site_id = site_id 
WHERE  pat_delete_ind = 'N' 
       AND site_delete_ind = 'N' 
