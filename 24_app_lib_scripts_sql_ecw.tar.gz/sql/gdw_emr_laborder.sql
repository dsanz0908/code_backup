select top 10000 * from gdw.emr_laborder order by random()
