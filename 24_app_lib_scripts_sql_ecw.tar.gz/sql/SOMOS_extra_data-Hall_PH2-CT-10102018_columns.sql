drop table feeds.SOMOS_extra_data-Hall_PH2-CT-10102018;
create table if not exists feeds.SOMOS_extra_data-Hall_PH2-CT-10102018 ( 
ID,ClinicID,ClinicName,PatientID,PatientName,DOB,document date ,PCP,PCP_NPI,EngagementType,CodeType,SpeificCode,insurance1,insuredid1,insurance2,insurerid2,insurance3,insurerid3 VARCHAR(255));
grant all on feeds.SOMOS_extra_data-Hall_PH2-CT-10102018 to etluser;
