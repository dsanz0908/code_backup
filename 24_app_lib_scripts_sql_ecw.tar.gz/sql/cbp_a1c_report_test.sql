create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
region 'us-east-1'
dateformat 'auto'
delimiter  '|';


create temp table arcadia_cbp_all(
pat_id varchar(255),
vitals_date timestamp,
systolic varchar(255),
diastolic varchar(255));

copy arcadia_cbp_all
from 's3://sftp_test/arcadia_cbp_all.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
region 'us-east-1'
dateformat 'auto'
delimiter  '|';



select distinct member_id, trunc(vitals_date) as vitals_date, systolic, diastolic from (select *, row_number() over (partition by member_id order by trunc(vitals_date) desc) as rn from (
select member_id, vitals_date, systolic, diastolic from arcadia_cbp_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_cbp_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_all_eligibility on policy_nbr = member_id where medicare_patient_id = '' and effective_period = (select max(effective_period) from payor.healthfirst_all_eligibility) and date_part(year, vitals_date) = 2019
union
select member_id, vitals_date, systolic, diastolic from arcadia_cbp_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_cbp_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_somos_all_eligibility on policy_nbr = member_id where medicare_patient_id = '' and effective_period = (select max(effective_period) from payor.healthfirst_somos_all_eligibility) and date_part(year, vitals_date) = 2019
union
select medicare_patient_id, vitals_date, systolic, diastolic from arcadia_cbp_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_cbp_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_all_eligibility on policy_nbr = medicare_patient_id where medicare_patient_id <> '' and effective_period = (select max(effective_period) from payor.healthfirst_all_eligibility) and date_part(year, vitals_date) = 2019
union
select medicare_patient_id, vitals_date, systolic, diastolic from arcadia_cbp_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_cbp_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_somos_all_eligibility on policy_nbr = medicare_patient_id where medicare_patient_id <> '' and effective_period = (select max(effective_period) from payor.healthfirst_somos_all_eligibility) and date_part(year, vitals_date) = 2019))
where rn = 1



select distinct member_id, trunc(vitals_date) as vitals_date, systolic, diastolic from (select *, row_number() over (partition by member_id order by trunc(vitals_date) desc) as rn from (
select member_id, vitals_date, systolic, diastolic from arcadia_cbp_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_cbp_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_all_eligibility on policy_nbr = member_id where provider_parent_code = 'EXC1' and medicare_patient_id = '' and effective_period = (select max(effective_period) from payor.healthfirst_all_eligibility) and date_part(year, vitals_date) = 2019
union
select medicare_patient_id, vitals_date, systolic, diastolic from arcadia_cbp_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_cbp_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_all_eligibility on policy_nbr = medicare_patient_id where provider_parent_code = 'EXC1' and medicare_patient_id <> '' and effective_period = (select max(effective_period) from payor.healthfirst_all_eligibility) and date_part(year, vitals_date) = 2019))
where rn = 1



create temp table arcadia_a1c_all(
pat_id varchar(255),
collection_date timestamp,
value varchar(255));

copy arcadia_a1c_all
from 's3://sftp_test/arcadia_a1c_all.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

select distinct member_id, trunc(collection_date) as collection_date, value from (select *, row_number() over (partition by member_id order by trunc(collection_date) desc) as rn from (
select member_id, collection_date, value from arcadia_a1c_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_a1c_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_somos_all_eligibility on policy_nbr = member_id where  medicare_patient_id = '' and effective_period = (select max(effective_period) from payor.healthfirst_somos_all_eligibility) and date_part(year, collection_date) = 2019
union
select medicare_patient_id, collection_date, value from arcadia_a1c_all join (
select distinct pat_id, policy_nbr from direct_match union
select distinct arcadia_pat_id, mco_cin from fuzz_test
) as pat_id_cin on arcadia_a1c_all.pat_id = pat_id_cin.pat_id
join payor.healthfirst_somos_all_eligibility on policy_nbr = medicare_patient_id where  medicare_patient_id <> '' and effective_period = (select max(effective_period) from payor.healthfirst_somos_all_eligibility) and date_part(year, collection_date) = 2019))
where rn = 1




create temp table arcadia_awc_all(
pat_id varchar(255),
dos date,
cpt varchar(255),
icd varchar(255));

copy arcadia_awc_all
from 's3://sftp_test/arcadia_awc_all_2019.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
region 'us-east-1'
dateformat 'auto'
delimiter  '|';



SELECT * 
FROM   (SELECT member_id, 
               dob, 
               Trim(Split_part(d, ',', 1)) AS dos1, 
               Trim(Split_part(d, ',', 2)) AS dos2, 
               Trim(Split_part(d, ',', 3)) AS dos3, 
               Trim(Split_part(d, ',', 4)) AS dos4, 
               Trim(Split_part(d, ',', 5)) AS dos5, 
               Trim(Split_part(d, ',', 6)) AS dos6 
        FROM   (SELECT DISTINCT member_id, 
                                dob, 
                                Listagg(dos, ', ') 
                                  within GROUP (ORDER BY dos) over ( 
                                    PARTITION BY member_id, dob) AS d 
                FROM   (SELECT *, 
                               Row_number() 
                                 over ( 
                                   PARTITION BY member_id, dob 
                                   ORDER BY dos) AS rn 
                        FROM   (SELECT member_id, 
                                       dob, 
                                       dos 
                                FROM   arcadia_w15_all 
                                       join (SELECT DISTINCT pat_id, 
                                                             policy_nbr 
                                             FROM   direct_match 
                                             UNION 
                                             SELECT DISTINCT arcadia_pat_id, 
                                                             mco_cin 
                                             FROM   fuzz_test) AS pat_id_cin 
                                         ON arcadia_w15_all.pat_id = pat_id_cin.pat_id 
                                       join payor.healthfirst_all_eligibility 
                                         ON policy_nbr = member_id 
                                WHERE  provider_parent_code = 'COR2' 
                                       AND effective_period = (SELECT Max(effective_period) 
                                                               FROM   payor.healthfirst_all_eligibility)
                                UNION 
                                SELECT medicare_patient_id, 
                                       dob, 
                                       dos 
                                FROM   arcadia_w15_all 
                                       join (SELECT DISTINCT pat_id, 
                                                             policy_nbr 
                                             FROM   direct_match 
                                             UNION 
                                             SELECT DISTINCT arcadia_pat_id, 
                                                             mco_cin 
                                             FROM   fuzz_test) AS pat_id_cin 
                                         ON arcadia_w15_all.pat_id = pat_id_cin.pat_id 
                                       join payor.healthfirst_all_eligibility 
                                         ON policy_nbr = medicare_patient_id 
                                WHERE  provider_parent_code = 'COR2' 
                                       AND effective_period = (SELECT Max(effective_period) 
                                                               FROM   payor.healthfirst_all_eligibility)))))
WHERE  Trim(dos6) <> '' 
