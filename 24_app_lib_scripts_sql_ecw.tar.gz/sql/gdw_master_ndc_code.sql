select top 10000 * from gdw.master_ndc_code order by random()
