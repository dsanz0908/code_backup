select top 10000 * from gdw.emr_laborderdetails order by random()
