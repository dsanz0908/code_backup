select distinct master_table from mco_file_to_table_mapping where mco_name = 'Empire_Somos' and file_type = 'pharmacy';
