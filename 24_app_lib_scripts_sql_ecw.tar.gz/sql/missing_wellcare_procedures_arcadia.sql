WITH cte_latest_wellcare_members
     AS (SELECT *
         FROM   (SELECT *,
                        Rank()
                          OVER (
                            partition BY
                                CASE
                                        WHEN loaded_from_file LIKE '%somos%' THEN 1
                                        WHEN loaded_from_file LIKE '%wellcare_all_%' THEN 2
                                END
                            ORDER BY modify_timestamp DESC) AS plan_member_elig_rn
                 FROM   plan_member_elig
                 WHERE  source_id = 1000
                        AND delete_ind = 'N') AS all_wellcare_members
         WHERE  plan_member_elig_rn = 1 and loaded_from_file not like '%ecap%'),
     cte_latest_distinct_members
     AS (SELECT DISTINCT cte_latest_wellcare_members.orig_member_id,
                         first_name,
                         middle_name,
                         last_name,
                         dob,
                         sex
         FROM   cte_latest_wellcare_members
                JOIN plan_member
                  ON cte_latest_wellcare_members.orig_member_id = plan_member.orig_member_id
         WHERE  end_date = (SELECT Max(end_date)
                            FROM   cte_latest_wellcare_members))
SELECT distinct top 100 cte_latest_distinct_members.*,
       t_patient.pat_id,
       cc_cpt_code,
       cc_date_of_service,
       provider_master.prov_last_name,
       provider_master.prov_first_name,
       provider_master.prov_middle_name,
       responsible_provider_master.prov_last_name   AS responsible_prov_last_name,
       responsible_provider_master.prov_first_name  AS responsible_prov_first_name,
       responsible_provider_master.prov_middle_name AS responsible_prov_middle_name,
       site_master.site_center_name
FROM   cte_latest_distinct_members
       INNER JOIN t_payer
               ON cte_latest_distinct_members.orig_member_id = t_payer.policy_nbr
       INNER JOIN t_encounter
               ON t_payer.patient_id = t_encounter.enc_patient_id
       INNER JOIN t_patient
               ON t_encounter.enc_patient_id = t_patient.pat_id
       INNER JOIN t_chargecapture
               ON t_chargecapture.cc_enc_id = t_encounter.enc_id
       LEFT JOIN site_master
               ON t_encounter.enc_site_id = site_master.site_id
       LEFT JOIN provider_master
               ON t_encounter.enc_rendering_provider_id = provider_master.prov_id
       LEFT JOIN provider_master AS responsible_provider_master
               ON t_patient.pat_responsible_provider_id = responsible_provider_master.prov_id
       WHERE cc_cpt_code is not null and ltrim(rtrim(cc_cpt_code)) <> ''
