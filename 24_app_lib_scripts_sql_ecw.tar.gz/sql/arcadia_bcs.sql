SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE) dob, 
                cc_date_of_service, 
                cc_cpt_code, 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   t_chargecapture 
       JOIN t_patient 
         ON cc_patient_id = pat_id 
       JOIN provider_master 
         ON cc_rendering_provider_id = prov_id 
WHERE  cc_delete_ind = 'N' 
       AND cc_date_of_service >= '2017-10-01' 
       AND cc_cpt_code IN ( '77055', '77056', '77057', '77061', 
                            '77062', '77063', '77065', '77066', 
                            '77067', 'G0202', 'G0204', 'G0206' ) 
       AND pat_date_of_birth BETWEEN '1945-01-01' AND '1967-12-31' 
       AND pat_delete_ind = 'N' 
UNION 
SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE), 
                collection_date, 
                '77057', 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   t_result 
       JOIN t_patient 
         ON t_patient.pat_id = t_result.pat_id 
       JOIN provider_master 
         ON provider_id = prov_id 
WHERE  delete_ind = 'N' 
       AND collection_date >= '2017-10-01' 
       AND pat_date_of_birth BETWEEN '1945-01-01' AND '1967-12-31' 
       AND pat_delete_ind = 'N' 
       AND ( original_name LIKE '%mammogram%' 
              OR result_value LIKE '%mammogram%' ) 
UNION 
SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE), 
                result_received_date, 
                '77057', 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   t_order 
       JOIN t_patient 
         ON t_patient.pat_id = t_order.pat_id 
       JOIN provider_master 
         ON ordering_provider_id = prov_id 
WHERE  delete_ind = 'N' 
       AND result_received_date >= '2017-10-01' 
       AND pat_date_of_birth BETWEEN '1945-01-01' AND '1967-12-31' 
       AND pat_delete_ind = 'N' 
       AND ( order_name LIKE '%mammogram%' 
              OR order_notes LIKE '%mammogram%' 
              OR order_category LIKE '%mammogram%' 
              OR cpt_code IN ( '77055', '77056', '77057', '77061', 
                               '77062', '77063', '77065', '77066', 
                               '77067', 'G0202', 'G0204', 'G0206' ) ) 
