        ?column?         
-------------------------
  claim_number,
  fill_date,
  product,
  pcp_name,
  pcp_tin,
  src_subs_id,
  mcd_number,
  mbr_first_name,
  mbr_last_name,
  dob,
  prescriber_npi,
  prescriber_name,
  prescribing_specialty,
  drug_name,
  script_cnt,
  refill_cnt,
  anl_paid_amt,
  received_month,
  filename,
(19 rows)

