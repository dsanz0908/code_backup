delete from  where filename = 'Empire_BCBS_HealthPlus_RX_CLM_SOMOS_201701_201902.TXT';
insert into  ( 
  claim_number,
  fill_date,
  PRODUCT,
  PCP_NAME,
  PCP_TIN,
  SRC_SUBS_ID,
  MCD_Number,
  MBR_FIRST_NAME,
  MBR_LAST_NAME,
  DOB,
  Prescriber_name,
  Prescriber_NPI,
  Prescribing_Specialty,
  DRUG_NAME,
  SCRIPT_CNT,
  REFILL_CNT,
  ANL_Paid_Amt,
  received_month,
  filename
)
select 
from staging_empire_somos_RX;
drop table staging_empire_somos_RX;
