select count(*) from payor.healthfirst_somos_all_claims where received_month = '201908'
