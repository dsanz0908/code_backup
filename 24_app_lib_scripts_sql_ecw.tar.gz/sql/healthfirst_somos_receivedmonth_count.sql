select count(*) from payor.healthfirst_somos_all_eligibility where received_month = '201908'
