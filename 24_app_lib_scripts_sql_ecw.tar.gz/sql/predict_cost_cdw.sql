create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

drop table if exists predict_cost;
create temporary table predict_cost (
patient_id varchar(255),
a1 float,
a2 float,
a3 float,
a4 float,
a5 float,
a6 float,
a7 float,
a8 float,
a9 float,
a10 float,
a11 float,
a12 float,
a13 float,
a14 float,
a15 float,
a16 float,
a17 float,
a18 float,
a19 float,
a20 float,
a21 float,
a22 float,
a23 float,
a24 float,
a25 float,
a26 float,
a27 float,
a28 float,
a29 float,
a30 float,
a31 float,
a32 float,
a33 float,
a34 float,
a35 float,
a36 float,
a37 float,
a38 float,
a39 float,
a40 float,
a41 float,
a42 float,
a43 float,
a44 float,
a45 float,
a46 float,
a47 float,
a48 float,
a49 float,
a50 float,
a51 float,
a52 float,
a53 float,
a54 float,
a55 float,
a56 float,
a57 float,
a58 float,
a59 float,
a60 float,
a61 float,
a62 float,
a63 float,
a64 float,
a65 float,
a66 float,
a67 float,
a68 float,
a69 float,
a70 float,
a71 float,
a72 float,
a73 float,
a74 float,
a75 float,
a76 float,
a77 float,
a78 float,
a79 float,
a80 float,
a81 float,
a82 float,
a83 float,
a84 float,
a85 float,
a86 float,
a87 float,
a88 float,
a89 float,
a90 float,
a91 float,
a92 float,
a93 float,
a94 float,
a95 float,
a96 float,
a97 float,
a98 float,
a99 float,
a100 float);


copy predict_cost
from 's3://sftp_test/predict_cost_with_arcadia.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 500
region 'us-east-1'
dateformat 'auto'
delimiter ','
NULL as 'NULL';



unload ($$
with cte_cin_cost as (SELECT member_cin,
               Sum(to_pay_amount) AS cost
FROM   fact_claims
       JOIN dim_membership
         ON fact_claims.local_member_id = dim_membership.local_member_id
WHERE  effective_date >= '2019-01-01'
GROUP  BY member_cin union
SELECT healthfirst_src_member_id,
               Sum(to_pay_amount) AS cost
FROM   fact_claims
       JOIN dim_membership
         ON fact_claims.local_member_id = dim_membership.local_member_id
WHERE  effective_date >= '2019-01-01'
GROUP  BY healthfirst_src_member_id union
SELECT wellcare_src_member_id,
               Sum(to_pay_amount) AS cost
FROM   fact_claims
       JOIN dim_membership
         ON fact_claims.local_member_id = dim_membership.local_member_id
WHERE  effective_date >= '2019-01-01'
GROUP  BY wellcare_src_member_id)
select predict_cost.*, case when cost > 10000 then 'Y' else 'N' end as cost from (select arcadia_pat_id, sum(cost) as cost from (select distinct arcadia_pat_id, cost from fuzz_test join cte_cin_cost on mco_cin = member_cin) group by arcadia_pat_id) join predict_cost
on arcadia_pat_id = patient_id
$$)
to 's3://sftp_test/predict_cost_cdw'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

