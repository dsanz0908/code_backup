unload ($$
WITH cte_cen_count 
     AS (SELECT DISTINCT patient_first_name, 
                         patient_last_name, 
                         patient_dob :: text, 
                         medicaid_id, 
                         (SELECT Count(DISTINCT filename)::text 
                          FROM   bronx_rhio_enriched_cen AS b 
                          WHERE  a.patient_first_name = b.patient_first_name 
                                 AND a.patient_last_name = b.patient_last_name 
                                 AND a.patient_dob = b.patient_dob 
                                 AND a.medicaid_id = b.medicaid_id 
                                 AND admit_datetime > current_date - 7)  AS last7, 
                         (SELECT Count(DISTINCT filename)::text
                          FROM   bronx_rhio_enriched_cen AS b 
                          WHERE  a.patient_first_name = b.patient_first_name 
                                 AND a.patient_last_name = b.patient_last_name 
                                 AND a.patient_dob = b.patient_dob 
                                 AND a.medicaid_id = b.medicaid_id 
                                 AND admit_datetime > current_date - 30) AS last30, 
                         (SELECT Count(DISTINCT filename)::text 
                          FROM   bronx_rhio_enriched_cen AS b 
                          WHERE  a.patient_first_name = b.patient_first_name 
                                 AND a.patient_last_name = b.patient_last_name 
                                 AND a.patient_dob = b.patient_dob 
                                 AND a.medicaid_id = b.medicaid_id 
                                 AND admit_datetime > current_date - 90) AS last90 
         FROM   bronx_rhio_enriched_cen AS a) 
SELECT * FROM (
SELECT 'patient_first_name', 'patient_last_name', 'patient_dob', 'medicaid_id', 'last7', 'last30', '0_last90'
UNION
SELECT * FROM cte_cen_count WHERE last90 > 0
UNION 
SELECT NULL, NULL, NULL, NULL, SUM(last7)::text, SUM(last30)::text, 'Total:' || SUM(last90)::text FROM cte_cen_count GROUP BY 1, 2, 3, 4) 
order by 7,1,2
$$)
to 's3://sftp_test/20190301_bronx_rhio_cin_cen_report.csv'
delimiter ','
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;


unload ($$
select 'admit_facility', 'last7', 'last30', 'last90' union
SELECT t1.admit_facility, 
       last7::text, 
       last30::text, 
       last90::text 
FROM   (SELECT admit_facility, 
               Sum(rn) AS last7 
        FROM   (SELECT admit_facility, 
                       Row_number() 
                         OVER ( 
                           partition BY patient_first_name, patient_last_name, patient_dob, medicaid_id) AS rn
                FROM   (SELECT DISTINCT admit_facility, 
                                        patient_first_name, 
                                        patient_last_name, 
                                        patient_dob, 
                                        medicaid_id 
                        FROM   bronx_rhio_enriched_cen AS b 
                        WHERE  admit_datetime > CURRENT_DATE - 7)) 
        GROUP  BY 1) AS t1 
       JOIN (SELECT admit_facility, 
                    Sum(rn) AS last30 
             FROM   (SELECT admit_facility, 
                            Row_number() 
                              OVER ( 
                                partition BY patient_first_name, patient_last_name, patient_dob, medicaid_id) AS rn
                     FROM   (SELECT DISTINCT admit_facility, 
                                             patient_first_name, 
                                             patient_last_name, 
                                             patient_dob, 
                                             medicaid_id 
                             FROM   bronx_rhio_enriched_cen AS b 
                             WHERE  admit_datetime > CURRENT_DATE - 30)) 
             GROUP  BY 1) AS t2 
         ON t1.admit_facility = t2.admit_facility 
       JOIN (SELECT admit_facility, 
                    Sum(rn) AS last90 
             FROM   (SELECT admit_facility, 
                            Row_number() 
                              OVER ( 
                                partition BY patient_first_name, patient_last_name, patient_dob, medicaid_id) AS rn
                     FROM   (SELECT DISTINCT admit_facility, 
                                             patient_first_name, 
                                             patient_last_name, 
                                             patient_dob, 
                                             medicaid_id 
                             FROM   bronx_rhio_enriched_cen AS b 
                             WHERE  admit_datetime > CURRENT_DATE - 90)) 
             GROUP  BY 1) AS t3 
         ON t1.admit_facility = t3.admit_facility 
$$)
to 's3://sftp_test/20190301_bronx_rhio_hospital_cin_report.csv'
delimiter ','
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;

