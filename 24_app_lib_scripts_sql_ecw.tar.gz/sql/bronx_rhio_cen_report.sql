unload ($$
WITH cte_cen_count 
     AS (SELECT DISTINCT patient_first_name, 
                         patient_last_name, 
                         patient_dob :: text, 
                         medicaid_id, 
                         (SELECT Count(DISTINCT admit_datetime) 
                          FROM   bronx_rhio_enriched_cen AS b 
                          WHERE  a.patient_first_name = b.patient_first_name 
                                 AND a.patient_last_name = b.patient_last_name 
                                 AND a.patient_dob = b.patient_dob 
                                 AND a.medicaid_id = b.medicaid_id 
                                 AND admit_datetime > current_date - 7)  AS 
                         last7, 
                         (SELECT Count(DISTINCT admit_datetime) 
                          FROM   bronx_rhio_enriched_cen AS b 
                          WHERE  a.patient_first_name = b.patient_first_name 
                                 AND a.patient_last_name = b.patient_last_name 
                                 AND a.patient_dob = b.patient_dob 
                                 AND a.medicaid_id = b.medicaid_id 
                                 AND admit_datetime > current_date - 30) AS 
                         last30, 
                         (SELECT Count(DISTINCT admit_datetime) 
                          FROM   bronx_rhio_enriched_cen AS b 
                          WHERE  a.patient_first_name = b.patient_first_name 
                                 AND a.patient_last_name = b.patient_last_name 
                                 AND a.patient_dob = b.patient_dob 
                                 AND a.medicaid_id = b.medicaid_id 
                                 AND admit_datetime > current_date - 90) AS 
                         last90 
         FROM   bronx_rhio_enriched_cen AS a) 
SELECT * 
FROM   (SELECT * 
        FROM   cte_cen_count 
        WHERE  last90 > 0 
        UNION 
        SELECT NULL, 
               NULL, 
               NULL, 
               NULL, 
               SUM(last7), 
               SUM(last30), 
               SUM(last90) 
        FROM   cte_cen_count 
        GROUP  BY 1, 
                  2, 
                  3, 
                  4) 
ORDER  BY 7, 
          1, 
          2 
$$)
to 's3://sftp_test/20200217_bronx_rhio_cin_cen_report.csv'
delimiter ','
parallel off
ALLOWOVERWRITE
ADDQUOTES
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;


unload ($$
WITH cte_hospital_count
     AS (SELECT t1.admit_facility,
                last7,
                last30,
                last90,
                last7 - old7   AS plusminus7,
                last30 - old30 AS plusminus30,
                last90 - old90 AS plusminus90
         FROM   (SELECT admit_facility,
                        count(*) AS last7
                 FROM   (SELECT DISTINCT admit_facility,
                                                 patient_first_name,
                                                 patient_last_name,
                                                 patient_dob,
                                                 medicaid_id
                                 FROM   bronx_rhio_enriched_cen AS b
                                 WHERE  admit_datetime > CURRENT_DATE - 7)
                 GROUP  BY 1) AS t1
                LEFT JOIN (SELECT admit_facility,
                        count(*) AS last30
                 FROM   (SELECT DISTINCT admit_facility,
                                                 patient_first_name,
                                                 patient_last_name,
                                                 patient_dob,
                                                 medicaid_id
                                 FROM   bronx_rhio_enriched_cen AS b
                                 WHERE  admit_datetime > CURRENT_DATE - 30)
                 GROUP  BY 1) AS t2
                  ON t1.admit_facility = t2.admit_facility
               LEFT JOIN (SELECT admit_facility,
                        count(*) AS last90
                 FROM   (SELECT DISTINCT admit_facility,
                                                 patient_first_name,
                                                 patient_last_name,
                                                 patient_dob,
                                                 medicaid_id
                                 FROM   bronx_rhio_enriched_cen AS b
                                 WHERE  admit_datetime > CURRENT_DATE - 90)
                 GROUP  BY 1) AS t3
                  ON t1.admit_facility = t3.admit_facility
              LEFT JOIN (SELECT admit_facility,
                        count(*) AS old7
                 FROM   (SELECT DISTINCT admit_facility,
                                                 patient_first_name,
                                                 patient_last_name,
                                                 patient_dob,
                                                 medicaid_id
                                 FROM   bronx_rhio_enriched_cen AS b
                                 WHERE  admit_datetime between CURRENT_DATE - 14 and CURRENT_DATE - 7)
                 GROUP  BY 1) AS t4
                  ON t1.admit_facility = t4.admit_facility
                 LEFT JOIN (SELECT admit_facility,
                        count(*) AS old30
                 FROM   (SELECT DISTINCT admit_facility,
                                                 patient_first_name,
                                                 patient_last_name,
                                                 patient_dob,
                                                 medicaid_id
                                 FROM   bronx_rhio_enriched_cen AS b
                                 WHERE  admit_datetime between CURRENT_DATE - 37 and CURRENT_DATE - 7)
                 GROUP  BY 1) AS t5
                  ON t1.admit_facility = t5.admit_facility
                 LEFT JOIN (SELECT admit_facility,
                        count(*) AS old90
                 FROM   (SELECT DISTINCT admit_facility,
                                                 patient_first_name,
                                                 patient_last_name,
                                                 patient_dob,
                                                 medicaid_id
                                 FROM   bronx_rhio_enriched_cen AS b
                                 WHERE  admit_datetime between CURRENT_DATE - 97 and CURRENT_DATE - 7)
                 GROUP  BY 1) AS t6
                  ON t1.admit_facility = t6.admit_facility)
SELECT *
FROM   (SELECT *
        FROM   cte_hospital_count
        UNION
        SELECT '',
               Sum(last7),
               Sum(last30),
               Sum(last90),
               Sum(plusminus7),
               Sum(plusminus30),
               Sum(plusminus90)
        FROM   cte_hospital_count)
ORDER  BY 4,1

$$)
to 's3://sftp_test/20200217_bronx_rhio_hospital_cin_report.csv'
delimiter ','
parallel off
ALLOWOVERWRITE
ADDQUOTES
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;

