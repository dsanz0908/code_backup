unload ( $$
select membership_month, empire_provider_id, pcp_npi, pcp_name, pcp_tax_id, product, region, empire_subscriber_id, member_medicaid_number, member_last_name, 
member_first_name, member_dob,gndr_nm, lang_nm, monthly_membership_start_date, monthly_membership_end_date, mm_cnt from payor.empire_bcbs_healthplus_somos_all_roster
where received_month = 'MNTH' 
$$ )
to 's3://acp-data/Arcadia/Outgoing/anthem/empire_somos_eligibility_SEPMNTH_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;


unload ($$
select  claim_number,  claim_line_number,  product,  rendering_provider,  npi,  rendering_specialty,  empire_member_id,  member_medicaid_id,  member_last_name,  member_first_name,  gend_desc,  lang_desc,  race_ethn_desc,  member_dob,  claim_form_type,  bill_type,  place_of_service,  drg,  admit_type,  revenue_code,  primary_diagnosis,  seconday_diagnosis,  tertiary_diagnosis,  quaternary_diagnosis,  procedure_code,  modifier_1,  modifier_2,  modifier_3,  modifier_4,  claim_line_start_date,  claim_line_end_date,  pcp_tax_id,  pcp_name,  pcp_npi,  pcp_empire_id,  claim_line_paid_amt  from payor.empire_bcbs_healthplus_somos_all_claims where received_month = 'MNTH'
$$)
to 's3://acp-data/Arcadia/Outgoing/anthem/empire_somos_claims_SEPMNTH_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';


unload ($$
select  claim_number,  fill_date,  product,  pcp_name,  pcp_tin,  src_subs_id,  mcd_number,  mbr_first_name,  mbr_last_name,  dob, 
 prescriber_npi,  prescriber_name,  prescribing_specialty,  drug_name,  script_cnt,  refill_cnt,  anl_paid_amt, '' as ndc
 from payor.empire_bcbs_healthplus_somos_all_rx where received_month = 'MNTH'
$$)
to 's3://acp-data/Arcadia/Outgoing/anthem/empire_somos_rx_SEPMNTH_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
