SELECT patient_id, 
       icd10_code, 
       prov_fullname, 
       prov_npi, 
       site_center_name, 
       pat_first_name, 
       pat_last_name, 
       pat_middle_name, 
       pat_phone_1, 
       pat_date_of_birth, 
       assessment_date, 
       description 
FROM   (SELECT DISTINCT patient_id, 
                        icd10_code, 
                        prov_fullname, 
                        prov_npi, 
                        site_center_name, 
                        pat_first_name, 
                        pat_last_name, 
                        pat_middle_name, 
                        pat_phone_1, 
                        pat_date_of_birth, 
                        assessment_date, 
                        description, 
                        Row_number() 
                          OVER ( 
                            partition BY patient_id, icd10_code 
                            ORDER BY assessment_date DESC) AS rn 
        FROM   t_assessment 
               JOIN provider_master 
                 ON provider_id = prov_id 
               JOIN site_master 
                 ON t_assessment.site_id = site_master.site_id 
               JOIN t_patient 
                 ON pat_id = patient_id 
               LEFT JOIN lookup.code 
                      ON icd10_code = code_value 
        WHERE  delete_ind = 'N' 
               AND assessment_date >= '2018-01-01' 
               AND icd10_code IS NOT NULL 
               AND prov_delete_ind = 'N' 
               AND pat_delete_ind = 'N' 
               AND site_delete_ind = 'N') AS tbl 
WHERE  rn = 1 
