WITH cte_total_measures AS
(
	 SELECT   ownerid,
		  Count(DISTINCT id) AS total
	 FROM     salesforce_tasks
	 WHERE    getdate()::date = added_tz::date
	 GROUP BY ownerid), table1 AS
(
		SELECT          NAME,
				Round("closed"                                                                  * 100.0 / total, 2),
				Round("completed"                                                               * 100.0 / total, 2),
				Round("completed - awaiting claim submission"                                   * 100.0 / total, 2),
				Round("completed - awaiting coding correction"                                  * 100.0 / total, 2),
				Round("exclusion - does not meet criteria - verified by management"             * 100.0 / total, 2),
				Round("exclusion - moved out of coverage area/switched to commercial insurance" * 100.0 / total, 2),
				Round("exclusion - patient deceased"                                            * 100.0 / total, 2),
				Round("exclusion - patient switched to oon pcp"                                 * 100.0 / total, 2),
				Round("issue - eligibility - needs review"                                      * 100.0 / total, 2),
				Round("issue - ineligible for measure - needs review"                           * 100.0 / total, 2),
				Round("issue - patient refused"                                                 * 100.0 / total, 2),
				Round("issue - pcp refused to collaborate"                                      * 100.0 / total, 2),
				Round("issue - phone wrong/disconnected/out of service"                         * 100.0 / total, 2),
				Round("issue - unable to reach (3) attempts - needs management review"          * 100.0 / total, 2),
				Round("open"                                                                    * 100.0 / total, 2),
				Round("outreach - unable to reach"                                              * 100.0 / total, 2),
				Round("pending - appointment scheduled"                                         * 100.0 / total, 2),
				Round("pending - patient will call"                                             * 100.0 / total, 2),
				Round("pending - practice will schedule"                                        * 100.0 / total, 2),
				Round("pending"                                                                 * 100.0 / total, 2),
				Round("rx - pending"                                                            * 100.0 / total, 2),
				total
		FROM            (
					 SELECT   ownerid,
						  Sum("closed")                                                                  AS "Closed",
						  Sum("completed")                                                               AS "Completed",
						  Sum("completed - awaiting claim submission")                                   AS "Completed - Awaiting Claim Submission",
						  Sum("completed - awaiting coding correction")                                  AS "Completed - Awaiting Coding Correction",
						  Sum("exclusion - does not meet criteria - verified by management")             AS "Exclusion - Does not meet criteria - Verified by Management",
						  Sum("exclusion - moved out of coverage area/switched to commercial insurance") AS "Exclusion - Moved out of coverage area/Switched to commercial insurance",
						  Sum("exclusion - patient deceased")                                            AS "Exclusion - Patient deceased",
						  Sum("exclusion - patient switched to oon pcp")                                 AS "Exclusion - Patient switched to OON PCP",
						  Sum("issue - eligibility - needs review")                                      AS "Issue - Eligibility - Needs review",
						  Sum("issue - ineligible for measure - needs review")                           AS "Issue - Ineligible for measure - Needs Review",
						  Sum("issue - patient refused")                                                 AS "Issue - Patient refused",
						  Sum("issue - pcp refused to collaborate")                                      AS "Issue - PCP refused to collaborate",
						  Sum("issue - phone wrong/disconnected/out of service")                         AS "Issue - Phone wrong/disconnected/out of service",
						  Sum("issue - unable to reach (3) attempts - needs management review")          AS "Issue - Unable to reach (3) attempts - Needs Management Review",
						  Sum("open")                                                                    AS "Open",
						  Sum("outreach - unable to reach")                                              AS "Outreach - Unable to reach",
						  Sum("pending - appointment scheduled")                                         AS "Pending - Appointment Scheduled",
						  Sum("pending - patient will call")                                             AS "Pending - Patient will call",
						  Sum("pending - practice will schedule")                                        AS "Pending - Practice will schedule",
						  Sum("pending")                                                                 AS "Pending",
						  Sum("rx - pending")                                                            AS "Rx - Pending"
					 FROM     (
							 SELECT ownerid,
								CASE
								       WHEN status = 'Open' THEN 1
								       ELSE 0
								END AS "Open",
								CASE
								       WHEN status = 'Outreach - Unable to reach' THEN 1
								       ELSE 0
								END AS "Outreach - Unable to reach",
								CASE
								       WHEN status = 'Completed' THEN 1
								       ELSE 0
								END AS "Completed",
								CASE
								       WHEN status = 'Exclusion - Does not meet criteria - Verified by Management' THEN 1
								       ELSE 0
								END AS "Exclusion - Does not meet criteria - Verified by Management",
								CASE
								       WHEN status = 'Issue - Phone wrong/disconnected/out of service' THEN 1
								       ELSE 0
								END AS "Issue - Phone wrong/disconnected/out of service",
								CASE
								       WHEN status = 'Completed - Awaiting Claim Submission' THEN 1
								       ELSE 0
								END AS "Completed - Awaiting Claim Submission",
								CASE
								       WHEN status = 'Exclusion - Patient switched to OON PCP' THEN 1
								       ELSE 0
								END AS "Exclusion - Patient switched to OON PCP",
								CASE
								       WHEN status = 'Issue - Ineligible for measure - Needs Review' THEN 1
								       ELSE 0
								END AS "Issue - Ineligible for measure - Needs Review",
								CASE
								       WHEN status = 'Exclusion - Moved out of coverage area/Switched to commercial insurance' THEN 1
								       ELSE 0
								END AS "Exclusion - Moved out of coverage area/Switched to commercial insurance",
								CASE
								       WHEN status = 'Completed - Awaiting Coding Correction' THEN 1
								       ELSE 0
								END AS "Completed - Awaiting Coding Correction",
								CASE
								       WHEN status = 'Pending - Practice will schedule' THEN 1
								       ELSE 0
								END AS "Pending - Practice will schedule",
								CASE
								       WHEN status = 'Pending - Appointment Scheduled' THEN 1
								       ELSE 0
								END AS "Pending - Appointment Scheduled",
								CASE
								       WHEN status = 'Issue - Patient refused' THEN 1
								       ELSE 0
								END AS "Issue - Patient refused",
								CASE
								       WHEN status = 'Issue - Eligibility - Needs review' THEN 1
								       ELSE 0
								END AS "Issue - Eligibility - Needs review",
								CASE
								       WHEN status = 'Pending - Patient will call' THEN 1
								       ELSE 0
								END AS "Pending - Patient will call",
								CASE
								       WHEN status = 'Issue - Unable to reach (3) attempts - Needs Management Review' THEN 1
								       ELSE 0
								END AS "Issue - Unable to reach (3) attempts - Needs Management Review",
								CASE
								       WHEN status = 'Rx - Pending' THEN 1
								       ELSE 0
								END AS "Rx - Pending",
								CASE
								       WHEN status = 'Issue - PCP refused to collaborate' THEN 1
								       ELSE 0
								END AS "Issue - PCP refused to collaborate",
								CASE
								       WHEN status = 'Pending' THEN 1
								       ELSE 0
								END AS "Pending",
								CASE
								       WHEN status = 'Exclusion - Patient deceased' THEN 1
								       ELSE 0
								END AS "Exclusion - Patient deceased",
								CASE
								       WHEN isclosed = 'TRUE' THEN 1
								       ELSE 0
								END AS "Closed"
							 FROM   salesforce_tasks
							 WHERE  getdate()::date = added_tz::date)
					 GROUP BY 1) AS t1
		LEFT JOIN       cte_total_measures   AS t2
		ON              t1.ownerid = t2.ownerid
		LEFT OUTER JOIN salesforce_users AS t3
		ON              t1.ownerid = t3.id
		WHERE           isactive = 'TRUE'
		ORDER BY        NAME), cte_total_measures_before_today AS
(
	 SELECT   ownerid,
		  Count(DISTINCT id) AS total
	 FROM     salesforce_tasks
	 WHERE    Getdate()::date - interval '1 DAY' = added_tz::date
	 GROUP BY ownerid), table2 AS
(
		SELECT          NAME,
				Round("closed"                                                                  * 100.0 / total, 2),
				Round("completed"                                                               * 100.0 / total, 2),
				Round("completed - awaiting claim submission"                                   * 100.0 / total, 2),
				Round("completed - awaiting coding correction"                                  * 100.0 / total, 2),
				Round("exclusion - does not meet criteria - verified by management"             * 100.0 / total, 2),
				Round("exclusion - moved out of coverage area/switched to commercial insurance" * 100.0 / total, 2),
				Round("exclusion - patient deceased"                                            * 100.0 / total, 2),
				Round("exclusion - patient switched to oon pcp"                                 * 100.0 / total, 2),
				Round("issue - eligibility - needs review"                                      * 100.0 / total, 2),
				Round("issue - ineligible for measure - needs review"                           * 100.0 / total, 2),
				Round("issue - patient refused"                                                 * 100.0 / total, 2),
				Round("issue - pcp refused to collaborate"                                      * 100.0 / total, 2),
				Round("issue - phone wrong/disconnected/out of service"                         * 100.0 / total, 2),
				Round("issue - unable to reach (3) attempts - needs management review"          * 100.0 / total, 2),
				Round("open"                                                                    * 100.0 / total, 2),
				Round("outreach - unable to reach"                                              * 100.0 / total, 2),
				Round("pending - appointment scheduled"                                         * 100.0 / total, 2),
				Round("pending - patient will call"                                             * 100.0 / total, 2),
				Round("pending - practice will schedule"                                        * 100.0 / total, 2),
				Round("pending"                                                                 * 100.0 / total, 2),
				Round("rx - pending"                                                            * 100.0 / total, 2),
				total
		FROM            (
					 SELECT   ownerid,
						  Sum("closed")                                                                  AS "Closed",
						  Sum("completed")                                                               AS "Completed",
						  Sum("completed - awaiting claim submission")                                   AS "Completed - Awaiting Claim Submission",
						  Sum("completed - awaiting coding correction")                                  AS "Completed - Awaiting Coding Correction",
						  Sum("exclusion - does not meet criteria - verified by management")             AS "Exclusion - Does not meet criteria - Verified by Management",
						  Sum("exclusion - moved out of coverage area/switched to commercial insurance") AS "Exclusion - Moved out of coverage area/Switched to commercial insurance",
						  Sum("exclusion - patient deceased")                                            AS "Exclusion - Patient deceased",
						  Sum("exclusion - patient switched to oon pcp")                                 AS "Exclusion - Patient switched to OON PCP",
						  Sum("issue - eligibility - needs review")                                      AS "Issue - Eligibility - Needs review",
						  Sum("issue - ineligible for measure - needs review")                           AS "Issue - Ineligible for measure - Needs Review",
						  Sum("issue - patient refused")                                                 AS "Issue - Patient refused",
						  Sum("issue - pcp refused to collaborate")                                      AS "Issue - PCP refused to collaborate",
						  Sum("issue - phone wrong/disconnected/out of service")                         AS "Issue - Phone wrong/disconnected/out of service",
						  Sum("issue - unable to reach (3) attempts - needs management review")          AS "Issue - Unable to reach (3) attempts - Needs Management Review",
						  Sum("open")                                                                    AS "Open",
						  Sum("outreach - unable to reach")                                              AS "Outreach - Unable to reach",
						  Sum("pending - appointment scheduled")                                         AS "Pending - Appointment Scheduled",
						  Sum("pending - patient will call")                                             AS "Pending - Patient will call",
						  Sum("pending - practice will schedule")                                        AS "Pending - Practice will schedule",
						  Sum("pending")                                                                 AS "Pending",
						  Sum("rx - pending")                                                            AS "Rx - Pending"
					 FROM     (
							 SELECT ownerid,
								CASE
								       WHEN status = 'Open' THEN 1
								       ELSE 0
								END AS "Open",
								CASE
								       WHEN status = 'Outreach - Unable to reach' THEN 1
								       ELSE 0
								END AS "Outreach - Unable to reach",
								CASE
								       WHEN status = 'Completed' THEN 1
								       ELSE 0
								END AS "Completed",
								CASE
								       WHEN status = 'Exclusion - Does not meet criteria - Verified by Management' THEN 1
								       ELSE 0
								END AS "Exclusion - Does not meet criteria - Verified by Management",
								CASE
								       WHEN status = 'Issue - Phone wrong/disconnected/out of service' THEN 1
								       ELSE 0
								END AS "Issue - Phone wrong/disconnected/out of service",
								CASE
								       WHEN status = 'Completed - Awaiting Claim Submission' THEN 1
								       ELSE 0
								END AS "Completed - Awaiting Claim Submission",
								CASE
								       WHEN status = 'Exclusion - Patient switched to OON PCP' THEN 1
								       ELSE 0
								END AS "Exclusion - Patient switched to OON PCP",
								CASE
								       WHEN status = 'Issue - Ineligible for measure - Needs Review' THEN 1
								       ELSE 0
								END AS "Issue - Ineligible for measure - Needs Review",
								CASE
								       WHEN status = 'Exclusion - Moved out of coverage area/Switched to commercial insurance' THEN 1
								       ELSE 0
								END AS "Exclusion - Moved out of coverage area/Switched to commercial insurance",
								CASE
								       WHEN status = 'Completed - Awaiting Coding Correction' THEN 1
								       ELSE 0
								END AS "Completed - Awaiting Coding Correction",
								CASE
								       WHEN status = 'Pending - Practice will schedule' THEN 1
								       ELSE 0
								END AS "Pending - Practice will schedule",
								CASE
								       WHEN status = 'Pending - Appointment Scheduled' THEN 1
								       ELSE 0
								END AS "Pending - Appointment Scheduled",
								CASE
								       WHEN status = 'Issue - Patient refused' THEN 1
								       ELSE 0
								END AS "Issue - Patient refused",
								CASE
								       WHEN status = 'Issue - Eligibility - Needs review' THEN 1
								       ELSE 0
								END AS "Issue - Eligibility - Needs review",
								CASE
								       WHEN status = 'Pending - Patient will call' THEN 1
								       ELSE 0
								END AS "Pending - Patient will call",
								CASE
								       WHEN status = 'Issue - Unable to reach (3) attempts - Needs Management Review' THEN 1
								       ELSE 0
								END AS "Issue - Unable to reach (3) attempts - Needs Management Review",
								CASE
								       WHEN status = 'Rx - Pending' THEN 1
								       ELSE 0
								END AS "Rx - Pending",
								CASE
								       WHEN status = 'Issue - PCP refused to collaborate' THEN 1
								       ELSE 0
								END AS "Issue - PCP refused to collaborate",
								CASE
								       WHEN status = 'Pending' THEN 1
								       ELSE 0
								END AS "Pending",
								CASE
								       WHEN status = 'Exclusion - Patient deceased' THEN 1
								       ELSE 0
								END AS "Exclusion - Patient deceased",
								CASE
								       WHEN isclosed = 'TRUE' THEN 1
								       ELSE 0
								END AS "Closed"
							 FROM   salesforce_tasks
							 WHERE  Getdate()::date - interval '1 DAY' = added_tz::date)
					 GROUP BY 1)            AS t1
		LEFT JOIN       cte_total_measures_before_today AS t2
		ON              t1.ownerid = t2.ownerid
		LEFT OUTER JOIN salesforce_users AS t3
		ON              t1.ownerid = t3.id
		WHERE           isactive = 'TRUE'
		ORDER BY        NAME)
SELECT          table1.*,
		table2.*
FROM            table1
LEFT OUTER JOIN table2
ON              table1.NAME = table2.NAME
ORDER BY 1

