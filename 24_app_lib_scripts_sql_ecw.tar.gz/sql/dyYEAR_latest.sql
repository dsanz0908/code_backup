--drop table #my5reports;
/*create table #my5reports (
	projectcode			varchar(10),
	project				varchar(100),
	structuredata		varchar(100),
	eventsourcesystem	varchar(100),
	eventprovidername	varchar(100),
	eventprovidernpi	varchar(100),
	planmemberno		varchar(100),
	member_name			varchar(100),
	dob					date,
	age					int,
	sex					varchar(50),
	phone				varchar(100),
	address1			varchar(100),
	address2			varchar(100),
	city				varchar(100),
	"state"				varchar(100),
	zip					varchar(100),
	race				varchar(100),
	enthnicity			varchar(100),
	"language"			varchar(100),
	planpayer			varchar(100),
	planproduct			varchar(100),
	planfundingsource	varchar(100),
	lob_type			varchar(100),
	activeind			varchar(50),
	denominator			smallint,
	numerator			smallint,
	numerator_cpt_code	varchar(50),
	service_date		date,
	group_name			varchar(255),
	group_no			varchar(50),
	denominator_event_date date);*/
--HEALTH HOME AT RISK
with cte_denominator as (select distinct eventsourcesystem,eventprovidername,eventprovidernpi, 1 as denominator,personid ,pm.member_id,medicaid_id,pl.orig_member_id,payor_desc,product_desc,lob_desc,
							lob_type,pe.eventEndDate,group_desc,group_no
from acpps_client_prd01..personevents pe
inner join  mpi.person_member pm
on pe.personid = pm.person_id
inner join plan_member pl
on pm.member_id = pl.member_id
inner join plan_member_elig pme
on pl.member_id = pme.member_id
and pe.eventStartDate >= pme.start_date
and pe.eventEndDate <= pme.end_date
inner join plan_product pp
on pme.product_id = pp.product_id
inner join plan_lob plob
on pp.lob_id = plob.lob_id
inner join plan_payor pay
on plob.payor_id = pay.payor_id
left outer join plan_group pg
on pme.group_id = pg.group_id
where pe.eventstartdate >= '20170401' 
and pe.eventenddate <= '20180331' 
and pe.eventcodeset = 'icd10'
and pe.eventcodevalue in ('J41.0','J41.1','J41.8','J42','J43.0','J43.1','J43.2','J43.8','J43.9','J44.0','J44.1','J44.9','I50.1',
'I50.20','I50.21','I50.22','I50.23','I50.30','I50.31','I50.32','I50.33','I50.40','I50.41','I50.42','I50.43','I50.9','I20.0','I20.1','I20.8','I20.9','M15.0','M15.1',
 'M15.2','M15.4','M15.3','M15.8','M15.9','M32.0','M32.10','M32.11','M32.12','M32.13','M32.14','M32.15','M32.19','M32.8','D57.00','D57.01','D57.02','D57.1','D57.20','D57.211','D57.212','D57.219','D57.3',
 'D57.40','D57.411','D57.412','D57.419','G70.00','G70.01','G70.1','G70.2','G70.80','G70.81','G70.89','G70.9','N18.1','N18.2','N18.3','N18.9','N18.4','N18.5','N18.6')
and pe.eventsourcetable = 't_assessment'
and lob_desc in ('WellCare | Medicaid','NY State | Mdcd','Hf | Corinth | Dual','Hf | Corinth | Mcd','Hf | Somos | Mcd')),

cte_numerator as ( select site_center_name,medicaid_id,1 as numerator,cc_cpt_code,cc_date_of_service from t_chargecapture T1 , T_ENCOUNTER T2, mpi.person_patient t4, mpi.person_member t5, site_master t6, plan_member t7
where cc_date_of_service between '20170401' and '20180331' 
AND CC_CPT_CODE = 'CP001'
AND T1.CC_ENC_ID = T2.ENC_ID
AND  ENC_PATIENT_ID = PAT_ID
and  t4.person_id = t5.person_id
and  t2.enc_site_id = t6.site_id
and  t5.member_id = t7.member_id
and exists ( select 1 from cte_denominator cte where site_center_name = eventsourcesystem and cte.medicaid_id = t7.medicaid_id)
)

--insert #my5reports
select '2AIII' as project_code,	'HEALTH HOME AT RISK' as project,	'CHRONIC DISEASE CARE PLAN' as structure_data,
eventsourcesystem,eventprovidername,eventprovidernpi,orig_member_id,name,dob,age,sex,phone,address1,address2,city,"state",zip,race,ethnicity,"language",
payor_desc,product_desc,lob_desc,lob_type,activeind,denominator,numerator,cc_cpt_code,cc_date_of_service,group_desc,group_no,eventenddate
from cte_denominator t1
left outer join cte_numerator t2
on t1.eventsourcesystem = t2.site_Center_Name
and t1.medicaid_id = t2.medicaid_id
inner join acpps_client_prd01..persondemographics t3
on t1.personid = t3.personid;


--TRANSITION OF CARE
with cte_denominator as (select distinct eventsourcesystem,eventprovidername,eventprovidernpi, 1 as denominator,personid ,medicaid_id,pl.orig_member_id, payor_desc,product_desc,lob_desc,
							lob_type,pe.eventEndDate,group_desc,group_no
from acpps_client_prd01..personevents pe
inner join  mpi.person_member pm
on pe.personid = pm.person_id
inner join plan_member pl
on pm.member_id = pl.member_id
inner join plan_member_elig pme
on pl.member_id = pme.member_id
and pe.eventStartDate >= pme.start_date
and pe.eventEndDate <= pme.end_date
inner join plan_product pp
on pme.product_id = pp.product_id
inner join plan_lob plob
on pp.lob_id = plob.lob_id
inner join plan_payor pay
on plob.payor_id = pay.payor_id
left outer join plan_group pg
on pme.group_id = pg.group_id
where pe.eventstartdate >= '20170401' 
and pe.eventenddate <= '20180331' 
and eventsourcetable = 't_assessment'
and lob_desc in ('WellCare | Medicaid','NY State | Mdcd','Hf | Corinth | Dual','Hf | Corinth | Mcd','Hf | Somos | Mcd') ),

cte_numerator as ( select site_center_name,medicaid_id,1 as numerator,cc_date_of_service,cc_cpt_code from t_chargecapture T1 , T_ENCOUNTER T2, mpi.person_patient t4, mpi.person_member t5, site_master t6, plan_member t7
where cc_date_of_service between '20170401' and '20180331' 
AND CC_CPT_CODE in ('PD001','99495','99496')
AND T1.CC_ENC_ID = T2.ENC_ID
AND  ENC_PATIENT_ID = PAT_ID
and  t4.person_id = t5.person_id
and  t2.enc_site_id = t6.site_id
and  t5.member_id = t7.member_id
and exists ( select 1 from cte_denominator cte where site_center_name = eventsourcesystem and cte.medicaid_id = t7.medicaid_id )
)

insert #my5reports
select '2BIV' as project_code,	'TRANSITION OF CARE' as project,	'TRANSITION OF CARE' as structure_data,
eventsourcesystem,eventprovidername,eventprovidernpi,t1.orig_member_id,name,dob,age,sex,phone,address1,address2,city,"state",zip,race,ethnicity,"language",
payor_desc,product_desc,lob_desc,lob_type,activeind,denominator,numerator,cc_cpt_code,cc_date_of_service,group_desc,group_no,eventEndDate
from cte_denominator t1
left outer join cte_numerator t2
on t1.eventsourcesystem = t2.site_Center_Name
and t1.medicaid_id = t2.medicaid_id
inner join acpps_client_prd01..persondemographics t3
on t1.personid = t3.personid;


--CARDIOVASCULAR
with cte_denominator as (
select distinct eventsourcesystem,eventprovidername,eventprovidernpi, 1 as denominator,personid ,medicaid_id,pl.orig_member_id,payor_desc,product_desc,lob_desc,
							lob_type,pe.eventEndDate,group_desc,group_no
from acpps_client_prd01..personevents pe
inner join  mpi.person_member pm
on pe.personid = pm.person_id
inner join plan_member pl
on pm.member_id = pl.member_id
inner join plan_member_elig pme
on pl.member_id = pme.member_id
and pe.eventStartDate >= pme.start_date
and pe.eventEndDate <= pme.end_date
inner join plan_product pp
on pme.product_id = pp.product_id
inner join plan_lob plob
on pp.lob_id = plob.lob_id
inner join plan_payor pay
on plob.payor_id = pay.payor_id
left outer join plan_group pg
on pme.group_id = pg.group_id
where pe.eventstartdate >= '20170401' 
and pe.eventenddate <= '20180331' 
and eventsourcetable = 't_assessment'
and lob_desc in ('WellCare | Medicaid','NY State | Mdcd','Hf | Corinth | Dual','Hf | Corinth | Mcd','Hf | Somos | Mcd')
and eventcodevalue in (
'I25.9','I05.0','I06.0','I07.0','I07.1','I07.2','I07.8','I07.9','I08.0','I09.0','I09.2','I10','I11.9','I12.9', 
'I13.10','I20.8','I21.09','I25.10','I25.2','I50.1','I50.20','I50.21','I50.22','I50.23','I50.30','I50.31', 
'I50.32','I50.33','I50.40','I50.41','I50.42','I50.43','I50.9','E78.4','E78.5' )),

cte_numerator as ( select site_center_name,medicaid_id,1 as numerator,cc_cpt_Code,cc_date_of_service from t_chargecapture T1 , T_ENCOUNTER T2, mpi.person_patient t4, mpi.person_member t5, site_master t6, plan_member t7
where cc_date_of_service between '20170401' and '20180331' 
AND CC_CPT_CODE in ('LSM01')
AND T1.CC_ENC_ID = T2.ENC_ID
AND  ENC_PATIENT_ID = PAT_ID
and  t4.person_id = t5.person_id
and  t2.enc_site_id = t6.site_id
and  t5.member_id = t7.member_id
and exists ( select 1 from cte_denominator cte where site_center_name = eventsourcesystem and cte.medicaid_id = t7.medicaid_id )
)

--insert #my5reports
select '3BI' as project_code,	'CARDIOVASCULAR' as project,	'LIFESTYLE MODIFICATION COUNSELING DOCUMENTED' as structure_data,
eventsourcesystem,eventprovidername,eventprovidernpi,t1.orig_member_id,name,dob,age,sex,phone,address1,address2,city,"state",zip,race,ethnicity,"language",
payor_desc,product_desc,lob_desc,lob_type,activeind,denominator,numerator,cc_cpt_code,cc_date_of_service,group_desc,group_no,eventEndDate
from cte_denominator t1
left outer join cte_numerator t2
on t1.eventsourcesystem = t2.site_Center_Name
and t1.medicaid_id = t2.medicaid_id
inner join acpps_client_prd01..persondemographics t3
on t1.personid = t3.personid;


--DIABETES
with cte_denominator as ( select distinct eventsourcesystem,eventprovidername,eventprovidernpi, 1 as denominator,personid ,medicaid_id,pl.orig_member_id,payor_desc,product_desc,lob_desc,
							lob_type,pe.eventEndDate,group_desc,group_no
from acpps_client_prd01..personevents pe
inner join  mpi.person_member pm
on pe.personid = pm.person_id
inner join plan_member pl
on pm.member_id = pl.member_id
inner join plan_member_elig pme
on pl.member_id = pme.member_id
and pe.eventStartDate >= pme.start_date
and pe.eventEndDate <= pme.end_date
inner join plan_product pp
on pme.product_id = pp.product_id
inner join plan_lob plob
on pp.lob_id = plob.lob_id
inner join plan_payor pay
on plob.payor_id = pay.payor_id
left outer join plan_group pg
on pme.group_id = pg.group_id
where pe.eventstartdate >= '20170401' 
and pe.eventenddate <= '20180331' 
and eventsourcetable = 't_assessment'
and lob_desc in ('WellCare | Medicaid','NY State | Mdcd','Hf | Corinth | Dual','Hf | Corinth | Mcd','Hf | Somos | Mcd')
and eventcodevalue in ( 
'E08.9','E09.9','E13.9','E08.65','E09.65','E08.10','E09.10','E13.10','E08.00','E08.01','E09.00','E09.01','E13.00','E13.01','E08.11','E08.641','E09.11','E09.641','E13.11','E13.641',
'E08.21','E08.22','E08.29','E09.21','E09.22','E09.29','E13.21','E13.22','E13.29','E08.311','E08.319','E08.321','E08.329','E08.331','E08.339','E08.341','E08.349','E08.351','E08.359',
'E08.36','E08.39','E09.311','E09.319','E09.321','E09.329','E09.331','E09.339','E09.341','E09.349','E09.351','E09.359','E09.36','E09.39','E13.311','E13.319','E13.321','E13.329','E13.331',
'E13.339','E13.341','E13.349','E13.351','E13.359','E13.36','E13.39','E08.40','E08.41','E08.42','E08.43','E08.44','E08.49','E08.610','E09.40','E09.41','E09.42','E09.43','E09.44',
'E09.49','E09.610','E13.40','E13.41','E13.42','E13.43','E13.44','E13.49','E13.610','E08.51','E08.52','E08.59','E09.51','E09.52','E09.59','E13.51','E13.52','E13.59','E08.618',
'E08.620','E08.621','E08.622','E08.628','E08.630','E08.638','E08.649','E08.69','E09.618','E09.620','E09.621','E09.622','E09.628','E09.630','E09.638','E09.649','E09.69','E13.618',
'E13.620','E13.621','E13.622','E13.628','E13.630','E13.638','E13.649','E13.65','E13.69','E08.8','E09.8','E13.8','E11.9','E10.9','E11.65','E10.65','E11.69','E10.10','E11.00','E11.01','E10.69',
'E11.641','E10.11','E10.641','E11.21','E11.22','E11.29','E11.311','E11.319','E11.321','E11.329','E11.331','E11.339','E11.341','E11.349','E11.351','E11.359','E11.36','E11.39','E10.311','E10.319',
'E10.321','E10.329','E10.331','E10.339','E10.341','E10.349','E10.351','E10.359','E10.36','E10.39','E11.40','E11.41','E11.42','E11.43','E11.44','E11.49','E11.610','E10.40','E10.41','E10.42',
'E10.43','E10.44','E10.49','E10.610','E11.51','E11.52','E11.59','E10.51','E10.52','E10.59','E11.618','E11.620','E11.621','E11.622','E11.628','E11.630','E11.638','E11.649','E10.618','E10.620',
'E10.621','E10.622','E10.628','E10.630','E10.638','E10.649','E11.8','E10.8' )),

cte_numerator as ( select site_center_name,medicaid_id,1 as numerator,cc_cpt_code,cc_date_of_service from t_chargecapture T1 , T_ENCOUNTER T2, mpi.person_patient t4, mpi.person_member t5, site_master t6, plan_member t7
where cc_date_of_service between '20170401' and '20180331' 
AND CC_CPT_CODE in ('3044F', '3045F','3046F')
AND T1.CC_ENC_ID = T2.ENC_ID
AND  ENC_PATIENT_ID = PAT_ID
and  t4.person_id = t5.person_id
and  t2.enc_site_id = t6.site_id
and  t5.member_id = t7.member_id
and exists ( select 1 from cte_denominator cte where site_center_name = eventsourcesystem and cte.medicaid_id = t7.medicaid_id )
)

--insert #my5reports
select '3CI' as project_code,	'DIABETES' as project,	'HA1C TEST' as structure_data,
eventsourcesystem,eventprovidername,eventprovidernpi,t1.orig_member_id,name,dob,age,sex,phone,address1,address2,city,"state",zip,race,ethnicity,"language",
payor_desc,product_desc,lob_desc,lob_type,activeind,denominator,numerator,cc_cpt_code,cc_date_of_service,group_desc,group_no,eventEndDate
from cte_denominator t1
left outer join cte_numerator t2
on t1.eventsourcesystem = t2.site_Center_Name
and t1.medicaid_id = t2.medicaid_id
inner join acpps_client_prd01..persondemographics t3
on t1.personid = t3.personid;


--ASTHMA
with cte_denominator as (select distinct eventsourcesystem,eventprovidername,eventprovidernpi, 1 as denominator,personid ,medicaid_id,pl.orig_member_id,payor_desc,product_desc,lob_desc,
							lob_type,pe.eventEndDate,group_desc,group_no
from acpps_client_prd01..personevents pe
inner join  mpi.person_member pm
on pe.personid = pm.person_id
inner join plan_member pl
on pm.member_id = pl.member_id
inner join plan_member_elig pme
on pl.member_id = pme.member_id
and pe.eventStartDate >= pme.start_date
and pe.eventEndDate <= pme.end_date
inner join plan_product pp
on pme.product_id = pp.product_id
inner join plan_lob plob
on pp.lob_id = plob.lob_id
inner join plan_payor pay
on plob.payor_id = pay.payor_id
left outer join plan_group pg
on pme.group_id = pg.group_id
where pe.eventstartdate >= '20170401' 
and pe.eventenddate <= '20180331' 
and eventsourcetable = 't_assessment'
and lob_desc in ('WellCare | Medicaid','NY State | Mdcd','Hf | Corinth | Dual','Hf | Corinth | Mcd','Hf | Somos | Mcd')
and eventcodevalue in ( 
'J45.20','J45.21','J45.22','J45.30','J45.31','J45.32','J45.40','J45.41','J45.42','J45.50','J45.51','J45.52','J45.901','J45.902','J45.909','J45.990','J45.991','J45.998',
'J45.2','J45.3','J45.4','J45.5','J45.9','J45.90','J45.99')),

cte_numerator as ( select site_center_name,medicaid_id,1 as numerator,cc_cpt_Code,cc_date_of_service from t_chargecapture T1 , T_ENCOUNTER T2, mpi.person_patient t4, mpi.person_member t5, site_master t6, plan_member t7
where cc_date_of_service between '20170401' and '20180331' 
AND CC_CPT_CODE in ('AST01')
AND T1.CC_ENC_ID = T2.ENC_ID
AND  ENC_PATIENT_ID = PAT_ID
and  t4.person_id = t5.person_id
and  t2.enc_site_id = t6.site_id
and  t5.member_id = t7.member_id
and exists ( select 1 from cte_denominator cte where site_center_name = eventsourcesystem and cte.medicaid_id = t7.medicaid_id )
)

--insert #my5reports
select '3AIII' as project_code,	'ASTHMA' as project,	'ASTHMA ACTION PLAN' as structure_data,
eventsourcesystem,eventprovidername,eventprovidernpi,t1.orig_member_id,name,dob,age,sex,phone,address1,address2,city,"state",zip,race,ethnicity,"language",
payor_desc,product_desc,lob_desc,lob_type,activeind,denominator,numerator,cc_cpt_code,cc_date_of_service,group_desc,group_no,eventEndDate
from cte_denominator t1
left outer join cte_numerator t2
on t1.eventsourcesystem = t2.site_Center_Name
and t1.medicaid_id = t2.medicaid_id
inner join acpps_client_prd01..persondemographics t3
on t1.personid = t3.personid;


--BEHAVIORAL HEALTH
with cte_denominator as (select distinct eventsourcesystem,eventprovidername,eventprovidernpi, 1 as denominator,personid ,medicaid_id,pl.orig_member_id,payor_desc,product_desc,lob_desc,
							lob_type,pe.eventEndDate,group_desc,group_no,pl.first_name + ' ' + pl.last_name as name ,pl.dob,datediff(year,dob,getdate()) as age, pl.sex,
							pl.home_phone as phone,pl.race,pl.ethnicity
from acpps_client_prd01..personevents pe
inner join  mpi.person_member pm
on pe.personid = pm.person_id
inner join plan_member pl
on pm.member_id = pl.member_id
inner join plan_member_elig pme
on pl.member_id = pme.member_id
and pe.eventStartDate >= pme.start_date
and pe.eventEndDate <= pme.end_date
inner join plan_product pp
on pme.product_id = pp.product_id
inner join plan_lob plob
on pp.lob_id = plob.lob_id
inner join plan_payor pay
on plob.payor_id = pay.payor_id
left outer join plan_group pg
on pme.group_id = pg.group_id
where pe.eventstartdate >= '20170401' 
and pe.eventenddate <= '20180331' 
and lob_desc in ('WellCare | Medicaid','NY State | Mdcd','Hf | Corinth | Dual','Hf | Corinth | Mcd','Hf | Somos | Mcd')
and datediff(year,pl.dob,getdate()) >= 12
and pe.eventcodeDESCRIPTION in ('Alcohol/drug screening','Annual alcohol screen 15 min',
'Alcohol and/or drug screenin',
'Drug screening cocaine',
'Drug screening methadone',
'Drug screening oxycodone',
'HEDIS 2016 Value Set - PHQ Administered',
'Phq-scr >9 doc in 12m time',
'PHQ-9 quick depression assessment panel',
'Prior assessment resident mood interview (PHQ-9) total severity score',
'Prior assessment staff assessment of resident mood interview (PHQ-9) total severity score',
'PHQ-9 interpretation',
'Little interest or pleasure in doing things in last 2W',
'Little interest or pleasure in doing things in last 2W.frequency',
'Little interest or pleasure in doing things in last 2W.presence',
'Depression screen annual','Alcohol and/or drug assess','Screen depression performed','Pt screened for depression') ) ,

cte_numerator as ( select distinct eventsourcesystem,eventprovidername,eventprovidernpi, 1 as numerator,personid ,medicaid_id,pl.orig_member_id,payor_desc,product_desc,lob_desc,
							lob_type,pe.eventEndDate,group_desc,group_no,pl.first_name + ' ' + pl.last_name as name ,pl.dob,datediff(year,dob,getdate()) as age, pl.sex,
							pl.home_phone as phone,pl.race,pl.ethnicity,eventcodevalue
from acpps_client_prd01..personevents pe
inner join  mpi.person_member pm
on pe.personid = pm.person_id
inner join plan_member pl
on pm.member_id = pl.member_id
inner join plan_member_elig pme
on pl.member_id = pme.member_id
and pe.eventStartDate >= pme.start_date
and pe.eventEndDate <= pme.end_date
inner join plan_product pp
on pme.product_id = pp.product_id
inner join plan_lob plob
on pp.lob_id = plob.lob_id
inner join plan_payor pay
on plob.payor_id = pay.payor_id
left outer join plan_group pg
on pme.group_id = pg.group_id
where eventcodevalue in ('3725F','G8510','G8431','3016F','G9622','G9621')
and pe.eventstartdate >= '20170401' 
and pe.eventenddate <= '20180331'
and lob_type in ('Medicaid','Dual')
and datediff(year,pl.dob,getdate()) >= 12 )

--insert #my5reports 
SELECT '3AI'                                  AS project_code, 
       'BEHAVIORAL HEALTH'                    AS project, 
       'PHQ2, PHQ9, ALCOHOL SCREENING, SBIRT' AS structure_data, 
       COALESCE(t1.eventsourcesystem, t2.eventsourcesystem), 
       COALESCE(t1.eventprovidername, t2.eventprovidername), 
       COALESCE(t1.eventprovidernpi, t2.eventprovidernpi), 
       COALESCE(t1.orig_member_id, t2.orig_member_id), 
       COALESCE(t1.NAME, t2.NAME), 
       COALESCE(t1.dob, t2.dob), 
       COALESCE(t1.age, t2.age), 
       COALESCE(t1.sex, t2.sex), 
       COALESCE(t1.phone, t2.phone), 
       NULL                                   AS add1, 
       NULL                                   AS add2, 
       NULL                                   AS city, 
       NULL                                   AS state, 
       NULL                                   AS zip, 
       --coalesce(address1,t2.address1), coalesce(t1.address2,t2.address2), coalesce(t1.city,t2.city), coalesce(t1."state",t2."state"), coalesce(t1.zip,t2.zip),coalesce(t1."language",t2."language"),
       --coalesce(t1.activeind,t2.activeind), 
       COALESCE(t1.race, t2.race), 
       COALESCE(t1.ethnicity, t2.ethnicity), 
       NULL                                   AS lang, 
       COALESCE(t1.payor_desc, t2.payor_desc), 
       COALESCE(t1.product_desc, t2.product_desc), 
       COALESCE(t1.lob_desc, t2.lob_desc), 
       COALESCE(t1.lob_type, t2.lob_type), 
       NULL                                   AS active_ind, 
       denominator, 
       numerator, 
       t2.eventcodevalue                      AS cpt_code, 
       t2.eventenddate                        AS date_of_service, 
       COALESCE(t1.group_desc, t2.group_desc), 
       COALESCE(t1.group_no, t2.group_no), 
       t1.eventenddate 
FROM   cte_denominator t1 
       FULL OUTER JOIN cte_numerator t2 
                    ON t1.eventsourcesystem = t2.eventsourcesystem 
                       AND t1.medicaid_id = t2.medicaid_id 
       INNER JOIN acpps_client_prd01..persondemographics t3 
               ON t1.personid = t3.personid; 
