select count(*) from payor.affinity_census where filename = 'Inpatient Notifications3_26_2020.csv'
