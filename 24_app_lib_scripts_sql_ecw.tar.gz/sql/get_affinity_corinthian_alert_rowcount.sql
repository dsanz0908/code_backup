select count(*) from payor.affinity_census where filename = 'Inpatient Notifications1_30_2020.csv'
