select count(*) from payor.affinity_census where filename = 'Inpatient Notifications3_5_2020.csv'
