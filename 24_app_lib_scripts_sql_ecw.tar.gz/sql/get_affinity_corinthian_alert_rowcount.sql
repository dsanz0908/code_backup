select count(*) from payor.affinity_census where filename = 'Inpatient Notifications2_27_2020.csv'
