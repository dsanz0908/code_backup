select count(*) from payor.affinity_census where filename = 'Inpatient Notifications2_20_2020.csv'
