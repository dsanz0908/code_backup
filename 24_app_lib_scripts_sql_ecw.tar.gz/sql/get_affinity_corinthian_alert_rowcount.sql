select count(*) from payor.affinity_census where filename = 'Inpatient Notifications2_13_2020.csv'
