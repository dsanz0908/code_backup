select count(*) from payor.affinity_census where filename = 'Inpatient Notifications1_15_2020.csv'
