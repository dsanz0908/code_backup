select count(*) from payor.affinity_census where filename = 'Inpatient Notifications4_2_2020.csv'
