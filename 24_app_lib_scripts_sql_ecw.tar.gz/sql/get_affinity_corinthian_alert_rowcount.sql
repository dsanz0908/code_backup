select count(*) from payor.affinity_census where filename = 'Inpatient Notifications1_23_2020.csv'
