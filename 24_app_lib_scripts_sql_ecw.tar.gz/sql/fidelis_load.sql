drop table if exists staging_fidelis;
create temp table if not exists staging_fidelis ( 
member_id VARCHAR(255),
enrollment_category_desc VARCHAR(255),
region_desc VARCHAR(255),
county_code VARCHAR(255),
county_desc VARCHAR(255),
revenue_ind VARCHAR(255),
revenue_amount VARCHAR(255),
revenue_date VARCHAR(255));
grant all on staging_fidelis to etluser;
copy staging_fidelis from 's3://acp-data/Fidelis/Somos/FidelisCare_Prod_MedicaidRevenue_FULL_SOMOSINNOVATOR_20160101_20190628.txt' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter '|';
delete from payor.FidelisCare_Prod_MedicaidRevenue_FULL_SOMOS_all where filename = 'FidelisCare_Prod_MedicaidRevenue_FULL_SOMOSINNOVATOR_20160101_20190628.txt';
insert into payor.FidelisCare_Prod_MedicaidRevenue_FULL_SOMOS_all (member_id,enrollment_category_desc,region_desc,county_code,county_desc,revenue_ind,revenue_amount,revenue_date, filename, received_month) select member_id,enrollment_category_desc,region_desc,county_code,county_desc,revenue_ind,revenue_amount,revenue_date, 'FidelisCare_Prod_MedicaidRevenue_FULL_SOMOSINNOVATOR_20160101_20190628.txt', 201906 from staging_fidelis;
