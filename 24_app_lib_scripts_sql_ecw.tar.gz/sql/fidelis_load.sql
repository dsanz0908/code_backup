drop table if exists staging_fidelis;
create temp table if not exists staging_fidelis ( 
claim_id VARCHAR(255),
claim_line VARCHAR(255),
service_from_date VARCHAR(255),
service_to_date VARCHAR(255),
place_of_service VARCHAR(255),
emergency_indicator VARCHAR(255),
procedure_code VARCHAR(255),
modifier_1 VARCHAR(255),
modifier_2 VARCHAR(255),
modifier_3 VARCHAR(255),
modifier_4 VARCHAR(255),
diagnosis_code_pointer VARCHAR(255),
line_charge VARCHAR(255),
billed_units VARCHAR(255),
id_qualifier VARCHAR(255),
provider_id VARCHAR(255),
plan_paid VARCHAR(255),
member_liability VARCHAR(255),
allowed_amount VARCHAR(255),
covered_units VARCHAR(255),
member_responsibility VARCHAR(255),
capitation_indicator
VARCHAR(255));
grant all on staging_fidelis to etluser;
copy staging_fidelis from 's3://acp-data/Fidelis/Somos/FidelisCare_Prod_VisionLine_FULL_SOMOSINNOVATOR_20170101_20200220.txt' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter '|';
delete from payor.FidelisCare_Prod_VisionLine_FULL_SOMOS_all where filename = 'FidelisCare_Prod_VisionLine_FULL_SOMOSINNOVATOR_20170101_20200220.txt';
insert into payor.FidelisCare_Prod_VisionLine_FULL_SOMOS_all (claim_id,claim_line,service_from_date,service_to_date,place_of_service,emergency_indicator,procedure_code,modifier_1,modifier_2,modifier_3,modifier_4,diagnosis_code_pointer,line_charge,billed_units,id_qualifier,provider_id,plan_paid,member_liability,allowed_amount,covered_units,member_responsibility,capitation_indicator, filename, received_month) select claim_id,claim_line,service_from_date,service_to_date,place_of_service,emergency_indicator,procedure_code,modifier_1,modifier_2,modifier_3,modifier_4,diagnosis_code_pointer,line_charge,billed_units,id_qualifier,provider_id,plan_paid,member_liability,allowed_amount,covered_units,member_responsibility,capitation_indicator, 'FidelisCare_Prod_VisionLine_FULL_SOMOSINNOVATOR_20170101_20200220.txt', '20170101_20200220' from staging_fidelis;
