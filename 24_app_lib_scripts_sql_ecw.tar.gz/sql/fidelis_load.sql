drop table if exists staging_fidelis;
create temp table if not exists staging_fidelis ( 
person_id VARCHAR(255),
cin VARCHAR(255),
member_name VARCHAR(255),
person_dob VARCHAR(255),
age_group_cd VARCHAR(255),
person_gender VARCHAR(255),
line_of_business_desc VARCHAR(255),
product_type_desc VARCHAR(255),
paid_through_date VARCHAR(255),
phys_network_name VARCHAR(255),
phys_group_id VARCHAR(255),
phys_group_name VARCHAR(255),
npi VARCHAR(255),
phys_name VARCHAR(255),
crg_weight VARCHAR(255),
member_months VARCHAR(255),
active_flag VARCHAR(255),
patient_segment_desc VARCHAR(255),
acrg3_base VARCHAR(255),
acrg3_desc VARCHAR(255),
reporting_period_desc
VARCHAR(255));
grant all on staging_fidelis to etluser;
copy staging_fidelis from 's3://acp-data/Fidelis/Somos/FidelisCare_Prod_MemberCRG_FULL_SOMOSInnovator_20160101_20190802.txt' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' delimiter '|';
delete from payor.FidelisCare_Prod_MemberCRG_FULL_SOMOSInnovator where filename = 'FidelisCare_Prod_MemberCRG_FULL_SOMOSInnovator_20160101_20190802.txt';
insert into payor.FidelisCare_Prod_MemberCRG_FULL_SOMOSInnovator (person_id,cin,member_name,person_dob,age_group_cd,person_gender,line_of_business_desc,product_type_desc,paid_through_date,phys_network_name,phys_group_id,phys_group_name,npi,phys_name,crg_weight,member_months,active_flag,patient_segment_desc,acrg3_base,acrg3_desc,reporting_period_desc, filename, received_month) select person_id,cin,member_name,person_dob,age_group_cd,person_gender,line_of_business_desc,product_type_desc,paid_through_date,phys_network_name,phys_group_id,phys_group_name,npi,phys_name,crg_weight,member_months,active_flag,patient_segment_desc,acrg3_base,acrg3_desc,reporting_period_desc, 'FidelisCare_Prod_MemberCRG_FULL_SOMOSInnovator_20160101_20190802.txt', '201908' from staging_fidelis;
