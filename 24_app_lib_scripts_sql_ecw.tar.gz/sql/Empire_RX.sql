create temp table if not exists staging_empire_somos ( 
CLM_NBR VARCHAR(255),
RX_FILLED_DT VARCHAR(255),
PRODUCT VARCHAR(255),
PCP VARCHAR(255),
PCP_TIN VARCHAR(255),
SRC_SUBS_ID VARCHAR(255),
MCD_Number VARCHAR(255),
MBR_FIRST_NAME VARCHAR(255),
MBR_LAST_NAME VARCHAR(255),
DOB VARCHAR(255),
Prescriber_NPI VARCHAR(255),
Prescriber VARCHAR(255),
PrescribingSpecialty VARCHAR(255),
DRUG_NAME VARCHAR(255),
SCRIPT_CNT VARCHAR(255),
REFILL_CNT VARCHAR(255),
ANL_Paid_Amt VARCHAR(255));
grant all on staging_empire_somos to etluser;
copy staging_empire_somos from 's3://acp-data/Empire/Somos/Empire_BCBS_HealthPlus_RX_CLM_SOMOS_201701_201901.TXT' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' delimiter ' ' NULL as 'NULL' dateformat 'auto' REMOVEQUOTES;
delete from  where filename = 'Empire_BCBS_HealthPlus_RX_CLM_SOMOS_201701_201901.TXT';
insert into  ( 
)
select 
from staging_empire_somos;
