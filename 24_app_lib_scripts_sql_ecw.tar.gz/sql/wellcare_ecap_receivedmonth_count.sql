select count(*) from payor.wellcare_all_demographics where master_ipa = 'EC1' and receivedmonth = ''
