select
distinct pat_first_name,
                pat_last_name,
dob,
                cast(cc_date_of_service as date) as dos,
                cc_cpt_code
from (

select *, row_number() over (partition by pat_first_name, pat_last_name, dob order by cc_date_of_service desc) as rn from
(SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       JOIN provider_master
         ON cc_rendering_provider_id = prov_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service >= '2010-01-01'
       AND cc_cpt_code IN ( '44388', '44389', '44390', '44391',
                        '44392', '44393', '44394', '44397',
                        '44401', '44402', '44403', '44404',
                        '44405', '44406', '44407', '44408',
                        '45355', '45378', '45379', '45380',
                        '45381', '45382', '45383', '45384',
                        '45385', '45386', '45387', '45388',
                        '45389', '45390', '45391', '45392',
                        '45393', '45398', 'G0105', 'G0121' )
       AND pat_delete_ind = 'N'
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                collection_date,
                '44388'
FROM   t_result
       JOIN t_patient
         ON t_patient.pat_id = t_result.pat_id
       JOIN provider_master
         ON provider_id = prov_id
WHERE  delete_ind = 'N'
       AND collection_date >= '2010-01-01'
       AND pat_delete_ind = 'N'
       AND ( original_name LIKE '%colonoscopy%'
              OR result_value LIKE '%colonoscopy%' )
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                result_received_date,
                '44388'
FROM   t_order
       JOIN t_patient
         ON t_patient.pat_id = t_order.pat_id
       JOIN provider_master
         ON ordering_provider_id = prov_id
WHERE  delete_ind = 'N'
       AND result_received_date >= '2010-01-01'
       AND pat_delete_ind = 'N'
       AND ( order_name LIKE '%colonoscopy%'
              OR order_notes LIKE '%colonoscopy%'
              OR order_category LIKE '%colonoscopy%'
              OR cpt_code IN ( '44388', '44389', '44390', '44391',
                        '44392', '44393', '44394', '44397',
                        '44401', '44402', '44403', '44404',
                        '44405', '44406', '44407', '44408',
                        '45355', '45378', '45379', '45380',
                        '45381', '45382', '45383', '45384',
                        '45385', '45386', '45387', '45388',
                        '45389', '45390', '45391', '45392',
                        '45393', '45398', 'G0105', 'G0121' ) )
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       JOIN provider_master
         ON cc_rendering_provider_id = prov_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service >= '2015-01-01'
       AND cc_cpt_code IN ( '45330', '45331', '45332', '45333',
                        '45334', '45335', '45337', '45338',
                        '45339', '45340', '45341', '45342',
                        '45345', '45346', '45347', '45349', '45350', 'G0104' )
       AND pat_delete_ind = 'N'
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                collection_date,
                '45330'
FROM   t_result
       JOIN t_patient
         ON t_patient.pat_id = t_result.pat_id
       JOIN provider_master
         ON provider_id = prov_id
WHERE  delete_ind = 'N'
       AND collection_date >= '2015-01-01'
       AND pat_delete_ind = 'N'
       AND ( original_name LIKE '%sigmoidoscopy%'
              OR result_value LIKE '%sigmoidoscopy%' )
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                result_received_date,
                '45330'
FROM   t_order
       JOIN t_patient
         ON t_patient.pat_id = t_order.pat_id
       JOIN provider_master
         ON ordering_provider_id = prov_id
WHERE  delete_ind = 'N'
       AND result_received_date >= '2015-01-01'
       AND pat_delete_ind = 'N'
       AND ( order_name LIKE '%sigmoidoscopy%'
              OR order_notes LIKE '%sigmoidoscopy%'
              OR order_category LIKE '%sigmoidoscopy%'
              OR cpt_code IN ( '45330', '45331', '45332', '45333',
                        '45334', '45335', '45337', '45338',
                        '45339', '45340', '45341', '45342',
                        '45345', '45346', '45347', '45349', '45350', 'G0104' ) )
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       JOIN provider_master
         ON cc_rendering_provider_id = prov_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service >= '2019-01-01'
       AND cc_cpt_code IN ( '82270', '82274', 'G0328' )
       AND pat_delete_ind = 'N'
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                collection_date,
                '44388'
FROM   t_result
       JOIN t_patient
         ON t_patient.pat_id = t_result.pat_id
       JOIN provider_master
         ON provider_id = prov_id
WHERE  delete_ind = 'N'
       AND collection_date >= '2019-01-01'
       AND pat_delete_ind = 'N'
       AND ( original_name LIKE '%fobt%'
              OR result_value LIKE '%fobt%' )
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                result_received_date,
                '82270'
FROM   t_order
       JOIN t_patient
         ON t_patient.pat_id = t_order.pat_id
       JOIN provider_master
         ON ordering_provider_id = prov_id
WHERE  delete_ind = 'N'
       AND result_received_date >= '2019-01-01'
       AND pat_delete_ind = 'N'
       AND ( order_name LIKE '%fobt%'
              OR order_notes LIKE '%fobt%'
              OR order_category LIKE '%fobt%'
              OR cpt_code IN ( '82270', '82274', 'G0328' ) )
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       JOIN provider_master
         ON cc_rendering_provider_id = prov_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service >= '2018-01-01'
       AND cc_cpt_code IN ( '74263', '81528', 'G0464' )
       AND pat_delete_ind = 'N'
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                collection_date,
                '44388'
FROM   t_result
       JOIN t_patient
         ON t_patient.pat_id = t_result.pat_id
       JOIN provider_master
         ON provider_id = prov_id
WHERE  delete_ind = 'N'
       AND collection_date >= '2018-01-01'
       AND pat_delete_ind = 'N'
       AND ( original_name LIKE '%fit%dna%'
              OR result_value LIKE '%fit%dna%' )
UNION ALL
SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE),
                result_received_date,
                '74263'
FROM   t_order
       JOIN t_patient
         ON t_patient.pat_id = t_order.pat_id
       JOIN provider_master
         ON ordering_provider_id = prov_id
WHERE  delete_ind = 'N'
       AND result_received_date >= '2018-01-01'
       AND pat_delete_ind = 'N'
       AND ( order_name LIKE '%fit%dna%'
              OR order_notes LIKE '%fit%dna%'
              OR order_category LIKE '%fit%dna%'
              OR cpt_code IN ( '74263', '81528', 'G0464' ) )) as t1) as t2 where rn = 1
