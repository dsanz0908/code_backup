SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                dob, 
                Cast(cc_date_of_service AS DATE) AS dos, 
                cc_cpt_code, cc_dx_id_1 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY pat_first_name, pat_last_name, dob 
                   ORDER BY cc_date_of_service DESC) AS rn 
        FROM   (SELECT pat_first_name, 
                       pat_last_name, 
                       Cast(pat_date_of_birth AS DATE) dob, 
                       cc_date_of_service, 
                       cc_cpt_code, cc_dx_id_1 
                FROM   t_chargecapture 
                       JOIN t_patient 
                         ON cc_patient_id = pat_id 
                       JOIN provider_master 
                         ON cc_rendering_provider_id = prov_id 
                WHERE  cc_delete_ind = 'N' 
                       AND cc_date_of_service between '2010-01-01' and '2019-12-31'
                       AND cc_cpt_code IN ( '44388', '44389', '44390', '44391', 
                                            '44392', '44393', '44394', '44397', 
                                            '44401', '44402', '44403', '44404', 
                                            '44405', '44406', '44407', '44408', 
                                            '45355', '45378', '45379', '45380', 
                                            '45381', '45382', '45383', '45384', 
                                            '45385', '45386', '45387', '45388', 
                                            '45389', '45390', '45391', '45392', 
                                            '45393', '45398', 'G0105', 'G0121' ) 
                       AND pat_delete_ind = 'N' 
                UNION ALL 
                SELECT pat_first_name, 
                       pat_last_name, 
                       Cast(pat_date_of_birth AS DATE) dob, 
                       cc_date_of_service, 
                       cc_cpt_code, cc_dx_id_1 
                FROM   t_chargecapture 
                       JOIN t_patient 
                         ON cc_patient_id = pat_id 
                       JOIN provider_master 
                         ON cc_rendering_provider_id = prov_id 
                WHERE  cc_delete_ind = 'N' 
                       AND cc_date_of_service between '2015-01-01' and '2019-12-31'
                       AND cc_cpt_code IN ( '45330', '45331', '45332', '45333', 
                                            '45334', '45335', '45337', '45338', 
                                            '45339', '45340', '45341', '45342', 
                                            '45345', '45346', '45347', '45349', 
                                            '45350', 'G0104' ) 
                       AND pat_delete_ind = 'N' 
                UNION ALL 
                SELECT pat_first_name, 
                       pat_last_name, 
                       Cast(pat_date_of_birth AS DATE) dob, 
                       cc_date_of_service, 
                       cc_cpt_code, cc_dx_id_1 
                FROM   t_chargecapture 
                       JOIN t_patient 
                         ON cc_patient_id = pat_id 
                       JOIN provider_master 
                         ON cc_rendering_provider_id = prov_id 
                WHERE  cc_delete_ind = 'N' 
                       AND cc_date_of_service between '2019-01-01' and '2019-12-31'
                       AND cc_cpt_code IN ( '82270', '82274', 'G0328' ) 
                       AND pat_delete_ind = 'N' 
                UNION ALL 
                SELECT pat_first_name, 
                       pat_last_name, 
                       Cast(pat_date_of_birth AS DATE) dob, 
                       cc_date_of_service, 
                       cc_cpt_code, cc_dx_id_1 
                FROM   t_chargecapture 
                       JOIN t_patient 
                         ON cc_patient_id = pat_id 
                       JOIN provider_master 
                         ON cc_rendering_provider_id = prov_id 
                WHERE  cc_delete_ind = 'N' 
                       AND cc_date_of_service between '2018-01-01' and '2019-12-31'
                       AND cc_cpt_code IN ( '74263', '81528', 'G0464' ) 
                       AND pat_delete_ind = 'N') AS t1) AS t2 
WHERE  rn = 1 
