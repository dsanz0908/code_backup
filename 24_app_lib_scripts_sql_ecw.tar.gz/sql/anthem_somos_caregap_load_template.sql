delete from payor.staging_anthem_somos_all_caregaps;

copy payor.staging_anthem_somos_all_caregaps
from 's3://acp-data/Anthem/Somos/Anthem_SOMOS_CareGaps_YEARMONTH.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 2
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;

delete from payor.anthem_somos_all_caregaps where filename = 'Anthem_SOMOS_CareGaps_YEARMONTH.txt';
insert into payor.anthem_somos_all_caregaps (select stg.*, 'Anthem_SOMOS_CareGaps_YEARMONTH.txt' from payor.staging_anthem_somos_all_caregaps stg)
