delete arcadia.TABLENAME WHERE arcadia_to_somos_filename = 'FILENAME';
copy arcadia.TABLENAME
from 's3://acp-data/Arcadia/Incoming/FILENAME'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
ignoreheader 1
region 'us-east-1'
dateformat 'auto'
csv;
