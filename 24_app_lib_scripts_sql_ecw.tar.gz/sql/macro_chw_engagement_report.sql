WITH cte_date_snapshots AS 
( 
         SELECT   npi, 
                  Min(t) :: date AS date_snapshot 
         FROM     ( 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') as npi, 
                                timestamp                                                                   AS t
                         FROM   etl_new.success_new 
                         WHERE  timestamp >= '2019-04-01' 
                         UNION ALL 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                                timestamp                                                                   AS t
                         FROM   etl_new.fail_new 
                         WHERE  timestamp >= '2019-04-01') 
         GROUP BY 1), cte_snapshot AS 
( 
       SELECT b.* 
       FROM   cte_date_snapshots AS a 
       JOIN 
              ( 
                     SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                            'success'                                                                   AS status,
                            timestamp                                                                   AS t,
                            0                                                                           AS errorzero,
                            0                                                                           AS errorone
                     FROM   etl_new.success_new 
                     WHERE  timestamp >= '2019-04-01' 
                     UNION ALL 
                     SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                            'fail', 
                            timestamp AS t, 
                            CASE 
                                   WHEN error ilike '%Processing failed%' 
                                   AND    s3_key NOT ilike '%Insurance%' 
                                   AND    s3_key NOT ilike '%Report%' THEN 1 
                                   WHEN error ilike '%Unable to extract%' THEN 1 
                                   ELSE 0 
                            END, 
                            CASE 
                                   WHEN error ilike '%A required column%' 
                                   OR     error ilike '%Name column not found%' 
                                   OR     error ilike '%Excel file has more than one sheet%' 
                                   OR     error ilike '%Unsupported format%' 
                                   OR     error ilike '%bad operand type for unary%' 
                                   OR     error ilike '%Unkown header format%' 
                                   OR     error ilike '%Error tokenizing%' THEN 1 
                                   ELSE 0 
                            END 
                     FROM   etl_new.fail_new 
                     WHERE  timestamp >= '2019-04-01') AS b 
       ON     a.npi = b.npi 
       AND    date_snapshot = t::date), cte_delta AS 
( 
       SELECT b.* 
       FROM   cte_date_snapshots AS a 
       JOIN 
              ( 
                     SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                            'success'                                                                   AS status,
                            timestamp                                                                   AS t,
                            0                                                                           AS errorzero,
                            0                                                                           AS errorone
                     FROM   etl_new.success_new 
                     WHERE  timestamp >= '2019-04-01' 
                     UNION ALL 
                     SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                            'fail', 
                            timestamp AS t, 
                            CASE 
                                   WHEN error ilike '%Processing failed%' 
                                   AND    s3_key NOT ilike '%Insurance%' 
                                   AND    s3_key NOT ilike '%Report%' THEN 1 
                                   WHEN error ilike '%Unable to extract%' THEN 1 
                                   ELSE 0 
                            END, 
                            CASE 
                                   WHEN error ilike '%A required column%' 
                                   OR     error ilike '%Name column not found%' 
                                   OR     error ilike '%Excel file has more than one sheet%' 
                                   OR     error ilike '%Unsupported format%' 
                                   OR     error ilike '%bad operand type for unary%' 
                                   OR     error ilike '%Unkown header format%' 
                                   OR     error ilike '%Error tokenizing%' THEN 1 
                                   ELSE 0 
                            END 
                     FROM   etl_new.fail_new 
                     WHERE  timestamp >= '2019-04-01') AS b 
       ON     a.npi = b.npi 
       AND    date_snapshot < t::date) 
SELECT          sa.npi, 
                NAME AS practice, 
                emr, 
                last_pass, 
                segment_lead AS segmentlead, 
                team_lead    AS teamlead, 
                gatekeeper, 
                team_member AS teammember, 
                ( 
                       SELECT count(DISTINCT t) 
                       FROM   cte_snapshot 
                       WHERE  npi = sa.npi)::varchar AS totalsubmitted, 
                sum( 
                CASE 
                                WHEN status = 'success' THEN 1 
                                ELSE 0 
                END)::                      varchar AS totalprocessed, 
                COALESCE(sum(errorzero),0)::varchar AS totalerrors, 
                COALESCE(sum(errorzero) - sum( 
                CASE 
                                WHEN when_status = 'snapshot' 
                                AND             errorzero = 1 THEN 1 
                                ELSE 0 
                END),0)::                  varchar AS unresolvederrors, 
                COALESCE(sum(errorone),0)::varchar AS totalcleanup, 
                COALESCE(sum(errorone) - sum( 
                CASE 
                                WHEN when_status = 'snapshot' 
                                AND             errorone = 1 THEN 1 
                                ELSE 0 
                END),0)::varchar               AS unresolvedcleanup, 
                max(t)                         AS last_modified 
FROM            etl_new.sneakernet_assignments AS sa 
LEFT OUTER JOIN 
                ( 
                       SELECT *, 
                              'snapshot' AS when_status 
                       FROM   cte_snapshot 
                       UNION ALL 
                       SELECT *, 
                              'delta' 
                       FROM   cte_delta) AS all_rows 
ON              sa.npi = all_rows.npi 
GROUP BY        1, 
                2, 
                3, 
                4, 
                5, 
                6, 
                7, 
                8 
ORDER BY        practice
