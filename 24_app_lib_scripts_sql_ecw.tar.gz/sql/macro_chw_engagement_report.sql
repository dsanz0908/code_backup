WITH cte_date_snapshots AS 
( 
         SELECT   npi, 
                  Min(t) :: date AS date_snapshot 
         FROM     ( 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') as npi, 
                                timestamp                                                                   AS t
                         FROM   etl_new.success_new 
                         WHERE  timestamp >= '2019-04-01' 
                         UNION ALL 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                                timestamp                                                                   AS t
                         FROM   etl_new.fail_new 
                         WHERE  timestamp >= '2019-04-01') 
         GROUP BY 1), 
cte_snapshot AS 
( 
         SELECT   b.*, 
                  'snapshot'                                                                                                                                AS when_status,
                  row_number() OVER (partition BY replace(lower(s3_key), split_part(lower(s3_key), '.', regexp_count(s3_key,'[.]')+1), '') ORDER BY t DESC) AS temp_rn
         FROM     cte_date_snapshots                                                                                                                        AS a
         JOIN 
                  ( 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')              AS npi, 
                                'success'                                                                                AS status,
                                timestamp                                                                                AS t,
                                0                                                                                        AS errorzero,
                                0                                                                                        AS errorone,
                                replace(lower(s3_key), split_part(lower(s3_key), '.', regexp_count(s3_key,'[.]')+1), '') AS s3_key
                         FROM   etl_new.success_new 
                         WHERE  timestamp >= '2019-04-01' 
                         UNION ALL 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                                'fail', 
                                timestamp AS t, 
                                CASE 
                                       WHEN error ilike '%Processing failed%' 
                                       AND    s3_key NOT ilike '%Insurance%' 
                                       AND    s3_key NOT ilike '%Report%' THEN 1 
                                       WHEN error ilike '%Unable to extract%' THEN 1 
                                       ELSE 0 
                                END, 
                                CASE 
                                       WHEN error ilike '%A required column%' 
                                       OR     error ilike '%Name column not found%' 
                                       OR     error ilike '%Excel file has more than one sheet%'
                                       OR     error ilike '%Unsupported format%' 
                                       OR     error ilike '%bad operand type for unary%' 
                                       OR     error ilike '%Unkown header format%' 
                                       OR     error ilike '%Error tokenizing%' THEN 1 
                                       ELSE 0 
                                                                                                                            END,
                                replace(lower(s3_key), split_part(lower(s3_key), '.', regexp_count(s3_key,'[.]')+1), '') AS s3_key
                         FROM   etl_new.fail_new 
                         WHERE  timestamp >= '2019-04-01') AS b 
         ON       a.npi = b.npi 
         AND      date_snapshot = t::date), 
cte_delta AS 
( 
         SELECT   b.*, 
                  'delta', 
                  row_number() OVER (partition BY s3_key ORDER BY t DESC) AS temp_rn 
         FROM     cte_date_snapshots                                      AS a 
         JOIN 
                  ( 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')              AS npi, 
                                'success'                                                                                AS status,
                                timestamp                                                                                AS t,
                                0                                                                                        AS errorzero,
                                0                                                                                        AS errorone,
                                replace(lower(s3_key), split_part(lower(s3_key), '.', regexp_count(s3_key,'[.]')+1), '') AS s3_key
                         FROM   etl_new.success_new 
                         WHERE  timestamp >= '2019-04-01' 
                         UNION ALL 
                         SELECT regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                                'fail', 
                                timestamp AS t, 
                                CASE 
                                       WHEN error ilike '%Processing failed%' 
                                       AND    s3_key NOT ilike '%Insurance%' 
                                       AND    s3_key NOT ilike '%Report%' THEN 1 
                                       WHEN error ilike '%Unable to extract%' THEN 1 
                                       ELSE 0 
                                END, 
                                CASE 
                                       WHEN error ilike '%A required column%' 
                                       OR     error ilike '%Name column not found%' 
                                       OR     error ilike '%Excel file has more than one sheet%'
                                       OR     error ilike '%Unsupported format%' 
                                       OR     error ilike '%bad operand type for unary%' 
                                       OR     error ilike '%Unkown header format%' 
                                       OR     error ilike '%Error tokenizing%' THEN 1 
                                       ELSE 0 
                                                                                                                            END,
                                replace(lower(s3_key), split_part(lower(s3_key), '.', regexp_count(s3_key,'[.]')+1), '') AS s3_key
                         FROM   etl_new.fail_new 
                         WHERE  timestamp >= '2019-04-01') AS b 
         ON       a.npi = b.npi 
         AND      date_snapshot < t::date), 
all_rows AS 
( 
         SELECT   *, 
                  row_number() OVER (partition BY s3_key ORDER BY t DESC) AS rn 
         FROM     ( 
                         SELECT * 
                         FROM   cte_snapshot 
                         UNION ALL 
                         SELECT * 
                         FROM   cte_delta)), 
cte_ec AS 
( 
       SELECT npi, 
              lower(replace(s3_key, ' ', '_')) AS f, 
              errorzero, 
              errorone, 
              t 
       FROM   all_rows 
       WHERE  rn = 1), cte_summary AS 
( 
       SELECT cte_ec.*, 
              ec_snapshot.errorzero AS snapshot_errorzero, 
              ec_snapshot.errorone  AS snapshot_errorone 
       FROM   cte_ec 
       JOIN 
              ( 
                     SELECT npi, 
                            lower(replace(s3_key, ' ', '_')) AS f, 
                            errorzero, 
                            errorone 
                     FROM   cte_snapshot 
                     WHERE  temp_rn = 1) AS ec_snapshot 
       ON     cte_ec.f = ec_snapshot.f) 
SELECT          sa.npi, 
                NAME AS practice, 
                emr, 
                last_pass, 
                segment_lead AS segmentlead, 
                team_lead    AS teamlead, 
                gatekeeper, 
                team_member AS teammember, 
                ( 
                       SELECT count(*) 
                       FROM   all_rows 
                       WHERE  rn = 1 
                       AND    sa.npi = npi)::varchar AS totalsubmitted, 
                ( 
                       SELECT count(*) 
                       FROM   all_rows 
                       WHERE  rn = 1 
                       AND    sa.npi = npi 
                       AND    status = 'success')::  varchar AS totalprocessed, 
                COALESCE(sum(snapshot_errorzero),0)::varchar AS totalerrors, 
                COALESCE(sum(errorzero),0)::         varchar AS unresolvederrors, 
                COALESCE(sum(snapshot_errorone),0):: varchar AS totalcleanups, 
                COALESCE(sum(errorone),0)::          varchar AS unresolvedcleanups, 
                max(t)                                       AS last_modified 
FROM            etl_new.sneakernet_assignments               AS sa 
LEFT OUTER JOIN cte_summary 
ON              sa.npi = cte_summary.npi 
GROUP BY        1, 
                2, 
                3, 
                4, 
                5, 
                6, 
                7, 
                8 
ORDER BY        practice
