select top 10000 * from gdw.medications order by random()
