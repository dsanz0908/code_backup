create temp table if not exists staging_empire_somos ( 
MEMBERSHIP_MONTH VARCHAR(255),
PRODUCT VARCHAR(255),
REGION VARCHAR(255),
EMPIRE_Member_ID VARCHAR(255),
MEMBER_MEDICAID_NUMBER VARCHAR(255),
MEMBER_LAST_NAME VARCHAR(255),
MEMBER_FIRST_NAME VARCHAR(255),
GEND_DESC VARCHAR(255),
LANG_DESC VARCHAR(255),
RACE_ETHN_DESC VARCHAR(255),
MEMBER_DOB VARCHAR(255),
PCP_NAME VARCHAR(255),
EMPIRE_PROVIDER_ID VARCHAR(255),
PCP_NPI VARCHAR(255),
PCP_TIN VARCHAR(255),
IPA VARCHAR(255),
MBRSHIP_START_DATE VARCHAR(255),
MBRSHIP_END_DATE VARCHAR(255),
MM_CNT VARCHAR(255));
grant all on staging_empire_somos to etluser;
copy staging_empire_somos from 's3://acp-data/Empire/Somos/Empire_BCBS_HealthPlus_Enrollment_SOMOS_201701_201901.TXT_1' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' delimiter ' ' NULL as 'NULL' dateformat 'auto' REMOVEQUOTES;
delete from  where filename = 'Empire_BCBS_HealthPlus_Enrollment_SOMOS_201701_201901.TXT_1';
insert into  ( 
)
select 
from staging_empire_somos;
