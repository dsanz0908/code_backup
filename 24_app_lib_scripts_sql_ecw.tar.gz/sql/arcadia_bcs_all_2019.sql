SELECT DISTINCT cc_patient_id, 
                Cast(cc_date_of_service AS DATE), 
                cc_cpt_code 
FROM   t_chargecapture 
WHERE  cc_delete_ind = 'N' 
       AND cc_date_of_service >= '2017-10-01'
       AND cc_cpt_code IN ( '77055', '77056', '77057', '77061', 
                            '77062', '77063', '77065', '77066', '77067' ) 
