create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';


create temporary table emr_january2019_arcadia_info (
enc_patient_id varchar(255),
encounter_count varchar(255),
site_count varchar(255),
provider_count varchar(255),
vitals_height varchar(255),
vitals_weight varchar(255),
vitals_bmi varchar(255),
vitals_systolic varchar(255),
vitals_diastolic varchar(255),
vitals_temperature varchar(255),
vitals_heart_rate varchar(255),
vitals_spo2 varchar(255),
vitals_bmi_percentile varchar(255),
icd10_count varchar(255),
cpt_count varchar(255),
cvx_count varchar(255),
order_category_count varchar(255),
ndc_count varchar(255));

delete from emr_january2019_arcadia_info;
copy emr_january2019_arcadia_info
from 's3://sftp_test/emr_january2019_arcadia_info.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 500
region 'us-east-1'
dateformat 'auto'
delimiter '|'
NULL as 'NULL';


WITH cte_match_ids 
     AS (SELECT enc_patient_id AS pat_id, 
                Max(CASE 
                      WHEN rn = 1 THEN mco_cin 
                    END)       AS id_1, 
                Max(CASE 
                      WHEN rn = 2 THEN mco_cin 
                    END)       AS id_2, 
                Max(CASE 
                      WHEN rn = 3 THEN mco_cin 
                    END)       AS id_3 
         FROM   (SELECT a.*, 
                        Row_number() 
                          OVER ( 
                            partition BY enc_patient_id 
                            ORDER BY mco_cin) AS rn 
                 FROM   (SELECT DISTINCT enc_patient_id, 
                                         mco_cin 
                         FROM   emr_january2019_arcadia_info AS a 
                                JOIN fuzz_test 
                                  ON enc_patient_id = arcadia_pat_id) AS a) 
         GROUP  BY 1), 
     cte_paid 
     AS (SELECT member_id, 
                Sum(cost) AS paid 
         FROM   (SELECT dim_membership.member_cin AS member_id, 
                        to_pay_amount             AS cost 
                 FROM   fact_claims 
                        JOIN dim_membership 
                          ON fact_claims.local_member_id = dim_membership.local_member_id 
                 WHERE  effective_date >= '2019-01-01' 
                 UNION ALL 
                 SELECT dim_membership.member_cin, 
                        to_pay_amount AS cost 
                 FROM   fact_pharmacy_claims 
                        JOIN dim_membership 
                          ON fact_pharmacy_claims.local_member_id = dim_membership.local_member_id
                 WHERE  effective_date >= '2019-01-01' 
                 UNION ALL 
                 SELECT dim_membership.healthfirst_src_member_id, 
                        to_pay_amount AS cost 
                 FROM   fact_claims 
                        JOIN dim_membership 
                          ON fact_claims.local_member_id = dim_membership.local_member_id 
                 WHERE  effective_date >= '2019-01-01' 
                 UNION ALL 
                 SELECT dim_membership.healthfirst_src_member_id, 
                        to_pay_amount AS cost 
                 FROM   fact_pharmacy_claims 
                        JOIN dim_membership 
                          ON fact_pharmacy_claims.local_member_id = dim_membership.local_member_id
                 WHERE  effective_date >= '2019-01-01' 
                 UNION ALL 
                 SELECT dim_membership.wellcare_src_member_id, 
                        to_pay_amount AS cost 
                 FROM   fact_claims 
                        JOIN dim_membership 
                          ON fact_claims.local_member_id = dim_membership.local_member_id 
                 WHERE  effective_date >= '2019-01-01' 
                 UNION ALL 
                 SELECT dim_membership.wellcare_src_member_id, 
                        to_pay_amount AS cost 
                 FROM   fact_pharmacy_claims 
                        JOIN dim_membership 
                          ON fact_pharmacy_claims.local_member_id = dim_membership.local_member_id
                 WHERE  effective_date >= '2019-01-01') 
         GROUP  BY 1) 
SELECT emr_january2019_arcadia_info.*, case when paid > 10000 then 1 else 0 end as paid
FROM   emr_january2019_arcadia_info 
       JOIN cte_match_ids 
         ON enc_patient_id = pat_id 
       JOIN cte_paid 
         ON ( id_1 = member_id 
               OR id_2 = member_id 
               OR id_3 = member_id ) 
