insert into monte_patient_list_final
with cte_maxmember as (select DISTINCT mbr_id FROM nydoh.all_claims WHERE srv_dt BETWEEN '2017-01-01' AND '2017-12-31' AND received_month = '201806'
AND ( prim_dx_cd  IN ('F840','F842','F809','F843','F845','F848','F849','Q900','Q901','Q902','Q909','358','35801','3581','3582','3583','35831','35839','3588','3589','29900','29901','75800','343','3431','3432','3433','3434','3438','3439')
OR  dx_cd_2  IN ('F840','F809','F842','F843','F845','F848','F849','Q900','Q901','Q902','Q909','358','35801','3581','3582','3583','35831','35839','3588','3589','29900','29901','75800','343','3431','3432','3433','3434','3438','3439')
OR dx_cd_3  IN ('F840','F809','F842','F843','F845','F848','F849','Q900','Q901','Q902','Q909','358','35801','3581','3582','3583','35831','35839','3588','3589','29900','29901','75800','343','3431','3432','3433','3434','3438','3439')
OR dx_cd_4  IN ('F840','F809','F842','F843','F845','F848','F849','Q900','Q901','Q902','Q909','358','35801','3581','3582','3583','35831','35839','3588','3589','29900','29901','75800','343','3431','3432','3433','3434','3438','3439') 
OR proc_cd_1  IN ('G0161','T1021','G0496','T1022','G0159','G0158','S9122','G0160','G0164','G0179','G0157','G0495','G0064','G0299','S5181','G0181','S5180','s5130','t1019','t1020')
OR pl_of_srv_bill_type_cd  IN ('31','32','34','49')) )


select distinct
'' as "member_id (Healthplan)",
mbr_cin as Member_cin,
'' as Member_SSN,
c.beneficiary_date_of_birth as Member_dob,
c.beneficiary_sex_code as member_gender,
'' as "Dual_Eligible (Y/N)",
c.beneficiary_last_name as member_last_name,
c.beneficiary_first_name as member_first_name,
c.beneficiary_middle_name as member_middle_name,
c.address_line_1 as member_address1,
c.address_line_2 as member_address2,
c.city as member_city,
c.beneficiary_fips_state_code as member_state,
c.beneficiary_zip_code as member_zip,
'' as member_email,
c.plan_id as Healthplan,
c.phone_number as "Member Home/Main Phone Number",
'' as "Member Cell Phone Number",
'' as "Member Work Number",
pcp_npi as "PCP NPI",
NULL::DATE, --as "Somos Enrollment Date",
NULL::DATE, --as "Somos Term Date?"
sysdate,
null::TIMESTAMP,
null
from montechronic06282018 a
inner join nydoh.all_rosters_all_columns c
on a.mbr_cin=c.beneficiary_hic_number
WHERE C.RECEIVED_MONTH = '201807'
AND NOT EXISTS ( SELECT 1 FROM cte_maxmember cte WHERE MBR_CIN = CTE.MBR_ID )
AND (c.lead_health_home_mmis_id is null or c.lead_health_home_mmis_id='')
AND (c.phone_number != ('') and c.phone_number != '0' and c.phone_number != '0000000000')  
AND NOT EXISTS ( SELECT 1 FROM monte_patient_list_final mnt where MBR_CIN = mnt.member_cin )
