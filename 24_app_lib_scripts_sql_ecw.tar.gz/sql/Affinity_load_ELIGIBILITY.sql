delete from payor.staging_Affinity_corinthian_ELIGIBILITY;
copy payor.staging_Affinity_corinthian_ELIGIBILITY
from 's3://acp-data/Affinity/Corinthian/AFFINITY-CORINTHIAN-ELIGIBILITY-201901.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;
