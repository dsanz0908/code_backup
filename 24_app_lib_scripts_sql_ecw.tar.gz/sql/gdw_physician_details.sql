select top 10000 * from gdw.physician_details order by random()
