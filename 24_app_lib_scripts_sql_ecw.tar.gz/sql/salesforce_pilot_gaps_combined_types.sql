unload ($$
SELECT * 
FROM   (SELECT 'CHW', 
               NAME, 
               Count(DISTINCT whoid)  AS unique_members, 
               Count(DISTINCT whoid2) AS unique_members_with_open_gaps, 
               Count(DISTINCT whoid3), 
               Count(DISTINCT whoid4), 
               Count(DISTINCT whoid5), 
               Count(DISTINCT whoid6), 
               Count(DISTINCT whoid7), 
               Count(DISTINCT whoid8), 
               Count(DISTINCT whoid9) 
        FROM   (SELECT NAME, 
                       whoid, 
                       CASE 
                         WHEN status = 'Open' THEN whoid 
                         ELSE NULL 
                       END AS whoid2, 
                       CASE 
                         WHEN status = 'Closed' THEN whoid 
                         ELSE NULL 
                       END AS whoid3, 
                       CASE 
                         WHEN status LIKE 'Completed%' THEN whoid 
                         ELSE NULL 
                       END AS whoid4, 
                       CASE 
                         WHEN status LIKE 'Exclu%' THEN whoid 
                         ELSE NULL 
                       END AS whoid5, 
                       CASE 
                         WHEN status LIKE 'Issue%' THEN whoid 
                         ELSE NULL 
                       END AS whoid6, 
                       CASE 
                         WHEN status = 'Open - No Show' THEN whoid 
                         ELSE NULL 
                       END AS whoid7, 
                       CASE 
                         WHEN status = 'Outreach - Unable to reach' THEN whoid 
                         ELSE NULL 
                       END AS whoid8, 
                       CASE 
                         WHEN status LIKE '%Pending%' THEN whoid 
                         ELSE NULL 
                       END AS whoid9 
                FROM   salesforce_users AS a 
                       LEFT OUTER JOIN (SELECT * 
                                        FROM   (SELECT salesforce_tasks.*, contact_assigned_chw__c,
                                                       Row_number() 
                                                         OVER ( 
                                                           partition BY salesforce_tasks.id 
                                                           ORDER BY LEFT(salesforce_tasks.lastmodifieddate, 10) DESC,
                                                         added_tz 
                                                         DESC) AS 
                                                       rn 
                                                FROM   salesforce_tasks 
                                                       JOIN salesforce_patients 
                                                         ON salesforce_tasks.whoid = salesforce_patients.id
                                                WHERE  salesforce_tasks.project_end_date__c = '2019-12-31' 
                                                       AND pilot_initiative__c = 'TRUE') 
                                        WHERE  rn = 1) AS b 
                                    ON b.contact_assigned_chw__c = a.id) AS c 
        GROUP  BY NAME 
        HAVING Count(DISTINCT whoid) > 0 
        UNION 
        SELECT 'PRACTICE', 
               organization_name__c, 
               Count(DISTINCT whoid)  AS unique_members, 
               Count(DISTINCT whoid2) AS unique_members_with_open_gaps, 
               Count(DISTINCT whoid3), 
               Count(DISTINCT whoid4), 
               Count(DISTINCT whoid5), 
               Count(DISTINCT whoid6), 
               Count(DISTINCT whoid7), 
               Count(DISTINCT whoid8), 
               Count(DISTINCT whoid9) 
        FROM   (SELECT organization_name__c, 
                       whoid, 
                       CASE 
                         WHEN status = 'Open' THEN whoid 
                         ELSE NULL 
                       END AS whoid2, 
                       CASE 
                         WHEN status = 'Closed' THEN whoid 
                         ELSE NULL 
                       END AS whoid3, 
                       CASE 
                         WHEN status LIKE 'Completed%' THEN whoid 
                         ELSE NULL 
                       END AS whoid4, 
                       CASE 
                         WHEN status LIKE 'Exclu%' THEN whoid 
                         ELSE NULL 
                       END AS whoid5, 
                       CASE 
                         WHEN status LIKE 'Issue%' THEN whoid 
                         ELSE NULL 
                       END AS whoid6, 
                       CASE 
                         WHEN status = 'Open - No Show' THEN whoid 
                         ELSE NULL 
                       END AS whoid7, 
                       CASE 
                         WHEN status = 'Outreach - Unable to reach' THEN whoid 
                         ELSE NULL 
                       END AS whoid8, 
                       CASE 
                         WHEN status LIKE '%Pending%' THEN whoid 
                         ELSE NULL 
                       END AS whoid9 
                FROM   salesforce_providers AS a 
                       LEFT OUTER JOIN (SELECT * 
                                        FROM   (SELECT salesforce_tasks.*, 
                                                       Row_number() 
                                                         OVER ( 
                                                           partition BY salesforce_tasks.id 
                                                           ORDER BY LEFT(salesforce_tasks.lastmodifieddate, 10) DESC,
                                                         added_tz 
                                                         DESC) AS 
                                                       rn 
                                                FROM   salesforce_tasks 
                                                       JOIN salesforce_patients 
                                                         ON salesforce_tasks.whoid = salesforce_patients.id
                                                WHERE  salesforce_tasks.project_end_date__c = '2019-12-31'  and salesforce_tasks.isdeleted = 'FALSE'
                                                       AND pilot_initiative__c = 'TRUE') 
                                        WHERE  rn = 1) AS b 
                                    ON b.pcp__c = a.id) AS c 
        WHERE  organization_name__c <> '' 
        GROUP  BY organization_name__c 
        HAVING Count(DISTINCT whoid) > 0) AS d 
ORDER  BY 1, 
          2 
 $$) to 's3://sftp_test/2020-01-02_pilot_gaps_combined_types' delimiter ',' parallel off ALLOWOVERWRITE addquotes iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
