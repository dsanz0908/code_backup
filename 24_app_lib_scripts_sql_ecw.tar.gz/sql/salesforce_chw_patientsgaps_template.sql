unload ($$
SELECT name, 
       Count(DISTINCT whoid) :: VARCHAR AS unique_members, 
       Sum(CASE 
             WHEN status = 'Open' THEN 1 
             ELSE 0 
           end) :: VARCHAR              AS current_open_gaps 
FROM   salesforce_users AS a 
       LEFT OUTER JOIN (SELECT * 
                        FROM   salesforce_tasks 
                        WHERE  Trunc(added_tz) = 'DATE') AS b 
                    ON b.ownerid = a.id 
GROUP  BY name 
HAVING Count(DISTINCT accountid) > 0 
ORDER  BY 1
$$) 
to 's3://sftp_test/DATE_chw_patientsgaps'
delimiter ','
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;
