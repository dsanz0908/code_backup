select distinct master_table from mco_file_to_table_mapping where mco_name = 'Anthem_Corinthian' and file_type = 'eligibility';
