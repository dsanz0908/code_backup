delete from staging_optimus_healthfirst_claims;
copy public.staging_optimus_healthfirst_claims
from 's3://acp-data/OPTIMUS_HF_Tables/claims_201909.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';

delete from optimus_healthfirst_all_claims where filename = 'claims_201909.txt';

insert into optimus_healthfirst_all_claims (select null,
providerid,
claimnumber,
claimreceiveddate,
primaryservice,
place_of_service,
first_posted_date,
paiddate,
paidamount,
paystatus,
tin,
cpt_code,
i_o_p,
admitdiagnosiscode,
icd9_code1,
icd9_code2,
icd9_code3,
icd9_code4,
icd9_code5,
icd9_code6,
icd9_code7,
icd9_code8,
icd9_code9,
icd9_code10,
icd9_code11,
icd9_code12,
icd9_code13,
icd9_code14,
icd9_code15,
icd9_code16,
icd9_code17,
icd9_code18,
specialtycode,
planmemberid,
diagnosistype,
claimstatus,
'claims_201909.txt',
getdate(), 
case when trim(first_date_of_service) = '' then NULL else cast(first_date_of_service as date) end,
case when trim(last_date_of_service) = '' then NULL else cast(last_date_of_service as date) end
from public.staging_optimus_healthfirst_claims);

delete from staging_optimus_healthfirst_cmsmmr;
copy public.staging_optimus_healthfirst_cmsmmr
from 's3://acp-data/OPTIMUS_HF_Tables/cmsmmr_201909.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto'
ACCEPTINVCHARS;
delete from optimus_healthfirst_all_cmsmmr where filename = 'cmsmmr_201909.txt';
insert into optimus_healthfirst_all_cmsmmr (select 
birth_date, null, null, null,
segment_id,
enrollment_source,
eghp_flag,
part_d_lowincome_indicator,
part_d_long_term_institutional_indicator,
data_warehouse_load_date,
risk_adjuster_factor_a,
risk_adjuster_factor_b,
previous_disable_ratio_prdib,
number_of_paymtadjustmt_months_part_d,
part_d_ra_factor,
part_d_lowincome_multiplier,
part_d_long_term_institutional_multiplier,
reason_code,
accounting_period,
adjustment_end_date,
adjustment_start_date,
report_date,
location_code,
medicare_id,
previous_disable_indicator,
medicaid_addon_indicator,
default_factor_indicator,
risk_adjuster_age_group_raag,
race_code,
plan_benefit_package_id,
frailty_indicator,
lag_indicator,
ra_factor_type_code,
current_medicaid_status,
old_member_id,
esrd_msp_flag,
msa_depositrecovery_months,
de_minimis,
beneficiary_dual_part_d_enrollment_status_flag,
lti_flag,
new_medicare_beneficiary_medicaid_status,
part_c_frailty_score_factor,
msp_factor,
medicaid_dual_status_code,
part_d_ra_factor_type,
default_part_d_risk_factor_code,
line_of_business_code,
member_id,
number_of_adjustment_months,
total_rate_a_and_b_adjustment,
total_part_d_payment_adjustment,
lis_premium_payments_adjustment,
part_d_direct_subsidy_payment_amount_adjustment,
reinsurance_subsidy_amount_adjustment,
lowincome_subsidy_costsharing_amount_adjustment,
rebate_for_part_d_basic_premium_reduction_adjustment,
demographic_paymentadj_rate_a_adjustment,
demographic_paymentadj_rate_b_adjustment,
risk_adjustment_paymentadj_rate_a_adjustment,
risk_adjustment_paymentadj_rate_b_adjustment,
rate_a_payment_adjustment,
rate_b_payment_adjustment,
part_c_basic_premium__part_a_amount_adjustment,
part_c_basic_premium__part_b_amount_adjustment,
rebate_for_part_a_cost_sharing_reduction_adjustment,
rebate_for_part_b_cost_sharing_reduction_adjustment,
rebate_for_other_part_a_mandatory_supplemental_benefits_adjustment,
rebate_for_other_part_b_mandatory_supplemental_benefits_adjustment,
rebate_for_part_b_premium_reduction_part_a_amount_adjustment,
rebate_for_part_b_premium_reduction_part_b_amount_adjustment,
rebate_for_part_d_supplemental_benefits_part_a_amount_adjustment,
rebate_for_part_d_supplemental_benefits_part_b_amount_adjustment,
part_d_basic_premium_amount_adjustment,
pace_premium_add_on_adjustment,
pace_cost_sharing_add_on_adjustment,
total_part_a_and_b_reduced_adjustment,
total_part_d_revenue_adjustment,
part_d_deposit_adjustment,
msa_part_a_depositrecovery_amount_adjustment,
msa_part_b_depositrecovery_amount_adjustment,
msp_reductionreduction_adjustment_amount__part_a_adjustments,
msp_reductionreduction_adjustment_amount__part_b_adjustments,
part_d_coverage_gap_discount_amount__adjustments,
part_a_monthly_payment_rate__adjustments,
part_b_monthly_payment_rate__adjustments,
part_d_monthly_payment_rate__adjustments,
effective_period,
premium_total,
premium_total_administration,
premium_total_no_administration,
premium_part_d_administration,
member_count,
premium_group,
region,
county,
member_age_in_years,
group_id,
gender,
primary_care_cap,
porg,
umr_specialty_code_1,
umr_specialty_code_2,
umr_specialty_code_3,
umr_specialty_code_4,
umr_specialty_code_5,
provider_parent_code,
institution_indicator,
hospice_indicator,
esrd_indicator,
working_age_indicator,
dual_eligible,
umr_group,
umr_subgroup,
umr_category,
umr_sub_category,
record_source,
primary_care_physician,
company_number, 'cmsmmr_201909.txt', getdate() from staging_optimus_healthfirst_cmsmmr);



delete from staging_optimus_healthfirst_cmsraps;
copy public.staging_optimus_healthfirst_cmsraps
from 's3://acp-data/OPTIMUS_HF_Tables/cmsraps_201909.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_cmsraps where filename = 'cmsraps_201909.txt';
insert into optimus_healthfirst_all_cmsraps (select *, 'cmsraps_201909.txt', getdate() from staging_optimus_healthfirst_cmsraps);


delete from staging_optimus_healthfirst_member;
copy public.staging_optimus_healthfirst_member
from 's3://acp-data/OPTIMUS_HF_Tables/member_201909.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_member where filename = 'member_201909.txt';
insert into optimus_healthfirst_all_member (select hicnumber,
lastname,
firstname,
middleinitial,
dateofbirth,
gender,
providerid,
enrollmentdate,
disenrollmentdate,
planid,
pbp,
alternatekey1,
alternatekey2,
addressline1,
addressline2,
city,
state,
zipcode,
phonenumber,
language, 'member_201909.txt', getdate(), mbrenrlstatus,
parent_code from staging_optimus_healthfirst_member);


delete from staging_optimus_healthfirst_pharma;
copy public.staging_optimus_healthfirst_pharma
from 's3://acp-data/OPTIMUS_HF_Tables/pharma_201909.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_pharma where filename = 'pharma_201909.txt';
insert into optimus_healthfirst_all_pharma (select *, 'pharma_201909.txt', getdate() from staging_optimus_healthfirst_pharma);



delete from staging_optimus_healthfirst_provider;
copy public.staging_optimus_healthfirst_provider
from 's3://acp-data/OPTIMUS_HF_Tables/provider_201909.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_provider where filename = 'provider_201909.txt';
insert into optimus_healthfirst_all_provider (select 
providerid,
lastname,
firstname,
taxonomycode,
hpspecialtycode,
providertype,
addressline1,
addressline2,
city,
state,
zipcode,
phonenumber,
faxnumber,
contactperson,
npi,
tin,
dea,
payorid,
alternatekey1,
alternatekey2,
'provider_201909.txt', getdate(), parent_code from staging_optimus_healthfirst_provider);

