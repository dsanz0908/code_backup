select top 10000 * from gdw.master_gender order by random()
