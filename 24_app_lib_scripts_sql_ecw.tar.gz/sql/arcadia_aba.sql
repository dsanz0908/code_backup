SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                cast(pat_date_of_birth as date) as dob, 
                cast(enc_timestamp as date) as dos, 
                icd10_code 
FROM   (SELECT pat_first_name, 
               pat_last_name, 
               pat_date_of_birth, 
               enc_timestamp, 
               icd10_code, 
               Row_number() 
                 OVER ( 
                   partition BY pat_first_name, pat_last_name, pat_date_of_birth 
                   ORDER BY enc_timestamp DESC) AS rn 
        FROM   t_patient 
               JOIN t_encounter 
                 ON pat_id = enc_patient_id 
               JOIN t_assessment 
                 ON enc_id = encounter_id 
        WHERE  pat_delete_ind = 'N' 
               AND delete_ind = 'N' 
               AND  icd10_code IN ('Z68.1','Z68.20','Z68.21','Z68.22','Z68.23','Z68.24','Z68.25','Z68.26','Z68.27','Z68.28','Z68.29','Z68.30','Z68.31','Z68.32','Z68.33','Z68.34','Z68.35','Z68.36','Z68.37','Z68.38','Z68.39','Z68.41','Z68.42','Z68.43','Z68.44','Z68.45') 
               AND Year(enc_timestamp) between 2018 and 2019) AS t1 
WHERE  rn = 1 
