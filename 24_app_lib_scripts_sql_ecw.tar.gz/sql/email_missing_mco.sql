SELECT Max(receivedmonth) FROM payor.wellcare_somos_all_claims
