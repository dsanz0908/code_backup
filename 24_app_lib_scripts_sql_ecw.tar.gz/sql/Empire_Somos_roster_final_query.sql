drop table if exists payor.staging_empire_bcbs_healthplus_somos_roster;
create table payor.staging_empire_bcbs_healthplus_somos_roster ( 
MEMBERSHIP_MONTH VARCHAR(255), PRODUCT VARCHAR(255), REGION VARCHAR(255), EMPIRE_Member_ID VARCHAR(255), MEMBER_MEDICAID_NUMBER VARCHAR(255), MEMBER_LAST_NAME VARCHAR(255), MEMBER_FIRST_NAME VARCHAR(255), GEND_DESC VARCHAR(255), LANG_DESC VARCHAR(255), RACE_ETHN_DESC VARCHAR(255), MEMBER_DOB VARCHAR(255), PCP_NAME VARCHAR(255), EMPIRE_PROVIDER_ID VARCHAR(255), PCP_NPI VARCHAR(255), PCP_TIN VARCHAR(255), IPA VARCHAR(255), MBRSHIP_START_DATE VARCHAR(255), MBRSHIP_END_DATE VARCHAR(255), MM_CNT VARCHAR(250));
grant all on payor.staging_empire_bcbs_healthplus_somos_roster to etluser;
delete from payor.staging_empire_bcbs_healthplus_somos_roster;
copy payor.staging_empire_bcbs_healthplus_somos_roster
from 's3://acp-data/Anthem/Somos/Empire_BCBS_HealthPlus_Enrollment_SOMOS_201701_201901.TXT'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter ' '
NULL as 'NULL'
dateformat 'auto'
REMOVEQUOTES;
delete from payor.empire_bcbs_healthplus_somos_all_roster where filename = 'Empire_BCBS_HealthPlus_Enrollment_SOMOS_201701_201901.TXT';
insert into payor.empire_bcbs_healthplus_somos_all_roster ( 
 membership_month,
 empire_provider_id,
 pcp_npi,
 pcp_name,
 pcp_tax_id,
 product,
 region,
 empire_subscriber_id,
 member_medicaid_number,
 member_last_name,
 member_first_name,
 member_dob,
 gndr_nm,
 lang_nm,
 monthly_membership_start_date,
 monthly_membership_end_date,
 mm_cnt,
 filename,
 IPA,
 RACE_ETHN_DESC,
 received_month
)
select 
 MEMBERSHIP_MONTH,
 EMPIRE_PROVIDER_ID,
 PCP_NPI,
 PCP_NAME,
 PCP_TIN,
 PRODUCT,
 REGION,
 EMPIRE_Member_ID,
 MEMBER_MEDICAID_NUMBER,
 MEMBER_LAST_NAME,
 MEMBER_FIRST_NAME,
 MEMBER_DOB,
 GEND_DESC,
 LANG_DESC,
 Case when trim(MBRSHIP_START_DATE) = ''   then NULL else  CAST ( MBRSHIP_START_DATE AS date ) end ,
 Case when trim(MBRSHIP_END_DATE) = ''   then NULL else  CAST ( MBRSHIP_END_DATE AS date ) end ,
 MM_CNT,
 'Empire_BCBS_HealthPlus_Enrollment_SOMOS_201701_201901.TXT',
 IPA,
 RACE_ETHN_DESC,
 '201902'
from payor.staging_empire_bcbs_healthplus_somos_roster
