select top 10000 * from gdw.master_dx_codes order by random()
