delete from payor.staging_uhc_somos_membership;

copy payor.staging_uhc_somos_membership
from 's3://acp-data/UHC/Somos/SOMOS_201908_MEM_CAID.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 0
ignoreheader 1
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.uhc_somos_all_membership where filename = 'SOMOS_201908_MEM_CAID.txt';

INSERT INTO payor.uhc_somos_all_membership 
SELECT *, 
       '201908', 
       'SOMOS_201908_MEM_CAID.txt' 
FROM   payor.staging_uhc_somos_membership; 
