delete from  where filename = 'AFFINITY-CORINTHIAN-QUALITY_CARE-201807.csv';
insert into  ( 
added_tz )
select 
 GETDATE() from payor.staging_Affinity_corinthian_QUALITY_CARE
