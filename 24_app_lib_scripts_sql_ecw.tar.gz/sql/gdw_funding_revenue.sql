select top 10000 * from gdw.funding_revenue order by random()
