unload ( $$
SELECT master_consumer_id,
       claim_nbr,
       "claim_adjustment_#",
       claim_disposition_code,
       line_number,
       from_date,
       end_date,
       status_code,
       reason_code,
       year,
       quarter,
       month,
       health_service_code,
       revenue_code,
       health_service_code_modifier,
       "#_of_service_units",
       line_billed,
       line_covered,
       place_of_service,
       contract_flag_1,
       diag_1_cd,
       diag_2_cd,
       diag_3_cd,
       diag_4_cd,
       diag_5_cd,
       inpatient_flag,
       potentially_avoidable_er_flag,
       imaging_flag,
       admit_thru_er_flag_inpatient_only,
       member_key,
       international_classification_of_diseases_version_code,
       claim_sor_cd,
       billed_service_unit_count,
       paid_service_unit_count,
       patient_responsibility_amount,
       line_allowed,
       line_paid,
       redact_flag,
       hlth_srvc_type_cd,
       pg_id,
       pg_name,
       clm_adjstmnt_key,
       in_and_out_of_network_claims,
       denial_reason_code,
       denial_reason_description
FROM payor.empire_somos_claim_det
where received_month = '201908' 
$$ )
to 's3://garage-s3/Empire/empire_somos_claim_det_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;


unload ($$
SELECT master_consumer_id,
       claim_nbr,
       "claim_adjustment_#",
       claim_disposition_code,
       "billing_provider_license_#",
       billing_provider_tax_id_could_contain_ssn,
       medicare_id_could_contain_ssn,
       paid_date,
       drg,
       billed_service_unit_count,
       paid_service_unit_count,
       "#_of_days",
       bill_type,
       inpatient_transplant_flag,
       admit_type,
       admit_source,
       admit_hour,
       discharge_status,
       billing_provider_npi,
       attending_provider_npi,
       admitting_provider_npi,
       service_rendering_provider_npi,
       other_provider_npi,
       "referring_provider_license_#",
       professional_indicator,
       institutional_indicator,
       fnl_msdrg,
       icd_cm_procedure_1,
       icd_cm_procedure_2,
       icd_cm_procedure_3,
       icd_cm_procedure_4,
       icd_cm_procedure_5,
       from_date,
       to_date_,
       admit_date,
       billing_provider_id_could_contain_ssn,
       billing_provider_sor_code,
       service_provider_id_could_contain_ssn,
       service_provider_sor_code,
       member_key,
       international_classification_of_diseases_version_code,
       redact_flag,
       discharge_date,
       drg_type_code,
       pg_id,
       pg_name,
       clm_adjstmnt_key,
       actual_paid_date,
       claim_processed_date
FROM payor.empire_somos_claim_header
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_claim_header_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT claim_nbr,
       "claim_adjustment_#",
       claim_disposition_code,
       pg_id,
       pg_name,
       clm_adjstmnt_key,
       sequence_number,
       icd_procedure_date,
       icd_cm_procedure
FROM payor.empire_somos_claim_header_proc
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_claim_header_proc_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT claim_nbr,
       "claim_adjustment_#",
       claim_disposition_code,
       pg_id,
       pg_name,
       clm_adjstmnt_key,
       line_number,
       sequence_number,
       diag_cd
FROM payor.empire_somos_clm_diag
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_claim_diag_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT master_consumer_id,
       encounter_medical_models_unweighted_retrospective_risk_score,
       encounter_medical_models_unweighted_prospective_risk_score,
       encounter_medical_models_weighted_retrospective_risk_score,
       encounter_medical_models_weighted_prospective_risk_score,
       rxip_models_unweighted_retrospective_risk_score,
       rxip_unweighted_prospective_risk_score,
       rxip_weighted_retrospective_risk_score,
       rxip_weighted_prospective_risk_score,
       medical_and_pharmacy_weighted_retrospective_risk_score,
       medical_and_pharmacy_weighted_prospective_risk_score,
       member_key,
       pg_id,
       pg_name
FROM payor.empire_somos_dxcg
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_dxcg_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT master_consumer_id,
       subscriber_id_could_contain_ssn,
       member_code,
       health_card_identifier,
       gender,
       date_of_birth,
       first_name,
       last_name,
       pcp_assignment_method_code,
       attribution_type_code,
       business_unit,
       member_address,
       member_city,
       member_state,
       member_zip,
       primary_language,
       deceased_indicator,
       "group_#",
       group_name,
       "subgroup_#",
       subgroup_name,
       bnft_pkg_id,
       etg_responsible_tax_id1_could_contain_ssn,
       etg_responsible_npi1,
       etg_responsible_tax_id1,
       etg_responsible_tax_id2_could_contain_ssn,
       etg_responsible_npi2,
       etg_responsible_tax_id2,
       etg_responsible_tax_id3_could_contain_ssn,
       etg_responsible_npi3,
       etg_responsible_tax_id3,
       responsible_tax_id_could_contain_ssn,
       dbm_responsible_license,
       hmopos_responsible_tax_id_could_contain_ssn,
       hmopos_responsible_license,
       effective_date,
       termination_date,
       member_phone,
       original_effective_date,
       bnft_pkg_name,
       member_key,
       alpha_prefix_id,
       funding_chartfield_code,
       responsible_npi,
       hmopos_responsible_npi,
       enterprise_member_code,
       member_sequence_number,
       chronic_care_flag,
       pln_st_cd,
       host_ind_cd,
       jaa_ind_cd,
       insert_update_ind,
       last_four_ssn,
       atrbn_trmntn_rsn_cd,
       redact_flag,
       contract_type,
       prod_sor_cd,
       pg_id,
       pg_name,
       pgm_id,
       panel_id,
       plan_desc,
       medicaid_could_contain_ssn,
       hicn_could_contain_ssn,
       ethnicity,
       written_language,
       member_county
FROM payor.empire_somos_member
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_member_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT mcid,
       eligibility_effective_date,
       eligibility_end_date,
       pg_id,
       pg_name,
       prdctsl,
       rxbnflg
FROM payor.empire_somos_member_eligibility
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_member_eligibility_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT provider_id_could_contain_ssn,
       provider_sor_code,
       prov_lcns_id,
       medicare_id_could_contain_ssn,
       provider_tax_id_could_contain_ssn,
       licensure_code,
       provider_last_name,
       provider_first_name,
       provider_specialty,
       address_line_1,
       address_line_2,
       provider_city,
       provider_state,
       provider_zip_code,
       provider_phone,
       "dea_#",
       npi,
       taxonomy_code,
       contract_flag1,
       provider_business_name_or_group_name,
       redact_flag,
       pg_id,
       pg_name
FROM payor.empire_somos_provider
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_provider_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT master_consumer_id,
       filled_date,
       ndc_number,
       dea_number,
       pharmacy_number,
       pharmacy_name,
       therapeutic_class,
       generic_indicator,
       dayssupplied,
       formulary_indicator,
       retail_mail_indicator,
       billed_charges,
       year,
       quarter,
       month,
       provider_license_number,
       script_written_date,
       prescriber_name,
       quanitity_dispensed,
       rx_number,
       ingredient_cost,
       copay,
       label_name,
       prescriber_npi,
       claim_number,
       claim_adjustment_number,
       claim_disposition_code,
       member_key,
       patient_responsibility_amount,
       paid_amount,
       allowed_amount,
       redact_flag,
       pg_id,
       pg_name,
       clm_adjstmnt_key,
       gl_post_dt,
       clm_line_nbr,
       drg_nm,
       status_code,
       refill_number,
       refill,
       claim_processed_date,
       denial_reason_code,
       denial_reason_description,
       compound_drug,
       dispensing_fee
FROM payor.empire_somos_rx_clms_delta
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_rx_clms_delta_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT dea_number,
       billing_provider_license_number,
       prescriber_npi,
       provider_first_name,
       provider_last_name,
       provider_specialty,
       taxonomy_code,
       redact_flag,
       pg_id,
       pg_name
FROM payor.empire_somos_rx_prov_delta
where received_month = '201908'
$$)
to 's3://garage-s3/Empire/empire_somos_rx_prov_delta_2019_08_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

