WITH cte_2018_diagnoses 
     AS (SELECT DISTINCT patient_id, 
                         person_id, 
                         icd10_code 
         FROM   t_assessment 
                JOIN mpi.person_patient 
                  ON t_assessment.patient_id = person_patient.pat_id 
         WHERE  delete_ind = 'N' 
                AND Year(assessment_date) = 2018 
                AND icd10_code IS NOT NULL), 
     cte_2019_diagnoses 
     AS (SELECT DISTINCT patient_id, 
                         person_id, 
                         icd10_code 
         FROM   t_assessment 
                JOIN mpi.person_patient 
                  ON t_assessment.patient_id = person_patient.pat_id 
         WHERE  delete_ind = 'N' 
                AND Year(assessment_date) = 2019 
                AND icd10_code IS NOT NULL), 
     cte_a 
     AS (SELECT DISTINCT pat_medical_record_number, 
                         pat_first_name, 
                         pat_last_name, 
                         pat_middle_name, 
                         pat_date_of_birth, 
                         pat_phone_1, 
                         prov_fullname, 
                         prov_npi, 
                         site_center_name, 
                         cte_2018_diagnoses.icd10_code, 
                         description, 
                         CASE 
                           WHEN cte_2019_diagnoses.patient_id IS NULL THEN 0 
                           ELSE 1 
                         END AS diagnosis_2019_fulfilled 
         FROM   cte_2018_diagnoses 
                LEFT JOIN cte_2019_diagnoses 
                       ON cte_2018_diagnoses.person_id = cte_2019_diagnoses.person_id 
                          AND cte_2018_diagnoses.icd10_code = cte_2019_diagnoses.icd10_code 
                JOIN t_patient 
                  ON t_patient.pat_id = cte_2018_diagnoses.patient_id 
                JOIN provider_master 
                  ON pat_responsible_provider_id = prov_id 
                LEFT JOIN lookup.code 
                       ON cte_2018_diagnoses.icd10_code = code_value 
                JOIN site_master 
                  ON prov_orig_site_id = site_orig_site_id 
         WHERE  pat_delete_ind = 'N') 
SELECT site_center_name, 
       description, 
       Count(*), 
       ( Sum(diagnosis_2019_fulfilled) * 100 ) / Count(*) 
FROM   cte_a 
GROUP  BY site_center_name, 
          description 
ORDER  BY site_center_name, 
          Count(*) DESC 
