delete from payor.staging_healthfirst_corinthian_ELIGIBILITY;
--quality care is comma delimited, rest is pipe
copy payor.staging_healthfirst_corinthian_ELIGIBILITY
from 's3://acp-data/Healthfirst/Corinthian/HEALTHFIRST-CORINTHIAN-ELIGIBILITY-201901.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;
