SELECT DISTINCT site_center_name, 
                cc_patient_id, 
                cc_cpt_code, 
                Cast(cc_date_of_service AS DATE) AS dos 
FROM   t_chargecapture 
       JOIN t_encounter 
         ON enc_id = cc_enc_id 
       JOIN site_master 
         ON enc_site_id = site_id 
WHERE  Year(cc_date_of_service) = 2019 
       AND cc_delete_ind = 'N' 
       AND enc_delete_ind = 'N' 
       AND site_delete_ind = 'N' 
       AND cc_delete_ind = 'N' 
