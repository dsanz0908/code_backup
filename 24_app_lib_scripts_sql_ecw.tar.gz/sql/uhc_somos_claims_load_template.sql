delete from payor.staging_uhc_somos_claims;

copy payor.staging_uhc_somos_claims
from 's3://acp-data/UHC/Somos/BASENAME'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 1
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.uhc_somos_all_claims where filename = 'BASENAME';

INSERT INTO payor.uhc_somos_all_claims 
SELECT *, 
       'YEARMONTH', 
       'BASENAME', 
       GETDATE(), 
       NULL 
FROM   payor.staging_uhc_somos_claims; 
