select top 10000 * from gdw.emr_encounter_dx order by random()
