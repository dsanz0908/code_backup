select top 10000 * from gdw.emr_vitalhistory order by random()
