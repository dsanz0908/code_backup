SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE) dob, 
                vitals_date, 
                Concat(CASE 
                         WHEN vitals_systolic < 130 THEN '3074F' 
                         ELSE '3075F' 
                       END, ',', CASE 
                                   WHEN vitals_diastolic < 80 THEN '3078F' 
                                   ELSE '3079F' 
                                 END), 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   t_vitals 
       JOIN t_patient 
         ON vitals_patient_id = pat_id 
       JOIN provider_master 
         ON vitals_prov_id = prov_id 
WHERE  vitals_delete_ind = 'N' 
       AND pat_date_of_birth BETWEEN '1934-01-01' AND '2001-12-31' 
       AND pat_delete_ind = 'N' 
       AND vitals_delete_ind = 'N' 
       AND vitals_systolic BETWEEN 60 AND 140 
       AND vitals_diastolic BETWEEN 20 AND 90 
       AND vitals_date >= '2019-01-01' 
