select * from (SELECT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE) dob, 
                cast(vitals_date as date) as dos, vitals_systolic, vitals_diastolic,
                CASE 
                         WHEN vitals_systolic < 130 THEN '3074F' 
                         ELSE '3075F' 
                       END as cpt1, CASE 
                                   WHEN vitals_diastolic < 80 THEN '3078F' 
                                   ELSE '3079F' 
                                 END as cpt2, row_number() over (partition by pat_first_name, pat_last_name, Cast(pat_date_of_birth AS DATE) order by vitals_date desc) as rn
FROM   t_vitals 
       JOIN t_patient 
         ON vitals_patient_id = pat_id 
       JOIN provider_master 
         ON vitals_prov_id = prov_id 
WHERE  vitals_delete_ind = 'N' 
       --AND pat_date_of_birth BETWEEN '1934-01-01' AND '2001-12-31' 
       AND pat_delete_ind = 'N' 
       AND vitals_delete_ind = 'N' 
       AND vitals_systolic BETWEEN 60 AND 140 
       AND vitals_diastolic BETWEEN 20 AND 90 
       AND vitals_date between '2019-01-01' and '2019-12-31') as t1 where rn = 1
