WITH cte_diagnosis_capture 
     AS (SELECT DISTINCT  encounter_id, 
                                  icd10_code, 
                                  Dense_rank() 
                                    OVER ( 
                                      partition BY encounter_id 
                                      ORDER BY encounter_id, icd10_code ) AS 
                                  rnumber 
         FROM   t_assessment 
         WHERE  encounter_id IS NOT NULL 
                AND icd10_code IS NOT NULL 
                AND primary_diagnosis_ind = 1), 
     cte_diagnosis_1 
     AS (SELECT encounter_id, 
                Max(CASE 
                      WHEN rnumber = 1 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code, 
                Max(CASE 
                      WHEN rnumber = 2 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_1, 
                Max(CASE 
                      WHEN rnumber = 3 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_2, 
                Max(CASE 
                      WHEN rnumber = 4 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_3, 
                Max(CASE 
                      WHEN rnumber = 5 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_4, 
                Max(CASE 
                      WHEN rnumber = 6 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_5, 
                Max(CASE 
                      WHEN rnumber = 7 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_6, 
                Max(CASE 
                      WHEN rnumber = 8 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_7, 
                Max(CASE 
                      WHEN rnumber = 9 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_8, 
                Max(CASE 
                      WHEN rnumber = 10 THEN icd10_code 
                      ELSE NULL 
                    END) AS icd10_code_9 
         FROM   cte_diagnosis_capture 
         GROUP  BY encounter_id), 
     cte_cc_capture 
     AS (SELECT  cc_enc_id, 
                         cc_cpt_code AS cpt_code 
         FROM   t_chargecapture 
         WHERE  cc_enc_id IS NOT NULL 
                AND cc_cpt_code IS NOT NULL 
                AND cc_cpt_code NOT IN ( '3078F', '3079F', '3080F', '3074F', 
                                         '3075F', '3077F', '0' )), 
     systolic_diastolic 
     AS (SELECT * 
         FROM   (SELECT systolic.cc_enc_id, 
                        systolic.cc_cpt_code 
                                AS systolic_code, 
                        diastolic.cc_cpt_code 
                                AS diastolic_code, 
                        Dense_rank() 
                          OVER ( 
                            partition BY systolic.cc_enc_id 
                            ORDER BY systolic.cc_enc_id, systolic.cc_cpt_code, 
                          diastolic.cc_cpt_code) AS 
                        rnumber 
                 FROM   (SELECT DISTINCT cc_enc_id, 
                                                  cc_cpt_code 
                         FROM   t_chargecapture 
                         WHERE  cc_cpt_code IN ( '3074F', '3075F', '3077F' ) 
                                AND cc_enc_id IS NOT NULL) AS systolic 
                        JOIN (SELECT DISTINCT cc_enc_id, 
                                                       cc_cpt_code 
                              FROM   t_chargecapture 
                              WHERE  cc_cpt_code IN ( '3078F', '3079F', '3080F' 
                                                    ) 
                                     AND cc_enc_id IS NOT NULL) AS diastolic 
                          ON systolic.cc_enc_id = diastolic.cc_enc_id) AS sd 
         WHERE  rnumber = 1) 
SELECT t3.pat_first_name, 
       t3.pat_middle_name, 
       t3.pat_last_name, 
       pat_date_of_birth, 
       pat_sex, 
       orig_member_id, 
       medicaid_id, 
       vitals_height, 
       vitals_height_unit, 
       vitals_weight, 
       vitals_weight_unit, 
       vitals_bmi, 
       vitals_systolic, 
       vitals_diastolic, 
       vitals_date, 
       site_center_name, 
       prov_fullname, 
       prov_specialty_1, 
       prov_npi, 
       prov_address_1, 
       prov_address_2, 
       prov_city, 
       prov_state, 
       prov_zip, 
       ps.source_desc, 
       icd10_code, 
       icd10_code_1, 
       icd10_code_2, 
       icd10_code_3, 
       icd10_code_4, 
       icd10_code_5, 
       icd10_code_6, 
       icd10_code_7, 
       icd10_code_8, 
       icd10_code_9, 
       cpt_code, 
       systolic_code, 
       diastolic_code,
       t3.pat_address_1,
       t3.pat_address_2,
       t3.pat_city,
       t3.pat_state,
       t3.pat_zip
FROM   t_vitals t1 
       INNER JOIN t_encounter t2 
               ON t1.vitals_enc_id = t2.enc_id 
       INNER JOIN t_patient t3 
               ON t2.enc_patient_id = t3.pat_id 
       INNER JOIN cte_diagnosis_1 d1 
               ON t2.enc_id = d1.encounter_id 
       INNER JOIN cte_cc_capture cc 
               ON t2.enc_id = cc.cc_enc_id 
       LEFT OUTER JOIN systolic_diastolic sd 
                    ON t2.enc_id = sd.cc_enc_id 
       LEFT OUTER JOIN mpi.person_patient pp 
                    ON t3.pat_id = pp.pat_id 
       INNER JOIN site_master sm 
               ON t1.vitals_orig_site_id = sm.site_orig_site_id 
       INNER JOIN provider_master prv 
               ON t1.vitals_prov_id = prv.prov_id 
       LEFT OUTER JOIN mpi.person_member pm 
                    ON pp.person_id = pm.person_id 
       LEFT OUTER JOIN plan_member plm 
                    ON pm.member_id = plm.member_id 
                       AND plm.delete_ind = 'N' 
       LEFT OUTER JOIN plan_source ps 
                    ON plm.source_id = ps.source_id 
WHERE  vitals_date BETWEEN '20180101' AND '20181031' 
       AND t1.vitals_delete_ind = 'N' 
ORDER  BY vitals_date 
