WITH cte_1
     AS (SELECT distinct Concat(pat_first_name, ' ', pat_middle_name, ' ', pat_last_name) AS NAME,
                         pat_date_of_birth,
                         enc_timestamp,
                         icd10_code,
                         cc_cpt_code
         FROM   t_encounter
                JOIN t_patient
                  ON enc_patient_id = pat_id
                JOIN t_assessment
                  ON enc_id = t_assessment.encounter_id
                JOIN t_chargecapture
                  ON enc_id = cc_enc_id
                     AND enc_delete_ind = 'N'
                     AND pat_delete_ind = 'N'
                     AND delete_ind = 'N'
                     AND cc_delete_ind = 'N'
                     AND Year(enc_timestamp) = 2019)
select * from cte_1
