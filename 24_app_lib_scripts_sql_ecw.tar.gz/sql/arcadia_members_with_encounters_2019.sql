WITH cte_1 
     AS (SELECT DISTINCT pat_first_name, 
                         pat_last_name, 
                         pat_date_of_birth 
         FROM   t_encounter 
                JOIN t_patient 
                  ON enc_patient_id = pat_id 
         WHERE  enc_delete_ind = 'N' 
                AND pat_delete_ind = 'N' 
                AND Year(enc_timestamp) = 2019) 
SELECT * 
FROM   cte_1 
