unload ($$
SELECT * 
FROM   (SELECT DISTINCT hedis_measure, 
                        b.gender, 
                        'Fidelis Pilot', 
                        cin, 
                        first_name, 
                        last_name, 
                        member_dob, 
                        street_address_1 
                        || ' ' 
                        || street_address_2                              AS address, 
                        b.city, 
                        b.state, 
                        zip_code, 
                        member_phone_number, 
                        npi, 
                        Regexp_replace(physician_name, '[^a-zA-Z]', ' ') AS pcp, 
                        Row_number() 
                          OVER ( 
                            partition BY cin, hedis_measure 
                            ORDER BY effective_date DESC)                AS rn 
        FROM   payor.fidelis_somos_all_caregaps AS a 
               JOIN payor.fideliscare_prod_membership_full_somos_20150101_20180928 AS b 
                 ON cin = alternate_member_id 
               JOIN payor.fidelis_somos_caregaps_201808 AS aa 
                 ON aa.member_id = a.cin 
                    AND EXISTS (SELECT 1 
                                FROM   payor.fidelis_somos_all_caregaps AS c 
                                       JOIN payor.fideliscare_prod_membership_full_somos_20150101_20180928 AS d
                                         ON cin = alternate_member_id 
                                WHERE  a.cin = c.cin 
                                       AND c.received_month = '201808') 
        WHERE  a.received_month = '201812' 
               AND a.npi IS NOT NULL 
               AND Length(cin) = 8 
               AND hedis_measure IN (SELECT mco_measure 
                                     FROM   payor.measure_hedis_sf_xwalk)) AS full_table 
WHERE  rn = 1 
       AND member_phone_number NOT IN ( '', '0' ) 
       AND member_phone_number IS NOT NULL 
ORDER  BY cin, 
          hedis_measure 
$$ )
to 's3://sftp_test/20190207_open_gaps_fidelispilot.csv'
delimiter ','
addquotes
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

