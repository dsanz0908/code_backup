select top 10000 * from gdw.patients order by random()
