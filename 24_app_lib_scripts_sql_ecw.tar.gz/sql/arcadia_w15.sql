WITH a 
     AS (SELECT DISTINCT pat_id, 
                         pat_date_of_birth                     AS dob, 
                         Dateadd(month, 15, pat_date_of_birth) AS fifteen 
         FROM   t_patient 
         WHERE  Datediff(month, pat_date_of_birth, '2019-12-31') BETWEEN 15 AND 26 
                AND pat_delete_ind = 'N') 
SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE) dob, 
                cc_date_of_service, 
                cc_cpt_code, 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   a 
       JOIN t_encounter 
         ON a.pat_id = enc_patient_id 
       JOIN t_assessment 
         ON enc_id = encounter_id 
       LEFT JOIN t_chargecapture 
              ON enc_id = cc_enc_id 
       JOIN t_patient 
         ON cc_patient_id = a.pat_id 
       JOIN provider_master 
         ON cc_rendering_provider_id = prov_id 
WHERE  delete_ind = 'N' 
       AND cc_delete_ind = 'N' 
       AND cc_cpt_code IN ( '99381', '99382', '99383', '99384', 
                            '99385', '99391', '99392', '99393', 
                            '99394', '99395', '99461', 'G0438', 'G0439' ) 
       AND enc_timestamp BETWEEN dob AND fifteen
