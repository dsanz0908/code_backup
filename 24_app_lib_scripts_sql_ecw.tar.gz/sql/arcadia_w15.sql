SELECT distinct pat_first_name, 
               pat_last_name, 
               pat_date_of_birth, 
               enc_timestamp, 
               cc_cpt_code, 
               icd10_code 
        FROM   t_patient 
               JOIN t_encounter 
                 ON pat_id = enc_patient_id 
               JOIN t_assessment 
                 ON enc_id = encounter_id 
               JOIN t_chargecapture 
                      ON enc_id = cc_enc_id 
        WHERE  pat_delete_ind = 'N' 
               AND delete_ind = 'N' 
               AND cc_delete_ind = 'N' 
               AND  icd10_code IN ( 'Z00.00', 'Z00.01', 'Z00.110', 'Z00.111',
                           'Z00.121', 'Z00.129', 'Z00.5', 'Z00.8',
                           'Z02.0', 'Z02.1', 'Z02.2', 'Z02.3',
                           'Z02.4', 'Z02.5', 'Z02.6', 'Z02.71',
                           'Z02.82', 'Z76.1', 'Z76.2' )
               AND  cc_cpt_code IN ( '99381', '99382', '99383', '99384',
                            '99385', '99391', '99392', '99393',
                            '99394', '99395', '99461', 'G0438', 'G0439' )
               AND Year(enc_timestamp) = 2019 
