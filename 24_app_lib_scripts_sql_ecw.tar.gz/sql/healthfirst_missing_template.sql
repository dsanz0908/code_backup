SELECT rpad(pcp_parent_code, 20, ' ') as IPA,
       rpad(t, 20, ' ') as "File Type",
       Max(received_month) AS "Latest Received Month"
FROM   (SELECT DISTINCT pcp_parent_code,
                        received_month,
                        'Claims' AS t
        FROM   payor.healthfirst_all_claims
        UNION
        SELECT DISTINCT 'SOMOS',
                        received_month,
                        'Claims'
        FROM   payor.healthfirst_somos_all_claims
        UNION
        SELECT DISTINCT provider_parent_code,
                        received_month,
                        'RX'
        FROM   payor.healthfirst_all_rx_claims
        UNION
        SELECT DISTINCT 'SOMOS',
                        received_month,
                        'RX'
        FROM   payor.healthfirst_somos_all_rx_claims
        UNION
        SELECT DISTINCT provider_parent_code,
                        received_month,
                        'Eligibility'
        FROM   payor.healthfirst_all_eligibility
        UNION
        SELECT DISTINCT 'SOMOS',
                        received_month,
                        'Eligibility'
        FROM   payor.healthfirst_somos_all_eligibility)
GROUP  BY 1,
          2
HAVING Max(received_month) < 'RECEIVEDMONTH'
ORDER  BY 1,
          2

