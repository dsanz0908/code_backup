SELECT tgt_column_name || ','
FROM   mco_file_to_table_mapping 
WHERE  mco_name = 'Empire_Somos' 
       AND Lower(file_type) = 'roster' 
ORDER  BY column_order; 
