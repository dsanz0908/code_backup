delete from discharge where filename = '31Jan2019_JH Inpatient ACP Discharges.csv';
insert into discharge select *, '31Jan2019', '31Jan2019_JH Inpatient ACP Discharges.csv' from staging_discharge;
drop table staging_discharge;
