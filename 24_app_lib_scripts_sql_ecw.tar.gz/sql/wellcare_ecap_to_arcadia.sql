
unload ($$ select 
 master_ipa,  seq_member_id, activity_date,seq_pcp_id, subscriber_id, pcp_first_name, pcp_last_name, external_pcp_id, lob, claim_type, claim_number, auth_number, place_of_service_1, denial_reason_list,
 diagnosis_1, diagnosis_2, diagnosis_3, diagnosis_4, diagnosis_5, diagnosis_6, diagnosis_7, diagnosis_8, diagnosis_9, diagnosis_10, diagnosis_11, diagnosis_12, diagnosis_13, diagnosis_14, diagnosis_15,
 diagnosis_16, diagnosis_17, diagnosis_18, diagnosis_19, diagnosis_20, diagnosis_21, diagnosis_22, diagnosis_23, diagnosis_24, diagnosis_25, diagnosis_icd_version_1, diagnosis_icd_version_2, diagnosis_icd_version_3,
 diagnosis_icd_version_4, diagnosis_icd_version_5, diagnosis_icd_version_6, diagnosis_icd_version_7, diagnosis_icd_version_8, diagnosis_icd_version_9, diagnosis_icd_version_10, diagnosis_icd_version_11, diagnosis_icd_version_12,
 diagnosis_icd_version_13,  diagnosis_icd_version_14,diagnosis_icd_version_15, diagnosis_icd_version_16, diagnosis_icd_version_17, diagnosis_icd_version_18, diagnosis_icd_version_19, diagnosis_icd_version_20, diagnosis_icd_version_21,
 diagnosis_icd_version_22,  diagnosis_icd_version_23, diagnosis_icd_version_24, diagnosis_icd_version_25, bill_type, drg_code, service_provider_id, provider_last_name, provider_first_name, patient_status, provider_par_stat, provider_spec,
 vm_full_name, service_date, service_thru_date, procedure_code_1, procedure_code_type_1, procedure_icd_version_1, procedure_modifier_1_1, procedure_modifier_1_2, procedure_modifier_1_3, procedure_modifier_1_4, procedure_code_2, procedure_code_type_2,
 procedure_icd_version_2, procedure_modifier_2_1, procedure_modifier_2_2, procedure_modifier_2_3, procedure_modifier_2_4, procedure_code_3, procedure_code_type_3, procedure_icd_version_3, procedure_modifier_3_1, procedure_modifier_3_2, procedure_modifier_3_3,
 procedure_modifier_3_4, procedure_code_4, procedure_code_type_4, procedure_icd_version_4, procedure_modifier_4_1, procedure_modifier_4_2, procedure_modifier_4_3, procedure_modifier_4_4, revenue_code_1, revenue_code_2, revenue_code_3, revenue_code_4,
 quantity, billed_amount, allowed_amount, copayment_1_amount, net_amount_paid, claim_status, processing_status, post_date, check_date, national_provider_id from payor.wellcare_all_claims where receivedmonth = '201903' and master_ipa = 'EC1' $$ )
to 's3://acp-data/Arcadia/Outgoing/wellcare/wellcare_ecap_claims_2019_03_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';


unload ( $$ select 
 lob,  master_ipa, ipa_id, seq_memb_id, activity_date, subscriber_id, funding_county, plan_code, seq_pcp_id, pcp_first_name, pcp_last_name, cohort, elig_category, date_of_birth, gender, medicaid_no, medicare_no, last_name, first_name, address_line_1,
 address_line_2, city, state, zip, risk_score_ab, risk_score_d, hospice, esrd, institutional, nursing_home_certifiable, medicaid, medicaid_add_on, previous_disable,home_phone_number, dual_elig, national_provider_id from payor.wellcare_all_demographics where
 receivedmonth = '201903' and master_ipa = 'EC1' $$ )
 to 's3://acp-data/Arcadia/Outgoing/wellcare/wellcare_ecap_demographics_2019_03_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';


unload ($$ select 
 master_ipa,  seq_memb_id, activity_date, seq_pcp_id, subscriber_id, pcp_first_name, pcp_last_name, external_pcp_id, lob, pharmacy_number, prescription_number, date_filled, ndc_number, drugdescription, therapeuticclass, number_of_refills,
 metric_quantity, days_supply, ingredient_cost, dispensing_fee, co_pay, sales_tax, amount_billed, prov_dea_no, mailorder_ind, amount_paid, route_of_admin, transaction_status, seq_prov_id, prescriber_id, prescriber_id_type, prescriber_first_name,
 prescriber_last_name, generic_indicator, ta_utilized, gross_dc_aboveattach_pnt_amt, lics_and_cgd, part_type_flag, national_provider_id from payor.wellcare_all_rx where  receivedmonth = '201903' and master_ipa = 'EC1' $$)
  to 's3://acp-data/Arcadia/Outgoing/wellcare/wellcare_ecap_rx_2019_03_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
