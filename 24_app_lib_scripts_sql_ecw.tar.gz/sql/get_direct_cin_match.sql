/* SELECT DISTINCT pat_id, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                policy_nbr, 
                payer_name_unscrubbed 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY pat_id 
                   ORDER BY pat_updated_timestamp DESC) AS rn 
        FROM   t_patient 
               JOIN t_payer 
                 ON patient_id = pat_id 
        WHERE  payer_delete_ind = 'N' 
               AND pat_delete_ind = 'N') AS a 
WHERE  rn = 1 */
SELECT DISTINCT pat_id,
                pat_first_name,
                pat_last_name,
                pat_date_of_birth,
                policy_nbr,
                payer_name_unscrubbed
FROM  t_patient
	  JOIN t_payer
      ON patient_id = pat_id
WHERE  payer_delete_ind = 'N'
AND pat_delete_ind = 'N'
