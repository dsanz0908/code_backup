                                                              ?column?                                                               
-------------------------------------------------------------------------------------------------------------------------------------
 CLM_NBR,
 Case when trim(RX_FILLED_DT) = '' or length(RX_FILLED_DT) <> 10 then NULL else cast(RX_FILLED_DT AS date ) end,
 PRODUCT,
 PCP,
 PCP_TIN,
 SRC_SUBS_ID,
 MCD_Number,
 MBR_FIRST_NAME,
 MBR_LAST_NAME,
 Case when trim(DOB) = '' or length(DOB) <> 10 then NULL else cast(DOB AS date ) end,
 Prescriber_NPI,
 Prescriber,
 PrescribingSpecialty,
 DRUG_NAME,
 Case when trim(SCRIPT_CNT) = '' or SCRIPT_CNT like '%"%' then NULL else cast(SCRIPT_CNT AS integer ) end,
 Case when trim(REFILL_CNT) = '' or REFILL_CNT like '%-%'  then NULL else  CAST ( REPLACE(REFILL_CNT, ',','')  AS real ) end ,
 Case when trim(ANL_Paid_Amt) = '' or ANL_Paid_Amt like '%-%'  then NULL else  CAST ( REPLACE(ANL_Paid_Amt, ',','')  AS real ) end ,
 RECEIVEDMONTH,
 'FILENAME',
(19 rows)

