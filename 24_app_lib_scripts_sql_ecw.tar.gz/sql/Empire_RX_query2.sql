                                        ?column?                                         
-----------------------------------------------------------------------------------------
 CLM_NBR,
 Case when trim(RX_FILLED_DT) = ''   then NULL else  CAST ( RX_FILLED_DT AS date ) end ,
 PRODUCT,
 PCP,
 PCP_TIN,
 SRC_SUBS_ID,
 MCD_Number,
 MBR_FIRST_NAME,
 MBR_LAST_NAME,
 Case when trim(DOB) = ''   then NULL else  CAST ( DOB AS date ) end ,
 prescriber_npi,
 prescriber_name,
 prescribing_specialty,
 DRUG_NAME,
 SCRIPT_CNT,
 REFILL_CNT,
 ANL_Paid_Amt,
 RECEIVEDMONTH,
 'FILENAME',
 Case when trim(added_tz) = ''   then NULL else  CAST ( added_tz AS date ) end ,
(20 rows)

