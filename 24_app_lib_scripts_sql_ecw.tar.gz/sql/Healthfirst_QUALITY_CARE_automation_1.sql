select case when tgt_column_name = 'received_month' then 'RECEIVEDMONTH'
when tgt_column_name = 'filename' then quote_literal('FILENAME')
when tgt_data_type is not NULL then 'Case when trim(' || src_column_name || ') in ('''', ''-'')   then NULL else ' || ' CAST ( ' || src_column_name || ' AS ' || tgt_data_type  || ' ) end '
else src_column_name end || ','
from mco_file_to_table_mapping
where mco_name = 'Healthfirst' and file_type = 'quality_caregaps'
order by column_order;
