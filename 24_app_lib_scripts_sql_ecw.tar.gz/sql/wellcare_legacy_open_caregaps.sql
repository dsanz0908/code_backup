unload ($$
SELECT * 
FROM   (SELECT measure, 
               gender, 
               'Wellcare Corinthian', 
               a.medicaid_no, 
               first_name, 
               last_name, 
               a.date_of_birth, 
               address_line_1 
               || ' ' 
               || address_line_2, 
               city, 
               state, 
               LEFT(zip, 5), 
               (SELECT TOP 1 Trim(home_phone_number) 
                FROM   payor.wellcare_all_demographics AS dd 
                WHERE  dd.medicaid_no = a.medicaid_no 
                       AND Trim(home_phone_number) <> '' 
                       AND Trim(home_phone_number) <> '0000000000' 
                       AND home_phone_number IS NOT NULL 
                ORDER  BY receivedmonth DESC)                           AS 
                      home_phone_number, 
               national_provider_id, 
               provider_name, 
               Row_number() 
                 OVER ( 
                   partition BY measure, a.medicaid_no 
                   ORDER BY activity_date DESC, home_phone_number DESC) AS rn 
        FROM   payor.wellcare_all_caregaps AS a 
               JOIN payor.wellcare_all_demographics AS b 
                 ON a.medicaid_no = b.medicaid_no 
        WHERE  received_month = '201811' 
               AND receivedmonth = '201812' 
               AND Length(a.medicaid_no) = 8 
               AND national_provider_id IS NOT NULL 
               AND lob <> 'NMR' 
               AND measure IN (SELECT mco_measure 
                               FROM   payor.measure_hedis_sf_xwalk) 
               AND EXISTS (SELECT 1 
                           FROM   payor.wellcare_all_caregaps AS c 
                                  JOIN payor.wellcare_all_demographics AS d 
                                    ON c.medicaid_no = d.medicaid_no 
                           WHERE  a.medicaid_no = c.medicaid_no 
                                  AND received_month = '201808' 
                                  AND receivedmonth = '201808')) AS full_table 
WHERE  rn = 1 
       AND Trim(home_phone_number) <> '' 
ORDER  BY medicaid_no, 
          measure 
$$ )
to 's3://sftp_test/20190214_open_gaps_wellcarelegacy.csv'
delimiter ','
addquotes
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

