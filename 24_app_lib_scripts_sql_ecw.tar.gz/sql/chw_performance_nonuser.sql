SELECT NAME, 
       mco, 
       Count(whoid)  AS unique_members, 
       Count(whoid2) AS unique_members_with_open_gaps, 
       Count(whoid3), 
       Count(whoid4), 
       Count(whoid5), 
       Count(whoid6), 
       Count(whoid9), 
       Count(whoid10), 
       Count(whoid11), 
       Count(whoid12), 
       Count(whoid13), 
       Count(whoid14), 
       Count(whoid15), 
       Count(whoid16), 
       Count(whoid17), 
       Count(whoid18), 
       Count(whoid19), 
       Count(whoid20), 
       Count(whoid21), 
       Count(whoid22), 
       Count(whoid25), 
       Count(whoid26), 
       Count(whoid27), 
       Count(whoid29), 
       Count(whoid30) 
FROM   (SELECT salesforce_users.NAME, 
               CASE 
                 WHEN health_plan_carriers__c ILIKE '%healthfirst%' 
                       OR health_plan_carriers__c ILIKE '%health first%' 
                       OR health_plan_carriers__c ILIKE 'hf%' THEN 'Healthfirst' 
                 WHEN health_plan_carriers__c ILIKE '%fidelis%' 
                       OR health_plan_carriers__c ILIKE '%catholic%' THEN 'Fidelis' 
                 WHEN health_plan_carriers__c ILIKE '%wellcare%' THEN 'Wellcare' 
                 WHEN health_plan_carriers__c ILIKE '%affinity%' THEN 'Affinity' 
                 WHEN health_plan_carriers__c ILIKE '%anthem%' 
                       OR health_plan_carriers__c ILIKE '%empire%' THEN 'Empire' 
                 WHEN health_plan_carriers__c ILIKE '%metroplus%' THEN 'Metroplus' 
                 WHEN health_plan_carriers__c ILIKE '%united%' THEN 'United' 
                 WHEN health_plan_carriers__c ILIKE '%emblem%' THEN 'Emblem' 
                 ELSE 'Unknown' 
               END AS mco, 
               whoid, 
               CASE 
                 WHEN status = 'Open' THEN whoid 
                 ELSE NULL 
               END AS whoid2, 
               CASE 
                 WHEN status = 'Closed' THEN whoid 
                 ELSE NULL 
               END AS whoid3, 
               CASE 
                 WHEN status = 'Completed' THEN whoid 
                 ELSE NULL 
               END AS whoid4, 
               CASE 
                 WHEN status = 'Completed - Awaiting Claim Submission' THEN whoid 
                 ELSE NULL 
               END AS whoid5, 
               CASE 
                 WHEN status = 'Completed - Awaiting Coding Correction' THEN whoid 
                 ELSE NULL 
               END AS whoid6, 
               CASE 
                 WHEN status = 'Excluded' THEN whoid 
                 ELSE NULL 
               END AS whoid9, 
               CASE 
                 WHEN status = 'Exclusion - Does not meet criteria - Verified by Management' THEN whoid
                 ELSE NULL 
               END AS whoid10, 
               CASE 
                 WHEN status = 'Exclusion - Moved out of coverage area/Switched to commercial insurance' THEN whoid
                 ELSE NULL 
               END AS whoid11, 
               CASE 
                 WHEN status = 'Exclusion - Patient deceased' THEN whoid 
                 ELSE NULL 
               END AS whoid12, 
               CASE 
                 WHEN status = 'Exclusion - Patient switched to OON PCP' THEN whoid 
                 ELSE NULL 
               END AS whoid13, 
               CASE 
                 WHEN status = 'Issue - Eligibility - Needs review' THEN whoid 
                 ELSE NULL 
               END AS whoid14, 
               CASE 
                 WHEN status = 'Issue - Ineligible for measure - Needs Review' THEN whoid 
                 ELSE NULL 
               END AS whoid15, 
               CASE 
                 WHEN status = 'Issue - Patient refused' THEN whoid 
                 ELSE NULL 
               END AS whoid16, 
               CASE 
                 WHEN status = 'Issue - PCP refused to collaborate' THEN whoid 
                 ELSE NULL 
               END AS whoid17, 
               CASE 
                 WHEN status = 'Issue - Phone wrong/disconnected/out of service' THEN whoid 
                 ELSE NULL 
               END AS whoid18, 
               CASE 
                 WHEN status = 'Issue - Referred to CBO for intervention' THEN whoid 
                 ELSE NULL 
               END AS whoid19, 
               CASE 
                 WHEN status = 'Issue - Unable to reach (3) attempts - Needs Management Review' THEN whoid
                 ELSE NULL 
               END AS whoid20, 
               CASE 
                 WHEN status = 'Open - No Show' THEN whoid 
                 ELSE NULL 
               END AS whoid21, 
               CASE 
                 WHEN status = 'Outreach - Unable to reach' THEN whoid 
                 ELSE NULL 
               END AS whoid22, 
               CASE 
                 WHEN status = 'Pending - Appointment Scheduled' THEN whoid 
                 ELSE NULL 
               END AS whoid25, 
               CASE 
                 WHEN status = 'Pending - Patient will call' THEN whoid 
                 ELSE NULL 
               END AS whoid26, 
               CASE 
                 WHEN status = 'Pending - Practice will schedule' THEN whoid 
                 ELSE NULL 
               END AS whoid27, 
               CASE 
                 WHEN status = 'Pending- Appointment Scheduled' THEN whoid 
                 ELSE NULL 
               END AS whoid29, 
               CASE 
                 WHEN status = 'Rx - Pending' THEN whoid 
                 ELSE NULL 
               END AS whoid30 
        FROM   (SELECT *, 
                       Row_number() 
                         OVER ( 
                           partition BY salesforce_tasks.id 
                           ORDER BY added_tz DESC) AS rn 
                FROM   salesforce_tasks) AS salesforce_tasks 
               JOIN salesforce_patients 
                 ON contact_id_18_characters__c = whoid 
               JOIN salesforce_users 
                 ON salesforce_users.id = salesforce_tasks.ownerid 
        WHERE  measure__c = 'Non-Utilizer' 
               AND rn = 1) 
GROUP  BY NAME, 
          mco 
HAVING Count(whoid) > 0
