WITH cte_diagnoses 
     AS (SELECT DISTINCT encounter_id, 
                         Stuff((SELECT DISTINCT ', ' + icd10_code 
                                FROM   t_assessment t2 
                                WHERE  t2.encounter_id = t1.encounter_id 
                                       AND icd10_code IS NOT NULL 
                                FOR xml path('')), 1, 2, '') AS diagnoses 
         FROM   t_assessment t1 
         WHERE  icd10_code IS NOT NULL 
         GROUP  BY encounter_id) 
SELECT distinct t_patient.pat_first_name, 
               t_patient.pat_middle_name, 
               t_patient.pat_last_name, 
               t_patient.pat_date_of_birth, 
               t_patient.pat_sex, 
               t_patient.pat_id, 
               cc_cpt_code, 
               cc_date_of_service, 
               provider_master.prov_last_name, 
               provider_master.prov_first_name, 
               provider_master.prov_middle_name, 
               responsible_provider_master.prov_last_name   AS responsible_prov_last_name, 
               responsible_provider_master.prov_first_name  AS responsible_prov_first_name, 
               responsible_provider_master.prov_middle_name AS responsible_prov_middle_name, 
               site_master.site_center_name, 
               diagnoses 
FROM   t_encounter 
       INNER JOIN t_patient 
               ON t_encounter.enc_patient_id = t_patient.pat_id 
       INNER JOIN t_chargecapture 
               ON t_chargecapture.cc_enc_id = t_encounter.enc_id 
       INNER JOIN cte_diagnoses 
               ON cte_diagnoses.encounter_id = t_encounter.enc_id 
       LEFT JOIN site_master 
              ON t_encounter.enc_site_id = site_master.site_id 
       LEFT JOIN provider_master 
              ON t_encounter.enc_rendering_provider_id = provider_master.prov_id 
       LEFT JOIN provider_master AS responsible_provider_master 
              ON t_patient.pat_responsible_provider_id = responsible_provider_master.prov_id 
WHERE  cc_cpt_code IS NOT NULL 
       AND Ltrim(Rtrim(cc_cpt_code)) <> '' 
       AND cc_date_of_service >= '2019-01-01'
