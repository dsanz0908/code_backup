delete from payor.staging_uhc_somos_claims;

copy payor.staging_uhc_somos_claims
from 's3://acp-data/UHC/Somos/SOMOS_201909_CLM_CAID.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 0
ignoreheader 1
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.uhc_somos_all_claims where filename = 'SOMOS_201909_CLM_CAID.txt';

INSERT INTO payor.uhc_somos_all_claims 
SELECT company_code,line_of_business_desc,category_of_svc,seq_claim_id,claim_number,line_number,sub_line_code,primary_svc_date,claim_thru_date,post_date,check_date,check_number,procedure_code,modifier_code_1,modifier_code_2,modifier_code_3,modifier_code_4,revenue_code,date_received,adjud_date,detail_svc_date,svc_to_date,svc_prov_id,svc_prov_full_name,svc_prov_npi,prov_spec,prov_type,provider_par_stat,att_prov_id,att_prov_full_name,att_prov_npi,ref_prov_id,ref_prov_full_name,vendor_id,vend_full_name,irs_tax_id,subscriber_id,pat_control_no,dob,memb_last_name,memb_middle_initial,memb_first_name,medicaid_no,medicare_no,gender,memb_zip,place_of_svc_code1,place_of_svc_code2,place_of_svc_code3,icd_prim_diag,icd_flag,diag1,diag2,diag3,diag4,diag5,diag6,diag7,diag8,diag9,diag10,diag11,diag12,diag13,diag14,diag15,diag16,diag17,diag18,diag19,diag20,diag21,diag22,diag23,diag24,diag25,diagnosis_1_poa,diagnosis_2_poa,diagnosis_3_poa,diagnosis_4_poa,diagnosis_5_poa,diagnosis_6_poa,diagnosis_7_poa,diagnosis_8_poa,diagnosis_9_poa,diagnosis_10_poa,diagnosis_11_poa,diagnosis_12_poa,diagnosis_13_poa,diagnosis_14_poa,diagnosis_15_poa,diagnosis_16_poa,diagnosis_17_poa,diagnosis_18_poa,diagnosis_19_poa,diagnosis_20_poa,diagnosis_21_poa,diagnosis_22_poa,diagnosis_23_poa,diagnosis_24_poa,diagnosis_25_poa,drg_code,bill_type,icd_proc_1,icd_proc_2,icd_proc_3,icd_proc_4,icd_proc_5,icd_proc_6,icd_proc_7,icd_proc_8,icd_proc_9,icd_proc_10,icd_proc_11,icd_proc_12,icd_proc_13,icd_proc_14,icd_proc_15,icd_proc_16,icd_proc_17,icd_proc_18,icd_proc_19,icd_proc_20,icd_proc_21,icd_proc_22,icd_proc_23,icd_proc_24,icd_proc_25,icd_proc_1_date,icd_proc_2_date,icd_proc_3_date,icd_proc_4_date,icd_proc_5_date,icd_proc_6_date,icd_proc_7_date,icd_proc_8_date,icd_proc_9_date,icd_proc_10_date,icd_proc_11_date,icd_proc_12_date,icd_proc_13_date,icd_proc_14_date,icd_proc_15_date,icd_proc_16_date,icd_proc_17_date,icd_proc_18_date,icd_proc_19_date,icd_proc_20_date,icd_proc_21_date,icd_proc_22_date,icd_proc_23_date,icd_proc_24_date,icd_proc_25_date,condition_code_1,condition_code_2,condition_code_3,condition_code_4,condition_code_5,condition_code_6,condition_code_7,condition_code_8,condition_code_9,condition_code_10,condition_code_11,admission_date,auth_number,admit_source_code,admit_hour,discharge_hour,patient_status,claim_status,processing_status,claim_type,quantity,total_billed_amt,billed_amt,ndc_code,rx_generic_brand_ind,rx_supply_days,rx_dispensing_fee_amt,rx_ingredient_amt,rx_formulary_ind,rx_date_prescription_written,brand_name,drug_strength_desc,gpi,gpi_desc,controlled_drug_ind,compound_code,
       '201909', 
       'SOMOS_201909_CLM_CAID.txt', 
       GETDATE(), 
       NULL, paid_amount_net 
FROM   payor.staging_uhc_somos_claims; 
