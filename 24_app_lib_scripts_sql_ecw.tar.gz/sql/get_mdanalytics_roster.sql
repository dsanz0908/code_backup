CREATE TEMPORARY TABLE T1
AS
SELECT DISTINCT member_id,
                medicare_patient_id,
                member_name,
                dob,
                provider_tin,
                pcp_name,
                provider_npi,
                payer,
                effective_period
FROM   (SELECT member_id,
               medicare_patient_id,
               member_name,
               To_date(member_dob, 'MM-DD-YYYY')     AS dob,
               provider_tin,
               pcp_name,
               provider_npi,
               'hf'                                  AS payer,
               Row_number()
                 OVER (
                   partition BY medicare_patient_id
                   ORDER BY pcp_effective_date DESC) AS rn,
              effective_period
        FROM   payor.healthfirst_all_eligibility
        WHERE  effective_period = (SELECT Max(effective_period)
                                   FROM   payor.healthfirst_all_eligibility)
               AND product = 'MCR'
        UNION
        SELECT DISTINCT member_id,
                        medicare_patient_id,
                        member_name,
                        To_date(member_dob, 'MM-DD-YYYY'),
                        provider_tin,
                        pcp_name,
                        provider_npi,
                        'hf',
                        Row_number()
                          OVER (
                            partition BY medicare_patient_id
                            ORDER BY pcp_effective_date DESC) AS rn,
                        effective_period
        FROM   payor.healthfirst_somos_all_eligibility
        WHERE  effective_period = (SELECT Max(effective_period)
                                   FROM   payor.healthfirst_somos_all_eligibility)
               AND product = 'MCR' )
WHERE  rn = 1 AND
medicare_patient_id NOT IN ( '0', '000000000' );


insert into t1
SELECT DISTINCT member_id,
                medicare_patient_id,
                member_name,
                dob,
                provider_tin,
                pcp_name,
                provider_npi,
                payer,
                effective_period
FROM   (

SELECT DISTINCT medicaid_no as member_id,
                        medicare_no as medicare_patient_id,
                        first_name
                        || ' '
                        || last_name as member_name,
                        date_of_birth as dob,
                        pcp_tin_1 as provider_tin,
                        pcp_first_name
                        || ' '
                        || pcp_last_name as pcp_name,
                        national_provider_id as provider_npi,
                        'wc' as payer,
                        Row_number()
                          OVER (
                            partition BY medicare_no
                            ORDER BY activity_date DESC) AS rn,
                        activity_date as effective_period
        FROM   payor.wellcare_all_demographics
               LEFT JOIN reference.wellcare_pcpid_to_tin_xwalk
                      ON seq_pcp_id = seq_prov_id
        WHERE  activity_date = (SELECT Max(activity_date)
                                FROM   payor.wellcare_all_demographics)
               AND lob = 'NMR'
        UNION
        SELECT DISTINCT medicaid_no,
                        medicare_no,
                        first_name
                        || ' '
                        || last_name,
                        date_of_birth,
                        pcp_tin_1,
                        pcp_first_name
                        || ' '
                        || pcp_last_name,
                        national_provider_id,
                        'wc',
                        Row_number()
                          OVER (
                            partition BY medicare_no
                            ORDER BY activity_date DESC) AS rn,
                        activity_date
        FROM   payor.wellcare_somos_all_demographics
               LEFT JOIN reference.wellcare_pcpid_to_tin_xwalk
                      ON seq_pcp_id = seq_prov_id
        WHERE  activity_date = (SELECT Max(activity_date)
                                FROM   payor.wellcare_somos_all_demographics)
               AND lob = 'NMR' ) a
WHERE  rn = 1 AND
medicare_patient_id NOT IN ( '0', '000000000' );
               
unload ( $$ with cte_1 as (
select *, rank() over ( partition by medicare_patient_id order by effective_period desc ) as rnk from t1 )
select member_id,medicare_patient_id,member_name,dob,provider_tin,pcp_name,provider_npi,payer from cte_1 where rnk = 1 $$)
to 's3://acp-data/mdanalytics/hc_wc_latest_roster_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

