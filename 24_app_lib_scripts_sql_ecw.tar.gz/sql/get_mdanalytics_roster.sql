unload ($$
SELECT DISTINCT member_id, 
                medicare_patient_id, 
                member_name, 
                dob, 
                provider_tin, 
                pcp_name, 
                provider_npi, 
                payer 
FROM   (SELECT member_id, 
               medicare_patient_id, 
               member_name, 
               To_date(member_dob, 'MM-DD-YYYY')     AS dob, 
               provider_tin, 
               pcp_name, 
               provider_npi, 
               'hf'                                  AS payer, 
               Row_number() 
                 OVER ( 
                   partition BY medicare_patient_id 
                   ORDER BY pcp_effective_date DESC) AS rn 
        FROM   payor.healthfirst_all_eligibility 
        WHERE  effective_period = (SELECT Max(effective_period) 
                                   FROM   payor.healthfirst_all_eligibility) 
               AND product = 'MCR' 
        UNION 
        SELECT DISTINCT member_id, 
                        medicare_patient_id, 
                        member_name, 
                        To_date(member_dob, 'MM-DD-YYYY'), 
                        provider_tin, 
                        pcp_name, 
                        provider_npi, 
                        'hf', 
                        Row_number() 
                          OVER ( 
                            partition BY medicare_patient_id 
                            ORDER BY pcp_effective_date DESC) AS rn 
        FROM   payor.healthfirst_somos_all_eligibility 
        WHERE  effective_period = (SELECT Max(effective_period) 
                                   FROM   payor.healthfirst_somos_all_eligibility) 
               AND product = 'MCR' 
        UNION 
        SELECT DISTINCT medicaid_no, 
                        medicare_no, 
                        first_name 
                        || ' ' 
                        || last_name, 
                        date_of_birth, 
                        pcp_tin_1, 
                        pcp_first_name 
                        || ' ' 
                        || pcp_last_name, 
                        national_provider_id, 
                        'wc', 
                        Row_number() 
                          OVER ( 
                            partition BY medicare_no 
                            ORDER BY activity_date DESC) AS rn 
        FROM   payor.wellcare_all_demographics 
               LEFT JOIN reference.wellcare_pcpid_to_tin_xwalk 
                      ON seq_pcp_id = seq_prov_id 
        WHERE  activity_date = (SELECT Max(activity_date) 
                                FROM   payor.wellcare_all_demographics) 
               AND lob = 'NMR' 
        UNION 
        SELECT DISTINCT medicaid_no, 
                        medicare_no, 
                        first_name 
                        || ' ' 
                        || last_name, 
                        date_of_birth, 
                        pcp_tin_1, 
                        pcp_first_name 
                        || ' ' 
                        || pcp_last_name, 
                        national_provider_id, 
                        'wc', 
                        Row_number() 
                          OVER ( 
                            partition BY medicare_no 
                            ORDER BY activity_date DESC) AS rn 
        FROM   payor.wellcare_somos_all_demographics 
               LEFT JOIN reference.wellcare_pcpid_to_tin_xwalk 
                      ON seq_pcp_id = seq_prov_id 
        WHERE  activity_date = (SELECT Max(activity_date) 
                                FROM   payor.wellcare_somos_all_demographics) 
               AND lob = 'NMR') 
WHERE  rn = 1 AND
medicare_patient_id NOT IN ( '0', '000000000' ) 
$$ )
to 's3://acp-data/mdanalytics/hc_wc_latest_roster_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

