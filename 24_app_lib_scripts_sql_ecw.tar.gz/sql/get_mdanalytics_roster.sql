unload ($$
SELECT * 
FROM   (SELECT DISTINCT medicare_patient_id, 
                        member_name, 
                        To_date(member_dob, 'MM-DD-YYYY'), 
                        provider_tin, 
                        pcp_name, 
                        provider_npi, 
                        'hf' 
        FROM   payor.healthfirst_all_eligibility 
        WHERE  effective_period = (SELECT Max(effective_period) 
                                   FROM   payor.healthfirst_all_eligibility) 
               AND medicare_patient_id <> '' 
        UNION 
        SELECT DISTINCT medicare_patient_id, 
                        member_name, 
                        To_date(member_dob, 'MM-DD-YYYY'), 
                        provider_tin, 
                        pcp_name, 
                        provider_npi, 
                        'hf' 
        FROM   payor.healthfirst_somos_all_eligibility 
        WHERE  effective_period = (SELECT Max(effective_period) 
                                   FROM   payor.healthfirst_somos_all_eligibility) 
               AND medicare_patient_id <> '' 
        UNION 
        SELECT DISTINCT medicare_no, 
                        first_name 
                        || ' ' 
                        || last_name, 
                        date_of_birth, 
                        pcp_tin_1, 
                        pcp_first_name 
                        || ' ' 
                        || pcp_last_name, 
                        national_provider_id, 
                        'wc' 
        FROM   payor.wellcare_all_demographics 
               LEFT JOIN reference.wellcare_pcpid_to_tin_xwalk 
                      ON seq_pcp_id = seq_prov_id 
        WHERE  activity_date = (SELECT Max(activity_date) 
                                FROM   payor.wellcare_all_demographics) 
               AND medicare_no <> '' 
        UNION 
        SELECT DISTINCT medicare_no, 
                        first_name 
                        || ' ' 
                        || last_name, 
                        date_of_birth, 
                        pcp_tin_1, 
                        pcp_first_name 
                        || ' ' 
                        || pcp_last_name, 
                        national_provider_id, 
                        'wc' 
        FROM   payor.wellcare_somos_all_demographics 
               LEFT JOIN reference.wellcare_pcpid_to_tin_xwalk 
                      ON seq_pcp_id = seq_prov_id 
        WHERE  activity_date = (SELECT Max(activity_date) 
                                FROM   payor.wellcare_somos_all_demographics) 
               AND medicare_no <> '') 
WHERE  medicare_patient_id NOT IN ( '0', '000000000' ) $$ )
to 's3://acp-data/mdanalytics/hc_wc_latest_roster_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

