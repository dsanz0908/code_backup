select top 10000 * from gdw.nonclaims_expense order by random()
