WITH top_providers 
     AS (SELECT local_pcp_provider_id 
         FROM   (SELECT local_pcp_provider_id, 
                        Sum(to_pay_amount)      AS paid, 
                        Row_number() 
                          OVER ( 
                            ORDER BY paid DESC) AS rn 
                 FROM   fact_claims 
                 WHERE  service_start_date >= '2019-07-01' 
                 GROUP  BY 1) 
         WHERE  rn <= 20) 
SELECT provider_full_name, provider_npi, member_first_name || ' ' || member_last_name as member_name, member_cin, service_start_date, to_pay_amount
FROM   fact_claims 
       JOIN top_providers 
         ON fact_claims.local_pcp_provider_id = top_providers.local_pcp_provider_id 
       JOIN dim_membership 
         ON fact_claims.local_member_id = dim_membership.local_member_id 
       JOIN dim_provider 
         ON fact_claims.local_pcp_provider_id = dim_provider.local_provider_id 
WHERE  service_start_date > '2019-07-01' 
