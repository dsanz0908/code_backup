select top 10000 * from gdw.patient_history order by random()
