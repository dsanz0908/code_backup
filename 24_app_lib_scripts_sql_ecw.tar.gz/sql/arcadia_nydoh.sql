unload ('select * from nydoh.all_claims where received_month = 201901 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201901/nydoh_claims_201901_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_cpa where received_month = 201901 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201901/nydoh_cpa_201901_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_rosters_all_columns where received_month = 201901 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201901/nydoh_all_rosters_all_columns_201901_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_shred where received_month = 201901 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201901/nydoh_shred_201901_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_patient_alerts where received_month = 201901 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201901/nydoh_patient_alerts_201901_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;

unload ('select * from nydoh.all_rx_claims where received_month = 201901 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201901/nydoh_rx_claims_201901_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;
