unload ('select * from nydoh.all_claims where received_month = 201906 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201906/nydoh_claims_201906_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_cpa where received_month = 201906 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201906/nydoh_cpa_201906_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_rosters_all_columns where received_month = 201906 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201906/nydoh_all_rosters_all_columns_201906_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_shred where received_month = 201906 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201906/nydoh_shred_201906_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;


unload ('select * from nydoh.all_patient_alerts where received_month = 201906 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201906/nydoh_patient_alerts_201906_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;

unload ('select * from nydoh.all_rx_claims where received_month = 201906 ')
to 's3://acp-data/Arcadia/Outgoing/nydoh/201906/nydoh_rx_claims_201906_'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
gzip
ALLOWOVERWRITE
parallel off;
