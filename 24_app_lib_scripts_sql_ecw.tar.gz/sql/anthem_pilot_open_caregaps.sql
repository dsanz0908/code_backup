unload ($$
SELECT * 
FROM   (SELECT measure, 
               sex                                               AS gender, 
               'Anthem Pilot'                                    AS health_plan, 
               member_medicaid_number                            AS patient_id, 
               member_first_name, 
               member_last_name, 
               To_char(To_date(dob, 'YYYY-MM-DD'), 'MM/DD/YYYY') AS member_dob, 
               member_address, 
               member_city                                       AS city, 
               member_state                                      AS state, 
               member_zip                                        AS zip, 
               CASE 
                 WHEN Trim(member_phone1) <> '' 
                      AND member_phone1 <> '000-000-0000' THEN member_phone1 
               END                                               AS member_phone_number, 
               pcp_provider_npi                                  AS provider_npi, 
               pcp_provider_name                                 AS pcp, 
               Row_number() 
                 OVER ( 
                   partition BY member_medicaid_number, measure) AS rn 
        FROM   payor.anthem_somos_all_caregaps 
               INNER JOIN payor.empire_bcbs_healthplus_somos_all_roster AS a 
                       ON Substring(member_key, 1, Len(member_key) - 2) = empire_subscriber_id 
        WHERE  yearmonth = '201811HEDIS2019' 
               AND received_month = '201811' 
               AND empire_subscriber_id IN (SELECT empire_subscriber_id 
                                            FROM   payor.anthem_somos_all_caregaps 
                                                   INNER JOIN payor.empire_bcbs_healthplus_somos_all_roster AS a
                                                           ON Substring(member_key, 1, Len(member_key) - 2) =
                                                              empire_subscriber_id 
                                            WHERE  yearmonth = '201808HEDIS2019') 
               AND measure IN (SELECT mco_measure 
                               FROM   payor.measure_hedis_sf_xwalk)) AS full_table 
WHERE  rn = 1 
       AND member_phone_number IS NOT NULL 
$$ )
to 's3://sftp_test/20190221_open_gaps_anthempilot.csv'
delimiter ','
addquotes
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

