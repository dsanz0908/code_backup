select distinct pat_first_name,
                pat_last_name,
                dob,
                cast(cc_date_of_service as date) as dos,
                cc_cpt_code, cc_dx_id_1 from 
(SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code, cc_dx_id_1, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by cc_date_of_service desc) as rn
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service between '2019-01-01' and '2019-12-31'
       AND cc_cpt_code IN ( '80047','80048','80050','80053','80069','82947','82950','82951','83036','83037','3044F','3045F','3046F','80061','83700','83701','83704','83721','3048F','3049F','3050F','82465','83718','84478' )
       AND pat_delete_ind = 'N') as t1 where rn = 1
