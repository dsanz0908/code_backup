SELECT DISTINCT cc_patient_id, 
                Cast(cc_date_of_service AS DATE) 
FROM   t_chargecapture 
WHERE  cc_cpt_code IN ( '94010', '94014', '94015', '94016', 
                        '94060', '94070', '94375', '94620' ) 
       AND cc_delete_ind = 'N' 
       AND cc_date_of_service >= '2016-01-01' 
