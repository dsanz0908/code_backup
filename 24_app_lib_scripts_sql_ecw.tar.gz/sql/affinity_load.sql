 
grant all on staging_affinity to etluser; copy staging_affinity from 's3://acp-data/Affinity/SOMOS/PCPRoster_(SOMOS)_07_01_2019' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv; delete from payor.affinity_somos_roster_all where filename = 'PCPRoster_(SOMOS)_07_01_2019';
 
