drop table feeds.SOMOS_extra_data_Hall_PH2_CT_10102018;
create table if not exists feeds.SOMOS_extra_data_Hall_PH2_CT_10102018 ( 
ID VARCHAR(255), ClinicID VARCHAR(255), ClinicName VARCHAR(255), PatientID VARCHAR(255), PatientName VARCHAR(255), DOB VARCHAR(255), dos  VARCHAR(255), PCP VARCHAR(255), PCP_NPI VARCHAR(255), EngagementType VARCHAR(255), CodeType VARCHAR(255), SpeificCode VARCHAR(255), insurance1 VARCHAR(255), insuredid1 VARCHAR(255), insurance2 VARCHAR(255), insurerid2 VARCHAR(255), insurance3 VARCHAR(255), insurerid3 VARCHAR(255));
grant all on feeds.SOMOS_extra_data_Hall_PH2_CT_10102018 to etluser;
