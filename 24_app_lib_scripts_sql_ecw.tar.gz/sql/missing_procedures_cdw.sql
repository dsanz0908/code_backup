drop table staging_arcadia_procedures;
create temp table if not exists staging_arcadia_procedures (
first_name varchar(255),
middle_name varchar(255),
last_name varchar(255),
dob datetime,
sex varchar(255),
pat_id varchar(255),
cc_cpt_code varchar(255),
cc_date_of_service datetime,
prov_last_name varchar(255),
prov_first_name varchar(255),
prov_middle_name varchar(255),
responsible_prov_last_name varchar(255),
responsible_prov_first_name varchar(255),
responsible_prov_middle_name varchar(255),
site_center_name varchar(255)
);


copy staging_arcadia_procedures
from 's3://sftp_test/missing_procedures_arcadia.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 500
region 'us-east-1'
dateformat 'auto'
delimiter '|'
NULL as 'NULL';

drop table fuzz_test;
create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';


set statement_timeout to 0;
unload ( $$
WITH cte_match_ids
     AS (SELECT pat_id,
                Max(CASE
                      WHEN rn = 1 THEN mco_cin
                    END) AS id_1,
                Max(CASE
                      WHEN rn = 2 THEN mco_cin
                    END) AS id_2,
                Max(CASE
                      WHEN rn = 3 THEN mco_cin
                    END) AS id_3
         FROM   (SELECT a.*,
                        Row_number()
                          OVER (
                            partition BY pat_id
                            ORDER BY mco_cin) AS rn
                 FROM   (SELECT DISTINCT pat_id,
                                         mco_cin
                         FROM   staging_arcadia_procedures AS a
                                JOIN fuzz_test
                                  ON pat_id = arcadia_pat_id where mco_source like 'Healthfirst%' or mco_source like 'WellCare%') AS a)
         GROUP  BY 1)
,
     cte_cdw_hf
     AS (SELECT DISTINCT healthfirst_src_member_id as member_id,
                         service_start_date,
                         service_cd
         FROM   fact_claims AS a
                JOIN dim_membership AS d
                  ON a.local_member_id = d.local_member_id
                JOIN dim_service_type
                  ON a.local_service_id = dim_service_type.local_service_id
         UNION
         SELECT DISTINCT member_cin,
                         service_start_date,
                         service_cd
         FROM   fact_claims AS a
                JOIN dim_membership AS d
                  ON a.local_member_id = d.local_member_id
                JOIN dim_service_type
                  ON a.local_service_id = dim_service_type.local_service_id
         UNION
         SELECT DISTINCT wellcare_src_member_id,
                         service_start_date,
                         service_cd
         FROM   fact_claims AS a
                JOIN dim_membership AS d
                  ON a.local_member_id = d.local_member_id
                JOIN dim_service_type
                  ON a.local_service_id = dim_service_type.local_service_id)
/*SELECT responsible_prov_last_name,
       responsible_prov_first_name,
       responsible_prov_middle_name,
       site_center_name,
       To_char(cc_date_of_service, 'YYYY-MM-01') AS dos, sum(claimed), count(*),
       Sum(claimed) * 100.0 / Count(*)
FROM   (*/SELECT distinct first_name,
               middle_name,
               last_name,
               dob,
               sex,
               cc_cpt_code,
               cc_date_of_service,
               prov_last_name,
               prov_first_name,
               prov_middle_name,
               responsible_prov_last_name,
               responsible_prov_first_name,
               responsible_prov_middle_name,
               site_center_name,
               id_1,
               id_2,
               id_3,
               CASE
                 WHEN service_start_date IS NULL THEN 0
                 ELSE 1
               END AS claimed
        FROM   staging_arcadia_procedures
               JOIN cte_match_ids
                 ON staging_arcadia_procedures.pat_id = cte_match_ids.pat_id
               LEFT OUTER JOIN cte_cdw_hf
                            ON ( id_1 = member_id
                                  OR id_2 = member_id
                                  OR id_3 = member_id )
                               AND cc_cpt_code = service_cd
        WHERE  cc_cpt_code IS NOT NULL and (service_start_date >= Trunc(cc_date_of_service) or service_start_date is null)/*)
GROUP  BY 1,2,3,4,5
ORDER  BY 4,1,2,3,5*/
$$ )
to 's3://sftp_test/missing_procedures_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;




