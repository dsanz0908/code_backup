delete from  where filename = 'Empire_BCBS_HealthPlus_Enrollment_SOMOS_201701_201902.TXT';
insert into  ( 
  membership_month,
  empire_provider_id,
  pcp_npi,
  pcp_name,
  pcp_tax_id,
  product,
  region,
  empire_subscriber_id,
  member_medicaid_number,
  member_last_name,
  member_first_name,
  member_dob,
  gndr_nm,
  lang_nm,
  monthly_membership_start_date,
  monthly_membership_end_date,
  mm_cnt,
  filename,
  IPA,
  RACE_ETHN_DESC,
  received_month
)
select 
from staging_empire_somos_Enrollment;
drop table staging_empire_somos_Enrollment;
