select ' ' || tgt_column_name || ',' from mco_file_to_table_mapping 
where mco_name = 'Empire_Somos' and file_type = 'pharmacy'
order by column_order;
