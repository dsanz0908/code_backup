delete from payor.empire_SOMOS_RX_PROV_DELTA where received_month = '201812' or received_month = '';
copy payor.empire_SOMOS_RX_PROV_DELTA
from 's3://acp-data/Anthem/Somos/SOMOS_RX_PROV_DELTA_12172018.out'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
fillrecord
region 'us-east-1'
dateformat 'auto'
delimiter '|';

update payor.empire_SOMOS_RX_PROV_DELTA set received_month = '201812' where received_month = '';
update payor.empire_SOMOS_RX_PROV_DELTA set file_name = 'SOMOS_RX_PROV_DELTA_12172018.out' where file_name = '';
update payor.empire_SOMOS_RX_PROV_DELTA set added_tz = getdate() where added_tz is null;

