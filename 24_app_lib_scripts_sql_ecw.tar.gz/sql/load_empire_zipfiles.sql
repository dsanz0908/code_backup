delete from payor.empire_SOMOS_RX_PROV_DELTA where received_month = '201901' or received_month = '';
copy payor.empire_SOMOS_RX_PROV_DELTA
from 's3://acp-data/Anthem/Somos/SOMOS_RX_PROV_DELTA_01142019.out'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
dateformat 'auto'
delimiter '|';

update payor.empire_SOMOS_RX_PROV_DELTA set received_month = '201901' where received_month = '';

