delete from payor.empire_SOMOS_Scorecard_Metrics where received_month = '201910' or received_month = '';
copy payor.empire_SOMOS_Scorecard_Metrics
from 's3://acp-data/Anthem/Somos/SOMOS_Scorecard_Metrics_10232019.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
fillrecord
region 'us-east-1'
dateformat 'auto'
delimiter '|';

update payor.empire_SOMOS_Scorecard_Metrics set received_month = '201910' where received_month = '';
update payor.empire_SOMOS_Scorecard_Metrics set file_name = 'SOMOS_Scorecard_Metrics_10232019.txt' where file_name = '';
update payor.empire_SOMOS_Scorecard_Metrics set added_tz = getdate() where added_tz is null;

