unload ($$
SELECT orig_member_id       AS member_id, 
       pat_first_name       AS member_first_name, 
       pat_last_name        AS member_last_name, 
       to_char(dob, 'MM/DD/YYYY'),
       NULL                 AS SSN, 
       sex, 
       provider_npi         AS facility_id, 
       NULL                 AS affinity_provider_id, 
       provider_npi         AS servicing_provider_npi, 
       provider_name        AS servicing_provider_name, 
       provider_zip         AS servicing_provider_zip_code, 
       11                   AS place_of_service, 
       to_char(vitals_date, 'MM/DD/YYYY')          AS date_of_service, 
       icd10_code           AS primary_diagnosis_code, 
       icd10_code_1                 AS SECONDARY_DIAGNOSIS_CODE_1, 
       icd10_code_2                 AS SECONDARY_DIAGNOSIS_CODE_2, 
       icd10_code_3                 AS SECONDARY_DIAGNOSIS_CODE_3, 
       icd10_code_4                 AS SECONDARY_DIAGNOSIS_CODE_4, 
       icd10_code_5                 AS SECONDARY_DIAGNOSIS_CODE_5, 
       icd10_code_6                 AS SECONDARY_DIAGNOSIS_CODE_6, 
       icd10_code_7                 AS SECONDARY_DIAGNOSIS_CODE_7, 
       icd10_code_8                 AS SECONDARY_DIAGNOSIS_CODE_8, 
       icd10_code_9                 AS SECONDARY_DIAGNOSIS_CODE_9, 
       cpt_code             AS PRINCIPAL_PROCEDURE_CODE, 
       10                   AS ICD_VERSION_INDICATOR, 
       case when vitals_systolic < 130 then '3074F' when vitals_systolic > 139 then '3077F' else '3075F' end                   AS cpt_code,
       case when vitals_diastolic < 80 then '3078F' when vitals_systolic > 89 then '3080F' else '3079F' end                   AS cpt_2_code,
       NULL                 AS loinc_code, 
       'CBP'                AS test_screen_name, 
       NULL                 AS result_name, 
       vitals_systolic      AS result_value_1, 
       vitals_diastolic     AS result_value_2, 
       'systolic/diastolic' AS result_unit 
FROM   cbp_reporting_new t1 
       INNER JOIN (SELECT cin, 
                          Max(pcp_id)       AS affinity_provider_id, 
                          Max(provider_npi) AS pcp_npi 
                   FROM   payor.affinity_corinthian_all_rosters 
                   WHERE  cin != '' 
                   GROUP  BY cin) 
               ON orig_member_id = cin 
WHERE  mco = 'NY State Claims' 
       AND vitals_systolic IS NOT NULL 
       AND vitals_diastolic IS NOT NULL 
       AND exists (select 1 from procedure_code_crosswalk where cpt_code = proc_code)
UNION 
SELECT cin                  AS member_id, 
       pat_first_name       AS member_first_name, 
       pat_last_name        AS member_last_name, 
       to_char(dob, 'MM/DD/YYYY'),
       NULL                 AS SSN, 
       sex, 
       provider_npi         AS facility_id, 
       NULL                 AS affinity_provider_id, 
       provider_npi         AS servicing_provider_npi, 
       provider_name        AS servicing_provider_name, 
       provider_zip         AS servicing_provider_zip_code, 
       11                   AS place_of_service, 
       to_char(vitals_date, 'MM/DD/YYYY')          AS date_of_service, 
       icd10_code           AS primary_diagnosis_code, 
       icd10_code_1                 AS SECONDARY_DIAGNOSIS_CODE_1, 
       icd10_code_2                 AS SECONDARY_DIAGNOSIS_CODE_2, 
       icd10_code_3                 AS SECONDARY_DIAGNOSIS_CODE_3, 
       icd10_code_4                 AS SECONDARY_DIAGNOSIS_CODE_4, 
       icd10_code_5                 AS SECONDARY_DIAGNOSIS_CODE_5, 
       icd10_code_6                 AS SECONDARY_DIAGNOSIS_CODE_6, 
       icd10_code_7                 AS SECONDARY_DIAGNOSIS_CODE_7, 
       icd10_code_8                 AS SECONDARY_DIAGNOSIS_CODE_8, 
       icd10_code_9                 AS SECONDARY_DIAGNOSIS_CODE_9, 
       cpt_code             AS PRINCIPAL_PROCEDURE_CODE, 
       10                   AS ICD_VERSION_INDICATOR, 
       case when vitals_systolic < 130 then '3074F' when vitals_systolic > 139 then '3077F' else '3075F' end                   AS cpt_code,
       case when vitals_diastolic < 80 then '3078F' when vitals_systolic > 89 then '3080F' else '3079F' end                   AS cpt_2_code,
       NULL                 AS loinc_code, 
       'CBP'                AS test_screen_name, 
       NULL                 AS result_name, 
       vitals_systolic      AS result_value_1, 
       vitals_diastolic     AS result_value_2, 
       'systolic/diastolic' AS result_unit 
FROM   cbp_reporting_new t1 
       INNER JOIN (SELECT cin, 
                          Upper(Substring(first_name, 1, 3)) mem_f, 
                          Upper(Substring(last_name, 1, 3))  AS mem_l, 
                          dob                                mem_dob, 
                          Max(pcp_id)                        AS 
                          affinity_provider_id, 
                          Max(provider_npi)                  AS pcp_npi 
                   FROM   payor.affinity_corinthian_all_rosters 
                   WHERE  cin IS NOT NULL 
                          AND cin != '' 
                   GROUP  BY Upper(Substring(first_name, 1, 3)), 
                             Upper(Substring(last_name, 1, 3)), 
                             dob, 
                             cin) t2 
               ON Upper(Substring(pat_first_name, 1, 3)) = mem_f 
                  AND Upper(Substring(pat_last_name, 1, 3)) = mem_l 
                  AND Cast(dob AS DATE) = mem_dob 
WHERE  mco IS NULL 
       AND vitals_systolic IS NOT NULL 
       AND vitals_diastolic IS NOT NULL
       AND exists (select 1 from procedure_code_crosswalk where cpt_code = proc_code)$$)
TO 's3://acp-data/CBP/cbp_reporting_affinity_TODAY_' delimiter '|' gzip parallel OFF allowoverwrite iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
