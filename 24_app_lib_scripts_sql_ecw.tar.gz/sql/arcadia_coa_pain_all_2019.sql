SELECT DISTINCT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                Cast(cc_date_of_service AS DATE), 
                cc_cpt_code 
FROM   t_chargecapture 
       JOIN t_patient 
         ON cc_patient_id = pat_id 
WHERE  cc_delete_ind = 'N' 
       AND cc_cpt_code IN ( '1125F', '1126F' ) 
       AND Year(cc_date_of_service) = 2019 
       AND Datediff(year, pat_date_of_birth, Getdate()) >= 66 
