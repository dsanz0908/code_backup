select top 10000 * from gdw.emr_encounters order by random()
