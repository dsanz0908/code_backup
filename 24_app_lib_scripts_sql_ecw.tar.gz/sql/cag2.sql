set nocount on;

SELECT *
FROM   acpps_sandbox_prd01..temp_cag_arcadia;
