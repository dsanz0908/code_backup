WITH cte_review 
     AS (SELECT DISTINCT cc_patient_id, 
                         Cast(cc_date_of_service AS DATE) AS d, 
                         cc_cpt_code 
         FROM   t_chargecapture 
                JOIN t_patient 
                  ON cc_patient_id = pat_id 
         WHERE  cc_delete_ind = 'N' 
                AND cc_cpt_code = '1159F' 
                AND Year(cc_date_of_service) = 2019 
                AND Datediff(year, pat_date_of_birth, Getdate()) >= 66), 
     cte_list 
     AS (SELECT DISTINCT cc_patient_id, 
                         Cast(cc_date_of_service AS DATE) AS d, 
                         cc_cpt_code 
         FROM   t_chargecapture 
                JOIN t_patient 
                  ON cc_patient_id = pat_id 
         WHERE  cc_delete_ind = 'N' 
                AND cc_cpt_code = '1160F' 
                AND Year(cc_date_of_service) = 2019 
                AND Datediff(year, pat_date_of_birth, Getdate()) >= 66) 
SELECT DISTINCT cte_review.cc_patient_id, 
                cte_review.d, 
                cte_review.cc_cpt_code, 
                cte_list.cc_cpt_code 
FROM   cte_review 
       JOIN cte_list 
         ON cte_review.cc_patient_id = cte_list.cc_patient_id 
            AND cte_review.d = cte_list.d 
