SELECT DISTINCT enc_patient_id, 
                Dateadd(month, Datediff(month, 0, t_encounter.enc_timestamp), 0) AS encounter_month,
                icd10_code 
FROM   t_encounter 
       JOIN t_patient 
         ON t_encounter.enc_patient_id = t_patient.pat_id 
       JOIN t_assessment 
         ON t_encounter.enc_id = t_assessment.encounter_id 
WHERE  t_encounter.enc_timestamp >= '2017-01-01' 
       AND t_encounter.enc_delete_ind = 'N' 
       AND t_assessment.delete_ind = 'N'
