delete nydoh.staging_claims;
delete nydoh.staging_rx_claims;
delete nydoh.staging_cpa;
delete nydoh.staging_shred;
delete nydoh.staging_roster;
delete nydoh.staging_patient_alerts;

copy nydoh.staging_claims
from 's3://acp-data/NYDOH/201901/claims.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
ignoreheader 1
region 'us-east-1'
delimiter '^'
dateformat 'auto'
ESCAPE;

copy nydoh.staging_rx_claims
from 's3://acp-data/NYDOH/201901/rx_claims.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 1
region 'us-east-1'
delimiter '^'
dateformat 'auto'
REMOVEQUOTES;

copy nydoh.staging_cpa
from 's3://acp-data/NYDOH/201901/cpa.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 1
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

copy nydoh.staging_shred
from 's3://acp-data/NYDOH/201901/shred.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 1
region 'us-east-1'
delimiter '^'
dateformat 'auto'
REMOVEQUOTES;

copy nydoh.staging_roster
from 's3://acp-data/NYDOH/201901/roster.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 1
region 'us-east-1'
delimiter '^'
dateformat 'auto'
REMOVEQUOTES;


copy nydoh.staging_patient_alerts
from 's3://acp-data/NYDOH/201901/patient_alerts.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 1
region 'us-east-1'
delimiter '^'
dateformat 'auto'
REMOVEQUOTES;


delete from nydoh.all_claims where mbr_id in ( select mbr_id from nydoh.staging_shred ) and received_month = '201812';
delete from nydoh.all_rx_claims where mbr_id in ( select mbr_id from nydoh.staging_shred ) and received_month = '201812';
delete from nydoh.all_cpa where mbr_id in ( select mbr_id from nydoh.staging_shred ) and received_month = '201812';
delete from nydoh.all_rosters_all_columns where beneficiary_hic_number in ( select mbr_id from nydoh.staging_shred ) and received_month = '201812';
delete from nydoh.all_patient_alerts where mbr_id in ( select mbr_id from nydoh.staging_shred ) and received_month = '201812';

delete from nydoh.all_claims where received_month = '201901';
delete from nydoh.all_rx_claims where received_month = '201901';
delete from nydoh.all_cpa where received_month = '201901';
delete from nydoh.all_rosters_all_columns where received_month = '201901';
delete from nydoh.all_patient_alerts where received_month = '201901';
delete from nydoh.all_shred where received_month = '201901';

insert into nydoh.all_claims ( select *, '201901' from nydoh.staging_claims );
insert into nydoh.all_rx_claims ( select *, '201901' from nydoh.staging_rx_claims );
insert into nydoh.all_cpa ( select *,'201901' from nydoh.staging_cpa );
insert into nydoh.all_rosters_all_columns ( select *, '201901' from nydoh.staging_roster );
insert into nydoh.all_patient_alerts ( select * , '201901' from nydoh.staging_patient_alerts );
insert into nydoh.all_shred ( select *, '201901' from nydoh.staging_shred );


\q
