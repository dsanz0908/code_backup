unload ($$
SELECT DISTINCT * 
FROM   (SELECT orig_member_id                     AS member_id, 
               pat_first_name                     AS member_first_name, 
               pat_last_name                      AS member_last_name, 
               To_char(dob, 'MM/DD/YYYY'), 
               NULL                               AS SSN, 
               sex, 
               provider_npi                       AS facility_id, 
               NULL                               AS affinity_provider_id, 
               provider_npi                       AS servicing_provider_npi, 
               provider_name                      AS servicing_provider_name, 
               provider_zip                       AS servicing_provider_zip_code 
               , 
               11                                 AS 
               place_of_service, 
               To_char(vitals_date, 'MM/DD/YYYY') AS date_of_service, 
               icd10_code                         AS primary_diagnosis_code, 
               icd10_code_1                       AS SECONDARY_DIAGNOSIS_CODE_1, 
               icd10_code_2                       AS SECONDARY_DIAGNOSIS_CODE_2, 
               icd10_code_3                       AS SECONDARY_DIAGNOSIS_CODE_3, 
               icd10_code_4                       AS SECONDARY_DIAGNOSIS_CODE_4, 
               icd10_code_5                       AS SECONDARY_DIAGNOSIS_CODE_5, 
               icd10_code_6                       AS SECONDARY_DIAGNOSIS_CODE_6, 
               icd10_code_7                       AS SECONDARY_DIAGNOSIS_CODE_7, 
               icd10_code_8                       AS SECONDARY_DIAGNOSIS_CODE_8, 
               icd10_code_9                       AS SECONDARY_DIAGNOSIS_CODE_9, 
               cpt_code                           AS PRINCIPAL_PROCEDURE_CODE, 
               10                                 AS ICD_VERSION_INDICATOR, 
               CASE 
                 WHEN vitals_systolic < 130 THEN '3074F' 
                 WHEN vitals_systolic > 139 THEN '3077F' 
                 ELSE '3075F' 
               END                                AS cpt_code, 
               CASE 
                 WHEN vitals_diastolic < 80 THEN '3078F' 
                 WHEN vitals_systolic > 89 THEN '3080F' 
                 ELSE '3079F' 
               END                                AS cpt_2_code, 
               NULL                               AS loinc_code, 
               'CBP'                              AS test_screen_name, 
               NULL                               AS result_name, 
               vitals_systolic                    AS result_value_1, 
               vitals_diastolic                   AS result_value_2, 
               'systolic/diastolic'               AS result_unit 
        FROM   cbp_reporting_new t1 
               INNER JOIN (SELECT cin, 
                                  To_date(period, 'YYYYMM') AS period, 
                                  Max(pcp_id)               AS 
                                  affinity_provider_id, 
                                  Max(provider_npi)         AS pcp_npi 
                           FROM   payor.affinity_corinthian_all_rosters 
                           WHERE  cin != '' 
                           GROUP  BY cin, 
                                     To_date(period, 'YYYYMM')) 
                       ON orig_member_id = cin 
                          AND Date_part(year, vitals_date) = 
                              Date_part(year, period) 
                          AND Date_part(month, vitals_date) = 
                              Date_part(month, period) 
        WHERE  mco = 'NY State Claims' 
               AND vitals_systolic IS NOT NULL 
               AND vitals_diastolic IS NOT NULL 
               AND EXISTS (SELECT 1 
                           FROM   procedure_code_crosswalk 
                           WHERE  cpt_code = proc_code) 
        UNION 
        SELECT cin                                AS member_id, 
               pat_first_name                     AS member_first_name, 
               pat_last_name                      AS member_last_name, 
               To_char(dob, 'MM/DD/YYYY'), 
               NULL                               AS SSN, 
               sex, 
               provider_npi                       AS facility_id, 
               NULL                               AS affinity_provider_id, 
               provider_npi                       AS servicing_provider_npi, 
               provider_name                      AS servicing_provider_name, 
               provider_zip                       AS servicing_provider_zip_code 
               , 
               11                                 AS 
               place_of_service, 
               To_char(vitals_date, 'MM/DD/YYYY') AS date_of_service, 
               icd10_code                         AS primary_diagnosis_code, 
               icd10_code_1                       AS SECONDARY_DIAGNOSIS_CODE_1, 
               icd10_code_2                       AS SECONDARY_DIAGNOSIS_CODE_2, 
               icd10_code_3                       AS SECONDARY_DIAGNOSIS_CODE_3, 
               icd10_code_4                       AS SECONDARY_DIAGNOSIS_CODE_4, 
               icd10_code_5                       AS SECONDARY_DIAGNOSIS_CODE_5, 
               icd10_code_6                       AS SECONDARY_DIAGNOSIS_CODE_6, 
               icd10_code_7                       AS SECONDARY_DIAGNOSIS_CODE_7, 
               icd10_code_8                       AS SECONDARY_DIAGNOSIS_CODE_8, 
               icd10_code_9                       AS SECONDARY_DIAGNOSIS_CODE_9, 
               cpt_code                           AS PRINCIPAL_PROCEDURE_CODE, 
               10                                 AS ICD_VERSION_INDICATOR, 
               CASE 
                 WHEN vitals_systolic < 130 THEN '3074F' 
                 WHEN vitals_systolic > 139 THEN '3077F' 
                 ELSE '3075F' 
               END                                AS cpt_code, 
               CASE 
                 WHEN vitals_diastolic < 80 THEN '3078F' 
                 WHEN vitals_systolic > 89 THEN '3080F' 
                 ELSE '3079F' 
               END                                AS cpt_2_code, 
               NULL                               AS loinc_code, 
               'CBP'                              AS test_screen_name, 
               NULL                               AS result_name, 
               vitals_systolic                    AS result_value_1, 
               vitals_diastolic                   AS result_value_2, 
               'systolic/diastolic'               AS result_unit 
        FROM   cbp_reporting_new t1 
               INNER JOIN (SELECT cin, 
                                  To_date(period, 'YYYYMM')          AS period, 
                                  Upper(Substring(first_name, 1, 3)) mem_f, 
                                  Upper(Substring(last_name, 1, 3))  AS mem_l, 
                                  dob                                mem_dob, 
                                  Max(pcp_id)                        AS 
                                  affinity_provider_id, 
                                  Max(provider_npi)                  AS pcp_npi 
                           FROM   payor.affinity_corinthian_all_rosters 
                           WHERE  cin IS NOT NULL 
                                  AND cin != '' 
                           GROUP  BY Upper(Substring(first_name, 1, 3)), 
                                     Upper(Substring(last_name, 1, 3)), 
                                     dob, 
                                     cin, 
                                     To_date(period, 'YYYYMM')) t2 
                       ON Upper(Substring(pat_first_name, 1, 3)) = mem_f 
                          AND Upper(Substring(pat_last_name, 1, 3)) = mem_l 
                          AND Cast(dob AS DATE) = mem_dob 
                          AND Date_part(year, vitals_date) = 
                              Date_part(year, period) 
                          AND Date_part(month, vitals_date) = 
                              Date_part(month, period) 
        WHERE  mco IS NULL 
               AND vitals_systolic IS NOT NULL 
               AND vitals_diastolic IS NOT NULL 
               AND EXISTS (SELECT 1 
                           FROM   procedure_code_crosswalk 
                           WHERE  cpt_code = proc_code) 
        UNION 
        SELECT orig_member_id                     AS member_id, 
               pat_first_name                     AS member_first_name, 
               pat_last_name                      AS member_last_name, 
               To_char(dob, 'MM/DD/YYYY'), 
               NULL                               AS SSN, 
               sex, 
               provider_npi                       AS facility_id, 
               NULL                               AS affinity_provider_id, 
               provider_npi                       AS servicing_provider_npi, 
               provider_name                      AS servicing_provider_name, 
               provider_zip                       AS servicing_provider_zip_code 
               , 
               11                                 AS 
               place_of_service, 
               To_char(vitals_date, 'MM/DD/YYYY') AS date_of_service, 
               icd10_code                         AS primary_diagnosis_code, 
               icd10_code_1                       AS SECONDARY_DIAGNOSIS_CODE_1, 
               icd10_code_2                       AS SECONDARY_DIAGNOSIS_CODE_2, 
               icd10_code_3                       AS SECONDARY_DIAGNOSIS_CODE_3, 
               icd10_code_4                       AS SECONDARY_DIAGNOSIS_CODE_4, 
               icd10_code_5                       AS SECONDARY_DIAGNOSIS_CODE_5, 
               icd10_code_6                       AS SECONDARY_DIAGNOSIS_CODE_6, 
               icd10_code_7                       AS SECONDARY_DIAGNOSIS_CODE_7, 
               icd10_code_8                       AS SECONDARY_DIAGNOSIS_CODE_8, 
               icd10_code_9                       AS SECONDARY_DIAGNOSIS_CODE_9, 
               cpt_code                           AS PRINCIPAL_PROCEDURE_CODE, 
               10                                 AS ICD_VERSION_INDICATOR, 
               CASE 
                 WHEN vitals_systolic < 130 THEN '3074F' 
                 WHEN vitals_systolic > 139 THEN '3077F' 
                 ELSE '3075F' 
               END                                AS cpt_code, 
               CASE 
                 WHEN vitals_diastolic < 80 THEN '3078F' 
                 WHEN vitals_systolic > 89 THEN '3080F' 
                 ELSE '3079F' 
               END                                AS cpt_2_code, 
               NULL                               AS loinc_code, 
               'CBP'                              AS test_screen_name, 
               NULL                               AS result_name, 
               vitals_systolic                    AS result_value_1, 
               vitals_diastolic                   AS result_value_2, 
               'systolic/diastolic'               AS result_unit 
        FROM   cbp_reporting_new t1 
               INNER JOIN (SELECT cin, 
                                  To_date(period, 'YYYYMM') AS period, 
                                  Max(pcp_id)               AS 
                                  affinity_provider_id, 
                                  Max(provider_npi)         AS pcp_npi 
                           FROM   payor.affinity_somos_roster_all 
                           WHERE  cin != '' 
                           GROUP  BY cin, 
                                     To_date(period, 'YYYYMM')) 
                       ON orig_member_id = cin 
                          AND Date_part(year, vitals_date) = 
                              Date_part(year, period) 
                          AND Date_part(month, vitals_date) = 
                              Date_part(month, period) 
        WHERE  mco = 'NY State Claims' 
               AND vitals_systolic IS NOT NULL 
               AND vitals_diastolic IS NOT NULL 
               AND EXISTS (SELECT 1 
                           FROM   procedure_code_crosswalk 
                           WHERE  cpt_code = proc_code) 
        UNION 
        SELECT cin                                AS member_id, 
               pat_first_name                     AS member_first_name, 
               pat_last_name                      AS member_last_name, 
               To_char(dob, 'MM/DD/YYYY'), 
               NULL                               AS SSN, 
               sex, 
               provider_npi                       AS facility_id, 
               NULL                               AS affinity_provider_id, 
               provider_npi                       AS servicing_provider_npi, 
               provider_name                      AS servicing_provider_name, 
               provider_zip                       AS servicing_provider_zip_code 
               , 
               11                                 AS 
               place_of_service, 
               To_char(vitals_date, 'MM/DD/YYYY') AS date_of_service, 
               icd10_code                         AS primary_diagnosis_code, 
               icd10_code_1                       AS SECONDARY_DIAGNOSIS_CODE_1, 
               icd10_code_2                       AS SECONDARY_DIAGNOSIS_CODE_2, 
               icd10_code_3                       AS SECONDARY_DIAGNOSIS_CODE_3, 
               icd10_code_4                       AS SECONDARY_DIAGNOSIS_CODE_4, 
               icd10_code_5                       AS SECONDARY_DIAGNOSIS_CODE_5, 
               icd10_code_6                       AS SECONDARY_DIAGNOSIS_CODE_6, 
               icd10_code_7                       AS SECONDARY_DIAGNOSIS_CODE_7, 
               icd10_code_8                       AS SECONDARY_DIAGNOSIS_CODE_8, 
               icd10_code_9                       AS SECONDARY_DIAGNOSIS_CODE_9, 
               cpt_code                           AS PRINCIPAL_PROCEDURE_CODE, 
               10                                 AS ICD_VERSION_INDICATOR, 
               CASE 
                 WHEN vitals_systolic < 130 THEN '3074F' 
                 WHEN vitals_systolic > 139 THEN '3077F' 
                 ELSE '3075F' 
               END                                AS cpt_code, 
               CASE 
                 WHEN vitals_diastolic < 80 THEN '3078F' 
                 WHEN vitals_systolic > 89 THEN '3080F' 
                 ELSE '3079F' 
               END                                AS cpt_2_code, 
               NULL                               AS loinc_code, 
               'CBP'                              AS test_screen_name, 
               NULL                               AS result_name, 
               vitals_systolic                    AS result_value_1, 
               vitals_diastolic                   AS result_value_2, 
               'systolic/diastolic'               AS result_unit 
        FROM   cbp_reporting_new t1 
               INNER JOIN (SELECT cin, 
                                  To_date(period, 'YYYYMM')          AS period, 
                                  Upper(Substring(first_name, 1, 3)) mem_f, 
                                  Upper(Substring(last_name, 1, 3))  AS mem_l, 
                                  dob                                mem_dob, 
                                  Max(pcp_id)                        AS 
                                  affinity_provider_id, 
                                  Max(provider_npi)                  AS pcp_npi 
                           FROM   payor.affinity_somos_roster_all 
                           WHERE  cin IS NOT NULL 
                                  AND cin != '' 
                           GROUP  BY Upper(Substring(first_name, 1, 3)), 
                                     Upper(Substring(last_name, 1, 3)), 
                                     dob, 
                                     cin, 
                                     To_date(period, 'YYYYMM')) t2 
                       ON Upper(Substring(pat_first_name, 1, 3)) = mem_f 
                          AND Upper(Substring(pat_last_name, 1, 3)) = mem_l 
                          AND Cast(dob AS DATE) = mem_dob 
                          AND Date_part(year, vitals_date) = 
                              Date_part(year, period) 
                          AND Date_part(month, vitals_date) = 
                              Date_part(month, period) 
        WHERE  mco IS NULL 
               AND vitals_systolic IS NOT NULL 
               AND vitals_diastolic IS NOT NULL 
               AND EXISTS (SELECT 1 
                           FROM   procedure_code_crosswalk 
                           WHERE  cpt_code = proc_code)) 
ORDER  BY member_last_name, 
          member_first_name, 
          date_of_service 
       $$)
TO 's3://sftp_test/20190716_affinity_adhoc_emrdata' delimiter '|' parallel OFF allowoverwrite iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
