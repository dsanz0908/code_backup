copy salesforce_contacts
from 's3://acp-data/Salesforce/salesforce_contacts.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
delimiter '|'
ignoreheader as 1;
\q
