select top 10000 * from gdw.master_claim_type order by random()
