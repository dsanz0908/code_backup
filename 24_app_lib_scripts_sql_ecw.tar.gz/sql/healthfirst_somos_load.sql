delete from payor.staging_healthfirst_somos_claims;
copy payor.staging_healthfirst_somos_claims
from 's3://acp-data/Healthfirst/Somos/ANA07601_SOMOS_APR2019_DTL_CLAIM.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.staging_healthfirst_somos_eligibility;
copy payor.staging_healthfirst_somos_eligibility
from 's3://acp-data/Healthfirst/Somos/ANA07801_SOMOS_APR2019_DTL_ELIGIBILITY.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;


delete from payor.staging_healthfirst_somos_rx_claims;
copy payor.staging_healthfirst_somos_rx_claims
from 's3://acp-data/Healthfirst/Somos/ANA07701_SOMOS_APR2019_DTL_PHARMACY_1.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.healthfirst_somos_all_claims where filename = 'ANA07601_SOMOS_APR2019_DTL_CLAIM.txt';
insert into payor.healthfirst_somos_all_claims (select * , '201904', 'ANA07601_SOMOS_APR2019_DTL_CLAIM.txt' from payor.staging_healthfirst_somos_claims); 
delete from payor.healthfirst_somos_all_rx_claims where filename = 'ANA07701_SOMOS_APR2019_DTL_PHARMACY.txt';
insert into payor.healthfirst_somos_all_rx_claims (select * , '201904', 'ANA07701_SOMOS_APR2019_DTL_PHARMACY.txt' from payor.staging_healthfirst_somos_rx_claims);

delete from payor.healthfirst_somos_all_eligibility where filename = 'ANA07801_SOMOS_APR2019_DTL_ELIGIBILITY.txt';
insert into payor.healthfirst_somos_all_eligibility (select
company_number,
product,
porg,
hospital_name,
provider_id,
members_physician_name,
pcp_address1,
pcp_address2,
pcp_city,
pcp_state,
pcp_zip,
Case when trim(effective_period) = ''   then NULL else  CAST ( effective_period AS date ) end ,
Case when trim(member_month) = ''   then NULL else  CAST ( member_month AS real ) end ,
eligibility_category,
eligibility_cat_w_demographic,
premium_group,
Case when trim(members_sex) = ''   then NULL else  CAST ( members_sex AS character(1) ) end ,
member_id,
member_name,
birth_date,
address1,
address2,
member_city,
member_state,
member_zip,
medicare_patient_id,
mcaid,
ratype,
member_last_name,
member_first_name,
national_provider_id,
provider_tin,
member_home_phone,
member_other_phone,
member_email,
provider_parent_code,
Case when trim(pcp_effective_date) = ''   then NULL else  CAST ( pcp_effective_date AS date ) end ,
Case when trim(pcp_expiration_date) = ''   then NULL else  CAST ( pcp_expiration_date AS date ) end ,
outreach_enrollment_code,
health_home_name,
medicaid_id,
premium_group_description,
'201904',
'ANA07801_SOMOS_APR2019_DTL_ELIGIBILITY'  
 from payor.staging_healthfirst_somos_eligibility );
