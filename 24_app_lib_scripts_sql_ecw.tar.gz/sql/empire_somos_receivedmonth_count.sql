select count(*) from payor.empire_bcbs_healthplus_somos_all_roster where received_month = '201903'
