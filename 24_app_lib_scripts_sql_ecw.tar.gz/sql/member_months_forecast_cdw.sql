unload ($$
SELECT Split_part(source, ' ', 1)               AS mco, 
       Split_part(source, ' ', 2)               AS ipa, 
       lob, 
       product_cd                               AS product, 
       practice_name                            AS practice, 
       provider_full_name                       AS pcp, 
       provider_taxonomies                      AS taxonomy, 
       CASE 
         WHEN Datediff(year, member_dob, effective_date) < 5 THEN 'Under 5 years' 
         WHEN Datediff(year, member_dob, effective_date) between 5 and 17 THEN '5 to 17 years' 
         WHEN Datediff(year, member_dob, effective_date) between 18 and 24 THEN '18 to 24 years' 
         WHEN Datediff(year, member_dob, effective_date) between 25 and 44 THEN '25 to 44 years' 
         WHEN Datediff(year, member_dob, effective_date) between 45 and 65 THEN '45 to 65 years' 
         WHEN Datediff(year, member_dob, effective_date) >= 65 THEN '65 years and older' 
         ELSE 'N/A' 
       END                                      AS age, 
       member_sex                               AS sex, 
       the_date, 
       Cast(Sum(membership_month_count) AS INT) AS member_months, 
       'real'                                   AS state 
FROM   fact_eligibility 
       JOIN dim_date 
         ON fact_eligibility.date_id = dim_date.date_id 
       JOIN dim_product 
         ON fact_eligibility.local_product_id = dim_product.local_product_id 
       JOIN dim_provider 
         ON fact_eligibility.local_provider_id = dim_provider.local_provider_id 
       JOIN dim_provider_org_detail 
         ON fact_eligibility.local_provider_org_id = dim_provider_org_detail.local_provider_org_id
       JOIN dim_membership 
         ON fact_eligibility.local_member_id = dim_membership.local_member_id 
WHERE  year >= 2017 
GROUP  BY 1,2,3,4,5,6,7,8,9,10
ORDER  BY 1,2,3,4,5,6,7,8,9,10 $$)
to 's3://sftp_test/member_months_forecast'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

