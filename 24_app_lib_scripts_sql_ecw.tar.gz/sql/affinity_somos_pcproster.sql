create temporary table if not exists PCPRoster_(SOMOS)_01_01_2019 (
Group Name VARCHAR(255),
PCP ID VARCHAR(255),
Provider NPI VARCHAR(255),
PCP Name VARCHAR(255),
PCP Address VARCHAR(255),
*Member Status VARCHAR(255),
Affinity Subscriber Number VARCHAR(255),
CIN VARCHAR(255),
LOB VARCHAR(255),
Last Name VARCHAR(255),
First Name VARCHAR(255),
DOB VARCHAR(255),
SEX VARCHAR(255),
Effective Date VARCHAR(255),
PCP Assgn Date VARCHAR(255),
Recertification Date VARCHAR(255),
Member Address VARCHAR(255),
Member Phone Number VARCHAR(255),
**Member Email Address VARCHAR(255),
Restricted Recipient VARCHAR(255),
Health Home VARCHAR(255),
Health Home Name VARCHAR(255),
Non User VARCHAR(255),
Auto Assigned VARCHAR(255),
HARP Eligible VARCHAR(255),
Group TIN
);
copy FILNENAME
from 's3://acp-data/Affinity/PCPRoster_(SOMOS)_01_01_2019.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 2
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;

