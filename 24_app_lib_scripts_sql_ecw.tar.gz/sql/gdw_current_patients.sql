select top 10000 * from gdw.current_patients order by random()
