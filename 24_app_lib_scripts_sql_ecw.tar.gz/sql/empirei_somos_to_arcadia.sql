unload ( 'select membership_month, empire_provider_id, pcp_npi, pcp_name, pcp_tax_id, product, region, empire_subscriber_id, member_medicaid_number, member_last_name, 
member_first_name, member_dob,gndr_nm, lang_nm, monthly_membership_start_date, monthly_membership_end_date, mm_cnt from payor.empire_bcbs_healthplus_somos_all_roster
where received_month = 201807 ' )
to 's3://acp-data/Arcadia/Outgoing/anthem/empire_somos_eligibility_2018_07_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;
