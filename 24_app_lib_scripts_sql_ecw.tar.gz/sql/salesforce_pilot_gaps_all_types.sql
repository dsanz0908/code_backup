unload ($$ 
SELECT *
FROM   (SELECT 'CHW',
               NAME,
               Count(DISTINCT whoid)  AS unique_members,
               Count(DISTINCT whoid2) AS unique_members_with_open_gaps,
               Count(DISTINCT whoid3),
               Count(DISTINCT whoid4),
               Count(DISTINCT whoid5),
               Count(DISTINCT whoid6),
               Count(DISTINCT whoid9),
               Count(DISTINCT whoid10),
               Count(DISTINCT whoid11),
               Count(DISTINCT whoid12),
               Count(DISTINCT whoid13),
               Count(DISTINCT whoid14),
               Count(DISTINCT whoid15),
               Count(DISTINCT whoid16),
               Count(DISTINCT whoid17),
               Count(DISTINCT whoid18),
               Count(DISTINCT whoid19),
               Count(DISTINCT whoid20),
               Count(DISTINCT whoid21),
               Count(DISTINCT whoid22),
               Count(DISTINCT whoid25),
               Count(DISTINCT whoid26),
               Count(DISTINCT whoid27),
               Count(DISTINCT whoid29),
               Count(DISTINCT whoid30)
        FROM   (SELECT NAME,
                       whoid,
                       CASE
                         WHEN status = 'Open' THEN whoid
                         ELSE NULL
                       END AS whoid2,
                       CASE
                         WHEN status = 'Closed' THEN whoid
                         ELSE NULL
                       END AS whoid3,
                       CASE
                         WHEN status = 'Completed' THEN whoid
                         ELSE NULL
                       END AS whoid4,
                       CASE
                         WHEN status = 'Completed - Awaiting Claim Submission' THEN whoid
                         ELSE NULL
                       END AS whoid5,
                       CASE
                         WHEN status = 'Completed - Awaiting Coding Correction' THEN whoid
                         ELSE NULL
                       END AS whoid6,
                       CASE
                         WHEN status = 'Excluded' THEN whoid
                         ELSE NULL
                       END AS whoid9,
                       CASE
                         WHEN status = 'Exclusion - Does not meet criteria - Verified by Management' THEN whoid
                         ELSE NULL
                       END AS whoid10,
                       CASE
                         WHEN status = 'Exclusion - Moved out of coverage area/Switched to commercial insurance' THEN
                         whoid
                         ELSE NULL
                       END AS whoid11,
                       CASE
                         WHEN status = 'Exclusion - Patient deceased' THEN whoid
                         ELSE NULL
                       END AS whoid12,
                       CASE
                         WHEN status = 'Exclusion - Patient switched to OON PCP' THEN whoid
                         ELSE NULL
                       END AS whoid13,
                       CASE
                         WHEN status = 'Issue - Eligibility - Needs review' THEN whoid
                         ELSE NULL
                       END AS whoid14,
                       CASE
                         WHEN status = 'Issue - Ineligible for measure - Needs Review' THEN whoid
                         ELSE NULL
                       END AS whoid15,
                       CASE
                         WHEN status = 'Issue - Patient refused' THEN whoid
                         ELSE NULL
                       END AS whoid16,
                       CASE
                         WHEN status = 'Issue - PCP refused to collaborate' THEN whoid
                         ELSE NULL
                       END AS whoid17,
                       CASE
                         WHEN status = 'Issue - Phone wrong/disconnected/out of service' THEN whoid
                         ELSE NULL
                       END AS whoid18,
                       CASE
                         WHEN status = 'Issue - Referred to CBO for intervention' THEN whoid
                         ELSE NULL
                       END AS whoid19,
                       CASE
                         WHEN status = 'Issue - Unable to reach (3) attempts - Needs Management Review' THEN whoid
                         ELSE NULL
                       END AS whoid20,
                       CASE
                         WHEN status = 'Open - No Show' THEN whoid
                         ELSE NULL
                       END AS whoid21,
                       CASE
                         WHEN status = 'Outreach - Unable to reach' THEN whoid
                         ELSE NULL
                       END AS whoid22,
                       CASE
                         WHEN status = 'Pending - Appointment Scheduled' THEN whoid
                         ELSE NULL
                       END AS whoid25,
                       CASE
                         WHEN status = 'Pending - Patient will call' THEN whoid
                         ELSE NULL
                       END AS whoid26,
                       CASE
                         WHEN status = 'Pending - Practice will schedule' THEN whoid
                         ELSE NULL
                       END AS whoid27,
                       CASE
                         WHEN status = 'Pending- Appointment Scheduled' THEN whoid
                         ELSE NULL
                       END AS whoid29,
                       CASE
                         WHEN status = 'Rx - Pending' THEN whoid
                         ELSE NULL
                       END AS whoid30
                FROM   salesforce_users AS a
                       LEFT OUTER JOIN (SELECT *
                                        FROM   (SELECT salesforce_tasks.*, contact_assigned_chw__c,
                                                       Row_number()
                                                         OVER (
                                                           partition BY salesforce_tasks.id
                                                           ORDER BY left(salesforce_tasks.lastmodifieddate,10) desc, added_tz DESC) AS rn
                                                FROM   salesforce_tasks join salesforce_patients on salesforce_tasks.whoid = salesforce_patients.id where salesforce_tasks.project_end_date__c = '2019-12-31' and pilot_initiative__c = 'TRUE')
                                        WHERE  rn = 1) AS b
                                    ON b.contact_assigned_chw__c = a.id) AS c
        GROUP  BY NAME
        HAVING Count(DISTINCT whoid) > 0
        UNION
        SELECT 'PRACTICE',
               organization_name__c,
               Count(DISTINCT whoid)  AS unique_members,
               Count(DISTINCT whoid2) AS unique_members_with_open_gaps,
               Count(DISTINCT whoid3),
               Count(DISTINCT whoid4),
               Count(DISTINCT whoid5),
               Count(DISTINCT whoid6),
               Count(DISTINCT whoid9),
               Count(DISTINCT whoid10),
               Count(DISTINCT whoid11),
               Count(DISTINCT whoid12),
               Count(DISTINCT whoid13),
               Count(DISTINCT whoid14),
               Count(DISTINCT whoid15),
               Count(DISTINCT whoid16),
               Count(DISTINCT whoid17),
               Count(DISTINCT whoid18),
               Count(DISTINCT whoid19),
               Count(DISTINCT whoid20),
               Count(DISTINCT whoid21),
               Count(DISTINCT whoid22),
               Count(DISTINCT whoid25),
               Count(DISTINCT whoid26),
               Count(DISTINCT whoid27),
               Count(DISTINCT whoid29),
               Count(DISTINCT whoid30)
        FROM   (SELECT organization_name__c,
                       whoid,
                       CASE
                         WHEN status = 'Open' THEN whoid
                         ELSE NULL
                       END AS whoid2,
                       CASE
                         WHEN status = 'Closed' THEN whoid
                         ELSE NULL
                       END AS whoid3,
                       CASE
                         WHEN status = 'Completed' THEN whoid
                         ELSE NULL
                       END AS whoid4,
                       CASE
                         WHEN status = 'Completed - Awaiting Claim Submission' THEN whoid
                         ELSE NULL
                       END AS whoid5,
                       CASE
                         WHEN status = 'Completed - Awaiting Coding Correction' THEN whoid
                         ELSE NULL
                       END AS whoid6,
                       CASE
                         WHEN status = 'Excluded' THEN whoid
                         ELSE NULL
                       END AS whoid9,
                       CASE
                         WHEN status = 'Exclusion - Does not meet criteria - Verified by Management' THEN whoid
                         ELSE NULL
                       END AS whoid10,
                       CASE
                         WHEN status = 'Exclusion - Moved out of coverage area/Switched to commercial insurance' THEN
                         whoid
                         ELSE NULL
                       END AS whoid11,
                       CASE
                         WHEN status = 'Exclusion - Patient deceased' THEN whoid
                         ELSE NULL
                       END AS whoid12,
                       CASE
                         WHEN status = 'Exclusion - Patient switched to OON PCP' THEN whoid
                         ELSE NULL
                       END AS whoid13,
                       CASE
                         WHEN status = 'Issue - Eligibility - Needs review' THEN whoid
                         ELSE NULL
                       END AS whoid14,
                       CASE
                         WHEN status = 'Issue - Ineligible for measure - Needs Review' THEN whoid
                         ELSE NULL
                       END AS whoid15,
                       CASE
                         WHEN status = 'Issue - Patient refused' THEN whoid
                         ELSE NULL
                       END AS whoid16,
                       CASE
                         WHEN status = 'Issue - PCP refused to collaborate' THEN whoid
                         ELSE NULL
                       END AS whoid17,
                       CASE
                         WHEN status = 'Issue - Phone wrong/disconnected/out of service' THEN whoid
                         ELSE NULL
                       END AS whoid18,
                       CASE
                         WHEN status = 'Issue - Referred to CBO for intervention' THEN whoid
                         ELSE NULL
                       END AS whoid19,
                       CASE
                         WHEN status = 'Issue - Unable to reach (3) attempts - Needs Management Review' THEN whoid
                         ELSE NULL
                       END AS whoid20,
                       CASE
                         WHEN status = 'Open - No Show' THEN whoid
                         ELSE NULL
                       END AS whoid21,
                       CASE
                         WHEN status = 'Outreach - Unable to reach' THEN whoid
                         ELSE NULL
                       END AS whoid22,
                       CASE
                         WHEN status = 'Pending - Appointment Scheduled' THEN whoid
                         ELSE NULL
                       END AS whoid25,
                       CASE
                         WHEN status = 'Pending - Patient will call' THEN whoid
                         ELSE NULL
                       END AS whoid26,
                       CASE
                         WHEN status = 'Pending - Practice will schedule' THEN whoid
                         ELSE NULL
                       END AS whoid27,
                       CASE
                         WHEN status = 'Pending- Appointment Scheduled' THEN whoid
                         ELSE NULL
                       END AS whoid29,
                       CASE
                         WHEN status = 'Rx - Pending' THEN whoid
                         ELSE NULL
                       END AS whoid30
                FROM   salesforce_providers AS a
                       LEFT OUTER JOIN (SELECT *
                                        FROM   (SELECT salesforce_tasks.*,
                                                       Row_number()
                                                         OVER (
                                                           partition BY salesforce_tasks.id
                                                           ORDER BY left(salesforce_tasks.lastmodifieddate,10) desc, added_tz DESC) AS rn
                                                FROM   salesforce_tasks join salesforce_patients on salesforce_tasks.whoid = salesforce_patients.id where salesforce_tasks.project_end_date__c = '2019-12-31'  and salesforce_tasks.isdeleted = 'FALSE' and pilot_initiative__c = 'TRUE')
                                        WHERE  rn = 1) AS b
                                    ON b.pcp__c = a.id) AS c
        GROUP  BY organization_name__c
        HAVING Count(DISTINCT whoid) > 0) AS d
ORDER  BY 1,
          2
 $$) to 's3://sftp_test/2019-11-21_pilot_gaps_all_types' delimiter ',' parallel off ALLOWOVERWRITE addquotes iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
