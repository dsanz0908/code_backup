WITH cte_my5_accesstocare_completed
     AS (SELECT DISTINCT cc_patient_id AS a
         FROM   t_chargecapture
         WHERE  cc_delete_ind = 'N'
                AND cc_date_of_service BETWEEN '20180701' AND '20190630'
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384',
                                     '99485', '99386', '99387', '99391',
                                     '99392', '99393', '99394', '99395',
                                     '99396', '99397', 'G0438', 'G0439', 'G0402' )),
     cte_my6_accesstocare_completed
     AS (SELECT DISTINCT cc_patient_id AS b
         FROM   t_chargecapture
         WHERE  cc_delete_ind = 'N'
                AND cc_date_of_service BETWEEN '20190701' AND '20200630'
                AND cc_cpt_code IN ( '99381', '99382', '99383', '99384',
                                     '99485', '99386', '99387', '99391',
                                     '99392', '99393', '99394', '99395',
                                     '99396', '99397', 'G0438', 'G0439', 'G0402' ))
SELECT DISTINCT pat_id,
                pat_first_name,
                pat_last_name,
                pat_address_1,
                pat_city,
                pat_state,
                pat_zip,
                CASE
                  WHEN pat_phone_1 <> ''
                       AND pat_phone_1 IS NOT NULL THEN pat_phone_1
                  ELSE pat_phone_2
                END                             AS phone,
                Cast(pat_date_of_birth AS DATE) AS dob,
                pat_sex,
                prov_npi,
                prov_first_name,
                prov_last_name,
                CASE
                  WHEN Datediff(month, pat_date_of_birth, Getdate()) BETWEEN 12 AND 24 THEN 'Children''s Access to Primary Care - 12 to 24 months'
                  WHEN Datediff(year, pat_date_of_birth, Getdate()) BETWEEN 2 AND 6 THEN 'Children''s Access to Primary Care - 25 months to 6 years'
                  WHEN Datediff(year, pat_date_of_birth, Getdate()) BETWEEN 7 AND 11 THEN 'Children''s Access to Primary Care - 7 to 11 years'
                  WHEN Datediff(year, pat_date_of_birth, Getdate()) BETWEEN 12 AND 19 THEN 'Adolescent Access to Primary Care - 12 to 19 years'
                  WHEN Datediff(year, pat_date_of_birth, Getdate()) BETWEEN 20 AND 44 THEN 'Adult Access to Preventive or Ambulatory Care - 20 to 44 years'
                  WHEN Datediff(year, pat_date_of_birth, Getdate()) BETWEEN 45 AND 64 THEN 'Adult Access to Preventive or Ambulatory Care - 45 to 54 years'
                  WHEN Datediff(year, pat_date_of_birth, Getdate()) >= 65 THEN 'Adult Access to Preventive or Ambulatory Care - 65 and older'
                  ELSE ''
                END                             AS measure
FROM   cte_my5_accesstocare_completed
       LEFT JOIN cte_my6_accesstocare_completed
              ON a = b
       JOIN t_patient
         ON a = pat_id
       JOIN provider_master
         ON pat_responsible_provider_id = prov_id
WHERE  b IS NULL
       AND pat_delete_ind = 'N'
       AND prov_delete_ind = 'N'
       AND pat_expired_ind = 'N'
