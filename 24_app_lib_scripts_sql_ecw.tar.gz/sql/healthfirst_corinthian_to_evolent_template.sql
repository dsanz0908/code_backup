unload ($$
SELECT company_number, 
       product, 
       provider_org, 
       hospital_name, 
       provider_id, 
       pcp_name, 
       pcp_address1, 
       pcp_address2, 
       pcp_city, 
       pcp_state, 
       pcp_zip, 
       effective_period, 
       member_month, 
       eligibility_category, 
       eligibility_cat_w_demographic, 
       premium_group, 
       member_sex, 
       member_id, 
       member_name, 
       member_dob, 
       member_address_1, 
       member_address_2, 
       member_city, 
       member_state, 
       member_zip, 
       medicare_patient_id, 
       mcaid, 
       ratype, 
       member_last_name, 
       member_first_name, 
       provider_npi, 
       provider_tin, 
       member_home_phone, 
       member_other_phone, 
       member_email, 
       provider_parent_code, 
       pcp_effective_date, 
       pcp_expiration_date, 
       outreach_enrollment_code, 
       health_home_name, 
       medicaid_id, 
       premium_group_description, 
       received_month 
FROM   payor.healthfirst_all_eligibility 
WHERE  effective_period = '2018-08-01' 
       AND NOT EXISTS (SELECT 1 
                       FROM   payor.healthfirst_somos_all_eligibility 
                       WHERE  healthfirst_all_eligibility.provider_id = healthfirst_somos_all_eligibility.provider_id
                              AND effective_period = '2018-08-01' 
                              AND CASE 
                                    WHEN healthfirst_all_eligibility.company_number = '01' THEN
                                      CASE 
                                        WHEN healthfirst_all_eligibility.eligibility_category = 'HARP' THEN 'HARP'
                                        ELSE 'MCD' 
                                      END 
                                    WHEN healthfirst_all_eligibility.company_number = '20' THEN 'CHP'
                                    WHEN healthfirst_all_eligibility.company_number = '30' THEN 'MCR'
                                    WHEN healthfirst_all_eligibility.company_number = '34' THEN 'MCR DUAL'
                                    WHEN healthfirst_all_eligibility.company_number = '42' THEN
                                      CASE 
                                        WHEN healthfirst_all_eligibility.eligibility_category IN ( 'EP PLAN 1', 'EP PLAN 2', 'EP PLAN 3', 'EP PLAN 4'
                                                                                                 ) THEN
                                        'EP' 
                                        ELSE 'QHP' 
                                      END 
                                    ELSE 'other' 
                                  END = CASE 
                                          WHEN healthfirst_somos_all_eligibility.company_number = '01' THEN
                                            CASE 
                                              WHEN healthfirst_somos_all_eligibility.eligibility_category = 'HARP' THEN 'HARP'
                                              ELSE 'MCD' 
                                            END 
                                          WHEN healthfirst_somos_all_eligibility.company_number = '20' THEN 'CHP'
                                          WHEN healthfirst_somos_all_eligibility.company_number = '30' THEN 'MCR'
                                          WHEN healthfirst_somos_all_eligibility.company_number = '34' THEN 'MCR DUAL'
                                          WHEN healthfirst_somos_all_eligibility.company_number = '42' THEN
                                            CASE 
                                              WHEN healthfirst_somos_all_eligibility.eligibility_category IN
                                                   ( 'EP PLAN 1', 'EP PLAN 2', 'EP PLAN 3', 'EP PLAN 4' )
                                            THEN 
                                              'EP' 
                                              ELSE 'QHP' 
                                            END 
                                          ELSE 'other' 
                                        END) 
$$)
to 's3://sftp_test/healthfirst_evolent/healthfirst_corinthian_eligibility_2018_08_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload ($$
SELECT company, 
       name_company, 
       provider_risk, 
       network, 
       member_porg, 
       member_hospital_name, 
       pcp_id, 
       pcp_name, 
       pcp_license_number, 
       pcp_npi, 
       pcp_fed_number, 
       pcp_level, 
       pcp_prov_type_code, 
       pcp_provider_type, 
       pcp_parent_code, 
       pcp_specialty_desc_1, 
       pcp_specialty_desc_2, 
       pcp_specialty_desc_3, 
       pcp_address, 
       pcp_city, 
       pcp_state, 
       pcp_zip, 
       member_name, 
       member_dob, 
       member_zip, 
       premium_group, 
       eligibility_category, 
       eligibility_category_with_demographic, 
       member_number, 
       accounting_period, 
       effective_period, 
       claim_type, 
       admit_type, 
       place_of_service_code, 
       place_of_service, 
       inpatient_advance_indicator, 
       capitated_claim_indicator, 
       claim_id, 
       line_no, 
       acct_payable_transaction_date, 
       start_date, 
       end_date, 
       discharge_status, 
       covered_days, 
       utilization_count, 
       unit_count, 
       umr_group, 
       umr_group_description, 
       umr_category, 
       umr_category_description, 
       sub_umr_category, 
       sub_umr_category_description, 
       ap_transaction_amount, 
       net_allowed_amount, 
       allowed_amount, 
       to_pay_amount, 
       billed_amount, 
       copay_amount, 
       coinsurance_amount, 
       deductible_amount, 
       care_type, 
       service_weight, 
       bill_type, 
       form_code, 
       service_type, 
       service_code, 
       service_code_description, 
       primary_diagnosis, 
       primary_diagnosis_description, 
       primary_diag_poa_description, 
       diagnosis_code_2, 
       diag_description_2, 
       poa_description_2, 
       diagnosis_code_3, 
       diag_description_3, 
       poa_description_3, 
       diagnosis_code_4, 
       diag_description_4, 
       poa_description_4, 
       diagnosis_code_5, 
       diag_description_5, 
       poa_description_5, 
       diagnosis_code_6, 
       diag_description_6, 
       poa_description_6, 
       diagnosis_code_7, 
       diag_description_7, 
       poa_description_7, 
       diagnosis_code_8, 
       diag_description_8, 
       poa_description_8, 
       diagnosis_code_9, 
       diag_description_9, 
       poa_description_9, 
       diagnosis_code_10, 
       diag_description_10, 
       poa_description_10, 
       diagnosis_code_11, 
       diag_description_11, 
       poa_description_11, 
       diagnosis_code_12, 
       diag_description_12, 
       poa_description_12, 
       diagnosis_code_13, 
       diag_description_13, 
       poa_description_13, 
       diagnosis_code_14, 
       diag_description_14, 
       poa_description_14, 
       diagnosis_code_15, 
       diag_description_15, 
       poa_description_15, 
       diagnosis_code_16, 
       diag_description_16, 
       poa_description_16, 
       diagnosis_code_17, 
       diag_description_17, 
       poa_description_17, 
       diagnosis_code_18, 
       diag_description_18, 
       poa_description_18, 
       principle_procedure_code, 
       secondary_procedure_code, 
       tertiary_procedure_code, 
       quaternary_procedure_code, 
       fifth_procedure_code, 
       sixth_procedure_code, 
       cpt_modifier_1, 
       cpt_modifier_2, 
       service_line_status, 
       reversal_indicator, 
       reversed_from, 
       reversed_to, 
       service_hold_code_1, 
       service_hold_code_2, 
       service_hold_code_3, 
       service_hold_code_4, 
       service_hold_code_5, 
       servicing_provider_porg_id, 
       servicing_provider_hospital, 
       servicing_provider_id, 
       servicing_provider_name, 
       servicing_provider_license_number, 
       servicing_provider_npi_id, 
       servicing_provider_fednum, 
       servicing_provider_pcp_level, 
       servicing_provider_parent_id, 
       prov_type, 
       servicing_provider_type, 
       servicing_specialty_description_1, 
       servicing_specialty_description_2, 
       servicing_specialty_description_3, 
       servicing_provider_address, 
       servicing_provider_city, 
       servicing_provider_state, 
       servicing_provider_zip, 
       attending_physician_npi_id, 
       non_covered_amount, 
       diagnosis_code_version_indicator, 
       admission_date, 
       admission_source, 
       admission_source_description, 
       patient_account_number, 
       discharge_date, 
       average_length_service, 
       coordination_benefits, 
       ip_op_indicator, 
       drg, 
       drg_description, 
       revenue_code, 
       revenue_code_description, 
       primary_procedure_code_description, 
       proc_description_2, 
       proc_description_3, 
       proc_description_4, 
       proc_description_5, 
       proc_description_6, 
       attending_provider_name, 
       referring_provider_npi, 
       referring_provider_name, 
       cpt_code, 
       cpt_modifier_3, 
       cpt_modifier_4, 
       modifier_code_1, 
       modifier_code_2, 
       modifier_code_3, 
       modifier_code_4, 
       vendor, 
       vendor_tax_id, 
       birth_weight, 
       admitting_diagnosis_code, 
       admitting_diagnosis_code_desc, 
       received_month 
FROM   payor.healthfirst_all_claims 
WHERE  effective_period = '2018-08-01' 
       AND NOT EXISTS (SELECT 1 
                       FROM   payor.healthfirst_somos_all_claims 
                       WHERE  healthfirst_all_claims.pcp_id = healthfirst_somos_all_claims.pcp_id
                              AND effective_period = '2018-08-01' 
                              AND CASE 
                                    WHEN healthfirst_all_claims.company = '01' THEN 
                                      CASE 
                                        WHEN healthfirst_all_claims.eligibility_category = 'HARP' THEN 'HARP'
                                        ELSE 'MCD' 
                                      END 
                                    WHEN healthfirst_all_claims.company = '20' THEN 'CHP' 
                                    WHEN healthfirst_all_claims.company = '30' THEN 'MCR' 
                                    WHEN healthfirst_all_claims.company = '34' THEN 'MCR DUAL' 
                                    WHEN healthfirst_all_claims.company = '42' THEN 
                                      CASE 
                                        WHEN healthfirst_all_claims.eligibility_category IN ( 'EP PLAN 1', 'EP PLAN 2', 'EP PLAN 3', 'EP PLAN 4' )
                                      THEN 'EP' 
                                        ELSE 'QHP' 
                                      END 
                                    ELSE 'other' 
                                  END = CASE 
                                          WHEN healthfirst_somos_all_claims.company = '01' THEN
                                            CASE 
                                              WHEN healthfirst_somos_all_claims.eligibility_category = 'HARP' THEN 'HARP'
                                              ELSE 'MCD' 
                                            END 
                                          WHEN healthfirst_somos_all_claims.company = '20' THEN 'CHP'
                                          WHEN healthfirst_somos_all_claims.company = '30' THEN 'MCR'
                                          WHEN healthfirst_somos_all_claims.company = '34' THEN 'MCR DUAL'
                                          WHEN healthfirst_somos_all_claims.company = '42' THEN
                                            CASE 
                                              WHEN healthfirst_somos_all_claims.eligibility_category IN (
                                                   'EP PLAN 1', 'EP PLAN 2', 'EP PLAN 3', 'EP PLAN 4'
                                                                                                        )
                                            THEN 
                                              'EP' 
                                              ELSE 'QHP' 
                                            END 
                                          ELSE 'other' 
                                        END) 
$$)
to 's3://sftp_test/healthfirst_evolent/healthfirst_corinthian_claims_2018_08_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

unload($$
SELECT cycle_date, 
       record_source, 
       line_of_business, 
       company_number, 
       network, 
       members_hospital, 
       hospital_name, 
       pcp_name, 
       pcp_npi, 
       pcp_identifier, 
       provider_parent_code, 
       claim_id, 
       member_number, 
       member_name, 
       member_dob, 
       member_zip_code, 
       member_home_phone, 
       member_other_phone, 
       member_sex, 
       member_age_years, 
       eligibility_category, 
       eligibility_demographic, 
       demographic_variable, 
       premium_group, 
       umr_category, 
       sub_umr_category, 
       service_date, 
       effective_period, 
       accounting_period, 
       administrative_fee_amount, 
       avg_wholesale_price, 
       basis_of_cost_of_determination, 
       cost_basis_determination, 
       dispensing_fee, 
       drug_type, 
       formulary_flag, 
       formulary_compliance, 
       generic_filled, 
       home_delivery_code, 
       ingredient_cost, 
       claims_paid_code, 
       pharmacy_class, 
       pharmacy_class_description, 
       prescription_cost, 
       refill_number, 
       prescribed_daily_supply, 
       prescription_filled, 
       prescription_processed, 
       prescription_writen_indicator, 
       specific_therapeutic_class_code, 
       pharmacy_name, 
       topay_amount, 
       prescribed_days_supply, 
       prescribed_days_category, 
       ndc_code_or_id_of_prod_or_svc_provided, 
       prescription_number, 
       pharmacy_id, 
       specialty_rx_claim_indicator, 
       compound_indicator, 
       prescriber_name, 
       pharmacy_npi, 
       pharmacy_phone_number, 
       gpi2_drug_group_desc, 
       gpi0_category, 
       drug_name, 
       gpi8_drug_name_desc, 
       gpi4_drug_class_desc, 
       gpi6_drug_subclass_desc, 
       received_month 
FROM   payor.healthfirst_all_rx_claims 
WHERE  effective_period = '2018-08-01' 
       AND NOT EXISTS (SELECT 1 
                       FROM   payor.healthfirst_somos_all_rx_claims 
                       WHERE  healthfirst_all_rx_claims.pcp_identifier = healthfirst_somos_all_rx_claims.pcp_identifier
                              AND effective_period = '2018-08-01' 
                              AND CASE 
                                    WHEN healthfirst_all_rx_claims.company_number = '01' THEN 
                                      CASE 
                                        WHEN healthfirst_all_rx_claims.eligibility_category = 'HARP' THEN 'HARP'
                                        ELSE 'MCD' 
                                      END 
                                    WHEN healthfirst_all_rx_claims.company_number = '20' THEN 'CHP'
                                    WHEN healthfirst_all_rx_claims.company_number = '30' THEN 'MCR'
                                    WHEN healthfirst_all_rx_claims.company_number = '34' THEN 'MCR DUAL'
                                    WHEN healthfirst_all_rx_claims.company_number = '42' THEN 
                                      CASE 
                                        WHEN healthfirst_all_rx_claims.eligibility_category IN ( 'EP PLAN 1', 'EP PLAN 2', 'EP PLAN 3', 'EP PLAN 4' )
                                      THEN 
                                        'EP' 
                                        ELSE 'QHP' 
                                      END 
                                    ELSE 'other' 
                                  END = CASE 
                                          WHEN healthfirst_somos_all_rx_claims.company_number = '01' THEN
                                            CASE 
                                              WHEN healthfirst_somos_all_rx_claims.eligibility_category = 'HARP' THEN 'HARP'
                                              ELSE 'MCD' 
                                            END 
                                          WHEN healthfirst_somos_all_rx_claims.company_number = '20' THEN 'CHP'
                                          WHEN healthfirst_somos_all_rx_claims.company_number = '30' THEN 'MCR'
                                          WHEN healthfirst_somos_all_rx_claims.company_number = '34' THEN 'MCR DUAL'
                                          WHEN healthfirst_somos_all_rx_claims.company_number = '42' THEN
                                            CASE 
                                              WHEN healthfirst_somos_all_rx_claims.eligibility_category IN (
                                                   'EP PLAN 1', 'EP PLAN 2', 'EP PLAN 3', 'EP PLAN 4' )
                                            THEN 'EP' 
                                              ELSE 'QHP' 
                                            END 
                                          ELSE 'other' 
                                        END) 
$$)
to 's3://sftp_test/healthfirst_evolent/healthfirst_corinthian_pharmacy_2018_08_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

