create temp table if not exists staging_wellcare_census ( 

VARCHAR(255));
grant all on staging_wellcare_census to etluser;
copy staging_wellcare_census from 's3://acp-data/census/wellcare/08222019-CENSUS-NMR-VR9.csv' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 4 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;
delete from payor.wellcare_census where filename = '08222019-CENSUS-NMR-VR9.csv';
insert into payor.wellcare_census (, filename) select , '08222019-CENSUS-NMR-VR9.csv' from staging_wellcare_census;
