SELECT DISTINCT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code,
                prov_npi,
                prov_fullname,
                prov_specialty_1
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       JOIN provider_master
         ON cc_rendering_provider_id = prov_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service between '2018-11-01' and '2019-12-31'
       AND cc_cpt_code IN ( '57170','58300','59430','99501','0503F','G0101' )
       AND pat_delete_ind = 'N'

