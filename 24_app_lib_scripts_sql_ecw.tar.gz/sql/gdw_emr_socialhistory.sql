select top 10000 * from gdw.emr_socialhistory order by random()
