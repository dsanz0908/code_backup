SELECT 'aws s3 cp "s3://acp-data/' 
       || s3_key 
       || '" "s3://sftp_test/20190418_engagement_assignments/' 
       || Replace(Replace(Lower(emr), ' ', '_'), '/', '_') 
       || '/' 
       || a.npi 
       || '/' 
       || Split_part(s3_key, '/', 5) 
       || '"' AS command 
FROM   (SELECT npi, 
               s3_key 
        FROM   (SELECT *, 
                       Row_number() 
                         OVER ( 
                           partition BY Lower(s3_key) 
                           ORDER BY t DESC) AS rn 
                FROM   (SELECT Regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                               'success'                                                                   AS status,
                               timestamp                                                                   AS t,
                               s3_key 
                        FROM   etl_new.success_new 
                        WHERE  timestamp >= '2019-04-01' 
                        UNION 
                        SELECT Regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                               'fail', 
                               timestamp                                                                   AS t,
                               s3_key 
                        FROM   etl_new.fail_new 
                        WHERE  timestamp >= '2019-04-01')) 
        WHERE  rn = 1 
               AND status = 'fail') AS a 
       JOIN etl_new.sneakernet_assignments AS b 
         ON a.npi = b.npi 
UNION 
SELECT 'aws s3 cp "s3://acp-data/' 
       || s3_key 
       || '" "s3://sftp_test/20190418_engagement_assignments/' 
       || 'unknown_emr' 
       || '/' 
       || npi 
       || '/' 
       || Split_part(s3_key, '/', 5) 
       || '"' 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY Lower(s3_key) 
                   ORDER BY t DESC) AS rn 
        FROM   (SELECT Regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                       'success'                                                                   AS status,
                       timestamp                                                                   AS t,
                       s3_key 
                FROM   etl_new.success_new 
                WHERE  timestamp >= '2019-04-01' 
                UNION 
                SELECT Regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                       'fail', 
                       timestamp                                                                   AS t,
                       s3_key 
                FROM   etl_new.fail_new 
                WHERE  timestamp >= '2019-04-01') 
        WHERE  npi NOT IN (SELECT npi 
                           FROM   sneakernet_assignments)) 
WHERE  rn = 1 
       AND status = 'fail' 
