SELECT DISTINCT 'aws s3 cp "s3://acp-data/' 
                || s3_key 
                || '" "s3://sftp_test/20190430_engagement_assignments/' 
                || npi 
                || '/' 
                || Split_part(s3_key, '/', 5) 
                || '"' AS command 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY Split_part(Replace(Lower(s3_key), Split_part(Lower(s3_key), '.', Regexp_count( s3_key,
                 '[.]') + 
                 1), '') 
                 , '/', Regexp_count(Replace(Lower(s3_key), Split_part(Lower(s3_key), '.', Regexp_count(s3_key, '[/]')+1
                 ), ''), 
                 '[/]') 
                 + 1) 
                   ORDER BY t DESC) AS rn 
        FROM   (SELECT Regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                       'success'                                                                   AS status,
                       timestamp                                                                   AS t,
                       s3_key 
                FROM   etl_new.success_new 
                WHERE  timestamp >= '2019-04-26' 
                UNION 
                SELECT Regexp_substr(s3_key, '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') AS npi, 
                       'fail', 
                       timestamp                                                                   AS t,
                       s3_key 
                FROM   etl_new.fail_new 
                WHERE  timestamp >= '2019-04-26')) 
WHERE  rn = 1 
       AND status = 'fail' 
