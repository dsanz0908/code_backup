SELECT DISTINCT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code,
                prov_npi,
                prov_fullname,
                prov_specialty_1
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       JOIN provider_master
         ON cc_rendering_provider_id = prov_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service between '2018-11-01' and '2019-12-31'
       AND cc_cpt_code IN ( '99202','99203','99204','99205','99211','99212','99213','99214','99215','99241','99242','99243','99244','99245','99483','G0463','T1015' )
       AND pat_delete_ind = 'N'

