delete from payor.staging_wellcare_corinthian_caregaps;

copy payor.staging_wellcare_corinthian_caregaps
from 's3://acp-data/Wellcare/SOMOS/WELLCARE-SOMOS-QUALITY_CARE-NMDCHP-201811.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 20
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;

delete from payor.wellcare_somos_all_caregaps where filename = 'WELLCARE-SOMOS-QUALITY_CARE-NMDCHP-201811.csv';
insert into payor.wellcare_somos_all_caregaps (select stg.*, 'WELLCARE-SOMOS-QUALITY_CARE-NMDCHP-201811.csv', '201811' from payor.staging_wellcare_corinthian_caregaps stg)
