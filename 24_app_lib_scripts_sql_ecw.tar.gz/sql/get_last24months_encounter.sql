select distinct enc_patient_id from t_encounter where enc_delete_ind = 'N' and enc_timestamp >= '2017-12-01'
