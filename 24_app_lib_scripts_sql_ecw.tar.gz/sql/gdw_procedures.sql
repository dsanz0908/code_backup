select top 10000 * from gdw.procedures order by random()
