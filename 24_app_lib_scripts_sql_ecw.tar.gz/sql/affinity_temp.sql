drop table if exists staging_affinity;
create temp table if not exists staging_affinity ( 
group_name VARCHAR(255),
pcp_id VARCHAR(255),
provider_npi VARCHAR(255),
pcp_name VARCHAR(255),
pcp_address VARCHAR(255),
member_status VARCHAR(255),
affinity_subscriber_number VARCHAR(255),
cin VARCHAR(255),
lob VARCHAR(255),
last_name VARCHAR(255),
first_name VARCHAR(255),
dob VARCHAR(255),
sex VARCHAR(255),
effective_date VARCHAR(255),
pcp_assgn_date VARCHAR(255),
recertification_date VARCHAR(255),
member_address VARCHAR(255),
member_phone_number VARCHAR(255),
member_email_address VARCHAR(255),
restricted_recipient VARCHAR(255),
health_home VARCHAR(255),
health_home_name VARCHAR(255),
non_user VARCHAR(255),
auto_assigned VARCHAR(255),
harp_eligible VARCHAR(255),
group_tin
VARCHAR(255));
grant all on staging_affinity to etluser;
copy staging_affinity from 's3://acp-data/Affinity/Corinthian/PCPRoster_(CORINTHIPA)_06_01_2019.csv' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;
