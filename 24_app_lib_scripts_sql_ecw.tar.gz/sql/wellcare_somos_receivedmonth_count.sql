select count(*) from payor.wellcare_somos_all_demographics where  receivedmonth = '201905'
