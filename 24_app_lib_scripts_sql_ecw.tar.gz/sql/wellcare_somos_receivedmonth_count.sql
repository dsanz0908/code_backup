select count(*) from payor.wellcare_somos_all_claims where  receivedmonth = '201907'
