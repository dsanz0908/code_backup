select count(*) from payor.wellcare_census where filename = ''
