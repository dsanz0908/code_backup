unload ($$
SELECT DISTINCT orig_member_id                                                 AS member_subscriber_id,
                NULL                                                           AS member_cntrl_num,
                pat_first_name                                                 AS member_fname, 
                pat_last_name                                                  AS member_lname, 
                NULL                                                           AS MEMBER_SSN, 
                NULL                                                           AS MEDICARE_NUM, 
                medicaid_id                                                    AS medicaid_num, 
                To_char(dob, 'YYYYMMDD')                                       AS birthdate, 
                sex, 
                Substring(provider_name, Charindex(',', provider_name) + 1)    AS provider_fname,
                Substring(provider_name, 1, Charindex(',', provider_name) - 1) AS provider_lname,
                provider_npi, 
                CASE 
                  WHEN provider_speciality = 'Licensed Clinical Social Worker' THEN 'BHC' 
                  WHEN provider_speciality = 'Cardiology' THEN 'CARD' 
                  WHEN provider_speciality = 'Oral Surgery (dental only)' THEN 'DENT' 
                  WHEN provider_speciality = 'Endocrinology' THEN 'ENDOC' 
                  WHEN provider_speciality = 'Emergency Medicine' THEN 'ER' 
                  WHEN provider_speciality = 'Family Practice' THEN 'FP' 
                  WHEN provider_speciality = 'Multi-Specialty Clinic or Group Practice' THEN 'FQHC' 
                  WHEN provider_speciality = 'Gastroenterology' THEN 'GASTRO' 
                  WHEN provider_speciality = 'Geriatric Medicine' THEN 'GERIAT' 
                  WHEN provider_speciality = 'General Practice' THEN 'GP' 
                  WHEN provider_speciality = 'Gynecology/Oncology' THEN 'GYNONC' 
                  WHEN provider_speciality = 'Internal Medicine' THEN 'IM' 
                  WHEN provider_speciality = 'Laboratory Pathology Testing' THEN 'LAB' 
                  WHEN provider_speciality = 'Nurse Midwife Certified' THEN 'MDWIFE' 
                  WHEN provider_speciality = 'Nephrology' THEN 'NEPHRO' 
                  WHEN provider_speciality = 'Nurse Practitioner' THEN 'NPR' 
                  WHEN provider_speciality = 'Registered Dietitian/Nutrition Professional' THEN 'NUTRI'
                  WHEN provider_speciality = 'Obstetrics Gynecology' THEN 'OB/GYN' 
                  WHEN provider_speciality = 'Ophthalmology' THEN 'OPHTH' 
                  WHEN provider_speciality = 'Optometry' THEN 'OPTOM' 
                  WHEN provider_speciality = 'Physician Assistant' THEN 'PA' 
                  WHEN provider_speciality = 'pediatrics' THEN 'PED' 
                  WHEN provider_speciality = 'Preventive Medicine' THEN 'PRVMED' 
                  WHEN provider_speciality = 'Psychologist' THEN 'PSY' 
                  WHEN provider_speciality = 'Psychiatry' THEN 'PSYCH' 
                  WHEN provider_speciality = 'Addiction Medicine' THEN 'SUBST' 
                  ELSE NULL 
                END                                                            AS provider_speciality,
                To_char(vitals_date, 'YYYYMMDD')                               AS service_date,
                11                                                             AS place_of_service,
                'BPL'                                                          AS SERVICE_PERFORMED,
                vitals_systolic 
                || '/' 
                || vitals_diastolic                                            AS SERVICE_RESULT,
                icd10_code                                                     AS DIAGNOSIS1, 
                icd10_code_1                                                   AS DIAGNOSIS2, 
                icd10_code_2                                                   AS DIAGNOSIS3, 
                icd10_code_3                                                   AS DIAGNOSIS4, 
                icd10_code_4                                                   AS DIAGNOSIS5, 
                icd10_code_5                                                   AS DIAGNOSIS6, 
                icd10_code_6                                                   AS DIAGNOSIS7, 
                icd10_code_7                                                   AS DIAGNOSIS8, 
                icd10_code_8                                                   AS DIAGNOSIS9, 
                icd10_code_9                                                   AS DIAGNOSIS10, 
                NULL                                                           AS DIAGNOSIS11, 
                NULL                                                           AS DIAGNOSIS12, 
                NULL                                                           AS DIAGNOSIS13, 
                NULL                                                           AS DIAGNOSIS14, 
                NULL                                                           AS DIAGNOSIS15, 
                NULL                                                           AS DIAGNOSIS16, 
                NULL                                                           AS DIAGNOSIS17, 
                NULL                                                           AS DIAGNOSIS18, 
                NULL                                                           AS DIAGNOSIS19, 
                NULL                                                           AS DIAGNOSIS20, 
                NULL                                                           AS DIAGNOSIS21, 
                NULL                                                           AS DIAGNOSIS22, 
                NULL                                                           AS DIAGNOSIS23, 
                NULL                                                           AS DIAGNOSIS24, 
                NULL                                                           AS DIAGNOSIS25, 
                'Y'                                                            AS ICD10_IND 
FROM   cbp_reporting_new 
WHERE  mco = 'WellCare' 
       AND vitals_systolic IS NOT NULL 
       AND vitals_diastolic IS NOT NULL 
$$)
TO 's3://acp-data/CBP/cbp_reporting_wellcare_TODAY_' delimiter '|' gzip parallel OFF allowoverwrite iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

