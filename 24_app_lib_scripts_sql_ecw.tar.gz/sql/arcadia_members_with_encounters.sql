WITH cte_1 
     AS (SELECT pat_id, pat_first_name, pat_last_name,
                         cast(pat_date_of_birth as date) as b, cast(max(enc_timestamp) as date) as last_enc
         FROM   t_encounter 
                JOIN t_patient 
                  ON enc_patient_id = pat_id 
         WHERE  enc_delete_ind = 'N' 
                AND pat_delete_ind = 'N' group by 
                pat_id, pat_first_name, pat_last_name, cast(pat_date_of_birth as date)         ) 
SELECT * 
FROM   cte_1 
