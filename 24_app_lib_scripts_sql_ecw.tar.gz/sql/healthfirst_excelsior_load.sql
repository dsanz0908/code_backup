copy payor.staging_healthfirst_somos_claims
from 's3://acp-data/Healthfirst/Excelsior/ANA07601_Excelsior_JAN2019_DTL_CLAIM.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.staging_healthfirst_somos_eligibility;
copy payor.staging_healthfirst_somos_eligibility
from 's3://acp-data/Healthfirst/Excelsior/ANA07801_Excelsior_JAN2019_DTL_ELIGIBILITY.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.staging_healthfirst_somos_rx_claims;
copy payor.staging_healthfirst_excelsior_rx_claims
from 's3://acp-data/Healthfirst/Excelsior/ANA07701_Excelsior_JAN2019_DTL_PHARMACY_1.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.healthfirst_all_claims where filename = 'ANA07601_Excelsior_JAN2019_DTL_CLAIM.txt';
insert into payor.healthfirst_all_claims (select * , '201901', 'ANA07601_Excelsior_JAN2019_DTL_CLAIM.txt', getdate() from payor.staging_healthfirst_somos_claims); 
delete from payor.healthfirst_all_rx_claims where filename = 'ANA07701_Excelsior_JAN2019_DTL_PHARMACY.txt';
--insert into payor.healthfirst_all_rx_claims (select * , '201901', 'ANA07701_Excelsior_JAN2019_DTL_PHARMACY.txt', getdate() from payor.staging_healthfirst_excelsior_rx_claims);
insert into payor.healthfirst_all_rx_claims (select 
cycle_date,
record_source,
line_of_business,
company_number,
network,
members_hospital,
hospital_name,
pcp_name,
pcp_npi,
pcp_identifier,
provider_parent_code,
claim_id,
member_number,
member_name,
member_dob,
member_zip_code,
member_home_phone,
member_other_phone,
member_sex,
member_age_years,
eligibility_category,
eligibility_demographic,
demographic_variable,
premium_group,
umr_category,
sub_umr_category,
service_date,
effective_period,
accounting_period,
administrative_fee_amount,
avg_wholesale_price,
basis_of_cost_of_determination,
cost_basis_determination,
dispensing_fee,
drug_type,
formulary_flag,
formulary_compliance,
generic_filled,
home_delivery_code,
ingredient_cost,
claims_paid_code,
pharmacy_class,
pharmacy_class_description,
prescription_cost,
refill_number,
prescribed_daily_supply,
prescription_filled,
prescription_processed,
prescription_writen_indicator,
specific_therapeutic_class_code,
pharmacy_name,
topay_amount,
prescribed_days_supply,
prescribed_days_category,
ndc_code_or_id_of_prod_or_svc_provided,
prescription_number,
pharmacy_id,
specialty_rx_claim_indicator,
compound_indicator,
prescriber_name,
pharmacy_npi,
pharmacy_phone_number,
gpi2_drug_group_desc,
gpi0_category,
drug_name,
gpi8_drug_name_desc,
gpi4_drug_class_desc,
gpi6_drug_subclass_desc,
'201901', 
transaction_id,
'ANA07701_Excelsior_JAN2019_DTL_PHARMACY.txt', getdate() from payor.staging_healthfirst_somos_rx_claims);
delete from payor.healthfirst_all_eligibility where filename = 'ANA07801_Excelsior_JAN2019_DTL_ELIGIBILITY.txt';
insert into payor.healthfirst_all_eligibility (select
company_number,
product,
porg,
hospital_name,
provider_id,
members_physician_name,
pcp_address1,
pcp_address2,
pcp_city,
pcp_state,
pcp_zip,
Case when trim(effective_period) = ''   then NULL else  CAST ( effective_period AS date ) end ,
Case when trim(member_month) = ''   then NULL else  CAST ( member_month AS real ) end ,
eligibility_category,
eligibility_cat_w_demographic,
premium_group,
Case when trim(members_sex) = ''   then NULL else  CAST ( members_sex AS character(1) ) end ,
member_id,
member_name,
birth_date,
address1,
address2,
member_city,
member_state,
member_zip,
medicare_patient_id,
mcaid,
ratype,
member_last_name,
member_first_name,
national_provider_id,
provider_tin,
member_home_phone,
member_other_phone,
member_email,
provider_parent_code,
Case when trim(pcp_effective_date) = ''   then NULL else  CAST ( pcp_effective_date AS date ) end ,
Case when trim(pcp_expiration_date) = ''   then NULL else  CAST ( pcp_expiration_date AS date ) end ,
outreach_enrollment_code,
health_home_name,
medicaid_id,
premium_group_description,
'201901',
'ANA07801_Excelsior_JAN2019_DTL_ELIGIBILITY.txt',
getdate()
 from payor.staging_healthfirst_somos_eligibility );
