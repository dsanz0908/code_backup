select distinct pat_first_name,
                pat_last_name,
                dob,
                cast(cc_date_of_service as date) as dos,
                cc_cpt_code, cc_dx_id_1 from 
(SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code, cc_dx_id_1, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by cc_date_of_service desc) as rn
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service between '2019-01-01' and '2019-12-31'
       AND cc_cpt_code IN ( '99201','99202','99203','99204','99205','99211','99212','99213','99214','99215','99241','99242','99243','99244','99245','99341','99342','99343','99344','99345','99347','99348','99349','99350','99381','99382','99383','99384','99385','99386','99387','99391','99392','99393','99394','99395','99396','99397','99401','99402','99403','99404','99411','99412','99420','99429','G0402','G0438','G0439','G0463','T1015' )
       AND pat_delete_ind = 'N') as t1 where rn = 1
