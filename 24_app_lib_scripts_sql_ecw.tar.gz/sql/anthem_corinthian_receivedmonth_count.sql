select count(*) from payor.empire_bcbs_healthplus_legacy_all_roster_oldformat where received_month = '201904'
