select count(*) from payor.anthem_corinthian_all_rosters where received_month = '201905'
