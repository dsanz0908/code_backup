create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

create temp table direct_match (
pat_id varchar(255),
pat_first_name varchar(255),
pat_last_name varchar(255),
pat_date_of_birth varchar(255),
policy_nbr varchar(255),
payer varchar(255));

copy direct_match
from 's3://sftp_test/pat_cin_match_direct.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
IGNOREBLANKLINES
MAXERROR 100
removequotes
region 'us-east-1'
dateformat 'auto'
delimiter  ',';


drop table if exists arcadia_padding;
create temp table arcadia_padding (
pat_id varchar(255),
dos date,
pat_original_id varchar(255),
pat_medical_record_number varchar(255),
site_emr_name varchar(255),
pat_race varchar(255),
pat_language varchar(255),
pat_ssn varchar(255),
pat_ethnicity varchar(255),
site_center_name varchar(255),
enc_original_id varchar(255),
site_id varchar(255),
enc_type_description varchar(255),
enc_reason varchar(255),
vitals_height varchar(255),
vitals_height_unit varchar(255),
vitals_weight varchar(255),
vitals_weight_unit varchar(255),
vitals_bmi varchar(255),
vitals_bmi_unit varchar(255),
vitals_systolic varchar(255),
vitals_systolic_unit varchar(255),
vitals_diastolic varchar(255),
vitals_diastolic_unit varchar(255),
vitals_temperature varchar(255),
vitals_temperature_units varchar(255),
vitals_heart_rate varchar(255),
vitals_heart_rate_unit varchar(255),
vitals_spo2 varchar(255),
vitals_spo2_unit varchar(255)
);

copy arcadia_padding
from 's3://sftp_test/temp_hl7_padding.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
removequotes
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

set statement_timeout to 0;

with cte_a as (select distinct policy_nbr, arcadia_padding.* from arcadia_padding INNER JOIN (SELECT pat_id,
                          policy_nbr
                   FROM   direct_match
                   UNION
                   SELECT arcadia_pat_id,
                          mco_cin
                   FROM   fuzz_test) as a
               ON arcadia_padding.pat_id = a.pat_id),
cte_members
     AS (SELECT DISTINCT dim_membership.local_member_id
         FROM   fact_eligibility
                JOIN dim_membership
                  ON fact_eligibility.local_member_id = dim_membership.local_member_id
                JOIN dim_provider
                  ON dim_provider.local_provider_id = fact_eligibility.local_provider_id
         WHERE  fact_eligibility.source LIKE 'Healthfirst%'
                AND dim_provider.provider_npi IN ( '1003911132', '1033437827', '1063673499', '1083071948',
                                                   '1093913642', '1154481885', '1184730707', '1184793846',
                                                   '1194244962', '1205918679', '1215107735', '1285642694',
                                                   '1285678169', '1295796464', '1306073291', '1306884408',
                                                   '1306927579', '1366753410', '1376610436', '1386605566',
                                                   '1427050970', '1467534131', '1487673380', '1528500808',
                                                   '1538320494', '1558357970', '1558575514', '1609812528',
                                                   '1639595192', '1649386145', '1720227226', '1760424543',
                                                   '1760678197', '1790707263', '1851404925', '1851454557',
                                                   '1881917748', '1902982739', '1912164849', '1912961616',
                                                   '1942257613', '1942358528', '1962408880', '1962408880',
                                                   '1982601191', '1982761375', '1255484440' ))
SELECT DISTINCT member_last_name,
                member_first_name,
                To_date(member_dob, '%Y%m%d') AS dob,
                member_sex,
                member_address_1,
                member_city,
                member_state,
                member_zip,
                member_home_phone,
                practice_name,
                provider_last_name,
                provider_first_name,
                provider_taxonomies,
                service_start_date,
                discharge_date,
                code,
                code_description,
                is_primary_ind,                cte_a.*
FROM   fact_claims
       JOIN dim_provider
         ON dim_provider.local_provider_id = fact_claims.local_pcp_provider_id
       JOIN dim_membership
         ON fact_claims.local_member_id = dim_membership.local_member_id
       JOIN dim_provider_org_detail
         ON dim_provider_org_detail.local_provider_org_id = fact_claims.local_service_org_id
       JOIN fact_claims_code_details
         ON fact_claims_code_details.claim_id = fact_claims.claim_id
            AND fact_claims_code_details.claim_line_no = fact_claims.claim_line_no
       JOIN dim_codes
         ON dim_codes.local_code_id = fact_claims_code_details.local_code_id
       LEFT JOIN cte_a on policy_nbr = member_cin
WHERE  code_type = 'ICD'
       AND Date_part(year, service_start_date) = 2019;

