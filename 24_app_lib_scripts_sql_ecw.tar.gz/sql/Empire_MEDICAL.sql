create temp table if not exists staging_empire_somos ( 
Claim_number VARCHAR(255),
Claim_Line_Number VARCHAR(255),
PRODUCT VARCHAR(255),
Rendering_Provider VARCHAR(255),
NPI VARCHAR(255),
Rendering_Specialty VARCHAR(255),
EMPRIE_MEMBER_ID VARCHAR(255),
Member_Medicaid_ID VARCHAR(255),
Member_Last_Name VARCHAR(255),
Member_First_Name VARCHAR(255),
GEND_DESC VARCHAR(255),
LANG_DESC VARCHAR(255),
RACE_ETHN_DESC VARCHAR(255),
Member_DOB VARCHAR(255),
Claim_Form_Type VARCHAR(255),
BILL_TYPE VARCHAR(255),
PLACE_OF_SERVICE VARCHAR(255),
DRG VARCHAR(255),
DRG_SEVERITY VARCHAR(255),
DRG_TYPE_NM VARCHAR(255),
ADMIT_TYPE VARCHAR(255),
REVENUE_CODE VARCHAR(255),
Primary_Diagnosis VARCHAR(255),
Secondary_Diagnosis VARCHAR(255),
Tertiary_Diagnosis VARCHAR(255),
Quaternary_Diagnosis VARCHAR(255),
PROCEDURE_CODE VARCHAR(255),
MODIFIER_1 VARCHAR(255),
MODIFIER_2 VARCHAR(255),
MODIFIER_3 VARCHAR(255),
MODIFIER_4 VARCHAR(255),
Claim_Line_Start_Date VARCHAR(255),
Claim_Line_End_Date VARCHAR(255),
PCP_TAX_ID VARCHAR(255),
PCP_Name VARCHAR(255),
PCP_NPI VARCHAR(255),
PCP_Empire_ID VARCHAR(255),
Claim_Line_Paid_Amt VARCHAR(255));
grant all on staging_empire_somos to etluser;
copy staging_empire_somos from 's3://acp-data/Empire/Somos/Empire_BCBS_HealthPlus_MEDICAL_CLM_SOMOS_201701_201901.TXT_1' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' delimiter ' ' NULL as 'NULL' dateformat 'auto' REMOVEQUOTES;
delete from  where filename = 'Empire_BCBS_HealthPlus_MEDICAL_CLM_SOMOS_201701_201901.TXT_1';
insert into  ( 
)
select 
from staging_empire_somos;
