unload ($$
SELECT * 
FROM   bronx_rhio_enriched_cen 
WHERE  filename = 'BxRHIO_to_ACP_12.26.2019.csv'
$$)
to 's3://acp-evolent/ToEvolent/RHIO/BxRHIO_to_ACP_12.26.2019_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

