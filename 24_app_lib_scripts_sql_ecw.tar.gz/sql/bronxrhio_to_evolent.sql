unload ($$
SELECT * 
FROM   bronx_rhio_enriched_cen 
WHERE  filename = 'BxRHIO_to_ACP_03.26.2020.csv'
$$)
to 's3://acp-evolent/ToEvolent/RHIO/BxRHIO_to_ACP_03.26.2020_'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

