SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE) dob, 
                cc_date_of_service, 
                cc_cpt_code, 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   t_chargecapture 
       JOIN t_patient 
         ON cc_patient_id = pat_id 
       JOIN provider_master 
         ON cc_rendering_provider_id = prov_id 
WHERE  cc_delete_ind = 'N' 
       AND cc_date_of_service >= '2019-01-01' 
       AND cc_cpt_code IN ( '80047', '80048', '80050', '80053', 
                            '80069', '82947', '82950', '82951', 
                            '83036', '83037', '3044F', '3045F', '3046F' ) 
       AND pat_date_of_birth BETWEEN '1955-01-01' AND '2001-12-31' 
       AND pat_delete_ind = 'N' 
UNION 
SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE), 
                collection_date, 
                '80047', 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   t_result 
       JOIN t_patient 
         ON t_patient.pat_id = t_result.pat_id 
       JOIN provider_master 
         ON provider_id = prov_id 
WHERE  delete_ind = 'N' 
       AND collection_date >= '2019-01-01' 
       AND pat_date_of_birth BETWEEN '1955-01-01' AND '2001-12-31' 
       AND pat_delete_ind = 'N' 
       AND ( original_name LIKE '%mammogram%' 
              OR result_value LIKE '%mammogram%' ) 
UNION 
SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE), 
                result_received_date, 
                '77057', 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   t_order 
       JOIN t_patient 
         ON t_patient.pat_id = t_order.pat_id 
       JOIN provider_master 
         ON ordering_provider_id = prov_id 
WHERE  delete_ind = 'N' 
       AND result_received_date >= '2019-01-01' 
       AND pat_date_of_birth BETWEEN '1955-01-01' AND '2001-12-31' 
       AND pat_delete_ind = 'N' 
       AND ( order_name LIKE '%glucose test%' 
              OR order_notes LIKE '%glucose test%' 
              OR order_category LIKE '%glucose test%' 
              OR order_name LIKE '%hba1c%' 
              OR order_notes LIKE '%hba1c%' 
              OR order_category LIKE '%hba1c%' 
              OR cpt_code IN ( '80047', '80048', '80050', '80053', 
                               '80069', '82947', '82950', '82951', 
                               '83036', '83037', '3044F', '3045F', '3046F' ) ) 
