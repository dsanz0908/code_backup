WITH a 
     AS (SELECT DISTINCT member_number 
         FROM   payor.healthfirst_all_claims 
         UNION 
         SELECT DISTINCT member_number 
         FROM   payor.healthfirst_somos_all_claims), 
     b 
     AS (SELECT member_id 
         FROM   (SELECT Lower(member_name)                AS NAME, 
                        member_dob, 
                        member_id, 
                        Row_number() 
                          OVER ( 
                            partition BY member_id 
                            ORDER BY received_month DESC) AS rn 
                 FROM   payor.healthfirst_all_eligibility 
                 WHERE  effective_period = (SELECT Max(effective_period) 
                                            FROM   payor.healthfirst_all_eligibility) 
                        AND NOT EXISTS (SELECT 1 
                                        FROM   a 
                                        WHERE  member_id = member_number)) 
         WHERE  rn = 1 
         UNION 
         SELECT member_id 
         FROM   (SELECT Lower(member_name)                AS NAME, 
                        member_dob, 
                        member_id, 
                        Row_number() 
                          OVER ( 
                            partition BY member_id 
                            ORDER BY received_month DESC) AS rn 
                 FROM   payor.healthfirst_somos_all_eligibility 
                 WHERE  effective_period = (SELECT Max(effective_period) 
                                            FROM   payor.healthfirst_somos_all_eligibility) 
                        AND NOT EXISTS (SELECT 1 
                                        FROM   a 
                                        WHERE  member_id = member_number)) 
         WHERE  rn = 1), 
     c 
     AS (SELECT *, 
                Row_number() 
                  OVER ( 
                    partition BY member_id 
                    ORDER BY received_month DESC) AS rn 
         FROM   payor.healthfirst_all_eligibility 
         WHERE  effective_period = '2019-12-01' 
                AND EXISTS (SELECT 1 
                            FROM   b 
                            WHERE  b.member_id = healthfirst_all_eligibility.member_id) 
                AND NOT EXISTS (SELECT 1 
                                FROM   cins 
                                WHERE  cin = member_id) 
         UNION 
         SELECT *, 
                Row_number() 
                  OVER ( 
                    partition BY member_id 
                    ORDER BY received_month DESC) AS rn 
         FROM   payor.healthfirst_somos_all_eligibility 
         WHERE  effective_period = '2019-12-01' 
                AND EXISTS (SELECT 1 
                            FROM   b 
                            WHERE  b.member_id = healthfirst_somos_all_eligibility.member_id) 
                AND NOT EXISTS (SELECT 1 
                                FROM   cins 
                                WHERE  cin = member_id)) 
SELECT DISTINCT product, 
                eligibility_category, 
                provider_id, 
                pcp_name, 
                pcp_address1, 
                pcp_address2, 
                pcp_city, 
                pcp_state, 
                pcp_zip, 
                member_sex, 
                member_id, 
                member_name, 
                member_dob, 
                member_address_1, 
                member_address_2, 
                member_city, 
                member_state, 
                member_zip, 
                medicare_patient_id, 
                provider_npi, 
                provider_tin, 
                member_home_phone, 
                member_other_phone, 
                member_email, 
                provider_parent_code AS ipa, 
                medicaid_id 
FROM   c 
WHERE  rn = 1 
ORDER  BY member_name, 
          member_dob 
