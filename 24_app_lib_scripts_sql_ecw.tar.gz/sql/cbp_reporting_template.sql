delete from cbp_reporting_new;
copy cbp_reporting_new
from 's3://acp-data/CBP/arcadia_cbp_TODAY.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
NULL AS 'NULL'
delimiter '|'
escape;
