copy public.optimus_healthfirst_optimus_healthfirst
from 's3://acp-data/OPTIMUS_HF_Tables/optimus_healthfirst.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto'
REMOVEQUOTES;
