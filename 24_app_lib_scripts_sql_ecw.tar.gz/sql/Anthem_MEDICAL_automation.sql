select ' ' || tgt_column_name || ',' from mco_file_to_table_mapping
where mco_name = 'Anthem_Corinthian' and file_type = 'claims'
order by column_order;
