select distinct pat_first_name,
                pat_last_name,
                dob,
                cast(cc_date_of_service as date) as dos,
                cc_cpt_code from 
(SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by cc_date_of_service desc) as rn
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service between '2019-01-01' and '2019-12-31'
       AND cc_cpt_code IN ( '2022F', '2024F', '2026F', '3072F' )
       AND pat_delete_ind = 'N') as t1 where rn = 1
