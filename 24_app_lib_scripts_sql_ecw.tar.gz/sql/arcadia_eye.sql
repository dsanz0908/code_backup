select distinct pat_first_name,
                pat_last_name,
                dob,
                cast(cc_date_of_service as date) as dos,
                cc_cpt_code, cc_dx_id_1 from 
(SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                cc_date_of_service,
                cc_cpt_code, cc_dx_id_1, row_number() over (partition by pat_first_name, pat_last_name, pat_date_of_birth order by cc_date_of_service desc) as rn
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
WHERE  cc_delete_ind = 'N'
       AND cc_date_of_service between '2019-01-01' and '2019-12-31'
       AND cc_cpt_code IN ( '67028','67030','67031','67036','67039','67040','67041','67042','67043','67101','67105','67107','67108','67110','67113','67121','67141','67145','67208','67210','67218','67220','67221','67227','67228','92002','92004','92012','92014','92018','92019','92134','92225','92226','92227','92228','92230','92235','92240','92250','92260','99203','99204','99205','99213','99214','99215','99242','99243','99244','99245','2022F','2024F','2026F','3072F','S0620','S0621','S3000' )
       AND pat_delete_ind = 'N') as t1 where rn = 1
