copy payor.TABLENAME
from 's3://acp-data/OPTIMUS_2018-07-10/FILENAME'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter ' '
dateformat 'auto'
REMOVEQUOTES;
