unload ($$ select company_number,product,provider_org,hospital_name,provider_id,pcp_name,pcp_address1,pcp_address2,pcp_city,pcp_state,
pcp_zip,effective_period,member_month,eligibility_category,eligibility_cat_w_demographic,premium_group,member_sex,member_id,
member_name,member_dob,member_address_1,member_address_2,member_city,member_state,member_zip,medicare_patient_id,mcaid,ratype,
member_last_name,member_first_name,provider_npi,provider_tin,member_home_phone,member_other_phone,member_email,provider_parent_code,
pcp_effective_date,pcp_expiration_date,outreach_enrollment_code,health_home_name,medicaid_id,premium_group_description
from payor.healthfirst_all_eligibility
where received_month = 'MNTH'
and not exists ( select 1 from payor.healthfirst_somos_all_eligibility s where a.effective_period = s.effective_period and a.provider_id = s.provider_id )
$$)
to 's3://acp-data/Arcadia/Outgoing/healthfirst/healthfirst_corinthian_eligibility_SEPMNTH_'
delimiter '|'
gzip
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
