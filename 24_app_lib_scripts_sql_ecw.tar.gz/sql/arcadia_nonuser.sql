SELECT pat_first_name, 
       pat_last_name, 
       Cast(pat_date_of_birth AS DATE)  AS b, 
       Cast(Max(cc_date_of_service) AS DATE) AS last_enc, 
       Max(cc_cpt_code) 
FROM   t_chargecapture
       JOIN t_patient 
         ON cc_patient_id = pat_id 
WHERE  cc_delete_ind = 'N' 
       AND pat_delete_ind = 'N' 
GROUP  BY pat_id, 
          pat_first_name, 
          pat_last_name, 
          Cast(pat_date_of_birth AS DATE) 
