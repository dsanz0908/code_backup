SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(receivedmonth), 'YYYYMM')) AS INT) FROM payor.wellcare_somos_all_demographics
