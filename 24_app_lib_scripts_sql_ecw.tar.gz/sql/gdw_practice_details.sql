select top 10000 * from gdw.practice_details order by random()
