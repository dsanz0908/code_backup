select distinct patient_id, icd10_code from t_assessment where delete_ind = 'N' and year(assessment_date) = 2019 and icd10_code is not null
