select top 10000 * from gdw.claims order by random()
