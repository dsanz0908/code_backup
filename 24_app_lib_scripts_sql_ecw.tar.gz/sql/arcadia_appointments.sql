SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                pat_date_of_birth,
                appt_date
FROM   t_appointment 
       JOIN t_patient 
         ON appt_patient_id = pat_id 
WHERE  appt_delete_ind = 'N' 
       AND pat_delete_ind = 'N' 
       AND appt_date >= '20180101' 
