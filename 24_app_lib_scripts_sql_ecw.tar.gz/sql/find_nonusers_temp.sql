WITH members 
     AS (SELECT local_member_id 
         FROM   fact_claims 
         WHERE  service_start_date >= '2018-08-01' 
                AND local_service_provider_id = local_pcp_provider_id and local_place_of_service_id = 5), 
     no_claim_members 
     AS (SELECT dim_membership.* 
         FROM   fact_eligibility 
                JOIN dim_membership 
                  ON fact_eligibility.local_member_id = dim_membership.local_member_id 
         WHERE  NOT EXISTS (SELECT 1 
                            FROM   members 
                            WHERE  fact_eligibility.local_member_id = members.local_member_id) 
                AND effective_date >= '2018-08-01'), 
     cte_match_ids 
     AS (SELECT pat_id, 
                Max(CASE 
                      WHEN rn = 1 THEN mco_cin 
                    END) AS id_1, 
                Max(CASE 
                      WHEN rn = 2 THEN mco_cin 
                    END) AS id_2, 
                Max(CASE 
                      WHEN rn = 3 THEN mco_cin 
                    END) AS id_3 
         FROM   (SELECT a.*, 
                        Row_number() 
                          OVER ( 
                            partition BY pat_id 
                            ORDER BY mco_cin) AS rn 
                 FROM   (SELECT DISTINCT pat_id, 
                                         mco_cin 
                         FROM   staging_arcadia_procedures AS a 
                                JOIN fuzz_test 
                                  ON pat_id = arcadia_pat_id 
                         WHERE  mco_source LIKE 'Healthfirst%' 
                                 OR mco_source LIKE 'WellCare%') AS a) 
         GROUP  BY 1), 
     cte_cdw_hf 
     AS (SELECT DISTINCT healthfirst_src_member_id AS member_id 
         FROM   no_claim_members 
         UNION 
         SELECT DISTINCT member_cin 
         FROM   no_claim_members 
         UNION 
         SELECT DISTINCT wellcare_src_member_id 
         FROM   no_claim_members)       
SELECT *
FROM   cte_cdw_hf 
WHERE  NOT EXISTS (SELECT 1 
                   FROM   cte_match_ids 
                   WHERE  cte_cdw_hf.member_id = id_1 
                           OR cte_cdw_hf.member_id = id_2 
                           OR cte_cdw_hf.member_id = id_3) */
                           

