delete from staging_optimus_healthfirst_claims;
copy public.staging_optimus_healthfirst_claims
from 's3://acp-data/OPTIMUS_HF_Tables/Claims_RECEIVEDMONTH.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';

delete from optimus_healthfirst_all_claims where filename = 'Claims_RECEIVEDMONTH.txt';

insert into optimus_healthfirst_all_claims (select
hicnumber,
providerid,
claimnumber,
claimreceiveddate,
primaryservice,
place_of_service,
first_posted_date,
paiddate,
paidamount,
paystatus,
tin,
cpt_code,
i_o_p,
admitdiagnosiscode,
icd9_code1,
icd9_code2,
icd9_code3,
icd9_code4,
icd9_code5,
icd9_code6,
icd9_code7,
icd9_code8,
icd9_code9,
icd9_code10,
icd9_code11,
icd9_code12,
icd9_code13,
icd9_code14,
icd9_code15,
icd9_code16,
icd9_code17,
icd9_code18,
specialtycode,
planmemberid,
diagnosistype,
claimstatus,
'Claims_RECEIVEDMONTH.txt',
getdate(), 
case when trim(first_date_of_service) = '' then NULL else cast(first_date_of_service as date) end,
case when trim(last_date_of_service) = '' then NULL else cast(last_date_of_service as date) end
from public.staging_optimus_healthfirst_claims);

delete from staging_optimus_healthfirst_cmsmmr;
copy public.staging_optimus_healthfirst_cmsmmr
from 's3://acp-data/OPTIMUS_HF_Tables/CMSMMR_RECEIVEDMONTH.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_cmsmmr where filename = 'CMSMMR_RECEIVEDMONTH.txt';
insert into optimus_healthfirst_all_cmsmmr (select *, 'CMSMMR_RECEIVEDMONTH.txt', getdate() from staging_optimus_healthfirst_cmsmmr);



delete from staging_optimus_healthfirst_cmsraps;
copy public.staging_optimus_healthfirst_cmsraps
from 's3://acp-data/OPTIMUS_HF_Tables/CMSRAPS_RECEIVEDMONTH.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_cmsraps where filename = 'CMSRAPS_RECEIVEDMONTH.txt';
insert into optimus_healthfirst_all_cmsraps (select *, 'CMSRAPS_RECEIVEDMONTH.txt', getdate() from staging_optimus_healthfirst_cmsraps);


delete from staging_optimus_healthfirst_member;
copy public.staging_optimus_healthfirst_member
from 's3://acp-data/OPTIMUS_HF_Tables/member_RECEIVEDMONTH.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_member where filename = 'member_RECEIVEDMONTH.txt';
insert into optimus_healthfirst_all_member (select *, 'member_RECEIVEDMONTH.txt', getdate() from staging_optimus_healthfirst_member);


delete from staging_optimus_healthfirst_pharma;
copy public.staging_optimus_healthfirst_pharma
from 's3://acp-data/OPTIMUS_HF_Tables/Pharma_RECEIVEDMONTH.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_pharma where filename = 'Pharma_RECEIVEDMONTH.txt';
insert into optimus_healthfirst_all_pharma (select *, 'Pharma_RECEIVEDMONTH.txt', getdate() from staging_optimus_healthfirst_pharma);



delete from staging_optimus_healthfirst_provider;
copy public.staging_optimus_healthfirst_provider
from 's3://acp-data/OPTIMUS_HF_Tables/Provider_RECEIVEDMONTH.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
region 'us-east-1'
delimiter '\t'
dateformat 'auto';
delete from optimus_healthfirst_all_provider where filename = 'Provider_RECEIVEDMONTH.txt';
insert into optimus_healthfirst_all_provider (select *, 'Provider_RECEIVEDMONTH.txt', getdate() from staging_optimus_healthfirst_provider);

