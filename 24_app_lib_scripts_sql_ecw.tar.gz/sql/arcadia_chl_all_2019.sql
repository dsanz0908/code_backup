SELECT DISTINCT t_result.pat_id, 
                Cast(collection_date AS DATE), 
                result_value 
FROM   t_result 
       JOIN t_patient 
         ON t_result.pat_id = t_patient.pat_id 
WHERE  ( original_name LIKE '%chlamydia%' 
          OR lab_type LIKE '%chlamydia%' ) 
       AND delete_ind = 'N' 
       AND Year(collection_date) = 2019 
       AND Datediff(year, pat_date_of_birth, Getdate()) BETWEEN 16 AND 24 
