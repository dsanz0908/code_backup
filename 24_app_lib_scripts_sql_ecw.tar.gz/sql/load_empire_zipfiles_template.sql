delete from payor.empire_TABLE_NAME where received_month = 'RECEIVED_MONTH' or received_month = '';
copy payor.empire_TABLE_NAME
from 's3://acp-data/Anthem/Somos/FILENAME'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
fillrecord
region 'us-east-1'
dateformat 'auto'
delimiter '|';

update payor.empire_TABLE_NAME set received_month = 'RECEIVED_MONTH' where received_month = '';
update payor.empire_TABLE_NAME set file_name = 'FILENAME' where file_name = '';
update payor.empire_TABLE_NAME set added_tz = getdate() where added_tz is null;

