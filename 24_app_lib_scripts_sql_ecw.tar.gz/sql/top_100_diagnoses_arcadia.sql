SELECT pat_id, 
       Sum(CASE 
             WHEN icd10_code = 'E11.65' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E78.1' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E78.2' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'F41.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'G47.00' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'H04.123' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'I10' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'J06.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'K59.00' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M17.0' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M25.511' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M25.562' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M54.16' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M54.5' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M81.0' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'N18.3' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R00.2' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R06.02' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R21' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R94.31' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z00.00' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z00.121' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z00.129' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z02.1' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z02.89' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z09' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z12.4' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z13.1' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z13.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.23' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.29' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.32' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z71.3' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z71.41' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z79.82' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'D64.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E03.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E55.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E78.00' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E78.4' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E78.5' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'I11.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'J45.909' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'K21.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'L85.3' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M25.569' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R05' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R42' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R51' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R53.83' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z01.419' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z11.3' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z11.4' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z13.89' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z23' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.24' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.25' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.27' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.31' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.52' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z71.6' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z71.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z76.0' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E11.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E66.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'I25.10' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'J02.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M25.561' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'N40.1' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R73.03' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z11.1' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z12.11' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z12.31' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z13.220' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.30' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.54' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z71.51' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'B18.1' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'E66.3' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'J30.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'K29.70' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'K30' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'L23.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M25.512' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'M54.2' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'N39.0' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R10.13' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R73.01' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R73.9' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'R94.5' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z00.01' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z13.29' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.1' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.20' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.21' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.22' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.26' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z68.28' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z71.2' THEN 1 
             ELSE 0 
           END), 
       Sum(CASE 
             WHEN icd10_code = 'Z71.89' THEN 1 
             ELSE 0 
           END) 
FROM   (SELECT * 
        FROM   (SELECT DISTINCT pat_id 
                FROM   t_encounter 
                       JOIN t_patient 
                         ON enc_patient_id = pat_id 
                WHERE  pat_delete_ind = 'N' 
                       AND enc_timestamp BETWEEN '2018-01-01' AND '2019-01-01') AS a) AS b 
       JOIN t_assessment 
         ON pat_id = patient_id 
WHERE  assessment_date BETWEEN '2018-01-01' AND '2019-01-01' 
GROUP  BY pat_id 
