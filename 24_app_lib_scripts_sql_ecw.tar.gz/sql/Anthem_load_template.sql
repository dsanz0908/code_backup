delete from payor.staging_Anthem_corinthian_FILETYPE;
copy payor.staging_Anthem_corinthian_FILETYPE
from 's3://acp-data/Anthem/Corinthian/FILENAME'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter ' '
NULL as 'NULL'
dateformat 'auto'
REMOVEQUOTES;
