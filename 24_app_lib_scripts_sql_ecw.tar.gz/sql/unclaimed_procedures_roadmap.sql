WITH cte_2018_diagnoses 
     AS (SELECT DISTINCT person_id, 
                         patient_id, 
                         Concat(pat_first_name, ' ', pat_last_name) AS patient, 
                         icd10_code 
         FROM   t_assessment 
                JOIN mpi.person_patient 
                  ON patient_id = pat_id 
                JOIN t_patient 
                  ON t_assessment.patient_id = t_patient.pat_id 
         WHERE  Year(assessment_date) = 2018 
                AND delete_ind = 'N' 
                AND active_ind = 'Y' 
                AND icd10_code IS NOT NULL), 
     cte_2019_diagnoses 
     AS (SELECT DISTINCT person_id, 
                         patient_id, 
                         Cast(assessment_date AS DATE)    AS assessment_date, 
                         Cast(cc_date_of_service AS DATE) AS cc_date_of_service, 
                         icd10_code, 
                         cc_cpt_code 
         FROM   t_assessment 
                JOIN mpi.person_patient 
                  ON patient_id = pat_id 
                LEFT JOIN t_chargecapture 
                       ON t_chargecapture.cc_enc_id = t_assessment.encounter_id 
         WHERE  Year(assessment_date) = 2019 
                AND delete_ind = 'N' 
                AND active_ind = 'Y' 
                AND icd10_code IS NOT NULL) 
SELECT DISTINCT cte_2018_diagnoses.patient_id, 
                patient, 
                cte_2019_diagnoses.icd10_code, 
                assessment_date, 
                cc_cpt_code, 
                cc_date_of_service 
FROM   cte_2018_diagnoses 
       LEFT JOIN cte_2019_diagnoses 
              ON cte_2019_diagnoses.person_id = cte_2018_diagnoses.person_id 
                 AND cte_2019_diagnoses.icd10_code = cte_2018_diagnoses.icd10_code 
