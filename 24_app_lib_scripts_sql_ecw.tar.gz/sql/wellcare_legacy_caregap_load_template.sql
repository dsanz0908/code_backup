delete from payor.staging_wellcare_corinthian_caregaps;

copy payor.staging_wellcare_corinthian_caregaps
from 's3://acp-data/Wellcare/LEGACY/FILENAME'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 20
ignoreheader 20
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;

delete from payor.wellcare_all_caregaps where filename = 'FILENAME';
insert into payor.wellcare_all_caregaps (select stg.*, 'FILENAME', 'YEARMONTH' from payor.staging_wellcare_corinthian_caregaps stg)
