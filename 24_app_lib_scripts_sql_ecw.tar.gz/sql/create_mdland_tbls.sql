 drop table if exists mdland.vaccine; create table mdland.vaccine ( 
"CVXCode" varchar(max) ,
"ShortName" varchar(max) ,
"FullName" varchar(max) ,
"IsActive" varchar(max) );
 copy mdland.vaccine from 's3://sftp_test/vaccine' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' csv; 
