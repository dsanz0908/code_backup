WITH cte_comorbidities 
     AS (SELECT patient_dob, 
                patient_first_name, 
                patient_last_name, 
                case when Sum(score) >= 4 then 5 else sum(score) end AS score 
         FROM   (SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 6 AS score 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%stromal%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 4 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%renal disease%' 
                         OR diagnosis_description ILIKE '%liver disease%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 4 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%aids%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 3 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%connective tissue%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 3 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%dementia%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 2 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%tumor%' 
                        AND diagnosis_description NOT ILIKE '%stromal%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 2 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%pulmonary disease%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 2 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%diabetes%' 
                        AND diagnosis_description ILIKE '%disease%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 2 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%heart failure%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 1 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%diabetes%' 
                        AND diagnosis_description ILIKE '%without complications%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 1 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%vascular disease%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 1 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%Cerebrovascular disease%' 
                 UNION ALL 
                 SELECT DISTINCT patient_dob, 
                                 patient_first_name, 
                                 patient_last_name, 
                                 1 
                 FROM   bronx_rhio_enriched_cen 
                 WHERE  diagnosis_description ILIKE '%myocardial%') 
         GROUP  BY 1, 
                   2, 
                   3), 
     cte_info 
     AS (SELECT patient_first_name, 
                patient_last_name, 
                patient_dob, 
                emergency + CASE WHEN length_of_stay BETWEEN 4 AND 6 THEN 4 WHEN length_of_stay BETWEEN 7 AND 13 THEN 5 WHEN length_of_stay >= 14 THEN 7 WHEN length_of_stay IS NULL THEN 0 ELSE length_of_stay END + CASE WHEN emergency_visits >= 4 THEN 4 ELSE emergency_visits END AS score,
                d 
         FROM   (SELECT master_patient_id, 
                        patient_first_name, 
                        patient_last_name, 
                        patient_dob, 
                        Max(CASE 
                              WHEN patient_class = 'Emergency' THEN 3 
                              ELSE 0 
                            END)            AS emergency, 
                        Sum(Datediff(day, admit_datetime, discharge_datetime) 
                            + 1)            AS length_of_stay, 
                        Sum(CASE 
                              WHEN patient_class = 'Emergency' THEN 3 
                              ELSE 0 
                            END)            AS emergency_visits, 
                        Max(admit_datetime) AS d 
                 FROM   (SELECT *, 
                                Row_number() 
                                  OVER ( 
                                    partition BY master_patient_id, Trunc(admit_datetime) 
                                    ORDER BY discharge_datetime, added_tz DESC) AS rn 
                         FROM   bronx_rhio_enriched_cen 
                         WHERE  Datediff(month, added_tz, Getdate()) BETWEEN 0 AND 5 
                                AND Datediff(year, patient_dob, added_tz) >= 18) 
                 WHERE  rn = 1 
                        AND discharge_datetime IS NOT NULL 
                        AND discharge_datetime < Getdate() 
                 GROUP  BY 1, 
                           2, 
                           3, 
                           4)) 
SELECT cte_info.patient_dob, cte_info.patient_first_name, cte_info.patient_last_name, cte_info.score + case when cte_comorbidities.score is not null then cte_comorbidities.score else 0 end as score, d
FROM   cte_info 
       LEFT JOIN cte_comorbidities 
         ON cte_info.patient_dob = cte_comorbidities.patient_dob 
            AND cte_info.patient_first_name = cte_comorbidities.patient_first_name 
            AND cte_info.patient_last_name = cte_comorbidities.patient_last_name
