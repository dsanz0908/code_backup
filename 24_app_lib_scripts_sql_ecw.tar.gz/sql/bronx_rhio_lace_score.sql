SELECT patient_first_name, 
       patient_last_name, 
       patient_dob, 
       emergency, 
       CASE 
         WHEN length_of_stay BETWEEN 4 AND 6 THEN 4 
         WHEN length_of_stay BETWEEN 7 AND 13 THEN 5 
         WHEN length_of_stay >= 14 THEN 7 
         WHEN length_of_stay IS NULL THEN 0 
         ELSE length_of_stay 
       END, 
       CASE 
         WHEN emergency_visits >= 4 THEN 4 
         ELSE emergency_visits 
       END 
FROM   (SELECT master_patient_id,patient_first_name, 
               patient_last_name, 
               patient_dob, 
               Max(CASE 
                     WHEN patient_class = 'Emergency' THEN 3 
                     ELSE 0 
                   END) AS emergency, 
               Sum(Datediff(day, admit_datetime, discharge_datetime) 
                   + 1) AS length_of_stay, 
               Sum(CASE 
                     WHEN patient_class = 'Emergency' THEN 3 
                     ELSE 0 
                   END) AS emergency_visits 
        FROM   (SELECT *, 
                       Row_number() 
                         OVER ( 
                           partition BY master_patient_id, Trunc(admit_datetime) 
                           ORDER BY discharge_datetime, added_tz DESC) AS rn 
                FROM   bronx_rhio_enriched_cen 
                WHERE  Datediff(month, added_tz, Getdate()) BETWEEN 0 AND 5 
                       AND Datediff(year, patient_dob, added_tz) >= 18) 
        WHERE  rn = 1 
               AND discharge_datetime IS NOT NULL 
               AND discharge_datetime < Getdate() 
        GROUP  BY 1, 
                  2, 
                  3) 
