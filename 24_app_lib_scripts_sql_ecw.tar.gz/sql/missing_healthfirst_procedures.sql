WITH cte_latest_healthfirst_members
     AS (SELECT *
         FROM   (SELECT *,
                        Rank()
                          OVER (
                            partition BY CASE WHEN loaded_from_file LIKE '%somos%' THEN 1 WHEN loaded_from_file LIKE
                          '%corinthian%' THEN
                          2 END
                            ORDER BY modify_timestamp DESC) AS plan_member_elig_rn
                 FROM   plan_member_elig
                 WHERE  source_id = 1002
                        AND delete_ind = 'N') AS all_healthfirst_members
         WHERE  plan_member_elig_rn = 1),
     cte_latest_distinct_members
     AS (SELECT DISTINCT cte_latest_healthfirst_members.orig_member_id,
                         first_name,
                         middle_name,
                         last_name,
                         dob,
                         sex
         FROM   cte_latest_healthfirst_members
                JOIN plan_member
                  ON cte_latest_healthfirst_members.orig_member_id = plan_member.orig_member_id
         WHERE  end_date = (SELECT Max(end_date)
                            FROM   cte_latest_healthfirst_members))
SELECT distinct cte_latest_distinct_members.*,
       t_patient.pat_id,
       cc_cpt_code,
       cc_date_of_service,
       provider_master.prov_last_name,
       provider_master.prov_first_name,
       provider_master.prov_middle_name,
       responsible_provider_master.prov_last_name   AS responsible_prov_last_name,
       responsible_provider_master.prov_first_name  AS responsible_prov_first_name,
       responsible_provider_master.prov_middle_name AS responsible_prov_middle_name,
       site_master.site_center_name
FROM   cte_latest_distinct_members
       INNER JOIN t_payer
               ON cte_latest_distinct_members.orig_member_id = t_payer.policy_nbr
       INNER JOIN t_encounter
               ON t_payer.patient_id = t_encounter.enc_patient_id
       INNER JOIN t_patient
               ON t_encounter.enc_patient_id = t_patient.pat_id
       INNER JOIN t_chargecapture
               ON t_chargecapture.cc_enc_id = t_encounter.enc_id               
       LEFT JOIN site_master
               ON t_encounter.enc_site_id = site_master.site_id
       LEFT JOIN provider_master
               ON t_encounter.enc_rendering_provider_id = provider_master.prov_id
       LEFT JOIN provider_master AS responsible_provider_master
               ON t_patient.pat_responsible_provider_id = responsible_provider_master.prov_id         
       WHERE cc_cpt_code is not null and ltrim(rtrim(cc_cpt_code)) <> ''

drop table staging_arcadia_procedures;
create temp table if not exists staging_arcadia_procedures (
orig_member_id varchar(255),
first_name varchar(255),
middle_name varchar(255),
last_name varchar(255),
dob datetime,
sex varchar(255),
pat_id varchar(255),
cc_cpt_code varchar(255),
cc_date_of_service datetime,
prov_last_name varchar(255),
prov_first_name varchar(255),
prov_middle_name varchar(255),
responsible_prov_last_name varchar(255),
responsible_prov_first_name varchar(255),
responsible_prov_middle_name varchar(255),
site_center_name varchar(255)
);


copy staging_arcadia_procedures
from 's3://sftp_test/missing_healthfirst_procedures.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 50
region 'us-east-1'
dateformat 'auto'
delimiter '|'
NULL as 'NULL';

drop table fuzz_test;
create temporary table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

WITH cte_match_ids
     AS (SELECT pat_id,
                Max(CASE
                      WHEN rn = 1 THEN mco_cin
                    END) AS id_1,
                Max(CASE
                      WHEN rn = 2 THEN mco_cin
                    END) AS id_2,
                Max(CASE
                      WHEN rn = 3 THEN mco_cin
                    END) AS id_3
         FROM   (SELECT a.*,
                        Row_number()
                          OVER (
                            partition BY pat_id
                            ORDER BY mco_cin) AS rn
                 FROM   (SELECT DISTINCT pat_id,
                                         mco_cin
                         FROM   staging_arcadia_procedures AS a
                                JOIN fuzz_test
                                  ON pat_id = arcadia_pat_id
                         WHERE  cc_date_of_service >= '2019-01-01') AS a)
         GROUP  BY 1),
     cte_cdw_hf
     AS (SELECT DISTINCT healthfirst_src_member_id,
                         service_start_date,
                         service_cd
         FROM   fact_claims AS a
                JOIN dim_membership AS d
                  ON a.local_member_id = d.local_member_id join dim_service_type on a.local_service_id = dim_service_type.local_service_id
         UNION
         SELECT DISTINCT member_cin,
                         service_start_date,
                         service_cd
         FROM   fact_claims AS a
                JOIN dim_membership AS d
                  ON a.local_member_id = d.local_member_id join dim_service_type on a.local_service_id = dim_service_type.local_service_id)
SELECT DISTINCT first_name,
                middle_name,
                last_name,
                dob,
                sex,
                cc_cpt_code,
                cc_date_of_service,
                prov_last_name,
                prov_middle_name,
                responsible_prov_last_name,
                responsible_prov_first_name,
                responsible_prov_middle_name,
                id_1,
                id_2,
                id_3
FROM   staging_arcadia_procedures
       JOIN cte_match_ids
         ON staging_arcadia_procedures.pat_id = cte_match_ids.pat_id
WHERE  NOT EXISTS (SELECT 1
                   FROM   cte_cdw_hf
                   WHERE  ( id_1 = healthfirst_src_member_id
                             OR id_2 = healthfirst_src_member_id
                             OR id_3 = healthfirst_src_member_id )
                          AND Trunc(cc_date_of_service) = service_start_date
                          AND cc_cpt_code = service_cd)
       AND cc_cpt_code IS NOT NULL
       AND cc_date_of_service >= '2019-01-01'
ORDER  BY orig_member_id,
          cc_date_of_service;
