--Wellcare Corinthian Claims 

delete from payor.staging_wellcare_somos_claims;

copy payor.staging_wellcare_somos_claims
from 's3://acp-data/Wellcare/SOMOS/WELLCARE-SOMOS-CLAIMS-201910.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 0
ignoreheader 1
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.wellcare_somos_all_claims where filename = 'WELLCARE-SOMOS-CLAIMS-201910.txt';
insert into payor.wellcare_somos_all_claims (
master_ipa,
seq_member_id,
activity_date,
seq_pcp_id,
subscriber_id,
pcp_first_name,
pcp_last_name,
external_pcp_id,
lob,
claim_type,
claim_number,
auth_number,
place_of_service_1,
denial_reason_list,
diagnosis_1,
diagnosis_2,
diagnosis_3,
diagnosis_4,
diagnosis_5,
diagnosis_6,
diagnosis_7,
diagnosis_8,
diagnosis_9,
diagnosis_10,
diagnosis_11,
diagnosis_12,
diagnosis_13,
diagnosis_14,
diagnosis_15,
diagnosis_16,
diagnosis_17,
diagnosis_18,
diagnosis_19,
diagnosis_20,
diagnosis_21,
diagnosis_22,
diagnosis_23,
diagnosis_24,
diagnosis_25,
diagnosis_icd_version_1,
diagnosis_icd_version_2,
diagnosis_icd_version_3,
diagnosis_icd_version_4,
diagnosis_icd_version_5,
diagnosis_icd_version_6,
diagnosis_icd_version_7,
diagnosis_icd_version_8,
diagnosis_icd_version_9,
diagnosis_icd_version_10,
diagnosis_icd_version_11,
diagnosis_icd_version_12,
diagnosis_icd_version_13,
diagnosis_icd_version_14,
diagnosis_icd_version_15,
diagnosis_icd_version_16,
diagnosis_icd_version_17,
diagnosis_icd_version_18,
diagnosis_icd_version_19,
diagnosis_icd_version_20,
diagnosis_icd_version_21,
diagnosis_icd_version_22,
diagnosis_icd_version_23,
diagnosis_icd_version_24,
diagnosis_icd_version_25,
bill_type,
drg_code,
service_provider_id,
provider_last_name,
provider_first_name,
patient_status,
provider_par_stat,
provider_spec,
vm_full_name,
service_date,
service_thru_date,
procedure_code_1,
procedure_code_type_1,
procedure_icd_version_1,
procedure_modifier_1_1,
procedure_modifier_1_2,
procedure_modifier_1_3,
procedure_modifier_1_4,
procedure_code_2,
procedure_code_type_2,
procedure_icd_version_2,
procedure_modifier_2_1,
procedure_modifier_2_2,
procedure_modifier_2_3,
procedure_modifier_2_4,
procedure_code_3,
procedure_code_type_3,
procedure_icd_version_3,
procedure_modifier_3_1,
procedure_modifier_3_2,
procedure_modifier_3_3,
procedure_modifier_3_4,
procedure_code_4,
procedure_code_type_4,
procedure_icd_version_4,
procedure_modifier_4_1,
procedure_modifier_4_2,
procedure_modifier_4_3,
procedure_modifier_4_4,
revenue_code_1,
revenue_code_2,
revenue_code_3,
revenue_code_4,
quantity,
billed_amount,
allowed_amount,
copayment_1_amount,
net_amount_paid,
claim_status,
processing_status,
post_date,
check_date,
admission_date,
service_provider_npi,
detail_line_number,
detail_sub_line_code,
receivedmonth,
national_provider_id,
filename) 
 
select stg.*, al.npi, 'WELLCARE-SOMOS-CLAIMS-201910.txt' from payor.staging_wellcare_somos_claims stg
left join (select DISTINCT npi, seq_pcp_id from payor.wellcare_provider_xwalk) as al
on stg.seq_pcp_id = al.seq_pcp_id;

--Wellcare Corinthian Demographics

delete from  payor.staging_wellcare_corinthian_demographics;

copy payor.staging_wellcare_corinthian_demographics
from 's3://acp-data/Wellcare/SOMOS/WELLCARE-SOMOS-DEMOGRAPHICS-201910.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 0
ignoreheader 1
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.wellcare_somos_all_demographics where filename = 'WELLCARE-SOMOS-DEMOGRAPHICS-201910.txt';

insert into payor.wellcare_somos_all_demographics (
lob,
master_ipa,
ipa_id,
seq_memb_id,
activity_date,
subscriber_id,
funding_county,
plan_code,
seq_pcp_id,
pcp_first_name,
pcp_last_name,
cohort,
elig_category,
date_of_birth,
gender,
medicaid_no,
medicare_no,
last_name,
first_name,
address_line_1,
address_line_2,
city,
state,
zip,
risk_score_ab,
risk_score_d,
hospice,
esrd,
institutional,
nursing_home_certifiable,
medicaid,
medicaid_add_on,
previous_disable,
home_phone_number,
dual_elig,
receivedmonth,
national_provider_id,
filename)
select 
stg.lob,
stg.master_ipa,
stg.ipa_id,
stg.seq_memb_id,
stg.activity_date,
stg.subscriber_id,
stg.funding_county,
stg.plan_code,
stg.seq_pcp_id,
stg.pcp_first_name,
stg.pcp_last_name,
stg.cohort,
stg.elig_category,
stg.date_of_birth,
stg.gender,
stg.medicaid_no,
stg.medicare_no,
stg.last_name,
stg.first_name,
stg.address_line_1,
stg.address_line_2,
stg.city,
stg.state,
stg.zip,
case when trim(stg.risk_score_ab) = '' then NULL 
else cast(stg.risk_score_ab as numeric(10,3)) end,
stg.risk_score_d,
stg.hospice,
stg.esrd,
stg.institutional,
stg.nursing_home_certifiable,
stg.medicaid,
stg.medicaid_add_on,
stg.previous_disable,
stg.home_phone_number,
stg.dual_elig,
stg.receivedmonth,
 al.npi, 'WELLCARE-SOMOS-DEMOGRAPHICS-201910.txt' from payor.staging_wellcare_corinthian_demographics stg
left outer join ( select DISTINCT npi, seq_pcp_id from payor.wellcare_provider_xwalk) as al
on stg.seq_pcp_id = al.seq_pcp_id;


--Wellcare Corinthian Rx 

delete from payor.staging_wellcare_somos_rx;

copy payor.staging_wellcare_somos_rx
from 's3://acp-data/Wellcare/SOMOS/WELLCARE-SOMOS-PHARMACY-201910.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 0
ignoreheader 1
region 'us-east-1'
delimiter '|'
dateformat 'auto'
REMOVEQUOTES;

delete from payor.wellcare_somos_all_rx where filename = 'WELLCARE-SOMOS-PHARMACY-201910.txt';
insert into payor.wellcare_somos_all_rx (
master_ipa,
seq_memb_id,
activity_date,
seq_pcp_id,
subscriber_id,
pcp_first_name,
pcp_last_name,
external_pcp_id,
lob,
pharmacy_number,
prescription_number,
date_filled,
ndc_number,
drugdescription,
therapeuticclass,
number_of_refills,
metric_quantity,
days_supply,
ingredient_cost,
dispensing_fee,
co_pay,
sales_tax,
amount_billed,
prov_dea_no,
mailorder_ind,
amount_paid,
route_of_admin,
transaction_status,
seq_prov_id,
prescriber_id,
prescriber_id_type,
prescriber_first_name,
prescriber_last_name,
generic_indicator,
ta_utilized,
gross_dc_aboveattach_pnt_amt,
lics_and_cgd,
part_type_flag,
receivedmonth,
national_provider_id,
filename)
(select stg.*, al.npi, 'WELLCARE-SOMOS-PHARMACY-201910.txt' from payor.staging_wellcare_somos_rx stg
left outer join ( select DISTINCT npi, seq_pcp_id from payor.wellcare_provider_xwalk) as al
on stg.seq_pcp_id = al.seq_pcp_id);

