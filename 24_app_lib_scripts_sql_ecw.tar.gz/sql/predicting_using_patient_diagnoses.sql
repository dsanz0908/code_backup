create temp table if not exists patient_diagnoses (
pat_id varchar(255),
encounter_date date,
diagnosis_code varchar(255));

copy patient_diagnoses
from 's3://sftp_test/patient_diagnoses.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 1000
region 'us-east-1'
dateformat 'auto'
delimiter '|'
null as '\000';

create temp table fuzz_test (
arcadia_name            varchar(255),
arcadia_dob                     date,
arcadia_pat_id          varchar(100),
mco_name                        varchar(255),
mco_dob       date,
mco_cin                         varchar(50),
mco_source    varchar(50),
mco_npi       varchar(20),
mco_address   varchar(255),
mco_phone     varchar(20),
mco_month     varchar(20));

copy fuzz_test
from 's3://sftp_test/pat_cin_match.txt'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
region 'us-east-1'
dateformat 'auto'
delimiter  '|';

WITH cte_match_ids 
     AS (SELECT pat_id, 
                Max(CASE 
                      WHEN rn = 1 THEN mco_cin 
                    END) AS id_1, 
                Max(CASE 
                      WHEN rn = 2 THEN mco_cin 
                    END) AS id_2, 
                Max(CASE 
                      WHEN rn = 3 THEN mco_cin 
                    END) AS id_3 
         FROM   (SELECT a.*, 
                        Row_number() 
                          OVER ( 
                            partition BY pat_id 
                            ORDER BY mco_cin) AS rn 
                 FROM   (SELECT DISTINCT pat_id, 
                                         mco_cin 
                         FROM   patient_diagnoses AS a 
                                JOIN fuzz_test 
                                  ON pat_id = arcadia_pat_id 
                         WHERE  mco_source LIKE 'Healthfirst%' 
                                 OR mco_source LIKE 'WellCare%') AS a) 
         GROUP  BY 1), 
     cte_cdw_hf 
     AS (SELECT DISTINCT healthfirst_src_member_id AS member_id, 
                         local_member_id 
         FROM   dim_membership 
         UNION 
         SELECT DISTINCT member_cin, 
                         local_member_id 
         FROM   dim_membership 
         UNION 
         SELECT DISTINCT wellcare_src_member_id, 
                         local_member_id 
         FROM   dim_membership) 
SELECT TOP 10 * 
FROM   patient_diagnoses 
       JOIN cte_match_ids 
         ON patient_diagnoses.pat_id = cte_match_ids.pat_id 
       LEFT OUTER JOIN cte_cdw_hf 
                    ON ( id_1 = member_id 
                          OR id_2 = member_id 
                          OR id_3 = member_id ) 
       JOIN fact_claims 
         ON cte_cdw_hf.local_member_id = fact_claims.local_member_id 
