SELECT DISTINCT pat_id, 
                collection_date, 
                result_value 
FROM   t_result 
WHERE  original_name LIKE '%a1c%' 
       AND delete_ind = 'N' 
       AND collection_date <> '' 
       AND received_date <> '' 
       AND result_value <> '' 
