SELECT DISTINCT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                collection_date, 
                result_value 
FROM   t_result 
join t_patient on t_result.pat_id = t_patient.pat_id
WHERE  original_name LIKE '%a1c%' 
       AND delete_ind = 'N' 
       AND collection_date <> '' 
       AND result_value <> '' 
       AND pat_delete_ind = 'N'
