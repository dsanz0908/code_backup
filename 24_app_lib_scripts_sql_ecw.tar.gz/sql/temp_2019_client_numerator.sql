SELECT distinct pat_id, measuredisplayname
FROM   acpps_client_prd01.dbo.personmeasures AS a 
       JOIN mpi.person_patient on personid = person_id
WHERE  periodname = '2019' 
       AND initiativename = 'DSRIP Year 3' and numerator = 1 and active_ind = 'Y'
