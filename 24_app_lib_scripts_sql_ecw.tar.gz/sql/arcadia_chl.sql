select distinct pat_first_name,
                pat_last_name,
                dob,
                dos,
                cc_cpt_code
from (

select *, row_number() over (partition by pat_first_name, pat_last_name, dob order by dos desc) as rn from (SELECT pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                case when collection_date is not null then cast(collection_date as date) else cast(cc_date_of_service as date) end as dos,
                cc_cpt_code
FROM   t_chargecapture
       JOIN t_patient
         ON cc_patient_id = pat_id
       LEFT JOIN t_result on cc_enc_id = enc_id
WHERE  cc_delete_ind = 'N'
       AND year(cc_date_of_service) = 2019
       AND cc_cpt_code IN ( '87110','87270','87320','87490','87491','87492','87810' )
       AND pat_delete_ind = 'N' and delete_ind = 'N') as t1 ) as t2 where rn = 1

