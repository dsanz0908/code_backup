CREATE temporary TABLE IF NOT EXISTS temp_affinity_somos_roster
  ( 
     group_name                 VARCHAR(255), 
     pcp_id                     VARCHAR(255), 
     provider_npi               VARCHAR(255), 
     pcp_name                   VARCHAR(255), 
     pcp_address                VARCHAR(255), 
     member_status              VARCHAR(255), 
     affinity_subscriber_number VARCHAR(255), 
     cin                        VARCHAR(255), 
     lob                        VARCHAR(255), 
     last_name                  VARCHAR(255), 
     first_name                 VARCHAR(255), 
     dob                        VARCHAR(255), 
     sex                        VARCHAR(255), 
     effective_date             VARCHAR(255), 
     pcp_assgn_date             VARCHAR(255), 
     recertification_date       VARCHAR(255), 
     member_address             VARCHAR(255), 
     member_phone_number        VARCHAR(255), 
     member_email_address       VARCHAR(255), 
     restricted_recipient       VARCHAR(255), 
     health_home                VARCHAR(255), 
     health_home_name           VARCHAR(255), 
     non_user                   VARCHAR(255), 
     auto_assigned              VARCHAR(255), 
     harp_eligible              VARCHAR(255), 
     group_tin                  VARCHAR(255) 
  ); 

copy temp_affinity_somos_roster
from 's3://acp-data/Affinity/SOMOS/FILENAME.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 0
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;

DELETE FROM payor.affinity_somos_roster_all
WHERE  filename = 'FILENAME.csv'; 

INSERT INTO payor.affinity_somos_roster_all
            (group_name, 
             pcp_id, 
             provider_npi, 
             pcp_name, 
             pcp_address, 
             member_status, 
             affinity_subscriber_number, 
             cin, 
             lob, 
             last_name, 
             first_name, 
             dob, 
             sex, 
             effective_date, 
             pcp_assgn_date, 
             recertification_date, 
             member_address, 
             member_phone_number, 
             member_email_address, 
             restricted_recipient, 
             health_home, 
             health_home_name, 
             non_user, 
             auto_assigned, 
             group_tin, 
             filename, 
             added_tz, 
             harp_eligible,
             period) 
SELECT group_name, 
       pcp_id, 
       provider_npi, 
       pcp_name, 
       pcp_address, 
       member_status, 
       affinity_subscriber_number, 
       cin, 
       lob, 
       last_name, 
       first_name, 
       To_date(dob, 'MM/DD/YYYY'), 
       sex, 
       To_date(effective_date, 'MM/DD/YYYY'), 
       To_date(pcp_assgn_date, 'MM/DD/YYYY'), 
       To_date(recertification_date, 'MM/DD/YYYY'), 
       member_address, 
       member_phone_number, 
       member_email_address, 
       restricted_recipient, 
       case when health_home = 'Y' then 1 else 0 end,
       health_home_name, 
       case when non_user = 'Y' then 1 else 0 end,
       case when auto_assigned = 'Y' then 1 else 0 end,
       group_tin, 
       'FILENAME.csv', 
       Getdate(), 
       case when harp_eligible = 'Y' then 1 else 0 end,
       'PERIOD'
FROM   temp_affinity_somos_roster; 
