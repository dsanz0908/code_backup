copy us_geo_codes(zipcode,latitude,longitude,city,state,county)
from 's3://sftp_test/geo_codes.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
delimiter ','
ignoreheader as 1
removequotes;
\q
