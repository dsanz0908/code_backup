delete from payor.staging_healthfirst_corinthian_QUALITY_CARE;
--quality care is comma delimited, rest is pipe
copy payor.staging_healthfirst_corinthian_QUALITY_CARE
from 's3://acp-data/Healthfirst/Corinthian/HEALTHFIRST-CORINTHIAN-QUALITY_CARE-201808.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 1
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;
