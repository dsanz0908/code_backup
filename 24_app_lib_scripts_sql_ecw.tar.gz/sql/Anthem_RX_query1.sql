        ?column?         
-------------------------
  claim_number,
  fill_date,
  PRODUCT,
  PCP_NAME,
  PCP_TIN,
  SRC_SUBS_ID,
  MCD_Number,
  MBR_FIRST_NAME,
  MBR_LAST_NAME,
  DOB,
  Prescriber_name,
  Prescriber_NPI,
  Prescribing_Specialty,
  DRUG_NAME,
  SCRIPT_CNT,
  REFILL_CNT,
  ANL_Paid_Amt,
  received_month,
  filename,
(19 rows)

