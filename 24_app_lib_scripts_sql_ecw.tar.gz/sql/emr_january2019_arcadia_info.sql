WITH cte_vitals 
     AS (SELECT vitals_patient_id, 
                vitals_height, 
                vitals_weight, 
                vitals_bmi, 
                vitals_systolic, 
                vitals_diastolic, 
                vitals_temperature, 
                vitals_heart_rate, 
                vitals_spo2, 
                vitals_bmi_percentile 
         FROM   t_vitals 
         WHERE  Month(vitals_date) = 1 
                AND Year(vitals_date) = 2019 
                AND vitals_delete_ind = 'N'), 
     cte_diagnoses 
     AS (SELECT patient_id, 
                Count(DISTINCT icd10_code) AS icd10_count 
         FROM   t_assessment 
         WHERE  delete_ind = 'N' 
                AND Year(assessment_date) = 2019 
                AND Month(assessment_date) = 1 
                AND icd10_code IS NOT NULL 
         GROUP  BY patient_id), 
     cte_chargecapture 
     AS (SELECT cc_patient_id, 
                Count(DISTINCT cc_cpt_code) AS cpt_count 
         FROM   t_chargecapture 
         WHERE  cc_delete_ind = 'N' 
                AND Year(cc_date_of_service) = 2019 
                AND Month(cc_date_of_service) = 1 
         GROUP  BY cc_patient_id), 
     cte_enc 
     AS (SELECT enc_patient_id, 
                Count(DISTINCT enc_id)                    AS encounter_count, 
                Count(DISTINCT enc_site_id)               AS site_count, 
                Count(DISTINCT enc_rendering_provider_id) AS provider_count 
         FROM   t_encounter 
         WHERE  enc_delete_ind = 'N' 
                AND Year(enc_timestamp) = 2019 
                AND Month(enc_timestamp) = 1 
         GROUP  BY enc_patient_id), 
     cte_imm 
     AS (SELECT patient_id, 
                Count(DISTINCT cvx_code) AS cvx_count 
         FROM   t_immunization 
         WHERE  Year(completed_date) = 2019 
                AND Month(completed_date) = 1 
                AND delete_ind = 'N' 
                AND cvx_code IS NOT NULL 
         GROUP  BY patient_id), 
     cte_order 
     AS (SELECT pat_id, 
                Count(DISTINCT order_category) AS order_category_count 
         FROM   t_order 
         WHERE  order_category IS NOT NULL 
                AND delete_ind = 'N' 
                AND Year(ordered_date) = 2019 
                AND Month(ordered_date) = 1 
         GROUP  BY pat_id), 
     cte_prescription 
     AS (SELECT patient_id, 
                Count(DISTINCT ndc_code) AS ndc_count 
         FROM   t_prescription 
         WHERE  delete_ind = 'N' 
                AND Year(prescription_date) = 2019 
                AND Month(prescription_date) = 1 
                AND ndc_code IS NOT NULL 
         GROUP  BY patient_id) 
SELECT DISTINCT cte_enc.*, 
                vitals_height, 
                vitals_weight, 
                vitals_bmi, 
                vitals_systolic, 
                vitals_diastolic, 
                vitals_temperature, 
                vitals_heart_rate, 
                vitals_spo2, 
                vitals_bmi_percentile, 
                icd10_count, 
                cpt_count, 
                cvx_count, 
                order_category_count, 
                ndc_count 
FROM   cte_enc 
       LEFT JOIN cte_vitals 
              ON cte_enc.enc_patient_id = cte_vitals.vitals_patient_id 
       LEFT JOIN cte_diagnoses 
              ON cte_enc.enc_patient_id = cte_diagnoses.patient_id 
       LEFT JOIN cte_chargecapture 
              ON cte_enc.enc_patient_id = cte_chargecapture.cc_patient_id 
       LEFT JOIN cte_imm 
              ON cte_enc.enc_patient_id = cte_imm.patient_id 
       LEFT JOIN cte_order 
              ON cte_enc.enc_patient_id = cte_order.pat_id 
       LEFT JOIN cte_prescription 
              ON cte_enc.enc_patient_id = cte_prescription.patient_id 
