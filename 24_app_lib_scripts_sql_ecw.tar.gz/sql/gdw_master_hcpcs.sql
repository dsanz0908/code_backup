select top 10000 * from gdw.master_hcpcs order by random()
