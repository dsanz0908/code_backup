select case when tgt_column_name = 'received_month' then 'RECEIVEDMONTH'
when tgt_column_name = 'filename' then quote_literal('FILENAME')
when tgt_data_type = 'boolean' then 'Case when trim('||src_column_name || ') = ''Y'' then True when trim('||src_column_name || ') = ''N'' then False else NULL end'
when tgt_data_type = 'real'  then  'Case when trim(' || src_column_name || ') = ''''   then NULL else ' || ' CAST ( REPLACE(' || src_column_name || ', '','','''')  AS ' || tgt_data_type  || ' ) end '
when tgt_data_type is NULL then src_column_name
else 'Case when trim(' || src_column_name || ') = ''''   then NULL else ' || ' CAST ( ' || src_column_name || ' AS ' || tgt_data_type  || ' ) end '
end || ','
from mco_file_to_table_mapping where mco_name = 'Healthfirst' and file_type = 'eligibility'
order by column_order;
