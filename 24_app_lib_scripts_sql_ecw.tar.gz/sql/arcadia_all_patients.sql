SELECT DISTINCT pat_id, 
                pat_first_name, 
                pat_last_name, 
                cast(pat_date_of_birth as date)
FROM   t_patient 
WHERE  pat_delete_ind = 'N'
