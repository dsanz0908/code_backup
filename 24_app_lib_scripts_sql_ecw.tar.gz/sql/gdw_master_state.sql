select top 10000 * from gdw.master_state order by random()
