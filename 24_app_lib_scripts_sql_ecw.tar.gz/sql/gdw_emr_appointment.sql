select top 10000 * from gdw.emr_appointment order by random()
