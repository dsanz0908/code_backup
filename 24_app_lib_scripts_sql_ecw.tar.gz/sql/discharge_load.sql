delete from staging_discharge;
copy staging_discharge
from 's3://acp-data/monte/discharge_csvs/31Jan2019_JH Inpatient ACP Discharges.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 40
ignoreheader 2
ACCEPTINVCHARS
region 'us-east-1'
delimiter ','
dateformat 'auto'
REMOVEQUOTES;
