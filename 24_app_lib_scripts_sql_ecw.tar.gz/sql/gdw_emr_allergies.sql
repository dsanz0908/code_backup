select top 10000 * from gdw.emr_allergies order by random()
