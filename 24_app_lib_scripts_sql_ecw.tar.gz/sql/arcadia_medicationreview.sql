WITH cte_review 
     AS (SELECT DISTINCT cc_patient_id, pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                         Cast(cc_date_of_service AS DATE) AS d,

                cc_cpt_code 
         FROM   t_chargecapture 
                JOIN t_patient 
                  ON cc_patient_id = pat_id 
         WHERE  cc_delete_ind = 'N' 
                AND cc_cpt_code = '1159F' 
                AND Year(cc_date_of_service) = 2019), 
     cte_list 
     AS (SELECT DISTINCT  cc_patient_id, pat_first_name,
                pat_last_name,
                Cast(pat_date_of_birth AS DATE) dob,
                         Cast(cc_date_of_service AS DATE) AS d, 
                         cc_cpt_code 
         FROM   t_chargecapture 
                JOIN t_patient 
                  ON cc_patient_id = pat_id 
         WHERE  cc_delete_ind = 'N' 
                AND cc_cpt_code = '1160F' 
                AND Year(cc_date_of_service) = 2019) 
select pat_first_name, pat_last_name, dob, d, c1, c2 from (SELECT cte_review.pat_first_name,
                cte_review.pat_last_name,
                cte_review.dob,
                cte_review.d, 
                cte_review.cc_cpt_code as c1, 
                cte_list.cc_cpt_code as c2, row_number() over (partition by cte_review.pat_first_name, cte_review.pat_last_name, cte_review.dob order by cte_review.d desc) as rn
FROM   cte_review 
       JOIN cte_list 
         ON cte_review.cc_patient_id = cte_list.cc_patient_id 
            AND cte_review.d = cte_list.d) as t1 where rn = 1
