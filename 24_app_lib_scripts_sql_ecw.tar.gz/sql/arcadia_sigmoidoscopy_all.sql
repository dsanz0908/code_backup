SELECT DISTINCT cc_patient_id, 
                cc_date_of_service, 
                cc_cpt_code 
FROM   t_chargecapture 
WHERE  cc_cpt_code IN ( '45330', '45331', '45332', '45333', 
                        '45334', '45335', '45337', '45338', 
                        '45339', '45340', '45341', '45342', 
                        '45345', '45346', '45347', '45349', '45350' ) 
       AND cc_delete_ind = 'N' 
       AND cc_date_of_service >= '2015-01-01' 
