select count(*) from payor.uhc_somos_all_membership where received_month = '201910'
