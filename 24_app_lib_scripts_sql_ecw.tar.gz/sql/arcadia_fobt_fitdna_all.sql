select distinct cc_patient_id, cc_date_of_service, cc_cpt_code from t_chargecapture where cc_cpt_code in 
('82270', '82274')
and cc_delete_ind = 'N' and cc_date_of_service >= '2019-01-01'
union
select distinct cc_patient_id, cc_date_of_service, cc_cpt_code from t_chargecapture where cc_cpt_code in 
('74263', '81528')
and cc_delete_ind = 'N' and cc_date_of_service >= '2018-01-01'
