delete arcadia.Immunization WHERE arcadia_to_somos_filename = '2018_12_07_175948_041_013_Immunization_01_4.csv';
copy arcadia.Immunization
from 's3://acp-data/Arcadia/Incoming/2018_12_07_175948_041_013_Immunization_01_4.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
ignoreheader 1
region 'us-east-1'
dateformat 'auto'
csv;
