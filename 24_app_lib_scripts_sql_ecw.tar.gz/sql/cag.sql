SET nocount ON; 

DROP TABLE acpps_sandbox_prd01..temp_cag_arcadia;
CREATE TABLE acpps_sandbox_prd01..temp_cag_arcadia 
  ( 
     measure              VARCHAR(100), 
     personid             INT, 
     memberid             INT, 
     memberno             VARCHAR(20), 
     member_name          VARCHAR(255), 
     dob                  DATE, 
     age                  INT, 
     sex                  CHAR(1), 
     membership_startdate DATETIME, 
     membership_enddate   DATETIME, 
     planpayer            VARCHAR(100), 
     planproduct          VARCHAR(100), 
     denominator          TINYINT, 
     eventstartdate       DATETIME, 
     eventenddate         DATETIME, 
     eventcodevalue       VARCHAR(20), 
     eventsourcesystem    VARCHAR(255), 
     eventprovidername    VARCHAR(255), 
     eventprovidernpi     VARCHAR(50), 
     eventlocationname    VARCHAR(255), 
     numerator            TINYINT, 
     diagnosis_code       VARCHAR(20) 
  ); 

WITH cte_denominator 
     AS (SELECT 'BREAST CANCER SCREENING' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                         AS denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  sex = 'F' 
                AND age BETWEEN 50 AND 74 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '3014F', '77055', '77056', '77057', 
                                    '77061', '77062', '77063', '77065', 
                                    '77066', '77067', 'G0202', 'G0204', 'G0206' 
                                  ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND eventenddate >= Dateadd(year, -2, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--CERVICAL CANCER SCREENING 
WITH cte_denominator 
     AS (SELECT 'CERVICAL CANCER SCREENING' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                           AS denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  sex = 'F' 
                AND age BETWEEN 21 AND 64 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '3015F', '88141', '88142', '88143', 
                                    '88147', '88148', '88150', '88152', 
                                    '88153', '88154', '88164', '88165', 
                                    '88166', '88167', '88174', '88175', 
                                    'G0123', 'G0124', 'G0141', 'G0143', 
                                    'G0144', 'G0145', 'G0147', 'G0148', 
                                    'P3000', 'P3001', 'Q0091' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND eventenddate >= Dateadd(year, -3, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

-- Chlamydia screening 
WITH cte_denominator 
     AS (SELECT 'CHLAMYDIA SCREENING FOR WOMEN' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                               AS denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  sex = 'F' 
                AND age BETWEEN 16 AND 24 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '87110', '87270', '87320', '87490', 
                                    '87491', '87492', '87810', 'G9820', 'G9821' 
                                  ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) >= Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

-- Colorectal cancer screening 
WITH cte_denominator 
     AS (SELECT 'Colorectal cancer screening' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                             AS denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  age BETWEEN 50 AND 75 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '3017F', '82270', '82274', 'G0328', 
                                    '81528', 'G0464', 'G0104', 'G0105', 'G0121' 
                                  ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datediff(year, eventenddate, Getdate()) <= 
                        CASE 
                                                                 WHEN 
                        eventcodevalue IN 
                        ( 
                        '82270', '82274', '81528', 'G0328' ) THEN 1 
                        WHEN eventcodevalue IN ( 'G0104' ) THEN 5 
                        WHEN eventcodevalue IN ( '3017F', 'G0105', 'G0121' ) 
                        THEN 10 
                                                               END 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

-- ADULT ACCESS TO CARE 
WITH cte_denominator_hf_person 
     AS (SELECT 'ADULT ACCESS TO CARE' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                      AS denominator 
         FROM   acpps_client_prd01..personattribution pa 
         WHERE  age >= 20 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_seen_last_2 
     AS (SELECT DISTINCT personid 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  personid IN (SELECT personid 
                             FROM   cte_denominator_hf_person) 
                AND Datediff(year, eventenddate, Getdate()) <= 2 
                AND eventsourcetable = 't_encounter'), 
     cte_denominator 
     AS (SELECT t1.* 
         FROM   cte_denominator_hf_person t1, 
                cte_seen_last_2 t2 
         WHERE  t1.personid = t2.personid), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '99381', '99382', '99383', '99384', 
                                    '99385', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397', 'G0438', 'G0439' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

-- CHILDREN'S ACCESS TO CARE 
WITH cte_denominator_hf_person 
     AS (SELECT 'CHILDREN''S ACCESS TO CARE' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                            AS denominator 
         FROM   acpps_client_prd01..personattribution pa 
         WHERE  Datediff(month, dob, Getdate()) BETWEEN 12 AND 32 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_seen_last_2 
     AS (SELECT DISTINCT personid 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  personid IN (SELECT personid 
                             FROM   cte_denominator_hf_person) 
                AND Datediff(year, eventenddate, Getdate()) <= 2 
                AND eventsourcetable = 't_encounter'), 
     cte_denominator 
     AS (SELECT t1.* 
         FROM   cte_denominator_hf_person t1, 
                cte_seen_last_2 t2 
         WHERE  t1.personid = t2.personid), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '99381', '99382', '99383', '99384', 
                                    '99385', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397', 'G0438', 'G0439' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

-- ADOLESCENT WELL-CARE VISITS 
WITH cte_denominator_hf_person 
     AS (SELECT 'ADOLESCENT WELL-CARE VISITS' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                             AS denominator 
         FROM   acpps_client_prd01..personattribution pa 
         WHERE  age BETWEEN 12 AND 19 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_seen_last_2 
     AS (SELECT DISTINCT personid 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  personid IN (SELECT personid 
                             FROM   cte_denominator_hf_person) 
                AND Datediff(year, eventenddate, Getdate()) <= 2 
                AND eventsourcetable = 't_encounter'), 
     cte_denominator 
     AS (SELECT t1.* 
         FROM   cte_denominator_hf_person t1, 
                cte_seen_last_2 t2 
         WHERE  t1.personid = t2.personid), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '99381', '99382', '99383', '99384', 
                                    '99385', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397', 'G0438', 'G0439' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

-- ADOLESCENT IMMUNIZATIONS COMBO 1 
WITH cte_denominator_hf_person 
     AS (SELECT 'ADOLESCENT IMMUNIZATIONS COMBO 1' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                                  AS denominator 
         FROM   acpps_client_prd01..personattribution pa 
         WHERE  age BETWEEN 10 AND 13 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_seen_last_2 
     AS (SELECT DISTINCT personid 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  personid IN (SELECT personid 
                             FROM   cte_denominator_hf_person) 
                AND Datediff(year, eventenddate, Getdate()) <= 2 
                AND eventsourcetable = 't_encounter'), 
     cte_denominator 
     AS (SELECT t1.* 
         FROM   cte_denominator_hf_person t1, 
                cte_seen_last_2 t2 
         WHERE  t1.personid = t2.personid), 
     cte_numerator_1 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  eventcodevalue IN ( '90734' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator)), 
     cte_numerator_2 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '90715' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_numerator_1) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       t2.eventenddate, 
       t2.eventcodevalue, 
       t2.eventsourcesystem, 
       t2.eventprovidername, 
       t2.eventprovidernpi, 
       t2.eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator_2 t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--PREVENTIVE CARE AND SCREENING: SCREENING FOR CLINICAL DEPRESSION AND FOLLOW-UP PLAN 
WITH cte_denominator_hf_person 
     AS (SELECT 
'PREVENTIVE CARE AND SCREENING: SCREENING FOR CLINICAL DEPRESSION AND FOLLOW-UP PLAN' 
  AS measure, 
personid, 
memberid, 
memberno, 
NAME, 
dob, 
age, 
sex, 
startdate, 
enddate, 
planpayer, 
quotename(planproduct, '"') as planproduct, 
1 AS denominator 
 FROM   acpps_client_prd01..personattribution pa 
 WHERE  age >= 12 
        AND planpayer = 'Health First' 
        AND planproduct LIKE 'Hf | Somos%' 
        AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
            CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                  FROM 
                acpps_client_prd01..personattribution 
                                                  WHERE 
            planpayer = 'Health First' 
            AND planproduct LIKE 
                'Hf | Somos%')), 
     cte_seen_last_2 
     AS (SELECT DISTINCT personid 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  personid IN (SELECT personid 
                             FROM   cte_denominator_hf_person) 
                AND Datediff(year, eventenddate, Getdate()) <= 2 
                AND eventsourcetable = 't_encounter'), 
     cte_denominator 
     AS (SELECT t1.* 
         FROM   cte_denominator_hf_person t1, 
                cte_seen_last_2 t2 
         WHERE  t1.personid = t2.personid), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '3725F', 'G8510', 'G8431', 'G0444' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--WELL CHILD VISITS (15 MONTHS) 
WITH cte_denominator_hf_person 
     AS (SELECT 'WELL CHILD VISITS (15 MONTHS)' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                               AS denominator 
         FROM   acpps_client_prd01..personattribution pa 
         WHERE  Datediff(month, dob, Getdate()) BETWEEN 0 AND 15 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_seen_last_2 
     AS (SELECT DISTINCT personid 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  personid IN (SELECT personid 
                             FROM   cte_denominator_hf_person) 
                AND Datediff(year, eventenddate, Getdate()) <= 2 
                AND eventsourcetable = 't_encounter'), 
     cte_denominator 
     AS (SELECT t1.* 
         FROM   cte_denominator_hf_person t1, 
                cte_seen_last_2 t2 
         WHERE  t1.personid = t2.personid), 
     cte_min_count 
     AS (SELECT personid, 
                Count(DISTINCT eventcodevalue) AS cnt 
         FROM   acpps_client_prd01..personevents t1 
         WHERE  eventcodevalue IN ( '99381', '99382', '99383', '99384', 
                                    '99385', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397', 'G0438', 'G0439' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
         GROUP  BY personid 
         HAVING Count(DISTINCT eventcodevalue) >= 2), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '99381', '99382', '99383', '99384', 
                                    '99385', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397', 'G0438', 'G0439' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1 
                       AND t2.personid IN (SELECT ctd.personid 
                                           FROM   cte_min_count cmin, 
                                                  cte_denominator ctd 
                                           WHERE  ctd.personid = cmin.personid); 

--WELL CHILD VISITS (3 TO 6 YEARS) 
WITH cte_denominator_hf_person 
     AS (SELECT 'WELL CHILD VISITS (3 TO 6 YEARS)' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                                  AS denominator 
         FROM   acpps_client_prd01..personattribution pa 
         WHERE  age BETWEEN 3 AND 6 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_seen_last_2 
     AS (SELECT DISTINCT personid 
         FROM   acpps_client_prd01..personevents pe 
         WHERE  personid IN (SELECT personid 
                             FROM   cte_denominator_hf_person) 
                AND Datediff(year, eventenddate, Getdate()) <= 2 
                AND eventsourcetable = 't_encounter'), 
     cte_denominator 
     AS (SELECT t1.* 
         FROM   cte_denominator_hf_person t1, 
                cte_seen_last_2 t2 
         WHERE  t1.personid = t2.personid), 
     cte_min_count 
     AS (SELECT personid, 
                Count(DISTINCT eventcodevalue) AS cnt 
         FROM   acpps_client_prd01..personevents t1 
         WHERE  eventcodevalue IN ( '99381', '99382', '99383', '99384', 
                                    '99385', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397', 'G0438', 'G0439' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
         --and personid in ( select personid from cte_denominator ) 
         GROUP  BY personid 
         HAVING Count(DISTINCT eventcodevalue) >= 2), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '99381', '99382', '99383', '99384', 
                                    '99385', '99386', '99387', '99391', 
                                    '99392', '99393', '99394', '99395', 
                                    '99396', '99397', 'G0438', 'G0439' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1 
                       AND t2.personid IN (SELECT ctd.personid 
                                           FROM   cte_min_count cmin, 
                                                  cte_denominator ctd 
                                           WHERE  ctd.personid = cmin.personid); 

--COMP DIABETES CARE: ALL THREE TESTS (HBA1C, DILATED EYE EXAM, AND MEDICAL ATTENTION FOR NEPHROPATHY)  
WITH cte_denominator 
     AS (SELECT 
'COMP DIABETES CARE: ALL THREE TESTS (HBA1C, DILATED EYE EXAM, AND MEDICAL ATTENTION FOR NEPHROPATHY)'
  AS measure, 
personid, 
memberid, 
memberno, 
NAME, 
dob, 
age, 
sex, 
startdate, 
enddate, 
planpayer, 
quotename(planproduct, '"') as planproduct, 
1 AS denominator 
 FROM   acpps_client_prd01..personattribution 
 WHERE  planpayer = 'Health First' 
        AND planproduct LIKE 'Hf | Somos%' 
        AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
            CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                  FROM 
                acpps_client_prd01..personattribution 
                                                  WHERE 
            planpayer = 'Health First' 
            AND planproduct LIKE 
                'Hf | Somos%') 
        AND personid IN (SELECT personid 
                         FROM   acpps_client_prd01..personevents 
                         WHERE  eventcodevalue IN ( 'E08.9', 'E09.9', 'E13.9', 
                                                    'E08.65', 
                                                    'E09.65', 'E08.10', 'E09.10' 
                                                    , 
                                                    'E13.10', 
                                                    'E08.00', 'E08.01', 'E09.00' 
                                                    , 
                                                    'E09.01', 
                                                    'E13.00', 'E13.01', 'E08.11' 
                                                    , 
                                                    'E08.641', 
                                                    'E09.11', 'E09.641', 
                                                    'E13.11', 
                                                    'E13.641' 
                                                    , 
                                                    'E08.21', 'E08.22', 'E08.29' 
                                                    , 
                                                    'E09.21', 
                                                    'E09.22', 'E09.29', 'E13.21' 
                                                    , 
                                                    'E13.22', 
                                                    'E13.29', 'E08.311', 
                                                    'E08.319', 
                                                    'E08.321', 
                                                    'E08.329', 'E08.331', 
                                                    'E08.339', 
                                                    'E08.341', 
                                                    'E08.349', 'E08.351', 
                                                    'E08.359', 
                                                    'E08.36', 
                                                    'E08.39', 'E09.311', 
                                                    'E09.319', 
                                                    'E09.321', 
                                                    'E09.329', 'E09.331', 
                                                    'E09.339', 
                                                    'E09.341', 
                                                    'E09.349', 'E09.351', 
                                                    'E09.359', 
                                                    'E09.36', 
                                                    'E09.39', 'E13.311', 
                                                    'E13.319', 
                                                    'E13.321', 
                                                    'E13.329', 'E13.331', 
                                                    'E13.339', 
                                                    'E13.341', 
                                                    'E13.349', 'E13.351', 
                                                    'E13.359', 
                                                    'E13.36', 
                                                    'E13.39', 'E08.40', 'E08.41' 
                                                    , 
                                                    'E08.42', 
                                                    'E08.43', 'E08.44', 'E08.49' 
                                                    , 
                                                    'E08.610', 
                                                    'E09.40', 'E09.41', 'E09.42' 
                                                    , 
                                                    'E09.43', 
                                                    'E09.44', 'E09.49', 
                                                    'E09.610', 
                                                    'E13.40', 
                                                    'E13.41', 'E13.42', 'E13.43' 
                                                    , 
                                                    'E13.44', 
                                                    'E13.49', 'E13.610', 
                                                    'E08.51', 
                                                    'E08.52', 
                                                    'E08.59', 'E09.51', 'E09.52' 
                                                    , 
                                                    'E09.59', 
                                                    'E13.51', 'E13.52', 'E13.59' 
                                                    , 
                                                    'E08.618', 
                                                    'E08.620', 'E08.621', 
                                                    'E08.622', 
                                                    'E08.628', 
                                                    'E08.630', 'E08.638', 
                                                    'E08.649', 
                                                    'E08.69', 
                                                    'E09.618', 'E09.620', 
                                                    'E09.621', 
                                                    'E09.622', 
                                                    'E09.628', 'E09.630', 
                                                    'E09.638', 
                                                    'E09.649', 
                                                    'E09.69', 'E13.618', 
                                                    'E13.620', 
                                                    'E13.621', 
                                                    'E13.622', 'E13.628', 
                                                    'E13.630', 
                                                    'E13.638', 
                                                    'E13.649', 'E13.65', 
                                                    'E13.69', 
                                                    'E08.8', 
                                                    'E09.8', 'E13.8', 'E11.9', 
                                                    'E10.9', 
                                                    'E11.65', 'E10.65', 'E11.69' 
                                                    , 
                                                    'E10.10', 
                                                    'E11.00', 'E11.01', 'E10.69' 
                                                    , 
                                                    'E11.641', 
                                                    'E10.11', 'E10.641', 
                                                    'E11.21', 
                                                    'E11.22', 
                                                    'E11.29', 'E11.311', 
                                                    'E11.319', 
                                                    'E11.321', 
                                                    'E11.329', 'E11.331', 
                                                    'E11.339', 
                                                    'E11.341', 
                                                    'E11.349', 'E11.351', 
                                                    'E11.359', 
                                                    'E11.36', 
                                                    'E11.39', 'E10.311', 
                                                    'E10.319', 
                                                    'E10.321', 
                                                    'E10.329', 'E10.331', 
                                                    'E10.339', 
                                                    'E10.341', 
                                                    'E10.349', 'E10.351', 
                                                    'E10.359', 
                                                    'E10.36', 
                                                    'E10.39', 'E11.40', 'E11.41' 
                                                    , 
                                                    'E11.42', 
                                                    'E11.43', 'E11.44', 'E11.49' 
                                                    , 
                                                    'E11.610', 
                                                    'E10.40', 'E10.41', 'E10.42' 
                                                    , 
                                                    'E10.43', 
                                                    'E10.44', 'E10.49', 
                                                    'E10.610', 
                                                    'E11.51', 
                                                    'E11.52', 'E11.59', 'E10.51' 
                                                    , 
                                                    'E10.52', 
                                                    'E10.59', 'E11.618', 
                                                    'E11.620', 
                                                    'E11.621', 
                                                    'E11.622', 'E11.628', 
                                                    'E11.630', 
                                                    'E11.638', 
                                                    'E11.649', 'E10.618', 
                                                    'E10.620', 
                                                    'E10.621', 
                                                    'E10.622', 'E10.628', 
                                                    'E10.630', 
                                                    'E10.638', 
                                                    'E10.649', 'E11.8', 'E10.8' 
                                                  ) 
                                AND eventstartdate >= Dateadd(year, -3, Getdate( 
                                                      )))), 
     cte_numerator_1 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '2022F', '3073F', '2024F', '2026F', 
                                    'S0620', 'S0621', 'S3000' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N'), 
     cte_numerator_2 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator 
         FROM   acpps_client_prd01..personevents 
         WHERE  eventcodevalue IN ( '3044F', '3045F', '3046F' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator)), 
     cte_numerator_3 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator 
         FROM   acpps_client_prd01..personevents 
         WHERE  eventcodevalue IN ( '3060F', '3061F', '3062F', '3066F' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator)), 
     cte_numerator 
     AS (SELECT DISTINCT n1.personid, 
                         n1.eventid, 
                         n1.eventstartdate, 
                         n1.eventenddate, 
                         n1.eventcodevalue, 
                         n1.eventsourcesystem, 
                         n1.eventprovidername, 
                         n1.eventprovidernpi, 
                         n1.eventlocationname, 
                         Rank() 
                           OVER ( 
                             partition BY n1.personid 
                             ORDER BY n1.eventenddate DESC, n1.eventid DESC ) AS 
                            person_rank, 
                         1                                                    AS 
                            numerator, 
                         icd10_code 
         FROM   cte_numerator_1 n1 
                INNER JOIN cte_numerator_2 n2 
                        ON n1.personid = n2.personid 
                INNER JOIN cte_numerator_3 n3 
                        ON n1.personid = n3.personid) 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--COMPREHENSIVE DIABETES CARE: EYE EXAM (RETINAL) PERFORMED 
WITH cte_denominator 
     AS (SELECT 'COMPREHENSIVE DIABETES CARE: EYE EXAM (RETINAL) PERFORMED' AS 
                measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                                                           AS 
                   denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%') 
                AND personid IN (SELECT personid 
                                 FROM   acpps_client_prd01..personevents 
                                 WHERE  eventcodevalue IN ( 
                                        'E08.9', 'E09.9', 'E13.9' 
                                        , 
                                        'E08.65', 
                                        'E09.65', 'E08.10', 
                                        'E09.10' 
                                        , 
                                        'E13.10', 
                                        'E08.00', 'E08.01', 
                                        'E09.00' 
                                        , 
                                        'E09.01', 
                                        'E13.00', 'E13.01', 
                                        'E08.11' 
                                        , 
                                        'E08.641', 
                                        'E09.11', 'E09.641', 
                                        'E13.11', 
                                        'E13.641' 
                                        , 
                                        'E08.21', 'E08.22', 
                                        'E08.29' 
                                        , 
                                        'E09.21', 
                                        'E09.22', 'E09.29', 
                                        'E13.21' 
                                        , 
                                        'E13.22', 
                                        'E13.29', 'E08.311', 
                                        'E08.319', 
                                        'E08.321', 
                                        'E08.329', 'E08.331', 
                                        'E08.339', 
                                        'E08.341', 
                                        'E08.349', 'E08.351', 
                                        'E08.359', 
                                        'E08.36', 
                                        'E08.39', 'E09.311', 
                                        'E09.319', 
                                        'E09.321', 
                                        'E09.329', 'E09.331', 
                                        'E09.339', 
                                        'E09.341', 
                                        'E09.349', 'E09.351', 
                                        'E09.359', 
                                        'E09.36', 
                                        'E09.39', 'E13.311', 
                                        'E13.319', 
                                        'E13.321', 
                                        'E13.329', 'E13.331', 
                                        'E13.339', 
                                        'E13.341', 
                                        'E13.349', 'E13.351', 
                                        'E13.359', 
                                        'E13.36', 
                                        'E13.39', 'E08.40', 
                                        'E08.41' 
                                        , 
                                        'E08.42', 
                                        'E08.43', 'E08.44', 
                                        'E08.49' 
                                        , 
                                        'E08.610', 
                                        'E09.40', 'E09.41', 
                                        'E09.42' 
                                        , 
                                        'E09.43', 
                                        'E09.44', 'E09.49', 
                                        'E09.610', 
                                        'E13.40', 
                                        'E13.41', 'E13.42', 
                                        'E13.43' 
                                        , 
                                        'E13.44', 
                                        'E13.49', 'E13.610', 
                                        'E08.51', 
                                        'E08.52', 
                                        'E08.59', 'E09.51', 
                                        'E09.52' 
                                        , 
                                        'E09.59', 
                                        'E13.51', 'E13.52', 
                                        'E13.59' 
                                        , 
                                        'E08.618', 
                                        'E08.620', 'E08.621', 
                                        'E08.622', 
                                        'E08.628', 
                                        'E08.630', 'E08.638', 
                                        'E08.649', 
                                        'E08.69', 
                                        'E09.618', 'E09.620', 
                                        'E09.621', 
                                        'E09.622', 
                                        'E09.628', 'E09.630', 
                                        'E09.638', 
                                        'E09.649', 
                                        'E09.69', 'E13.618', 
                                        'E13.620', 
                                        'E13.621', 
                                        'E13.622', 'E13.628', 
                                        'E13.630', 
                                        'E13.638', 
                                        'E13.649', 'E13.65', 
                                        'E13.69', 
                                        'E08.8', 
                                        'E09.8', 'E13.8', 'E11.9' 
                                        , 
                                        'E10.9', 
                                        'E11.65', 'E10.65', 
                                        'E11.69' 
                                        , 
                                        'E10.10', 
                                        'E11.00', 'E11.01', 
                                        'E10.69' 
                                        , 
                                        'E11.641', 
                                        'E10.11', 'E10.641', 
                                        'E11.21', 
                                        'E11.22', 
                                        'E11.29', 'E11.311', 
                                        'E11.319', 
                                        'E11.321', 
                                        'E11.329', 'E11.331', 
                                        'E11.339', 
                                        'E11.341', 
                                        'E11.349', 'E11.351', 
                                        'E11.359', 
                                        'E11.36', 
                                        'E11.39', 'E10.311', 
                                        'E10.319', 
                                        'E10.321', 
                                        'E10.329', 'E10.331', 
                                        'E10.339', 
                                        'E10.341', 
                                        'E10.349', 'E10.351', 
                                        'E10.359', 
                                        'E10.36', 
                                        'E10.39', 'E11.40', 
                                        'E11.41' 
                                        , 
                                        'E11.42', 
                                        'E11.43', 'E11.44', 
                                        'E11.49' 
                                        , 
                                        'E11.610', 
                                        'E10.40', 'E10.41', 
                                        'E10.42' 
                                        , 
                                        'E10.43', 
                                        'E10.44', 'E10.49', 
                                        'E10.610', 
                                        'E11.51', 
                                        'E11.52', 'E11.59', 
                                        'E10.51' 
                                        , 
                                        'E10.52', 
                                        'E10.59', 'E11.618', 
                                        'E11.620', 
                                        'E11.621', 
                                        'E11.622', 'E11.628', 
                                        'E11.630', 
                                        'E11.638', 
                                        'E11.649', 'E10.618', 
                                        'E10.620', 
                                        'E10.621', 
                                        'E10.622', 'E10.628', 
                                        'E10.630', 
                                        'E10.638', 
                                        'E10.649', 'E11.8', 
                                        'E10.8' 
                                                          ) 
                                        AND eventstartdate >= Dateadd(year, -3, 
                                                              Getdate( 
                                                              )))), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '2022F', '3073F', '2024F', '2026F', 
                                    'S0620', 'S0621', 'S3000' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--COMPREHENSIVE DIABETES CARE: HEMOGLOBIN A1C (HBA1C) TESTING [PERFORMED] 
WITH cte_denominator 
     AS (SELECT 
     'COMPREHENSIVE DIABETES CARE: HEMOGLOBIN A1C (HBA1C) TESTING [PERFORMED]' 
     AS 
     measure, 
     personid, 
     memberid, 
     memberno, 
     NAME, 
     dob, 
     age, 
     sex, 
     startdate, 
     enddate, 
     planpayer, 
     quotename(planproduct, '"') as planproduct, 
     1 
        AS denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%') 
                AND personid IN (SELECT personid 
                                 FROM   acpps_client_prd01..personevents 
                                 WHERE  eventcodevalue IN ( 
                                        'E08.9', 'E09.9', 'E13.9' 
                                        , 
                                        'E08.65', 
                                        'E09.65', 'E08.10', 
                                        'E09.10' 
                                        , 
                                        'E13.10', 
                                        'E08.00', 'E08.01', 
                                        'E09.00' 
                                        , 
                                        'E09.01', 
                                        'E13.00', 'E13.01', 
                                        'E08.11' 
                                        , 
                                        'E08.641', 
                                        'E09.11', 'E09.641', 
                                        'E13.11', 
                                        'E13.641' 
                                        , 
                                        'E08.21', 'E08.22', 
                                        'E08.29' 
                                        , 
                                        'E09.21', 
                                        'E09.22', 'E09.29', 
                                        'E13.21' 
                                        , 
                                        'E13.22', 
                                        'E13.29', 'E08.311', 
                                        'E08.319', 
                                        'E08.321', 
                                        'E08.329', 'E08.331', 
                                        'E08.339', 
                                        'E08.341', 
                                        'E08.349', 'E08.351', 
                                        'E08.359', 
                                        'E08.36', 
                                        'E08.39', 'E09.311', 
                                        'E09.319', 
                                        'E09.321', 
                                        'E09.329', 'E09.331', 
                                        'E09.339', 
                                        'E09.341', 
                                        'E09.349', 'E09.351', 
                                        'E09.359', 
                                        'E09.36', 
                                        'E09.39', 'E13.311', 
                                        'E13.319', 
                                        'E13.321', 
                                        'E13.329', 'E13.331', 
                                        'E13.339', 
                                        'E13.341', 
                                        'E13.349', 'E13.351', 
                                        'E13.359', 
                                        'E13.36', 
                                        'E13.39', 'E08.40', 
                                        'E08.41' 
                                        , 
                                        'E08.42', 
                                        'E08.43', 'E08.44', 
                                        'E08.49' 
                                        , 
                                        'E08.610', 
                                        'E09.40', 'E09.41', 
                                        'E09.42' 
                                        , 
                                        'E09.43', 
                                        'E09.44', 'E09.49', 
                                        'E09.610', 
                                        'E13.40', 
                                        'E13.41', 'E13.42', 
                                        'E13.43' 
                                        , 
                                        'E13.44', 
                                        'E13.49', 'E13.610', 
                                        'E08.51', 
                                        'E08.52', 
                                        'E08.59', 'E09.51', 
                                        'E09.52' 
                                        , 
                                        'E09.59', 
                                        'E13.51', 'E13.52', 
                                        'E13.59' 
                                        , 
                                        'E08.618', 
                                        'E08.620', 'E08.621', 
                                        'E08.622', 
                                        'E08.628', 
                                        'E08.630', 'E08.638', 
                                        'E08.649', 
                                        'E08.69', 
                                        'E09.618', 'E09.620', 
                                        'E09.621', 
                                        'E09.622', 
                                        'E09.628', 'E09.630', 
                                        'E09.638', 
                                        'E09.649', 
                                        'E09.69', 'E13.618', 
                                        'E13.620', 
                                        'E13.621', 
                                        'E13.622', 'E13.628', 
                                        'E13.630', 
                                        'E13.638', 
                                        'E13.649', 'E13.65', 
                                        'E13.69', 
                                        'E08.8', 
                                        'E09.8', 'E13.8', 'E11.9' 
                                        , 
                                        'E10.9', 
                                        'E11.65', 'E10.65', 
                                        'E11.69' 
                                        , 
                                        'E10.10', 
                                        'E11.00', 'E11.01', 
                                        'E10.69' 
                                        , 
                                        'E11.641', 
                                        'E10.11', 'E10.641', 
                                        'E11.21', 
                                        'E11.22', 
                                        'E11.29', 'E11.311', 
                                        'E11.319', 
                                        'E11.321', 
                                        'E11.329', 'E11.331', 
                                        'E11.339', 
                                        'E11.341', 
                                        'E11.349', 'E11.351', 
                                        'E11.359', 
                                        'E11.36', 
                                        'E11.39', 'E10.311', 
                                        'E10.319', 
                                        'E10.321', 
                                        'E10.329', 'E10.331', 
                                        'E10.339', 
                                        'E10.341', 
                                        'E10.349', 'E10.351', 
                                        'E10.359', 
                                        'E10.36', 
                                        'E10.39', 'E11.40', 
                                        'E11.41' 
                                        , 
                                        'E11.42', 
                                        'E11.43', 'E11.44', 
                                        'E11.49' 
                                        , 
                                        'E11.610', 
                                        'E10.40', 'E10.41', 
                                        'E10.42' 
                                        , 
                                        'E10.43', 
                                        'E10.44', 'E10.49', 
                                        'E10.610', 
                                        'E11.51', 
                                        'E11.52', 'E11.59', 
                                        'E10.51' 
                                        , 
                                        'E10.52', 
                                        'E10.59', 'E11.618', 
                                        'E11.620', 
                                        'E11.621', 
                                        'E11.622', 'E11.628', 
                                        'E11.630', 
                                        'E11.638', 
                                        'E11.649', 'E10.618', 
                                        'E10.620', 
                                        'E10.621', 
                                        'E10.622', 'E10.628', 
                                        'E10.630', 
                                        'E10.638', 
                                        'E10.649', 'E11.8', 
                                        'E10.8' 
                                                          ) 
                                        AND eventstartdate >= Dateadd(year, -3, 
                                                              Getdate( 
                                                              )))), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '3044F', '3045F', '3046F' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--COMPREHENSIVE DIABETES CARE: MEDICAL ATTENTION FOR NEPHROPATHY 
WITH cte_denominator 
     AS (SELECT 'COMPREHENSIVE DIABETES CARE: MEDICAL ATTENTION FOR NEPHROPATHY' 
                AS 
                measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1 
                AS 
                   denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%') 
                AND personid IN (SELECT personid 
                                 FROM   acpps_client_prd01..personevents 
                                 WHERE  eventcodevalue IN ( 
                                        'E08.9', 'E09.9', 'E13.9' 
                                        , 
                                        'E08.65', 
                                        'E09.65', 'E08.10', 
                                        'E09.10' 
                                        , 
                                        'E13.10', 
                                        'E08.00', 'E08.01', 
                                        'E09.00' 
                                        , 
                                        'E09.01', 
                                        'E13.00', 'E13.01', 
                                        'E08.11' 
                                        , 
                                        'E08.641', 
                                        'E09.11', 'E09.641', 
                                        'E13.11', 
                                        'E13.641' 
                                        , 
                                        'E08.21', 'E08.22', 
                                        'E08.29' 
                                        , 
                                        'E09.21', 
                                        'E09.22', 'E09.29', 
                                        'E13.21' 
                                        , 
                                        'E13.22', 
                                        'E13.29', 'E08.311', 
                                        'E08.319', 
                                        'E08.321', 
                                        'E08.329', 'E08.331', 
                                        'E08.339', 
                                        'E08.341', 
                                        'E08.349', 'E08.351', 
                                        'E08.359', 
                                        'E08.36', 
                                        'E08.39', 'E09.311', 
                                        'E09.319', 
                                        'E09.321', 
                                        'E09.329', 'E09.331', 
                                        'E09.339', 
                                        'E09.341', 
                                        'E09.349', 'E09.351', 
                                        'E09.359', 
                                        'E09.36', 
                                        'E09.39', 'E13.311', 
                                        'E13.319', 
                                        'E13.321', 
                                        'E13.329', 'E13.331', 
                                        'E13.339', 
                                        'E13.341', 
                                        'E13.349', 'E13.351', 
                                        'E13.359', 
                                        'E13.36', 
                                        'E13.39', 'E08.40', 
                                        'E08.41' 
                                        , 
                                        'E08.42', 
                                        'E08.43', 'E08.44', 
                                        'E08.49' 
                                        , 
                                        'E08.610', 
                                        'E09.40', 'E09.41', 
                                        'E09.42' 
                                        , 
                                        'E09.43', 
                                        'E09.44', 'E09.49', 
                                        'E09.610', 
                                        'E13.40', 
                                        'E13.41', 'E13.42', 
                                        'E13.43' 
                                        , 
                                        'E13.44', 
                                        'E13.49', 'E13.610', 
                                        'E08.51', 
                                        'E08.52', 
                                        'E08.59', 'E09.51', 
                                        'E09.52' 
                                        , 
                                        'E09.59', 
                                        'E13.51', 'E13.52', 
                                        'E13.59' 
                                        , 
                                        'E08.618', 
                                        'E08.620', 'E08.621', 
                                        'E08.622', 
                                        'E08.628', 
                                        'E08.630', 'E08.638', 
                                        'E08.649', 
                                        'E08.69', 
                                        'E09.618', 'E09.620', 
                                        'E09.621', 
                                        'E09.622', 
                                        'E09.628', 'E09.630', 
                                        'E09.638', 
                                        'E09.649', 
                                        'E09.69', 'E13.618', 
                                        'E13.620', 
                                        'E13.621', 
                                        'E13.622', 'E13.628', 
                                        'E13.630', 
                                        'E13.638', 
                                        'E13.649', 'E13.65', 
                                        'E13.69', 
                                        'E08.8', 
                                        'E09.8', 'E13.8', 'E11.9' 
                                        , 
                                        'E10.9', 
                                        'E11.65', 'E10.65', 
                                        'E11.69' 
                                        , 
                                        'E10.10', 
                                        'E11.00', 'E11.01', 
                                        'E10.69' 
                                        , 
                                        'E11.641', 
                                        'E10.11', 'E10.641', 
                                        'E11.21', 
                                        'E11.22', 
                                        'E11.29', 'E11.311', 
                                        'E11.319', 
                                        'E11.321', 
                                        'E11.329', 'E11.331', 
                                        'E11.339', 
                                        'E11.341', 
                                        'E11.349', 'E11.351', 
                                        'E11.359', 
                                        'E11.36', 
                                        'E11.39', 'E10.311', 
                                        'E10.319', 
                                        'E10.321', 
                                        'E10.329', 'E10.331', 
                                        'E10.339', 
                                        'E10.341', 
                                        'E10.349', 'E10.351', 
                                        'E10.359', 
                                        'E10.36', 
                                        'E10.39', 'E11.40', 
                                        'E11.41' 
                                        , 
                                        'E11.42', 
                                        'E11.43', 'E11.44', 
                                        'E11.49' 
                                        , 
                                        'E11.610', 
                                        'E10.40', 'E10.41', 
                                        'E10.42' 
                                        , 
                                        'E10.43', 
                                        'E10.44', 'E10.49', 
                                        'E10.610', 
                                        'E11.51', 
                                        'E11.52', 'E11.59', 
                                        'E10.51' 
                                        , 
                                        'E10.52', 
                                        'E10.59', 'E11.618', 
                                        'E11.620', 
                                        'E11.621', 
                                        'E11.622', 'E11.628', 
                                        'E11.630', 
                                        'E11.638', 
                                        'E11.649', 'E10.618', 
                                        'E10.620', 
                                        'E10.621', 
                                        'E10.622', 'E10.628', 
                                        'E10.630', 
                                        'E10.638', 
                                        'E10.649', 'E11.8', 
                                        'E10.8' 
                                                          ) 
                                        AND eventstartdate >= Dateadd(year, -3, 
                                                              Getdate( 
                                                              )))), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '3060F', '3061F', '3062F', '3066F' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--PREVENTIVE CARE AND SCREENING: TOBACCO USE: SCREENING AND CESSATION INTERVENTION 
WITH cte_denominator 
     AS (SELECT 
'PREVENTIVE CARE AND SCREENING: TOBACCO USE: SCREENING AND CESSATION INTERVENTION' 
  AS measure, 
personid, 
memberid, 
memberno, 
NAME, 
dob, 
age, 
sex, 
startdate, 
enddate, 
planpayer, 
quotename(planproduct, '"') as planproduct, 
1 AS denominator 
 FROM   acpps_client_prd01..personattribution 
 WHERE  planpayer = 'Health First' 
        AND planproduct LIKE 'Hf | Somos%' 
        AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
            CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                  FROM 
                acpps_client_prd01..personattribution 
                                                  WHERE 
            planpayer = 'Health First' 
            AND planproduct LIKE 
                'Hf | Somos%') 
        AND personid IN (SELECT personid 
                         FROM   acpps_client_prd01..personevents 
                         WHERE  eventcodevalue IN ( 'F17.200', 'F17.201', 
                                                    'F17.210', 
                                                    'F17.211', 
                                                    'F17.220', 'F17.221', 
                                                    'F17.290', 
                                                    'F17.291' ))), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '99406', '99407', '4000F', '4001F', 
                                    '4004F', 'S9075', 'S9453', 'G0436', 'G0437' 
                                  ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--USE OF SPIROMETRY TESTING IN THE ASSESSMENT AND DIAGNOSIS OF COPD 
WITH cte_denominator 
     AS (SELECT 
     'USE OF SPIROMETRY TESTING IN THE ASSESSMENT AND DIAGNOSIS OF COPD' AS 
     measure, 
     personid, 
     memberid, 
     memberno, 
     NAME, 
     dob, 
     age, 
     sex, 
     startdate, 
     enddate, 
     planpayer, 
     quotename(planproduct, '"') as planproduct, 
     1 
     AS 
        denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%') 
                AND personid IN (SELECT personid 
                                 FROM   acpps_client_prd01..personevents 
                                 WHERE  eventcodevalue IN ( 
                                        'J41.0', 'J41.1', 'J41.8' 
                                        , 
                                        'J42', 
                                        'J43.0', 'J43.1', 'J43.2' 
                                        , 
                                        'J43.8', 
                                        'J43.9', 'J44.0', 'J44.1' 
                                        , 
                                        'J44.9' ) 
                                        AND eventstartdate >= Dateadd(year, -3, 
                                                              Getdate( 
                                                              )) 
                                        AND eventsourcetable = 't_assessment') 
                AND personid IN (SELECT personid 
                                 FROM   acpps_client_prd01..personevents 
                                 WHERE  eventcodevalue IN ( 
                                        '90791', '90792', '90832' 
                                        , 
                                        '90833', 
                                        '90834', '90835', '90836' 
                                        , 
                                        '90837', 
                                        '90838', '90839', '90840' 
                                        , 
                                        '90845', 
                                        '90846', '90847', '90849' 
                                        , 
                                        '90853', 
                                        '90875', '90876', '98966' 
                                        , 
                                        '98967', 
                                        '98968', '99221', '99222' 
                                        , 
                                        '99223', 
                                        '99231', '99232', '99233' 
                                        , 
                                        '99238', 
                                        '99239', '99251', '99252' 
                                        , 
                                        '99253', 
                                        '99254', '99255', '99381' 
                                        , 
                                        '99382', 
                                        '99383', '99384', '99385' 
                                        , 
                                        '99386', 
                                        '99387', '99391', '99392' 
                                        , 
                                        '99393', 
                                        '99394', '99395', '99396' 
                                        , 
                                        '99397', 
                                        '99441', '99442', '99443' 
                                        , 
                                        'G0438', 
                                        'G0439' ) 
                                        AND eventstartdate >= Dateadd(year, -3, 
                                                              Getdate( 
                                                              )) 
                                        AND eventsourcetable = 't_chargecapture' 
                                )), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN ( '94010', '94014', '94015', '94016', 
                                    '94060', '94070', '94375', '94620' ) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

--ANNUAL DENTAL VISIT 
WITH cte_denominator 
     AS (SELECT 'ANNUAL DENTAL VISIT' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                     AS denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND age BETWEEN 2 AND 20 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%') 
                AND personid IN (SELECT personid 
                                 FROM   acpps_client_prd01..personevents 
                                 WHERE  eventcodevalue IN ( 'F17.200', 'F17.201' 
                                                            , 
                                                            'F17.210', 
                                                            'F17.211', 
                                                            'F17.220', 'F17.221' 
                                                            , 
                                                            'F17.290', 
                                                            'F17.291' ) 
                                        AND eventstartdate >= Dateadd(year, -2, 
                                                              Getdate( 
                                                              )))), 
     cte_numerator 
     AS (SELECT personid, 
                eventid, 
                eventstartdate, 
                eventenddate, 
                eventcodevalue, 
                eventsourcesystem, 
                eventprovidername, 
                eventprovidernpi, 
                eventlocationname, 
                Rank() 
                  OVER ( 
                    partition BY personid 
                    ORDER BY eventenddate DESC, eventid DESC ) AS person_rank, 
                1                                              AS numerator, 
                icd10_code 
         FROM   acpps_client_prd01..personevents pe 
                INNER JOIN t_chargecapture tc 
                        ON pe.eventsourcerecordid = tchargecaptureid 
                INNER JOIN t_assessment ta 
                        ON tc.cc_enc_id = ta.encounter_id 
         WHERE  eventcodevalue IN (SELECT 'D' + CONVERT(VARCHAR(10), seq) 
                                   FROM   (SELECT Row_number() 
                                                    OVER ( 
                                                      ORDER BY enc_id ) AS seq 
                                           FROM   t_encounter) a 
                                   WHERE  seq BETWEEN 120 AND 9999) 
                AND eventcodeset = 'CPT' 
                AND eventsourcetable = 't_chargecapture' 
                AND Datepart(year, eventenddate) = Datepart(year, Getdate()) 
                AND personid IN (SELECT personid 
                                 FROM   cte_denominator) 
                AND primary_diagnosis_ind = 1 
                AND ta.delete_ind = 'N') 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.eventstartdate, 
       eventenddate, 
       eventcodevalue, 
       eventsourcesystem, 
       eventprovidername, 
       eventprovidernpi, 
       eventlocationname, 
       t2.numerator, 
       icd10_code 
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.personid 
                       AND t2.person_rank = 1; 

WITH cte_dtap 
     AS (SELECT person_id, 
                Max(cc_id) AS cc_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '90698', '90700', '90721', '90723' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 4), 
     cte_ipv 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '10', '110', '120', '90698', 
                                 '90713', '90723' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 3), 
     cte_hepb 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '08', '110', '44', '51', 
                                 '90723', '90740', '90744', '90747', 
                                 '90748', 'G0010' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 3), 
     cte_inf 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '135', '140', '141', '153', 
                                 '155', '161', '166', '90655', 
                                 '90657', '90661', '90662', '90673', 
                                 '90685', '90687', 'G0008' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 2), 
     cte_pcv 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '100', '133', '90669', '90670', 'G0009' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 4), 
     cte_hib 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '120', '148', '46', '47', 
                                 '48', '49', '50', '51', 
                                 '90644', '90645', '90646', '90647', 
                                 '90648', '90698', '90721', '90748' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 3), 
     cte_rota 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '119', '116', '90681', '90680' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 3), 
     cte_hepa 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '83', '90633' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 1), 
     cte_vzv 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '21', '90710', '90716', '94' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 1), 
     cte_mmr 
     AS (SELECT person_id 
         FROM   t_chargecapture cc 
                INNER JOIN mpi.person_patient pp 
                        ON cc.cc_patient_id = pp.pat_id 
         WHERE  cc_cpt_code IN ( '03', '90707', '90710', '94' ) 
         GROUP  BY person_id 
         HAVING Count(*) >= 1), 
     --CHILDHOOD IMMUNIZATION STATUS 
     cte_denominator 
     AS (SELECT 'CHILDHOOD IMMUNIZATION STATUS' AS measure, 
                personid, 
                memberid, 
                memberno, 
                NAME, 
                dob, 
                age, 
                sex, 
                startdate, 
                enddate, 
                planpayer, 
                quotename(planproduct, '"') as planproduct, 
                1                               AS denominator 
         FROM   acpps_client_prd01..personattribution 
         WHERE  age = 2 
                AND planpayer = 'Health First' 
                AND planproduct LIKE 'Hf | Somos%' 
                AND CONVERT(VARCHAR(10), enddate, 101) = (SELECT 
                    CONVERT(VARCHAR(10), Max(enddate), 101) 
                                                          FROM 
                        acpps_client_prd01..personattribution 
                                                          WHERE 
                    planpayer = 'Health First' 
                    AND planproduct LIKE 
                        'Hf | Somos%')), 
     cte_numerator 
     AS (SELECT cte_1.person_id, 
                cc.cc_id, 
                cc.cc_date_of_service, 
                cc_cpt_code, 
                site_center_name, 
                pm.prov_fullname, 
                pm.prov_npi, 
                NULL AS eventlocationname, 
                1    AS numerator,
                NULL as icd10
         FROM   cte_dtap cte_1 
                INNER JOIN cte_ipv cte_2 
                        ON cte_1.person_id = cte_2.person_id 
                INNER JOIN cte_hepb cte_3 
                        ON cte_1.person_id = cte_3.person_id 
                INNER JOIN cte_hepb cte_4 
                        ON cte_1.person_id = cte_4.person_id 
                INNER JOIN cte_inf cte_5 
                        ON cte_1.person_id = cte_5.person_id 
                INNER JOIN cte_pcv cte_6 
                        ON cte_1.person_id = cte_6.person_id 
                INNER JOIN cte_hib cte_7 
                        ON cte_1.person_id = cte_7.person_id 
                INNER JOIN cte_rota cte_8 
                        ON cte_1.person_id = cte_8.person_id 
                INNER JOIN cte_hepa cte_9 
                        ON cte_1.person_id = cte_9.person_id 
                INNER JOIN cte_vzv cte_10 
                        ON cte_1.person_id = cte_10.person_id 
                INNER JOIN cte_mmr cte_11 
                        ON cte_1.person_id = cte_11.person_id 
                INNER JOIN t_chargecapture cc 
                        ON cte_1.cc_id = cc.cc_id 
                INNER JOIN t_encounter ec 
                        ON cc.cc_enc_id = ec.enc_id 
                INNER JOIN site_master sm 
                        ON ec.enc_site_id = sm.site_id 
                INNER JOIN provider_master pm 
                        ON ec.enc_rendering_provider_id = pm.prov_id) 
INSERT acpps_sandbox_prd01..temp_cag_arcadia 
SELECT t1.*, 
       t2.cc_date_of_service AS eventstartdate, 
       t2.cc_date_of_service AS eventenddate, 
       cc_cpt_code           AS eventcodevalue, 
       site_center_name      AS eventsourcesystem, 
       prov_fullname         AS eventprovidername, 
       prov_npi              AS eventprovidernpi, 
       eventlocationname, 
       t2.numerator,
       icd10
FROM   cte_denominator t1 
       LEFT OUTER JOIN cte_numerator t2 
                    ON t1.personid = t2.person_id ;

SELECT * 
FROM   acpps_sandbox_prd01..temp_cag_arcadia;
