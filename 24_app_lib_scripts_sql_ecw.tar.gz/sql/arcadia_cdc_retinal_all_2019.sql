SELECT DISTINCT cc_patient_id, 
                Cast(cc_date_of_service AS DATE) 
FROM   t_chargecapture 
WHERE  cc_date_of_service >= '2019-01-01' 
       AND cc_cpt_code = '2022F' 
       AND cc_delete_ind = 'N' 
