SELECT quotename(pat_first_name, '"') as c1,
       quotename(pat_last_name, '"') as c2, 
       quotename(pat_middle_name, '"') as c3, 
       pat_date_of_birth as c4, 
       quotename(pat_id, '"') as c5, 
       enc_timestamp as c6, 
       quotename(enc_location_id, '"') as c7, 
       quotename(enc_location_unscrubbed, '"') as c8, 
       quotename(prov_npi, '"') as c9, 
       quotename(prov_first_name, '"') as c10, 
       quotename(prov_last_name, '"') as c11
FROM   t_patient AS a 
       JOIN t_encounter AS b 
         ON enc_patient_id = pat_id 
       JOIN provider_master AS c 
         ON prov_id = enc_rendering_provider_id 
WHERE  enc_timestamp BETWEEN '2017-04-01' AND '2018-03-31' 
       AND Len(prov_npi) = 10 
       AND enc_location_id IS NOT NULL
       AND pat_date_of_birth IS NOT NULL
