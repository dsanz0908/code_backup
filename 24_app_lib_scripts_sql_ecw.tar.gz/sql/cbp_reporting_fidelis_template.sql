unload ($$
WITH cte_cpt_codes 
     AS (SELECT orig_member_id, 
                vitals_date, 
                cpt_code, 
                Dense_rank() 
                  OVER( 
                    partition BY orig_member_id, vitals_date 
                    ORDER BY cpt_code) AS r 
         FROM   cbp_reporting_new 
         WHERE  vitals_systolic IS NOT NULL 
                AND vitals_diastolic IS NOT NULL 
                AND orig_member_id IS NOT NULL 
                AND EXISTS (SELECT 1 
                            FROM   procedure_code_crosswalk 
                            WHERE  cpt_code = proc_code)), 
     cte_cpt_codes_2 
     AS (SELECT orig_member_id, 
                vitals_date, 
                Max(CASE 
                      WHEN r = 1 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd, 
                Max(CASE 
                      WHEN r = 2 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd2, 
                Max(CASE 
                      WHEN r = 3 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd3, 
                Max(CASE 
                      WHEN r = 4 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd4, 
                Max(CASE 
                      WHEN r = 5 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd5, 
                Max(CASE 
                      WHEN r = 6 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd6, 
                Max(CASE 
                      WHEN r = 7 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd7, 
                Max(CASE 
                      WHEN r = 8 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd8, 
                Max(CASE 
                      WHEN r = 9 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd9 
         FROM   cte_cpt_codes 
         GROUP  BY orig_member_id, 
                   vitals_date), 
     cte_cpt_codes_3 
     AS (SELECT orig_member_id, 
                vitals_date, 
                Max(CASE 
                      WHEN r = 10 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd, 
                Max(CASE 
                      WHEN r = 11 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd2, 
                Max(CASE 
                      WHEN r = 12 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd3, 
                Max(CASE 
                      WHEN r = 13 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd4, 
                Max(CASE 
                      WHEN r = 14 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd5, 
                Max(CASE 
                      WHEN r = 15 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd6, 
                Max(CASE 
                      WHEN r = 16 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd7, 
                Max(CASE 
                      WHEN r = 17 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd8, 
                Max(CASE 
                      WHEN r = 18 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd9 
         FROM   cte_cpt_codes 
         GROUP  BY orig_member_id, 
                   vitals_date), 
     cte_cpt_codes_4 
     AS (SELECT orig_member_id, 
                vitals_date, 
                Max(CASE 
                      WHEN r = 19 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd, 
                Max(CASE 
                      WHEN r = 20 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd2, 
                Max(CASE 
                      WHEN r = 21 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd3, 
                Max(CASE 
                      WHEN r = 22 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd4, 
                Max(CASE 
                      WHEN r = 23 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd5, 
                Max(CASE 
                      WHEN r = 24 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd6, 
                Max(CASE 
                      WHEN r = 25 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd7, 
                Max(CASE 
                      WHEN r = 26 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd8, 
                Max(CASE 
                      WHEN r = 27 THEN cpt_code 
                      ELSE NULL 
                    END) AS proc_cd9 
         FROM   cte_cpt_codes 
         GROUP  BY orig_member_id, 
                   vitals_date), 
     cte_cpt_all 
     AS (SELECT * 
         FROM   cte_cpt_codes_2 
         UNION 
         SELECT * 
         FROM   cte_cpt_codes_3 
         UNION 
         SELECT * 
         FROM   cte_cpt_codes_4) 
SELECT DISTINCT NULL                                 AS facility_id,
                provider_npi                         AS facility_npi, 
                NULL                                 AS pat_acct_no, 
                To_char(b.vitals_date, 'MM/DD/YYYY') AS date_of_service, 
                last_name                            AS pt_last_name, 
                first_name                           AS pt_first_name, 
                unique_member_id                     AS member_id, 
                provider_name                        AS att_prov_name, 
                lpad(member_pcp_id::text, 12, '0')::text                        AS fideliscare_prov_id, 
                provider_npi,
                '11'                                 AS pos, 
                proc_cd, 
                proc_cd2, 
                proc_cd3, 
                proc_cd4, 
                proc_cd5, 
                proc_cd6, 
                proc_cd7, 
                proc_cd8, 
                proc_cd9, 
                '0'                                  AS icd_version, 
                icd10_code                           AS trndx1_code, 
                icd10_code_2                         AS trndx2_code, 
                icd10_code_3                         AS trndx3_code, 
                icd10_code_4                         AS trndx4_code, 
                NULL                                 AS icd9_proc1, 
                NULL                                 AS icd9_proc2, 
                'CBP'                                AS test, 
                vitals_systolic                      AS result1, 
                vitals_diastolic                     AS result2, 
                'mmHg'                           AS units, 
                NULL                                 AS tot_chg_amt, 
                '30'                                 AS patient_status, 
                NULL                                 AS fileformat, 
                'E'                                  AS file_type, 
                NULL                                 AS tos, 
                'N'                                  AS reversal_flag, 
                NULL                                 AS modifier_code 
FROM   payor.fideliscare_prod_membership_full_somos_20150101_20180928 AS a 
       JOIN cbp_reporting_new AS b 
         ON a.alternate_member_id = b.orig_member_id 
       JOIN payor.fideliscare_prod_memberpcp_full_somos_20150101_20180928 AS c 
         ON a.member_id = c.member_id 
       JOIN cte_cpt_all AS d 
         ON b.orig_member_id = d.orig_member_id 
            AND b.vitals_date = d.vitals_date 
WHERE  mco = 'NY State Claims' 
       AND vitals_systolic IS NOT NULL 
       AND vitals_diastolic IS NOT NULL 
       AND proc_cd is not null
UNION 
SELECT DISTINCT NULL                                 AS facility_id, 
                provider_npi                         AS facility_npi, 
                NULL                                 AS pat_acct_no, 
                To_char(b.vitals_date, 'MM/DD/YYYY') AS date_of_service, 
                last_name                            AS pt_last_name, 
                first_name                           AS pt_first_name, 
                unique_member_id                AS member_id, 
                provider_name                        AS att_prov_name, 
                lpad(member_pcp_id::text, 12, '0')::text                        AS fideliscare_prov_id, 
                provider_npi,
                '11'                                 AS pos, 
                proc_cd, 
                proc_cd2, 
                proc_cd3, 
                proc_cd4, 
                proc_cd5, 
                proc_cd6, 
                proc_cd7, 
                proc_cd8, 
                proc_cd9, 
                '0'                                  AS icd_version, 
                icd10_code                           AS trndx1_code, 
                icd10_code_2                         AS trndx2_code, 
                icd10_code_3                         AS trndx3_code, 
                icd10_code_4                         AS trndx4_code, 
                NULL                                 AS icd9_proc1, 
                NULL                                 AS icd9_proc2, 
                'CBP'                                AS test, 
                vitals_systolic                      AS result1, 
                vitals_diastolic                     AS result2, 
                'mmHG'                           AS units, 
                NULL                                 AS tot_chg_amt, 
                '30'                                 AS patient_status, 
                NULL                                 AS fileformat, 
                'E'                                  AS file_type, 
                NULL                                 AS tos, 
                'N'                                  AS reversal_flag, 
                NULL                                 AS modifier_code 
FROM   payor.fideliscare_prod_membership_full_somos_20150101_20180928 AS a 
       INNER JOIN cbp_reporting_new AS b 
               ON Upper(Substring(pat_first_name, 1, 3)) = Upper(Substring(first_name, 1, 3)) 
                  AND Upper(Substring(pat_last_name, 1, 3)) = Upper(Substring(last_name, 1, 3))
                  AND Cast(dob AS DATE) = Cast(birth_date AS DATE) 
       INNER JOIN payor.fideliscare_prod_memberpcp_full_somos_20150101_20180928 AS c 
               ON a.member_id = c.member_id 
       INNER JOIN cte_cpt_all AS d 
               ON b.orig_member_id = d.orig_member_id 
                  AND b.vitals_date = d.vitals_date 
WHERE  mco IS NULL 
       AND vitals_systolic IS NOT NULL 
       AND vitals_diastolic IS NOT NULL 
       AND proc_cd is not null
$$)
TO 's3://acp-data/CBP/cbp_reporting_fidelis_TODAY_' delimiter '|' gzip parallel OFF allowoverwrite iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';

