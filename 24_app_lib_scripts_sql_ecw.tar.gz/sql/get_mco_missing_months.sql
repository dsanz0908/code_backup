SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(period), 'YYYYMM')) AS INT) FROM payor.affinity_corinthian_all_rosters
