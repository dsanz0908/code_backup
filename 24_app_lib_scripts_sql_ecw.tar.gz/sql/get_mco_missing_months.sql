SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(received_month), 'YYYYMM')) AS INT) FROM payor.empire_somos_claim_det
