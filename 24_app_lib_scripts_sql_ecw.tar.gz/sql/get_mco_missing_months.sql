SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(received_month), 'YYYYMM')) AS INT) FROM payor.empire_bcbs_healthplus_somos_all_roster
