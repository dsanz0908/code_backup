SELECT Cast(Months_between(Dateadd(month, -1, Getdate()), To_date(Max(period), 'YYYYMM')) AS INT) FROM payor.affinity_somos_roster_all
