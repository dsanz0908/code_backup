SELECT pat_id, 
       Cast(enc_timestamp AS DATE) AS dos, 
       pat_original_id, 
       pat_medical_record_number, 
       site_emr_name, 
       pat_race, 
       pat_language, 
       pat_ssn, 
       pat_ethnicity, 
       site_center_name, 
       enc_original_id, 
       site_id, 
       enc_type_description, 
       enc_reason, 
       vitals_height, 
       vitals_height_unit, 
       vitals_weight, 
       vitals_weight_unit, 
       vitals_bmi, 
       'kg/m2'                     AS vitals_bmi_unit, 
       vitals_systolic, 
       'mmHg'                      AS vitals_systolic_unit, 
       vitals_diastolic, 
       'mmHg'                      AS vitals_diastolic_unit, 
       vitals_temperature, 
       vitals_temperature_units, 
       vitals_heart_rate, 
       'bmp'                       AS vitals_heart_rate_unit, 
       vitals_spo2, 
       '%'                         AS vitals_spo2_unit 
FROM   t_encounter 
       JOIN t_patient 
         ON enc_patient_id = pat_id 
       JOIN site_master 
         ON enc_site_id = site_id 
       JOIN t_vitals 
         ON vitals_enc_id = enc_id 
WHERE  Year(enc_timestamp) = 2019 
and pat_delete_ind = 'N' and site_delete_ind = 'N'
and 
