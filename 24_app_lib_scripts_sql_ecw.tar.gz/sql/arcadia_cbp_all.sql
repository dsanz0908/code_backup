SELECT DISTINCT pat_id, 
                vitals_date,
                vitals_systolic, 
                vitals_diastolic 
FROM   t_patient 
       JOIN t_vitals 
         ON pat_id = vitals_patient_id 
WHERE  vitals_delete_ind = 'N' 
       AND vitals_systolic <> '' 
       AND vitals_diastolic <> ''
