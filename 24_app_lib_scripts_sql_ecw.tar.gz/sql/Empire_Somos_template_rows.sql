SELECT CASE 
         WHEN tgt_data_type <> '' THEN 'Case when trim(' 
                                       || src_column_name 
                                       || ') = ''''   then NULL else ' 
                                       || ' CAST ( ' 
                                       || src_column_name 
                                       || ' AS ' 
                                       || tgt_data_type 
                                       || ' ) end ' 
         WHEN tgt_column_name = 'received_month' THEN 'RECEIVEDMONTH' 
         WHEN tgt_column_name = 'filename' THEN 'FILENAME' 
         ELSE src_column_name 
       END 
       || ',' 
FROM   mco_file_to_table_mapping 
WHERE  mco_name = 'Empire_Somos' 
       AND Lower(file_type) = 'FILETYPE' 
ORDER  BY column_order 
