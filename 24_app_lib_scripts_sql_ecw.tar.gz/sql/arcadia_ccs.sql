WITH a 
     AS (SELECT pat_id, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                cc_date_of_service, 
                cc_cpt_code 
         FROM   t_chargecapture 
                JOIN t_patient 
                  ON cc_patient_id = pat_id 
         WHERE  cc_delete_ind = 'N' 
                AND cc_date_of_service BETWEEN '2015-01-01' AND '2019-12-31' 
                AND cc_cpt_code IN ( '77055', '77056', '77057', '77061', 
                                     '77062', '77063', '77065', '77066', 
                                     '77067', 'G0202', 'G0204', 'G0206' ) 
                AND pat_delete_ind = 'N'), 
     b 
     AS (SELECT pat_id, 
                pat_first_name, 
                pat_last_name, 
                pat_date_of_birth, 
                cc_date_of_service, 
                cc_cpt_code 
         FROM   t_chargecapture 
                JOIN t_patient 
                  ON cc_patient_id = pat_id 
         WHERE  cc_delete_ind = 'N' 
                AND cc_date_of_service BETWEEN '2015-01-01' AND '2019-12-31' 
                AND cc_cpt_code IN ( '87620', '87621', '87622', '87624', 
                                     '87625', 'G0476' ) 
                AND pat_delete_ind = 'N') 
SELECT DISTINCT pat_first_name, 
                pat_last_name, 
                cast(pat_date_of_birth as date) as dob,
                cast(cc_date_of_service as date) as dos, 
                cc_cpt_code 
FROM   (SELECT *, 
               Row_number() 
                 OVER ( 
                   partition BY pat_first_name, pat_last_name, pat_date_of_birth 
                   ORDER BY cc_date_of_service DESC) AS rn 
        FROM   (SELECT a.pat_first_name, 
                       a. pat_last_name, 
                       a. pat_date_of_birth, 
                       a. cc_date_of_service, 
                       a. cc_cpt_code 
                FROM   a 
                       JOIN b 
                         ON a.pat_id = b.pat_id 
                UNION ALL 
                SELECT pat_first_name, 
                       pat_last_name, 
                       pat_date_of_birth, 
                       cc_date_of_service, 
                       cc_cpt_code 
                FROM   t_chargecapture 
                       JOIN t_patient 
                         ON cc_patient_id = pat_id 
                WHERE  cc_delete_ind = 'N' 
                       AND cc_date_of_service BETWEEN '2017-01-01' AND '2019-12-31' 
                       AND cc_cpt_code IN ( '77055', '77056', '77057', '77061', 
                                            '77062', '77063', '77065', '77066', 
                                            '77067', 'G0202', 'G0204', 'G0206' ) 
                       AND pat_delete_ind = 'N') AS t1) AS t2 
WHERE  rn = 1 
