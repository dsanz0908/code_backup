WITH cte_patients 
     AS (SELECT pat_id, 
                Max(last_dos) AS last_dos 
         FROM   (SELECT pat_id, 
                        Max(cc_date_of_service) AS last_dos 
                 FROM   t_chargecapture 
                        JOIN t_patient 
                          ON pat_id = cc_patient_id 
                 WHERE  pat_delete_ind = 'N' 
                        AND cc_delete_ind = 'N' 
                        AND pat_date_of_birth BETWEEN '2017-01-01' AND '2017-12-31' 
                        AND cc_cpt_code IN ( '90698', '90700', '90721', '90723' ) 
                 GROUP  BY pat_id 
                 HAVING Count(DISTINCT cc_date_of_service) >= 4 
                 UNION ALL 
                 SELECT pat_id, 
                        Max(cc_date_of_service) 
                 FROM   t_chargecapture 
                        JOIN t_patient 
                          ON pat_id = cc_patient_id 
                 WHERE  pat_delete_ind = 'N' 
                        AND cc_delete_ind = 'N' 
                        AND pat_date_of_birth BETWEEN '2017-01-01' AND '2017-12-31' 
                        AND cc_cpt_code IN ( '90698', '90713', '90723' ) 
                 GROUP  BY pat_id 
                 HAVING Count(DISTINCT cc_date_of_service) >= 3 
                 UNION ALL 
                 SELECT pat_id, 
                        Max(cc_date_of_service) 
                 FROM   t_chargecapture 
                        JOIN t_patient 
                          ON pat_id = cc_patient_id 
                 WHERE  pat_delete_ind = 'N' 
                        AND cc_delete_ind = 'N' 
                        AND pat_date_of_birth BETWEEN '2017-01-01' AND '2017-12-31' 
                        AND cc_cpt_code IN ( '90723', '90740', '90744', '90747', 
                                             '90748', 'G0010' ) 
                 GROUP  BY pat_id 
                 HAVING Count(DISTINCT cc_date_of_service) >= 2 
                 UNION ALL 
                 SELECT pat_id, 
                        Max(cc_date_of_service) 
                 FROM   t_chargecapture 
                        JOIN t_patient 
                          ON pat_id = cc_patient_id 
                 WHERE  pat_delete_ind = 'N' 
                        AND cc_delete_ind = 'N' 
                        AND pat_date_of_birth BETWEEN '2017-01-01' AND '2017-12-31' 
                        AND cc_cpt_code IN ( '90644', '90645', '90646', '90647', 
                                             '90698', '90721', '90748' ) 
                 GROUP  BY pat_id 
                 HAVING Count(DISTINCT cc_date_of_service) >= 4 
                 UNION ALL 
                 SELECT pat_id, 
                        Max(cc_date_of_service) 
                 FROM   t_chargecapture 
                        JOIN t_patient 
                          ON pat_id = cc_patient_id 
                 WHERE  pat_delete_ind = 'N' 
                        AND cc_delete_ind = 'N' 
                        AND pat_date_of_birth BETWEEN '2017-01-01' AND '2017-12-31' 
                        AND cc_cpt_code IN ( '90669', '90670', 'G0009' ) 
                 GROUP  BY pat_id 
                 HAVING Count(DISTINCT cc_date_of_service) >= 2 
                 UNION ALL 
                 SELECT pat_id, 
                        Max(cc_date_of_service) 
                 FROM   t_chargecapture 
                        JOIN t_patient 
                          ON pat_id = cc_patient_id 
                 WHERE  pat_delete_ind = 'N' 
                        AND cc_delete_ind = 'N' 
                        AND pat_date_of_birth BETWEEN '2017-01-01' AND '2017-12-31' 
                        AND cc_cpt_code IN ( '90710', '90716', '90707' ) 
                 GROUP  BY pat_id 
                 HAVING Count(DISTINCT cc_date_of_service) >= 1) AS a 
         GROUP  BY pat_id 
         HAVING Count(*) = 6) 
SELECT DISTINCT t_patient.pat_id, 
                pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE) dob, 
                last_dos, 
                '90700', 
                prov_npi, 
                prov_fullname, 
                prov_specialty_1 
FROM   cte_patients 
       JOIN t_patient 
         ON cte_patients.pat_id = t_patient.pat_id 
       JOIN provider_master 
         ON pat_responsible_provider_id = prov_id 
