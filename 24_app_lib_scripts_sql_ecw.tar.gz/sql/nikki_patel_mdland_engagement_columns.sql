drop table feeds.nikki_patel_mdland_engagement;
create table if not exists feeds.nikki_patel_mdland_engagement ( 
id VARCHAR(255), clinic  VARCHAR(255), clinicname VARCHAR(255), patientid  VARCHAR(255), patientname VARCHAR(255), dob VARCHAR(255), dos VARCHAR(255), address VARCHAR(255), city VARCHAR(255), state VARCHAR(255), zipcode VARCHAR(255), phone VARCHAR(255), pcp VARCHAR(255), pcp_npi VARCHAR(255), engagementtype VARCHAR(255), codetype VARCHAR(255), specificcode VARCHAR(255), insurance1 VARCHAR(255), insuredid1 VARCHAR(255), insurance2 VARCHAR(255), insurerid2 VARCHAR(255), insurance3 VARCHAR(255), insurerid3 VARCHAR(255));
grant all on feeds.nikki_patel_mdland_engagement to etluser;
