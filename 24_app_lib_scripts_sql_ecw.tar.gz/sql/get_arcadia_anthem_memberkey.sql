select distinct "member key"  from acpps_sandbox_prd01..anthem_data
