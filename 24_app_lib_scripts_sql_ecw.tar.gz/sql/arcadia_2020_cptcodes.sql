SELECT DISTINCT site_center_name, 
                /*pat_first_name, 
                pat_last_name, 
                Cast(pat_date_of_birth AS DATE)  AS dob, */
                pat_id,
                cc_cpt_code, 
                Cast(cc_date_of_service AS DATE) AS dos 
FROM   t_chargecapture 
       JOIN t_patient 
         ON cc_patient_id = pat_id 
       JOIN site_master 
         ON cc_orig_site_id = site_orig_site_id 
WHERE  cc_delete_ind = 'N' 
       AND Year(cc_date_of_service) = 2020 
       AND pat_delete_ind = 'N' 
