unload ($$
SELECT * 
FROM   (SELECT measure, 
               member_sex                               AS gender, 
               'Healthfirst Corinthian'                 AS health_plan, 
               a.member_number                          AS patient_id, 
               a.member_first_name, 
               a.member_last_name, 
               To_char(a.member_dob, 'MM/DD/YYYY')      AS member_dob, 
               member_addres_line_1 
               || ' ' 
               || member_addres_line_2                  AS member_address, 
               member_city                              AS city, 
               member_state                             AS state, 
               member_zip                               AS zip, 
               member_home_phone                        AS member_phone_number, 
               provider_npi                             AS pcp_npi, 
               provider_first_name 
               || ' ' 
               || provider_last_name                    AS pcp, 
               Row_number() 
                 OVER ( 
                   partition BY member_number, measure) AS rn 
        FROM   payor.healthfirst_all_caregaps a 
               JOIN payor.healthfirst_all_eligibility AS b 
                 ON member_number = member_id 
        WHERE  a.received_month = (SELECT Max(received_month) 
                                   FROM   payor.healthfirst_all_caregaps) 
               AND b.received_month = (SELECT Max(received_month) 
                                       FROM   payor.healthfirst_all_eligibility) 
               AND product <> 'MCR' 
               AND Length(member_number) = 8 
               AND EXISTS (SELECT 1 
                           FROM   payor.healthfirst_all_caregaps c 
                                  JOIN payor.healthfirst_all_eligibility AS d 
                                    ON member_number = member_id 
                           WHERE  a.member_number = c.member_number 
                                  AND c.received_month = '201808') 
               AND provider_npi IS NOT NULL 
               AND measure IN (SELECT mco_measure 
                               FROM   payor.measure_hedis_sf_xwalk)) AS 
       full_table 
WHERE  rn = 1 
$$ )
to 's3://sftp_test/20190122_open_gaps_hflegacy.csv'
delimiter ','
addquotes
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole';
