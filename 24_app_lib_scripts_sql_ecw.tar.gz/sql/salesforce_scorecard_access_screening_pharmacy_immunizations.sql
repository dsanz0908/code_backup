WITH cte_task_id 
     AS (SELECT id            correct_id, 
                Max(added_tz) AS correct_dt 
         FROM   (SELECT *, 
                        Row_number() 
                          OVER ( 
                            partition BY id 
                            ORDER BY added_tz DESC) AS rn 
                 FROM   salesforce_tasks) salesforce_tasks 
         GROUP  BY id), 
     cte_task_2 
     AS (SELECT pcp__c, 
                CASE 
                  WHEN subject IN ( 'Access Care Gap (2019)', 'Recall Access (2019)', 'Subset Not Access (2019)' ) THEN 1 
                  ELSE 0 
                END AS AccessCareGap_denom, 
                CASE 
                  WHEN subject IN ( 'Care Gap Screening (2019)', 'Recall Screening (2019)', 'Screening Care Gap (2019)', 'Subset Not Screening', 'xxxCare Gap Screening (2019)' ) THEN 1
                  ELSE 0 
                END AS Screenings_denom, 
                CASE 
                  WHEN subject IN ( 'Pharmacy Care Gap (2019)' ) THEN 1 
                  ELSE 0 
                END AS Pharmacy_denom, 
                CASE 
                  WHEN subject IN ( 'Immunization Care Gap (2019)', 'Recall Immunization (2019)', 'Subset Not Immunization', 'Care Gap Immunization (2019)', 'xxxImmunization Care Gap (2019)' ) THEN 1
                  ELSE 0 
                END AS Immunizations_denom, 
                CASE 
                  WHEN subject IN ( 'Access Care Gap (2019)', 'Recall Access (2019)', 'Subset Not Access (2019)' ) 
                       AND status IN ( 'Completed', 'Closed', 'Completed - Awaiting Coding Correction', 'Completed - Awaiting Claim Submission', 'Pending - Appointment Scheduled' ) THEN 1
                  ELSE 0 
                END AS Accesscaregap_numer, 
                CASE 
                  WHEN subject IN ( 'Care Gap Screening (2019)', 'Recall Screening (2019)', 'Screening Care Gap (2019)', 'Subset Not Screening', 'xxxCare Gap Screening (2019)' )
                       AND status IN ( 'Completed', 'Closed', 'Completed - Awaiting Coding Correction', 'Completed - Awaiting Claim Submission', 'Pending - Appointment Scheduled' ) THEN 1
                  ELSE 0 
                END AS screenings_numer, 
                CASE 
                  WHEN subject IN ( 'Pharmacy Care Gap (2019)' ) 
                       AND status IN ( 'Completed', 'Closed', 'Completed - Awaiting Coding Correction', 'Completed - Awaiting Claim Submission', 'Pending - Appointment Scheduled' ) THEN 1
                  ELSE 0 
                END AS pharmacy_numer, 
                CASE 
                  WHEN subject IN ( 'Immunization Care Gap (2019)', 'Recall Immunization (2019)', 'Subset Not Immunization', 'Care Gap Immunization (2019)', 'xxxImmunization Care Gap (2019)' )
                       AND status IN ( 'Completed', 'Closed', 'Completed - Awaiting Coding Correction', 'Completed - Awaiting Claim Submission', 'Pending - Appointment Scheduled' ) THEN 1
                  ELSE 0 
                END AS immunizations_numer 
         FROM   (SELECT *, 
                        Row_number() 
                          OVER ( 
                            partition BY id 
                            ORDER BY added_tz DESC) AS rn 
                 FROM   salesforce_tasks) t1 
                INNER JOIN cte_task_id t2 
                        ON t1.id = t2.correct_id 
                           AND t1.added_tz = t2.correct_dt 
         WHERE  subject LIKE '%(2019)' 
                AND rn = 1 
                AND measure__c <> 'Annual dental visit' and measure__c <> 'Non-Utilizer'
                AND isdeleted = 'FALSE') 
SELECT organization_name__c, 
       CASE 
         WHEN Sum(accesscaregap_denom) > 0 THEN Cast(Sum(accesscaregap_numer) AS FLOAT) / Cast(Sum(accesscaregap_denom) AS FLOAT)
         ELSE 0 
       END AS AccesstoCare, 
       CASE 
         WHEN Sum(screenings_denom) > 0 THEN Cast(Sum(screenings_numer) AS FLOAT) / Cast(Sum(screenings_denom) AS FLOAT)
         ELSE 0 
       END AS Screening, 
       CASE 
         WHEN Sum(pharmacy_denom) > 0 THEN Cast(Sum(pharmacy_numer) AS FLOAT) / Cast(Sum(pharmacy_denom) AS FLOAT)
         ELSE 0 
       END AS Pharmacy, 
       CASE 
         WHEN Sum(immunizations_denom) > 0 THEN Cast (Sum(immunizations_numer) AS FLOAT) / Cast(Sum(immunizations_denom) AS FLOAT)
         ELSE 0 
       END AS Immunizations 
FROM   cte_task_2 ct1 
       INNER JOIN salesforce_providers t2 
               ON ct1.pcp__c = t2.id 
GROUP  BY organization_name__c 
ORDER  BY organization_name__c
