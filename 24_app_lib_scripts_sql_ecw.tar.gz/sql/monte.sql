INSERT INTO monte_patient_list_final 
            (member_cin, 
             member_dob, 
             member_sex,
             member_last_name, 
             member_first_name, 
             member_middile_initial, 
             member_address_1, 
             member_address_2, 
             member_city, 
             member_state, 
             member_zip, 
             member_home_phone, 
             pcp_npi, 
             somos_enrollment_date, 
             output_file_name, 
             diagnosis_1)
WITH cte_all_recent_monte_data 
     AS (SELECT a.*, 
                icd10, 
                pcp_npi, 
                home_phone, 
                Row_number() 
                  OVER ( 
                    partition BY a.beneficiary_hic_number 
                    ORDER BY update_timestamp DESC) AS rn 
         FROM   nydoh.all_rosters_all_columns AS a 
                INNER JOIN (SELECT mbr_cin, 
                                   pcp_npi, 
                                   prim_dx_cd AS icd10 
                            FROM   montechronic AS a 
                            UNION 
                            SELECT mbr_cin, 
                                   pcp_npi, 
                                   dx_cd_2 
                            FROM   montechronic AS b 
                            UNION 
                            SELECT mbr_cin, 
                                   pcp_npi, 
                                   dx_cd_3 
                            FROM   montechronic AS c 
                            UNION 
                            SELECT mbr_cin, 
                                   pcp_npi, 
                                   dx_cd_4 
                            FROM   montechronic AS d) AS e 
                        ON a.beneficiary_hic_number = mbr_cin 
                LEFT OUTER JOIN arcadia.planmember AS f 
                             ON a.beneficiary_hic_number = f.medicaid_id 
         WHERE  received_month = (SELECT Max(received_month) 
                                  FROM   nydoh.all_rosters_all_columns) 
                AND pcp_npi IS NOT NULL 
                AND pcp_npi <> '' 
                AND NOT EXISTS (SELECT 1 
                                FROM   monte_patient_list_final AS b 
                                WHERE  beneficiary_hic_number = member_cin 
                                       AND output_file_name IS NOT NULL) 
                AND beneficiary_hic_number IN (SELECT mbr_id 
                                               FROM   nydoh.all_patient_alerts 
                                               WHERE  received_month = (SELECT Max(received_month)
                                                                        FROM   nydoh.all_patient_alerts))
                AND beneficiary_hic_number NOT IN (SELECT member_cin 
                                                   FROM   exclusion_list_monte) 
                AND EXISTS (SELECT * 
                            FROM   icd10codes AS f 
                            WHERE  chronic_indicator = 1 
                                   AND icd10 = icd10code)) 
SELECT TOP 500 distinct 
               beneficiary_hic_number, 
               beneficiary_date_of_birth, 
               beneficiary_sex_code, 
               LEFT(beneficiary_last_name, 50), 
               LEFT(beneficiary_first_name, 50), 
               LEFT(beneficiary_middle_name, 1), 
               LEFT(address_line_1, 50), 
               LEFT(address_line_2, 50), 
               city, 
               beneficiary_fips_state_code, 
               beneficiary_zip_code, 
               final_phone, 
               pcp_npi, 
               Getdate()::date, 
               'SomosEligibility_Batch' 
               || (SELECT DISTINCT Max(Cast(Substring(output_file_name, 23, Charindex('_', Substring(output_file_name,
                                   23))-1) AS INT)) 
                                   + 1 
                   FROM   monte_patient_list_final 
                   WHERE  output_file_name IS NOT NULL) 
               || '_' 
               || Lpad(Datepart(mon, sysdate), 2, '0') 
               || Lpad(Datepart(day, sysdate), 2, '0') 
               || Datepart(year, sysdate) 
               || '_500.txt' AS filename, 
               icd10 
FROM   (SELECT a.*, 
               CASE 
                 WHEN home_phone IS NOT NULL 
                      AND Trim(home_phone) NOT IN ( '', '0000000000', '0' ) THEN home_phone 
                 WHEN phone_number IS NOT NULL 
                      AND Trim(phone_number) NOT IN ( '', '0000000000', '0' ) THEN phone_number
                 ELSE NULL 
               END                                        AS final_phone, 
               Row_number() 
                 OVER ( 
                   partition BY pcp_npi)                  AS npi_rank, 
               Row_number() 
                 OVER ( 
                   partition BY a.beneficiary_hic_number) AS cin_rank 
        FROM   cte_all_recent_monte_data AS a 
               INNER JOIN (SELECT beneficiary_hic_number 
                           FROM   cte_all_recent_monte_data 
                           GROUP  BY beneficiary_hic_number 
                           HAVING Count(DISTINCT icd10) = 1) AS b 
                       ON a.beneficiary_hic_number = b.beneficiary_hic_number 
        WHERE  rn = 1) AS final_table 
WHERE  npi_rank <= 25 
       AND cin_rank = 1 
       AND final_phone IS NOT NULL; 


unload ($$ 
SELECT member_id, 
       member_cin, 
       member_ssn, 
       member_dob, 
       member_sex, 
       dual_eligibility, 
       member_last_name, 
       member_first_name, 
       member_middile_initial, 
       member_address_1, 
       member_address_2, 
       member_city, 
       member_state, 
       member_zip, 
       member_email, 
       health_plan, 
       member_home_phone, 
       member_cell_phone, 
       member_work_phone, 
       pcp_npi, 
       somos_enrollment_date, 
       somos_term_date 
FROM   monte_patient_list_final 
WHERE  added_tz = (SELECT Max(added_tz) 
                   FROM   monte_patient_list_final) 
$$)
to 's3://sftp_test/SomosEligibility_Batch11_02252019_500.txt'
delimiter '|'
parallel off
ALLOWOVERWRITE
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' ;



