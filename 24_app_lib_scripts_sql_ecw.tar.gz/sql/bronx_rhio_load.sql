drop table if exists staging_BxRHIO_to_ACP_11;
create temp table staging_BxRHIO_to_ACP_11 ( 
mrn VARCHAR(65535),
practice_name VARCHAR(65535),
first_name VARCHAR(65535),
last_name VARCHAR(65535),
dob VARCHAR(65535),
gender VARCHAR(65535),
provider_name VARCHAR(65535),
provider_npi VARCHAR(65535),
patient_class VARCHAR(65535),
event VARCHAR(65535),
event_datetime VARCHAR(65535),
hospital VARCHAR(65535),
originating_qe VARCHAR(65535),
cin
 VARCHAR(65535));
grant all on staging_BxRHIO_to_ACP_11 to etluser;
copy staging_BxRHIO_to_ACP_11 from 's3://acp-data/bronx_rhio/BxRHIO_to_ACP_11.02.2018.csv' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' NULL AS 'NULL' csv;
delete from public.enriched_bronx_rhio where filename = 'BxRHIO_to_ACP_11.02.2018.csv';
