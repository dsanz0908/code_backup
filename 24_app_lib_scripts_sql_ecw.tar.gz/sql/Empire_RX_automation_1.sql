SELECT CASE 
         WHEN tgt_column_name = 'received_month' THEN 'RECEIVEDMONTH' 
         WHEN tgt_column_name = 'filename' THEN Quote_literal('FILENAME') 
         WHEN tgt_data_type = 'boolean' THEN 'Case when trim(' 
                                             || src_column_name 
                                             || ') = ''Y'' then True when trim(' 
                                             || src_column_name 
                                             || ') = ''N'' then False else NULL end' 
         WHEN tgt_data_type = 'real' THEN 'Case when trim(' 
                                          || src_column_name 
                                          || ') = '''' or ' 
                                          || src_column_name 
                                          || ' like ''%-%''  then NULL else ' 
                                          || ' CAST ( REPLACE(' 
                                          || src_column_name 
                                          || ', '','','''')  AS ' 
                                          || tgt_data_type 
                                          || ' ) end ' 
         WHEN tgt_data_type = 'date' THEN 'Case when trim(' 
                                          || src_column_name 
                                          || ') = '''' or length(' 
                                          || src_column_name 
                                          || ') <> 10 then NULL else cast(' 
                                          || src_column_name 
                                          || ' AS ' 
                                          || tgt_data_type 
                                          || ' ) end' 
         WHEN tgt_data_type = 'integer' THEN 'Case when trim(' 
                                             || src_column_name 
                                             || ') = '''' or ' 
                                             || src_column_name 
                                             || ' like ''%"%'' then NULL else cast(' 
                                             || src_column_name 
                                             || ' AS ' 
                                             || tgt_data_type 
                                             || ' ) end' 
         WHEN tgt_data_type IS NULL THEN src_column_name 
       END 
       || ',' 
FROM   mco_file_to_table_mapping 
WHERE  mco_name = 'Empire_Somos' 
       AND file_type = 'pharmacy' 
ORDER  BY column_order; 
