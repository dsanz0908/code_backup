delete arcadia.PlanProduct WHERE arcadia_to_somos_filename = '2018_12_07_175949_041_013_PlanProduct_01_1.csv';
copy arcadia.PlanProduct
from 's3://acp-data/Arcadia/Incoming/2018_12_07_175949_041_013_PlanProduct_01_1.csv'
iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole'
TRIMBLANKS
MAXERROR 30
ignoreheader 1
region 'us-east-1'
dateformat 'auto'
csv;
