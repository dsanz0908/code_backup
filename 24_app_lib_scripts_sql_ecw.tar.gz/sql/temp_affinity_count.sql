select count(*) from payor.affinity_corinthian_all_rosters where period = '201912'
