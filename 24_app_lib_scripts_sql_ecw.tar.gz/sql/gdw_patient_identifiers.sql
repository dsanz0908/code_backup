select top 10000 * from gdw.patient_identifiers order by random()
