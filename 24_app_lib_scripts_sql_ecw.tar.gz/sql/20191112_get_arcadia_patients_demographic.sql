SELECT DISTINCT Lower(Concat(pat_first_name, ' ', pat_middle_name, ' ', pat_last_name)) AS NAME, 
                pat_race, 
                pat_ethnicity, 
                pat_city, 
                pat_county, 
                pat_state, 
                pat_zip, 
                pat_date_of_birth, 
                pat_address_1, 
                pat_address_2 
FROM   t_patient 
WHERE  pat_delete_ind = 'N' 
