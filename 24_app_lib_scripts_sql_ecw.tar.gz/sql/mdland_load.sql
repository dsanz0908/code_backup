create temp table if not exists staging_mdland ( 
clinicid VARCHAR(255),
clinicname VARCHAR(255),
attendingdrid VARCHAR(255),
attendingdrname VARCHAR(255),
attendingdrnpi VARCHAR(255),
patientid VARCHAR(255),
patientname VARCHAR(255),
dob VARCHAR(255),
insurance VARCHAR(255),
dos VARCHAR(255),
codetype VARCHAR(255),
code VARCHAR(255),
id
VARCHAR(255));
grant all on staging_mdland to etluser;
copy staging_mdland from 's3://acp-data/mdland/ACP Weekly Excel 01_01_2018 - 03_31_2019_TabI1_Patient_OtherCode_Part2_1.csv' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;
delete from feeds.mdland_all where filename = 'ACP Weekly Excel 01_01_2018 - 03_31_2019_TabI1_Patient_OtherCode_Part2_1.csv';
insert into feeds.mdland_all (clinicid,clinicname,attendingdrid,attendingdrname,attendingdrnpi,patientid,patientname,dob,insurance,dos,codetype,code,id, filename) select clinicid,clinicname,attendingdrid,attendingdrname,attendingdrnpi,patientid,patientname,dob,insurance,dos,codetype,code,id, 'ACP Weekly Excel 01_01_2018 - 03_31_2019_TabI1_Patient_OtherCode_Part2_1.csv' from staging_mdland;
