create temp table if not exists staging_mdland ( 
id VARCHAR(255),
clinicid VARCHAR(255),
clinicname VARCHAR(255),
patientid VARCHAR(255),
patientname VARCHAR(255),
dob VARCHAR(255),
dos VARCHAR(255),
address VARCHAR(255),
city VARCHAR(255),
state VARCHAR(255),
zipcode VARCHAR(255),
phone VARCHAR(255),
pcp VARCHAR(255),
pcp_npi VARCHAR(255),
engagementtype VARCHAR(255),
codetype VARCHAR(255),
speificcode VARCHAR(255),
group_npi VARCHAR(255),
insurance1 VARCHAR(255),
insuredid1 VARCHAR(255),
payor_id1 VARCHAR(255),
insurance2 VARCHAR(255),
insuredid2 VARCHAR(255),
payor_id2 VARCHAR(255),
insurance3 VARCHAR(255),
insuredid3 VARCHAR(255),
payor_id3 VARCHAR(255),
medicaid_card_number VARCHAR(255),
last_terminated_insuredid VARCHAR(255),
last_terminated_insurance VARCHAR(255),
last_terminated_payor_id VARCHAR(255),
last_terminated_date
VARCHAR(255));
grant all on staging_mdland to etluser;
copy staging_mdland from 's3://acp-data/mdland/ACP Yearly Excel 2017-04-01_2018-03-31 Tab1_All_Engagement_Type_Part2_4.csv' iam_role 'arn:aws:iam::042108671686:role/myRedshiftRole' TRIMBLANKS MAXERROR 40 ignoreheader 1 ACCEPTINVCHARS region 'us-east-1' dateformat 'auto' csv;
delete from feeds.mdland_all where filename = 'ACP Yearly Excel 2017-04-01_2018-03-31 Tab1_All_Engagement_Type_Part2_4.csv';
insert into feeds.mdland_encounters (id,clinicid,clinicname,patientid,patientname,dob,dos,address,city,state,zipcode,phone,pcp,pcp_npi,engagementtype,codetype,speificcode,group_npi,insurance1,insuredid1,payor_id1,insurance2,insuredid2,payor_id2,insurance3,insuredid3,payor_id3,medicaid_card_number,last_terminated_insuredid,last_terminated_insurance,last_terminated_payor_id,last_terminated_date, filename) select id,clinicid,clinicname,patientid,patientname,dob,dos,address,city,state,zipcode,phone,pcp,pcp_npi,engagementtype,codetype,speificcode,group_npi,insurance1,insuredid1,payor_id1,insurance2,insuredid2,payor_id2,insurance3,insuredid3,payor_id3,medicaid_card_number,last_terminated_insuredid,last_terminated_insurance,last_terminated_payor_id,last_terminated_date, 'ACP Yearly Excel 2017-04-01_2018-03-31 Tab1_All_Engagement_Type_Part2_4.csv' from staging_mdland;
