import sftp_utils as sftp
import argparse
import boto3
import botocore
def main():
        parser = argparse.ArgumentParser(description='SFTP push')

        parser.add_argument('src_org_id', action='store',
                        help='Unique string identifying partner sftp host')

        parser.add_argument('dest_org_id', action='store',
                        help='Unique string for sftp destination host')

        parser.add_argument('dest_path', action='store',
                        help='Path to dir in which to place files on host')

        parser.add_argument('s3_bucket', action='store',
                        help='the source bucket on s3')

        parser.add_argument('sql_database', action='store',
                        help='the sql server database where the log files are restored')

        args = parser.parse_args()

        SRC_ORG_ID = args.src_org_id
        DEST_ORG_ID = args.dest_org_id
        S3_BUCKET = args.s3_bucket
        DEST_PATH = args.dest_path
        database = args.sql_database
        PREFIX = sftp.get_s3_prefix(SRC_ORG_ID)
        DATA_DIR = '/data/tmp/'
        DATA_DIR = DATA_DIR + SRC_ORG_ID[4:]

        print (SRC_ORG_ID,DEST_ORG_ID,S3_BUCKET,DEST_PATH,database,PREFIX,DATA_DIR)
        creds = sftp.get_creds(DEST_ORG_ID)
        conn = sftp.get_conn(creds)
        conn.cwd(DEST_PATH)
	creds = sftp.get_creds(DEST_ORG_ID)
	session = boto3.session.Session()
    	s3 = session.resource('s3')
    	bucket = s3.Bucket(S3_BUCKET)

    	# Populate the already processed list from db table and/or s3
    	src_files = sftp.get_s3_files(bucket, prefix=PREFIX)

    	# Connect to host and get diff of file names and upload them to S3

    	conn = sftp.get_conn(creds)

    	conn.cwd(DEST_PATH)
    	processed = conn.listdir()
    	lowercase_processed = [files.lower() for files in processed]
    	new = [f for f in src_files if f not in processed]
    	new = sorted([f for f in new if f[:-4] not in processed])
    	new = sorted([f for f in new if f[:-3] not in lowercase_processed])
   	print "Identified {} new files not in {}:{}{}".format(len(new),
                                                        creds['host'],
                                                        DEST_PATH,new)

if __name__ == '__main__':
        main()

