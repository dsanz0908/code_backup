"""
    Retrieves creds for endpoint from credstash.
    Connects using pysftp. Discerns which files are new,
    and moves them to s3 bucket specified by CLARG.

    If configs in master sftp job yaml file specify
    other destinations for files retreived, moves
    file there.

"""

import credstash
import pysftp
import yaml
import boto3
import botocore
import argparse
import os
import paramiko
import StringIO


def get_creds(endpoint, protocol, context=None):
    """ Retreive credentials for sftp job from credstash"""

    creds = {}

    KEYS = ['org_id', 'host', 'password', 'username',
            'protocol', 'port', 'private_key']

    for key_name in KEYS:
        if key_name not in ['org_id', 'protocol']:
            key = "{}.{}.{}".format(endpoint, protocol, key_name)
            try:
                creds[key_name] = credstash.getSecret(key, region='us-east-1')
            except Exception:
                pass

    return creds


def get_s3_keys(bucket, prefix=None):
    """ Retreive keys from s3 bucket with a given prefix """
    keys = []
    for obj in bucket.objects.filter(Prefix=prefix):
        if not obj.key.endswith('/'):
            keys.append(obj.key)
    return keys


def get_job_configs(endpoint, job_config_path):
    """
        Assumes job_config_path specifies a yaml file
        with the following nested dictionary structure:
        endpoint1:
            config1: <config1_value>
            config2: <config2_value>
        endpoint2:
            config1: <config1_value>
            config2: <config2_value>
    """
    with open(job_config_path, 'r') as f:
            all_configs = yaml.load(f)
            return all_configs[endpoint]


def get_conn(creds):
    """
        Return a pysftp connection object
    """

    if 'private_key' in creds:
        key_file = StringIO.StringIO(creds['private_key'])
        pkey = paramiko.RSAKey.from_private_key(key_file)
        creds['private_key'] = pkey

    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None

    creds['cnopts'] = cnopts

    sftp = pysftp.Connection(**creds)

    return sftp


def main():

    # Command line argument parsing
    parser = argparse.ArgumentParser(description='SFTP pull')
    arggroup = parser.add_mutually_exclusive_group(required=True)

    arggroup.add_argument('--dev', action='store_true',
                          help='run dev setup')

    arggroup.add_argument('--prod', action='store_true',
                          help='run production setup')

    arggroup.add_argument('--stage', action='store_true',
                          help='run staging setup')

    parser.add_argument('endpoint', action='store',
                        help='unique string for sftp host')
    parser.add_argument('s3_bucket', action='store',
                        help='the base target bucket on s3')
    parser.add_argument('job_config', action='store',
                        help='the master job config yaml file')

    args = parser.parse_args()

    ENDPOINT = args.endpoint
    S3_BUCKET = args.s3_bucket
    CONFIGS = get_job_configs(ENDPOINT, args.job_config)

    # Can record processed files in a DB table, rather than just s3

    # if args.stage:
    #     DB_CONFIG = 'db_config_test.yaml'
    # if args.prod:
    #     DB_CONFIG = 'db_config.yaml'

    if args.dev:

        print "development environment enabled"

        try:
            session = boto3.session.Session()
        except NoAuthHandlerFound:
            AWS_ACCESS_KEY_ID = os.environ['AWS_ACCESS_KEY_ID']
            AWS_SECRET_ACCESS_KEY = os.environ['AWS_SECRET_ACCESS_KEY']
            session = boto3.session.Session(aws_access_key_id=AWS_ACCESS_KEY_ID,
                                    aws_secret_access_key=AWS_SECRET_ACCESS_KEY)

        SFTP_CONFIG = 'test_endpoint_creds.yaml'

        with open(SFTP_CONFIG, 'r') as f:
                creds = yaml.load(f)

    elif args.prod or args.stage:

        print "production environment enabled"
        session = boto3.session.Session()

        creds = get_creds(ENDPOINT, CONFIGS['protocol'])

    s3 = session.resource('s3')
    bucket = s3.Bucket(S3_BUCKET)

    # Populate the already processed list from db table and/or s3
    processed = get_s3_keys(bucket, prefix=ENDPOINT)

    # Connect to the endpoint / host
    with pysftp.Connection(creds['host'],
                           username=creds['user'],
                           password=creds['secret']) as sftp:

        """
            May need to generically navigate to host dir with files
            to retreive... or not navigate at all. These reqs may
            need to be encoded somehow in config file...
        """

        src_files = sftp.listdir()

        print src_files

        for file_name in src_files:

            if file_name not in processed:

                # Transfer new file from host
                # TODO: error check / retry / handle failure here here
                sftp.get(file_name)

                # Upload to s3 (might need to add '/' here)
                key = "{}/{}".format(ENDPOINT, file_name)
                bucket.upload_file(file_name, key)

                # if 'destination' in CONFIGS:
                #     # move the file to the appropriate destination
                #     pass

                # Delete local file
                os.remove(file_name)


if __name__ == '__main__':
    main()
