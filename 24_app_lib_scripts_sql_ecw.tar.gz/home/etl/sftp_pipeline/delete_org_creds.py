"""
    Delete all creds from credstash whose
    keys contain clarg <org_id> as substring
"""

import credstash
import argparse


"""
    Credstash API:

    def getAllSecrets(version="", region=None, table="credential-store",
                  context=None, credential=None, session=None, **kwarg

    @clean_fail
    def deleteSecrets(name, region=None, table="credential-store",
                      **kwargs):

    def listSecrets(region=None, table="credential-store", **kwargs):
"""


def delete_all_creds(org_id, context=None):
    """
        Delete all secrets whose names contain org_id
    """

    all_secrets = credstash.listSecrets(region='us-east-1')

    if all_secrets:
        names = [x['name'] for x in all_secrets if org_id in x['name']]
        for name in names:
            credstash.deleteSecrets(name, region='us-east-1')


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("org_id", help="The org_id of creds to delete")
    args = parser.parse_args()

    delete_all_creds(args.org_id)


if __name__ == '__main__':
    main()
