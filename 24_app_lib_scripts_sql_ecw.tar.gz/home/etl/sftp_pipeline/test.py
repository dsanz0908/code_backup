import pyodbc

def main():
	#conn=sql_con = pyodbc.connect('DRIVER=/opt/microsoft/msodbcsql/lib64/libmsodbcsql-11.0.so.2270.0; SERVER=arcadia-sql-02.data.acppps.org;' 'DATABASE=master;uid=dev-etl;pwd=2aUK*BSy&z295sD')
	sql_con=pyodbc.connect('DSN=arcadia_sql_02;UID=dev-etl;PWD=2aUK*BSy&z295sD')
        cursor = sql_con.execute("select @@servername")
	res=cursor.fetchall()
	print(res)

if __name__ == '__main__':
	main()
