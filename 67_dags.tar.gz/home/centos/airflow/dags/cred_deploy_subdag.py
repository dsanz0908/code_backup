"""
    Subdag that runs deploy_cred_file.py with
    a single config file path and --staging as CLARGs
"""


from airflow.models import DAG
from airflow.operators.bash_operator import BashOperator


def subdag(parent_dag_name, child_dag_name, args, path):
    dag_subdag = DAG(
        dag_id="{}.{}".format(parent_dag_name, child_dag_name),
        default_args=args,
        schedule_interval="@once")

    cmd = """
        cd /opt/sftp_pipeline
        python deploy_cred_file.py {} """.format(path)


    print cmd

    BashOperator(
        task_id = child_dag_name,
        bash_command = cmd,
        retries = 0,
        dag = dag_subdag)

    return dag_subdag
