from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2019, 04, 23),
}

dag = DAG('grab_67_backup_dag',
            default_args=default_args,
            description='Grab a backup of certain files on the *.67 server',
            schedule_interval="0 9 * * FRI",
            catchup=False)

t1 = BashOperator(
    task_id='grab_67_backup_dag',
    bash_command='/home/centos/etl_home/scripts/take_backup.sh ',
    dag=dag)

