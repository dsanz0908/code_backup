"""
    DAG that runs the engagement ETL script daily
"""

from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}


dag = DAG('salesforce_task_pull_dag',
          description='Pull task from Salesforce using the Salesforce REST API',
          default_args=default_args,
          schedule_interval="0 1,8 * * *",
          start_date=datetime(2019, 3, 5), catchup=False)


t1 = BashOperator(
    task_id = 'salesforce_task_pull_dag',
    bash_command = "/home/centos/etl_home/scripts/salesforce_task_pull.sh ",
    retries = 1,
    dag = dag)


