
"""
    Dynamically instantiates cred deploy
    subdags for sftp config files found in
    SFTP_CRED_DIR environment variable.
"""

import os
from datetime import datetime
from airflow.models import DAG
from airflow.operators.subdag_operator import SubDagOperator
from cred_deploy_subdag import subdag


DAG_NAME = 'deploy_cred_dag'

args = {
    'start_date': datetime(2017, 6, 6),
    'owner': 'airflow',
    'retries': 1,
}


dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    # schedule_interval='@hourly',
    schedule_interval='@once',
    start_date=datetime(2017, 6, 15),
    catchup=False)


CRED_DIR = os.environ.get('SFTP_CRED_DIR')

if CRED_DIR:

    for cred_file in os.listdir(CRED_DIR):

        cred_path = os.path.join(CRED_DIR, cred_file)

        SubDagOperator(
            task_id=cred_file,
            subdag=subdag(DAG_NAME, cred_file, args, cred_path),
            default_args=args,
            dag=dag
        )


