'''
    DAG to pull from ECW_NYBMPL
    and push to ACP_arcadia-sql-02
'''

from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}

dag = DAG('ecw_nybmpl_sftp_dag',
          description= 'Pull and push ECW_NYBMPL',
          default_args= default_args,
          schedule_interval= '0 2 * * *',
          start_date= datetime(2018,02,05), catchup=False)

src_org_id = 'ECW_NYBMPL'
src_path = 'NYBMPL/'
s3_bucket = 'acp-etl'

pull_cmd = """
    cd ~/sftp_pipeline/
    python pull_new.py {} {} {} """. format(src_org_id,
                                            src_path,
                                            s3_bucket)

dest_org_id = 'ACP_arcadia-sql-02_2017'
dest_path = '/E:/NYBMPL - Bukhuman Mediical'
database = 'db_nybmpl'

push_cmd = """
    cd ~/sftp_pipeline/
    python push_new.py '{}' '{}' '{}' '{}' '{}' """.format(src_org_id,
                                                           dest_org_id,
                                                           dest_path,
                                                           s3_bucket, database)

t1 = BashOperator(
    task_id= 'pull',
    bash_command= pull_cmd,
    retries=0,
    dag = dag)

t2 = BashOperator(
    task_id= 'push',
    bash_command=push_cmd,
    retries=0,
    dag = dag)

t2.set_upstream(t1)

# f = open('/home/centos/personal_log.txt','a')
# f.write('The dag ran successfully and push to Aracdia SQL Server was executed')
# f.close()
