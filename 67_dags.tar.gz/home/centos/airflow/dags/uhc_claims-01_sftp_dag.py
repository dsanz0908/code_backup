"""
    DAG to pull files from UHC_claims-01 and
    push to <TBD> on a daily basis
"""

from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}


dag = DAG('uhc_claims-01_sftp_dag',
          description='Pull and push UHC_claims-01',
          default_args=default_args,
          schedule_interval="@daily",
          start_date=datetime(2017, 7, 23), catchup=False)


# Bash commands below are not dynamic strings but
# due to number of positional args, using .format()
# to keep things tidy.

src_org_id = 'UHC_claims-01'
src_path = '/out/somos_ipa_ny/mi1'
s3_bucket = 'acp-etl'

pull_cmd = """
    cd ~/sftp_pipeline/
    python pull_new.py {} {} {} """.format(src_org_id,
                                           src_path,
                                           s3_bucket)

dest_org_id = ''
dest_path = ''

push_cmd = """
    cd ~/sftp_pipeline/
    python push_new.py '{}' '{}' '{}' '{}' """.format(src_org_id,
                                                      dest_org_id,
                                                      dest_path,
                                                      s3_bucket)

t1 = BashOperator(
    task_id='pull',
    bash_command=pull_cmd,
    retries=1,
    dag=dag)


t2 = BashOperator(
    task_id='push',
    bash_command=push_cmd,
    retries=1,
    dag=dag)

t2.set_upstream(t1)
