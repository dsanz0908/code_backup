#!/bin/bash

cd $ETL_HOME
tar -czf `date +'%Y%m%d'_24_app_lib_scripts_sql.tar.gz` applications lib sql scripts

