from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}


dag = DAG('salesforce_appointment_scheduled_dag',
          description='Update Salesforce gaps to Appointment Scheduled',
          default_args=default_args,
          schedule_interval= "0 4 * * 1",
          start_date=datetime(2019, 10, 18), catchup=True)


t1 = BashOperator(
    task_id = 'salesforce_appointment_scheduled_dag',
    bash_command = "python /home/etl/etl_home/lib/salesforce_appointment_scheduled.py ",
    retries = 0,
    dag = dag)
