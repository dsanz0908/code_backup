from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
}


dag = DAG('wellcare_somos_pull',
          description='Ingesting Wellcare Somos Elig/Claims/Rx files',
          default_args=default_args,
          schedule_interval= "0 2 * * *",
          start_date=datetime(2019, 7, 3), catchup=True)


t1 = BashOperator(
    task_id = 'wellcare_somos_pull',
    bash_command = "/home/etl/etl_home/scripts/run_wellcare_somos.sh ",
    retries = 0,
    dag = dag)
