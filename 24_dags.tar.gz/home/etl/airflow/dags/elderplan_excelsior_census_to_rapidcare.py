from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}


dag = DAG('elderplan_excelsior_census_to_rapidcare',
          description='Elderplan Excelsior census to Rapidcare',
          default_args=default_args,
          schedule_interval= "0 4 * * *",
          start_date=datetime(2019, 8, 15), catchup=True)


t1 = BashOperator(
    task_id = 'elderplan_excelsior_census_to_rapidcare',
    bash_command = "/home/etl/etl_home/scripts/elderplan_excelsior_census_to_rapidcare.sh ",
    retries = 0,
    dag = dag)
