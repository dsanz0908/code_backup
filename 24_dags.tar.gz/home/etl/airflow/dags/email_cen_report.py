from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 05, 21),
}

dag = DAG('email_cen_report', 
            default_args=default_args, 
            description='Email CEN Report',
            schedule_interval="0 8 * * 1",
            catchup=False)

t1 = BashOperator(
    task_id='email_cen_report',
    bash_command='/home/etl/etl_home/scripts/cen_report_email.sh ',
    dag=dag)
