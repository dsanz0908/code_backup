from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 05, 23),
}

dag = DAG('data_lag_report', 
            default_args=default_args, 
            description='Data Lag Report',
            schedule_interval="0 9 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='data_lag_report',
    bash_command='/home/etl/etl_home/applications/data_lag_report_start.sh ',
    dag=dag)
