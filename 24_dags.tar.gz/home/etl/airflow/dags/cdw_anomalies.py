from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 07, 11),
}

dag = DAG('cdw_anomalies', 
            default_args=default_args, 
            description='CDW ANOMALIES',
            schedule_interval="0 9 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='cdw_anomalies',
    bash_command='/home/etl/etl_home/applications/cdw_anomalies_start.sh ',
    dag=dag)
