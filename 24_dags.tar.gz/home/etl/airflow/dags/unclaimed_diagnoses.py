from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 11, 12),
}

dag = DAG('unclaimed_diagnoses', 
            default_args=default_args, 
            description='Unclaimed Diagnoses',
            schedule_interval="0 8 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='unclaimed_diagnoses',
    bash_command='/home/etl/etl_home/applications/unclaimed_diagnoses_start.sh ',
    dag=dag)
