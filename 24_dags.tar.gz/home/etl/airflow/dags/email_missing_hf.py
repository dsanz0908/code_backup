from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
}


dag = DAG('email_missing_hf',
          description='Email missing HF',
          default_args=default_args,
          schedule_interval= "0 10 15 * *",
          start_date=datetime(2020, 3, 9), catchup=False)


t1 = BashOperator(
    task_id = 'email_missing_hf',
    bash_command = "/home/etl/etl_home/scripts/email_missing_hf.sh ",
    retries = 0,
    dag = dag)
