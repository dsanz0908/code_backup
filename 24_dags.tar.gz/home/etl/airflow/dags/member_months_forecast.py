from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 07, 23),
}

dag = DAG('member_months_forecast', 
            default_args=default_args, 
            description='Member Months Forecast',
            schedule_interval="0 2 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='member_months_forecast',
    bash_command='/home/etl/etl_home/applications/member_months_forecast_start.sh ',
    dag=dag)
