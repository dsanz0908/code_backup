"""
    Varun Girish Joshi
    DAG to pull files from ECW_NYTRIC and
    push to ACP_arcadia-sql-02 daily
"""

from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}


dag = DAG('ecw_nytric_sftp_dag',
          description='Pull and push ECW_NYTRIC',
          default_args=default_args,
          schedule_interval= '0 6 * * *' ,
          start_date=datetime(2017, 11, 8), catchup=False)


src_org_id = 'ECW_NYTRIC'
src_path = 'NYTRIC/'
s3_bucket = 'acp-etl'

pull_cmd = """
    cd ~/sftp_pipeline/
    python pull_new.py {} {} {} """.format(src_org_id,
                                           src_path,
                                           s3_bucket)

dest_org_id = 'ACP_arcadia-sql-02_2017'
dest_path = '/E:/NYTRIC - Pediatrics 2000'
database = 'db_nytric'

push_cmd = """
    cd ~/sftp_pipeline/
    python push_new.py '{}' '{}' '{}' '{}' '{}' """.format(src_org_id,
                                                      dest_org_id,
                                                      dest_path,
                                                      s3_bucket,database)

t1 = BashOperator(
    task_id='pull',
    bash_command=pull_cmd,
    retries=1,
    dag=dag)

t2 = BashOperator(
    task_id='push',
    bash_command=push_cmd,
    retries=1,
    dag=dag)

t2.set_upstream(t1)
