from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 05, 23),
}

dag = DAG('dental_referral_to_salesforce', 
            default_args=default_args, 
            description='Original to Need to Process or Need to be Fixed',
            schedule_interval="0 3 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='dental_referral_to_salesforce',
    bash_command='/home/etl/etl_home/scripts/dental_referral_to_salesforce.sh ',
    dag=dag)
