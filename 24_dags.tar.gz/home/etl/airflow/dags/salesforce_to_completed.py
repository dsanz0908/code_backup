from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'execution_timeout': None,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}


dag = DAG('salesforce_to_completed_dag',
          description='Update Salesforce gaps to Completed',
          default_args=default_args,
          schedule_interval= "0 5 * * 1,3",
          start_date=datetime(2019, 10, 31), catchup=True)


t1 = BashOperator(
    task_id = 'salesforce_to_completed_dag',
    bash_command = "/home/ssundararaman/anaconda3/bin/python /home/etl/etl_home/lib/salesforce_to_completed.py ",
    retries = 0,
    dag = dag)
