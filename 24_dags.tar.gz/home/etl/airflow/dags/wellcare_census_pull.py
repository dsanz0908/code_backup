from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    # 'retry_delay': timedelta(minutes=3),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
    # 'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}


dag = DAG('wellcare_census_pull',
          description='Ingesting Wellcare Census files',
          default_args=default_args,
          schedule_interval= "0 19 * * *",
          start_date=datetime(2019, 3, 27), catchup=True)


t1 = BashOperator(
    task_id = 'wellcare_census_pull',
    bash_command = "/home/etl/etl_home/scripts/load_wellcare_census.sh ",
    retries = 0,
    dag = dag)
