from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
}


dag = DAG('pull_healthfirst',
          description='Pull missing MCO data',
          default_args=default_args,
          schedule_interval= "0 8 5-15 * *",
          start_date=datetime(2020, 3, 9), catchup=False)


t1 = BashOperator(
    task_id = 'pull_healthfirst',
    bash_command = "/home/etl/etl_home/scripts/pull_healthfirst.sh ",
    retries = 0,
    dag = dag)
