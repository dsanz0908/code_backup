from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2018, 11, 29),
    'email': ['ssundararaman@somoscommunitycare.org'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG('StatusReportAutomation', 
            default_args=default_args, 
            description='Daily Score Card Automation Report',
            schedule_interval="30 8 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='StatusReportAutomation',
    bash_command='/home/etl/etl_home/scripts/gen_status_report.sh ',
    dag=dag)
