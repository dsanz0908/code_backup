from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 05, 23),
}

dag = DAG('metadata', 
            default_args=default_args, 
            description='Metadata',
            schedule_interval="0 8 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='metadata',
    bash_command='/home/etl/etl_home/applications/metadata_start.sh ',
    dag=dag)
