from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
}


dag = DAG('arcadia_lag',
          description='Emailing the Arcadia lags',
          default_args=default_args,
          schedule_interval= "0 9 * * 1",
          start_date=datetime(2019, 8, 5), catchup=True)


t1 = BashOperator(
    task_id = 'arcadia_lag',
    bash_command = "/home/etl/etl_home/scripts/arcadia_lag.sh ",
    retries = 0,
    dag = dag)
