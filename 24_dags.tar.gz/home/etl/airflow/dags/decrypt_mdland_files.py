from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
}


dag = DAG('decrypt_mdland_files',
          description='Decrypt MDLand files and move to S3',
          default_args=default_args,
          schedule_interval= "0 2 * * *",
          start_date=datetime(2019, 8, 7), catchup=True)


t1 = BashOperator(
    task_id = 'decrypt_mdland_files',
    bash_command = "/home/etl/etl_home/scripts/decrypt_mdland_files.sh ",
    retries = 0,
    dag = dag)
