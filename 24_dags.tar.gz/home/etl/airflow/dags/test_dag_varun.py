'''
This airflow script will run
a code to show Apple stock prices every 2 mins
'''

from airflow.models import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {'owner': 'airflow',
                'start_date': datetime(2017,10,11),
                'end_date': datetime(2017,10,12),
                'email': ['vjoshi@acppps.org'],
                'email_on_retry' : True,
                'retries': 2,
                'retry_delay': timedelta(minutes=5)}

dag = DAG('test_dag_stock_price',default_args=default_args, schedule_interval="@once")

cmd = """
        cd /home/centos/analytics/scratch_varun
        python2.7 airflow_test_project.py  """

BashOperator(task_id= 'apple_stocks',
             bash_command= cmd,
             dag=dag)

print 'Implemented Bash Operator'