from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'etl',
    'depends_on_past': False,
    'start_date': datetime(2019, 05, 23),
}

dag = DAG('dental_referral_sf_upload', 
            default_args=default_args, 
            description='Need to be Processed to SF',
            schedule_interval="0 5 * * *",
            catchup=False)

t1 = BashOperator(
    task_id='dental_referral_sf_upload',
    bash_command='/home/etl/etl_home/scripts/dental_referral_sf_upload.sh ',
    dag=dag)
