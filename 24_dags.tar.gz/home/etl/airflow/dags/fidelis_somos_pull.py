from datetime import timedelta
from datetime import datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
}


dag = DAG('fidelis_somos_pull',
          description='Ingesting Fidelis Somos Elig/Claims/Rx files',
          default_args=default_args,
          schedule_interval= "0 1 * * *",
          start_date=datetime(2019, 7, 5), catchup=True)


t1 = BashOperator(
    task_id = 'fidelis_somos_pull',
    bash_command = "/home/etl/etl_home/scripts/run_missing_mco_month.sh received_month fideliscare_prod_membership_full_somos_all /home/etl/etl_home/scripts/fidelis_load.sh ",
    retries = 0,
    dag = dag)
