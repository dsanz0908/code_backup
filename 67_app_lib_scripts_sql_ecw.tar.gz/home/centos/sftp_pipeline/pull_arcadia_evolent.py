"""
    Retrieves creds and configs for host from credstash.
    Connects using pysftp. Discerns which files are new
    by diffing with <s3_bucket>, and moves them to the bucket
"""

import yaml
import boto3
import botocore
import argparse
import atexit
import pysftp
import os
import sftp_utils as sftp
import pdb

def main():

    # Command line argument parsing
    parser = argparse.ArgumentParser(description='SFTP pull')

    parser.add_argument('src_org_id', action='store',
                        help='Unique string for sftp host')

    parser.add_argument('host_path', action='store',
                        help='Path to dir with files to retreive on host')

    parser.add_argument('s3_bucket', action='store',
                        help='The base target bucket on s3')

    args = parser.parse_args()

    SRC_ORG_ID = args.src_org_id
    S3_BUCKET = args.s3_bucket
    HOST_PATH = args.host_path
    #PREFIX = sftp.get_s3_prefix(SRC_ORG_ID)
    DATA_DIR = '/data/tmp/'


    DATA_DIR = sftp.check_or_make_dir(DATA_DIR,SRC_ORG_ID)
    #pdb.set_trace()

    # CONFIGS = sftp.get_job_configs(ENDPOINT, args.job_config)

    session = boto3.session.Session()

    #pdb.set_trace()
    creds = sftp.get_creds(SRC_ORG_ID)

    s3 = session.resource('s3')
    bucket = s3.Bucket(S3_BUCKET)

    processed = sftp.get_s3_files(bucket, prefix=None)

    conn = sftp.get_conn(creds)
    conn.cwd(HOST_PATH)
    src_files = conn.listdir()

    new = [f for f in src_files if f not in processed and sftp.is_data(conn, f)]

    print "Found {} new files in {}:{}".format(len(new),
                                               creds['host'],
                                               HOST_PATH)

    # # Here we handle the case where we find no new files
    # if not new and SOME_CONFIG:
    #     raise FileNotFoundExcpetion("No new file found")

    atexit.register(sftp.clean_up, new, DATA_DIR)

    for file_name in new:

        local_path = "{}/{}".format(DATA_DIR, file_name)

        print "Transfering {} to {}".format(file_name, DATA_DIR)

        # Transfer new file from host
        #pdb.set_trace()
        conn.get(file_name, localpath=local_path)

        # # Here we can handle decryption
        # for file_name in new:
        #     decrypt(file_name, new_file_name)

        # Upload to s3
        key = "{}".format(file_name)

        print "Transfering {} to the s3 bucket {}".format(file_name,
                                                     S3_BUCKET)

        bucket.upload_file(local_path, key)
        print "Removing {} from local".format(file_name)
        os.remove(local_path)

if __name__ == '__main__':
    main()
