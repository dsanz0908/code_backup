"""
    Varun Girish Joshi

    Retrieves creds for destination endpoint from credstash.
    Connects using pysftp. Discerns which files in s3 are new,
    and moves them to destination server.
    These files are restored in the SQL Server using restore commands.

"""

# importing all the required modules


import yaml
from collections import OrderedDict
import boto3
import botocore
import argparse
import pysftp
import os
import atexit
import sftp_utils as sftp
import pdb
import zipfile
import shutil
import pyodbc
import pull_new as pull
import datetime
import logging
import glob

logging.raiseExceptions = False


# Accomodatating all the arguments required to the restore the log files in their respective practices

def main():
    # Command line argument parsing
    parser = argparse.ArgumentParser(description='SFTP push')

    parser.add_argument('src_org_id', action='store',
                        help='Unique string identifying partner sftp host')

    parser.add_argument('dest_org_id', action='store',
                        help='Unique string for sftp destination host')

    parser.add_argument('dest_path', action='store',
                        help='Path to dir in which to place files on host')

    parser.add_argument('s3_bucket', action='store',
                        help='the source bucket on s3')

    parser.add_argument('sql_database', action='store',
                        help='the sql server database where the log files are restored')

    args = parser.parse_args()

    SRC_ORG_ID = args.src_org_id
    DEST_ORG_ID = args.dest_org_id
    S3_BUCKET = args.s3_bucket
    DEST_PATH = args.dest_path
    database = args.sql_database
    PREFIX = sftp.get_s3_prefix(SRC_ORG_ID)
    DATA_DIR = '/data/tmp/'
    DATA_DIR = DATA_DIR + SRC_ORG_ID[4:]

    # CONFIGS = get_job_configs(ENDPOINT, args.job_config)

    session = boto3.session.Session()

    # Getting credentials from credstash to log in to the Arcadia SQL Server 02 is setup and creating S3 bucket connection
    creds = sftp.get_creds(DEST_ORG_ID)

    s3 = session.resource('s3')
    bucket = s3.Bucket(S3_BUCKET)

    # Populate the already processed list from db table and/or s3
    src_files = sftp.get_s3_files(bucket, prefix=PREFIX)

    # Connect to host and get diff of file names and upload them to S3

    conn = sftp.get_conn(creds)
    #pdb.set_trace()
    conn.cwd(DEST_PATH)
    processed = conn.listdir()
    lowercase_processed = [files.lower() for files in processed]
    new = [f for f in src_files if f not in processed]
    new = sorted([f for f in new if f[:-4] not in processed])
    new = sorted([f for f in new if f[:-3] not in lowercase_processed])
    print "Identified {} new files not in {}:{}".format(len(new),
                                                        creds['host'],
                                                        DEST_PATH)

    atexit.register(sftp.clean_up, new, DATA_DIR)

    ALREADY_EXISTS_QUERY = """
    SELECT 1
    FROM   msdb.dbo.backupset s
           INNER JOIN msdb.dbo.backupmediafamily m
                   ON s.media_set_id = m.media_set_id
    WHERE  s.database_name = '{}'
           AND physical_device_name LIKE '%{}%'
    """

    # Skip the large 7z backup file and process the zip file
    for file_name in new:

        if file_name.endswith('.7z'):
            pass

        elif file_name.endswith('.zip'):

            # pull the latest folder/zip files which were most recently restored
            list_of_files = glob.glob(DATA_DIR + '/*')
            latest_file = max(list_of_files, key=os.path.getctime)


            # copy the file from S3 to the local machine and extract it.
            local_path = "{}/{}".format(DATA_DIR, file_name)
            print "Transfering {} to {}".format(file_name, DATA_DIR)
            key = "{}{}".format(PREFIX, file_name)
            bucket.download_file(key, local_path)
            print "Extracting the files at {}".format(DATA_DIR)
            extracted, result = sftp.extract_files(local_path)
            list_log_file = DATA_DIR + '/' + file_name[:-4] + ".txt"
            list_log = open(list_log_file, "w")

            # Create a folder in at the destination (Arcadia SQL 02)
            remote_dest_dir = DEST_PATH + '/' + file_name[:-4]
            create_folder = file_name[:-4]
            conn.mkdir(create_folder)
            if DEST_ORG_ID == 'ACP_arcadia-sql-02':
                sql_con = pyodbc.connect('DSN=arcadia_sql_02;UID=dev-etl;PWD=2aUK*BSy&z295sD')
            elif DEST_ORG_ID == 'ACP_arcadia-sql-02_2016':
                sql_con = pyodbc.connect('DSN=arcadia_sql_02_2016;UID=dev-etl;PWD=2aUK*BSy&z295sD')
            elif DEST_ORG_ID == 'ACP_arcadia-sql-02_2017':
                sql_con = pyodbc.connect('DSN=arcadia_sql_02_2017;UID=dev-etl;PWD=2aUK*BSy&z295sD')
            sql_con.autocommit = True
            cursor = sql_con.cursor()
            try:
                # Move all the files to the folder created at Arcadia SQL 02
                conn.put_d(extracted, create_folder)
                print "Removing {} from local".format(file_name)
                os.remove(local_path)
                shutil.rmtree(extracted)
                con = sftp.get_conn(creds)
                con.cwd(remote_dest_dir)

                #Sort all the log files according to their log sequence number
                log_files = sorted(con.listdir())
                temp_dict = {}
                for log in log_files:
                    sql_disk_path = 'E:\\' + DEST_PATH[4:] + '\\' + file_name[:-4] + '\\' + log
                    restore_headeronly_cmd = "restore headeronly from disk = '{}' ".format(sql_disk_path)
                    cursor.execute(restore_headeronly_cmd)
                    rows = cursor.fetchall()
                    print log
                    for row in rows:
                        print row.FirstLSN, row.LastLSN, row.CheckpointLSN
                        lsn = int(row.FirstLSN)
                        temp_dict[lsn] = log
                sorted_dict = OrderedDict(sorted(temp_dict.items()))

                # Restore these log files in their resepective databases
                for files in sorted_dict.values():

                    # disk paths and restore commands
                    new_sql_disk_path = 'E:\\' + DEST_PATH[4:] + '\\' + file_name[:-4] + '\\' + files
                    sql_standby_path = 'L:\\STANDBY\\' + SRC_ORG_ID[4:] + '\\' + files[:-4] + '.bak'
                    restore_sql_cmd = """
                    USE [master]
                    ALTER DATABASE {0}
                    SET single_user WITH
                    ROLLBACK immediate;
                    RESTORE log [{0}] FROM DISK = N'{1}' WITH FILE = 1, standby = N'{2}', nounload,
                    stats = 10;
                    ALTER DATABASE {0}
                    SET multi_user;
                    """.format(database, new_sql_disk_path, sql_standby_path)

                    cursor.execute(ALREADY_EXISTS_QUERY.format(database,files))
                    if cursor.fetchall():
                        con.remove(files)
                    else:
                        cursor.execute(restore_sql_cmd)
                        while cursor.nextset():
                            pass
                        print files + ' file ' + 'restored in ' + database
                        con.put(list_log_file, remote_dest_dir + '/' + file_name[:-4] + '.txt')
                        con.remove(files)
                cursor.close()
                del cursor
                sql_con.close()

            # for any exceptions, the recently created folder and the files inside it will be deleted and error will be raised
            except Exception as e:
                conn.cwd(remote_dest_dir)
                delete_list = conn.listdir(remote_dest_dir)
                for i in delete_list:
                    conn.remove(i)
                conn.cwd(DEST_PATH)
                conn.rmdir(create_folder)
                cursor.close()
                del cursor
                sql_con.close()
                raise e


if __name__ == '__main__':
    main()

