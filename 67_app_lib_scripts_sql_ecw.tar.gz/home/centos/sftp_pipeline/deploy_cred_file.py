"""
    Deploy a set of sftp configs to credstash

    TODO: add CLARG for dev / prod credstash context

    (to be called by the DAG)
"""

import credstash
import yaml
import argparse
import os

"""
    Credstash API:

    def putSecret(name, secret, version="", kms_key="alias/credstash",
                  region=None, table="credential-store", context=None,
                  digest=DEFAULT_DIGEST, **kwargs):
"""


def deploy(creds, context=None):

    KEYS = ['org_id', 'host', 'password',
        'username', 'protocol', 'port', 'private_key']

    # Confirm creds contain required field names
    for key_name in KEYS:
        if key_name not in ['password', 'private_key', 'port']:
            if key_name not in creds:
                msg = "{} field is missing".format(key_name)
                raise ValueError(msg)

    if ('password' not in creds and 'private_key' not in creds):
        msg = "password or private_key fields missing"
        raise ValueError(msg)

    # Deploy creds, filtering by KEYS
    for key in creds.keys():
        if (key not in ['org_id', 'protocol'] and key in KEYS):
            name = "{}.{}.{}".format(creds['org_id'], 'sftp', key)
            credstash.putSecret(name, str(creds[key]), region='us-east-1')


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("sftp_config_path",
                        help="Absolute path to yaml file configuring sftp job")

    args = parser.parse_args()

    CONFIG_FILE = args.sftp_config_path

    with open(CONFIG_FILE, 'r') as f:

        configs = yaml.load(f)

        deploy(configs)

    os.remove(CONFIG_FILE)


if __name__ == '__main__':
    main()