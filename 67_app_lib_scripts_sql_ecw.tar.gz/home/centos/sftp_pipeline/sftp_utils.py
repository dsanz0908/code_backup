"""
    Utility functions for sftp jobs
"""

import credstash
import pysftp
import yaml
import os
import paramiko
import StringIO
import zipfile
import pyodbc
from collections import OrderedDict
import pdb


def get_creds(endpoint, protocol='sftp', context=None):
    """
        Retreive credentials for sftp job from credstash
    """

    creds = {}

    KEYS = ['org_id', 'host', 'password', 'username',
            'protocol', 'port', 'private_key']

    for key_name in KEYS:
        if key_name not in ['org_id', 'protocol']:
            key = "{}.{}.{}".format(endpoint, protocol, key_name)
            try:
                creds[key_name] = credstash.getSecret(key, region='us-east-1')
            except Exception:
                pass

    if 'port' in creds:
        creds['port'] = int(creds['port'])

    return creds


def get_s3_keys(bucket, prefix=''):
    """
        Retreive keys from s3 bucket with a given prefix
    """

    keys = []
    for obj in bucket.objects.filter(Prefix=prefix):
        if not obj.key.endswith('/'):
            keys.append(obj.key)

    return keys


def get_s3_files(bucket, prefix=''):
    """
        Retrieve keys and parse for filenames already on s3
    """

    keys = get_s3_keys(bucket, prefix=prefix)

    return [key.split('/')[-1] for key in keys]


def get_job_configs(endpoint, job_config_path):
    """
        Assumes job_config_path specifies a yaml file
        with the following nested dictionary structure:
        endpoint1:
            config1: <config1_value>
            config2: <config2_value>
        endpoint2:
            config1: <config1_value>
            config2: <config2_value>
    """

    with open(job_config_path, 'r') as f:
            all_configs = yaml.load(f)
            return all_configs[endpoint]


def get_conn(creds):
    """
        Return a pysftp connection object
    """

    if 'private_key' in creds:
        key_file = StringIO.StringIO(creds['private_key'])
        pkey = paramiko.RSAKey.from_private_key(key_file)
        creds['private_key'] = pkey

    sftp = pysftp.Connection(**creds)

    return sftp


def clean_up(filenames, data_dir=None):
    """
        Delete files in pwd or data_dir with names
        matching those in <filenames>
    """

    if data_dir:
        to_remove = ["{}/{}".format(data_dir, f) for f in filenames]
    else:
        to_remove = filenames
    
    for path in to_remove:
        if os.path.isfile(path):
            os.remove(path)

    return


def get_s3_prefix(org_id):
    """
        Parse org_id and return an s3 prefix.

        Assumes org_id follows the following convention:

        <vendor>_<jobname>
    """

    as_list = org_id.split('_')

    if len(as_list) != 2:
        raise ValueError("Endpoint id is not properly formatted")

    return '{}/{}/'.format(as_list[0], as_list[1])


def is_data(conn, filename):
    """
        Boolean function for avoiding pulling .* files and dirs
        from sftp host
    """

    if filename.startswith('.') or conn.isdir(filename):
        return False

    # if not filename.endswith('.zip'):
    #     return False

    return True

def extract_files(local_path):

        if local_path.endswith('.zip'):
            zip_file = zipfile.ZipFile(local_path, 'r', allowZip64 = True)
            extracted = local_path[:-4]
            return extracted, zip_file.extractall(extracted)

        else:
            return

def lsn_sort(log):

    temp_dict = {}
    sql_disk_path = 'E:\\' + DEST_PATH[4:] + '\\'+ file_name[:-4] + '\\' + log
    restore_headeronly_cmd = "restore headeronly from disk = '{}' ".format(sql_disk_path)
    cursor.execute(restore_headeronly_cmd)
    rows = cursor.fetchall()
    print log
    for row in rows:
        print row.FirstLSN, row.LastLSN, row.CheckpointLSN
        lsn = int(row.FirstLSN)
        temp_dict[lsn] = log
    sorted_dict = OrderedDict(sorted(temp_dict.items()))
    sorted_logs = sorted_dict.values()
    return sorted_logs

def check_or_make_dir(DATA_DIR,SRC_ORG_ID):
    if os.path.exists(DATA_DIR +  '/' + SRC_ORG_ID[4:]):
        pass
    else:
        os.mkdir(DATA_DIR + SRC_ORG_ID[4:])
    new_dir = DATA_DIR + '/' + SRC_ORG_ID[4:]
    return new_dir





